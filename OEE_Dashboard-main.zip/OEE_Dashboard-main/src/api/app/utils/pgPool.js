const pg = require('pg')
const dotenv = require('dotenv')
const path = require('path')
const fs = require('fs')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

const dbConfig = require('../config/db.config.js')

class PgPool {
  // Do not change the order of database and user
  constructor ({
    database = null,
    user = null,
    password = null,
    host = null,
    port = null
  } = {}
  ) {
    const defaults = {
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000
    }

    this._settings = {
      ...defaults,
      ...(user !== null ? { user } : { user: dbConfig.USER }),
      ...(host !== null ? { host } : { host: dbConfig.HOST }),
      ...(database !== null ? { database } : { database: dbConfig.DATABASE }),
      ...(password !== null ? { password } : { password: dbConfig.PASSWORD }),
      ...(port !== null ? { port } : { port: dbConfig.PORT })
    }

    console.log('Starting a new PgPool instance', this._settings)
    this._pool = new pg.Pool(this._settings)
  }

  async getDatabase () {
    let database = null
    let client = null
    try {
      client = await this._pool.connect()
      database = client.database
      return database
    } catch (err) {
      console.error('Error acquiring client', err.stack)
    } finally {
      if (client) {
        client.release()
      }
    }
  }

  async getClient () {
    try {
      const client = await this._pool.connect()
      console.log('Connected to PostgreSQL')
      return client
    } catch (err) {
      console.error('Error acquiring client', err.stack)
    }
  }

  async loadSQLFile (filePath) {
    try {
      const sql = fs.readFileSync(filePath, 'utf8')
      const client = await this.getClient()
      try {
        await client.query(sql)
        console.log('SQL function loaded successfully')
      } finally {
        client.release()
      }
    } catch (err) {
      console.error('Error loading SQL file', err)
    }
  }

  async executeTransaction (callback) {
    const client = await this.getClient()
    try {
      await client.query('BEGIN')
      await callback(client)
      await client.query('COMMIT')
    } catch (error) {
      await client.query('ROLLBACK')
      console.error('Transaction error:', error)
      throw error
    } finally {
      client.release()
    }
  }

  async startTransaction () {
    const client = await this.getClient()
    await client.query('BEGIN')
    return client
  }

  async commitTransaction (client) {
    await client.query('COMMIT')
    client.release()
  }

  async rollbackTransaction (client) {
    await client.query('ROLLBACK')
    client.release()
  }

  async findByPrimaryKey (tableName, key, value, schemaName = 'public') {
    const client = await this.getClient()
    try {
      console.log('Executing query on database:', client.database)
      // Construct the query string with the correct column name
      const query = `SELECT * FROM
        "getTable"($1::varchar, $2::varchar, $3::varchar, $4::varchar)
        AS t(${key} VARCHAR);`

      const res = await client.query(query, [tableName, key, value, schemaName])
      return { row: res.rows[0], rowCount: res.rowCount }
    } catch (err) {
      console.error('Error executing query', err.stack)
      throw err
    } finally {
      client.release()
    }
  }

  async createTable (tableName, schemaName = null) {
    const client = await this.getClient()
    try {
      const tFileName = `create${tableName}Table.sql`
      const tName = `create${tableName}Table`
      const tschemaName = (schemaName == null) ? 'public' : schemaName

      const sqlFilePath = path.join(__dirname, '..', '..', '..', 'api', 'app', 'sql', 'tables', tFileName)
      await this.loadSQLFile(sqlFilePath)

      const query = `SELECT public.${tName}($1::varchar);`
      console.log('Query: ', query)
      console.log('schemaName: ', tschemaName)
      await client.query(query, [tschemaName])

      console.log(`Table ${tableName} created successfully`)
    } catch (error) {
      console.error(`Error creating table ${tableName}:`, error)
    } finally {
      client.release()
    }
  }
}

class PgPools {
  static _instance = null
  static _dbName = null

  constructor () {
    if (PgPools._instance) {
      throw new Error('Use PgPools.getInstance() to get the single instance of PgPools')
    }

    this.pools = new Map()
    PgPools._instance = this
  }

  async initialize (
    database = null,
    user = null,
    host = null,
    password = null,
    port = null
  ) {
    const pgp = new PgPool({
      database,
      user,
      password,
      host,
      port
    })
    const databaseName = await pgp.getDatabase()
    PgPools._dbName = databaseName
    this.pools.set(databaseName, pgp)
  }

  static async getInstance () {
    if (!PgPools._instance) {
      PgPools._instance = new PgPools()
      await PgPools._instance.initialize()
    }
    return PgPools._instance
  }

  getPool (key = null) {
    if (key == null) {
      key = PgPools._dbName
    }
    return this.pools.get(key)
  }

  // async addPool (key, pool = null) {
  //   if (!key) {
  //     console.error('Please enter a valid key')
  //     return
  //   }
  //   if (pool == null) {
  //     if (!this.getPool(key)) {
  //       const pgp = new PgPool(key)
  //       const databaseName = await pgp.getDatabase()
  //       this.pools.set(databaseName, pgp)
  //     }
  //   } else {
  //     this.pools.set(key, pool)
  //   }
  // }

  async addPool (key, config = null) {
    if (!key) {
      console.error('Please enter a valid key')
      return
    }
    if (config == null) {
      if (!this.getPool(key)) {
        const pgp = new PgPool({ database: key })
        const databaseName = await pgp.getDatabase()
        this.pools.set(databaseName, pgp)
      }
    } else {
      const pgp = new PgPool(config)
      const databaseName = await pgp.getDatabase()
      this.pools.set(databaseName, pgp)
    }
  }

  async findByPrimaryKey (dbName, tableName, key, value) {
    const pool = this.getPool(dbName)
    if (!pool) {
      throw new Error(`Pool for database ${dbName} not found`)
    }
    const Db = await pool.getDatabase()
    console.log(' The database is = ', Db)
    const res = await pool.findByPrimaryKey(tableName, key, value)
    return res
  }
}

module.exports = {
  PgPools
}
