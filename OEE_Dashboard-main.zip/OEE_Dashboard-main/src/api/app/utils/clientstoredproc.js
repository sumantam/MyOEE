const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

// Function to execute the SQL file
const executeClientSqlFile = async (schemaName) => {
  console.log('################## Called stored proc ####################')
  let pgPoolsInstance = null
  try {
    pgPoolsInstance = await PgPools.getInstance()
    const result003 = await pgPoolsInstance.getPool(dbConfig.DB).createTable('Model', schemaName)

    console.log('SQL file executed successfully:')
    return result003
  } catch (error) {
    console.error('Error executing SQL file:', error)
    return false
  }
}

// Usage example
module.exports = {
  executeClientSqlFile
}
