const firebase = require('../../utils/firebase')
const sequelize = require('../../utils/database')
const { Op } = require('sequelize')
const FDW = require('../../utils/FDW')
const { PgPools } = require('../../utils/pgPool')
const { Model } = require('../../models/Model')
const dbConfig = require('../../config/db.config')
const ClientStoredProc = require('../../utils/clientstoredproc')

// ####################################################
// Create a new DataBase by Super Admin
exports.createAuxDB = async (req, res) => {
  const data = req.body.data
  const remoteHost = data.remote_host
  const portNumber = data.port_number
  const remoteDb = data.remote_db
  const remoteServer = data.remote_server
  const user = data.user

  console.log('Creating Auxilliary DataBase')

  try {
    // create the foreign data wrapper of a database
    // const status = await FDW.createFDW(remote_host,port_number,remote_db,remote_server);
    const status = await FDW.createFDWDatabase(remoteDb, user)
    res.status(200).send('Foreign DataBase for Data Wrapper created successfully')
  } catch (error) {
    console.error('Error in creating Foreign Data Wrapper', error.message)
    res.status(500).send(error.message)
  };
}

// ####################################################
// Create Foreign Data Wrapper by Super Admin
exports.createFDW = async (req, res) => {
  const data = req.body.data
  const remoteHost = data.remote_host
  const portNumber = data.port_number
  const remoteDb = data.remote_db
  const remoteServer = data.remote_server
  const remoteUser = data.user

  console.log('Creating Foreign Data Wrapper')

  try {
    // create the foreign data wrapper of a database
    // const status = await FDW.createFDW(remote_host,port_number,remote_db,remote_server);

    const status = await FDW.createFDW(
      remoteUser,
      remoteHost,
      portNumber,
      remoteDb,
      remoteServer
    )

    res.status(200).send('Result of creating foreign data wrapper = ' + status)
  } catch (error) {
    console.error('Error in creating Foreign Data Wrapper', error.message)
    res.status(500).send(error.message)
  };
}

// ####################################################
// Create Client Tables
exports.createClientTables = async (req, res) => {
  const data = req.body.data
  const schemaName = data.schemaName
  // 'host=localhost port=5432 dbname=resonance_db10 user=dbUser1 password=passdbUser1'

  console.log('Creating New Tables')

  try {
    const status = await ClientStoredProc.executeClientSqlFile(schemaName)

    res.status(200).send('Result of creating Client Tables = ' + status)
  } catch (error) {
    console.error('Error in creating Client Tables', error.message)
    res.status(500).send(error.message)
  };
}


// exports.createModels = async (req, res) => {
//   const data = req.body.data
//   const { database, modelName, modelId = null, modelDataFile = null } = data
//   try {
//     const modelData = {
//       modelId,
//       modelName,
//       modelDataFile
//     }

//     // Test the database exists
//     let client = await PgPools.getPool().getClient()
//     const query = 'SELECT 1 FROM pg_database WHERE datname = $1;'
//     const result = await client.query(query, [database])
//     client.release(true)

//     if (result.rowCount > 0) {
//       // Test or create the Model Table
//       await PgPools.getPool(database).createTable('Model')
//       client = await PgPools.getPool(database).getClient()
//       const designModel = new Model()
//       const status = designModel.createModel(modelData, client)
//       client.release(true)
//       res.status(200).send('Result of creating Models = ' + status)
//     } else {
//       console.error('Error: Database is not present')
//       res.status(500).send('Database does not exist')
//     }
//   } catch (error) {
//     console.error('Error in creating Models', error.message)
//     res.status(500).send(error.message)
//   }
// }

exports.createModels = async (req, res) => {
  const data = req.body.data
  const { schemaName, database, modelName, modelId = null, modelDataFile = null } = data
  try {
    const modelData = {
      modelId,
      modelName,
      modelDataFile
    }

    // Test the database exists
    let client = await PgPools.getPool().getClient()
    const query = 'SELECT 1 FROM pg_database WHERE datname = $1;'
    const result = await client.query(query, [database])
    client.release(true)

    if (result.rowCount > 0) {
      // Test or create the Model Table
      await PgPools.getPool(dbConfig.DB).createTable('Model', schemaName)

      client = await PgPools.getPool(dbConfig.DB).getClient()
      const designModel = new Model()
      const status = designModel.createModel(modelData, schemaName)
      client.release(true)
      res.status(200).send('Result of creating Models = ' + status)
    } else {
      console.error('Error: Database is not present')
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating Models', error.message)
    res.status(500).send(error.message)
  }
}

exports.createLocations = async (req, res) => {

}
