const firebase = require('../utils/firebase')
const { User } = require('../models/User')
const { Relation } = require('../models/Relation')
const sequelize = require('../utils/database')
const { Op } = require('sequelize')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

// async function performTransaction() {
//   try {
//     await pgPool.executeTransaction(async (client) => {
//       await client.query('INSERT INTO users(name) VALUES($1)', ['Alice']);
//       await client.query('INSERT INTO orders(user_id, product) VALUES($1, $2)', [1, 'Laptop']);
//       // Add more queries as needed
//     });
//     console.log('Transaction completed successfully');
//   } catch (error) {
//     console.error('Transaction failed:', error);
//   }
// }

// ###############################################
// Get all users info
exports.findAll = (req, res) => {
  // save user in database
  User.findAll()
    .then((data) => {
      res.send(data)
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || 'Some error occurred while creating the User.'
      })
    })
}

// ###############################################
// find by primary Key
exports.findOne = (req, res) => {
  const email = req.params.email
  // console.log(username)
  // save user in database
  User.findByPk(email)
    .then((data) => {
      console.log('findOne called')
      if (data) {
        res.status(200).send(data)
      } else {
        res.status(404).send({ error_msg: 'Data Not Found' })
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || 'Some error occurred while creating the User.'
      })
    })
}

// ####################################################
// Delete by user email
exports.removeUser = async (req, res) => {
  const email = req.params.email
  console.log(`Deleting user: ${email}`)
  try {
    // deleting from database
    await User.destroy({ where: { email } })
    const userRecord = await firebase.auth().getUserByEmail(email)
    // deleting from firebase
    await firebase.auth().deleteUser(userRecord.uid)
    res.status(200).send(`user ${email} removed successfuly`)
  } catch (error) {
    console.error('Error in deleting the user:', error.message)
    res.status(500).send(error.message)
  };
}

// #########################################################
// get all matched substring usernames
exports.searchUser = (req, res) => {
  const { q } = req.query
  console.log(q)

  User.findAll({
    where: {
      email: {
        [Op.iLike]: `%${q}%`
      }
    }
  })
    .then((data) => {
      // console.log(data)
      res.status(200).send(data)
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || 'Some error occurred while removing the User.'
      })
    })
}

// #######################################################################
// get all matched substring usernames
exports.getUserByResponsibility = (req, res) => {
  const { q } = req.query
  console.log(q)

  User.findAll({
    where: { responsibility: q }
  })
    .then((data) => {
      // console.log(data)
      res.status(200).send(data)
    })
    .catch((err) => {
      console.log('Error with responsibility')
      res.status(500).send({
        message: err.message || 'Some error occurred while getting the User by responsibility.'
      })
    })
}

// ##############################################################

// create user
// may require some modification similar to createDefaultAdmin
exports.create = async (req, res) => {
  console.log(req.body.data)

  // storing the image here maybe need to use the file handling multer here.
  const img = req.body.data.img

  // extracting users basic details
  const user = {
    email: req.body.data.basic.email,
    name: req.body.data.basic.name,
    role: req.body.data.basic.role,
    responsibility: req.body.data.basic.responsibility,
    designation: req.body.data.basic.designation,
    countryCode: req.body.data.basic.countryCode,
    mobileNumber: req.body.data.basic.mobileNumber,
    img,
    location: req.body.data.basic.location
  }
  // validate required data here

  // extracting the relations
  const relations = []
  const mgrList = req.body.data.relation.mgrList
  const reporteeList = req.body.data.relation.reporteeList

  // Traversing through the manager list and establishing the user-manager relation
  for (let i = 0; i < mgrList.length; i++) {
    mgrEmail = mgrList[i].email
    relations.push({ userEmail: user.email, managerEmail: mgrEmail })
  }

  for (let i = 0; i < reporteeList.length; i++) {
    reporteeEmail = reporteeList[i].email
    relations.push({ userEmail: reporteeEmail, managerEmail: user.email })
  }
  let transaction
  try {
    const email = user.email
    const password = req.body.data.basic.password
    // const userFoundFB = false;
    // const userFoundDB = false;
    let userNotFoundFB
    let userNotFoundDB
    try {
      const userRecord = await firebase.auth().getUserByEmail(email)
      console.log('User Exists')
      userNotFoundFB = false
    } catch (error) {
      userNotFoundFB = true
      if (error.code === 'auth/user-not-found') {
        const Result = await User.findByPk(user.email)
        if (Result === null) {
          userNotFoundDB = true
        } else {
          userNotFoundDB = false
        }
      }
    }

    if (userNotFoundDB && userNotFoundFB) {
      transaction = await sequelize.transaction()
      const userRecord = await firebase.auth().createUser({
        email,
        password
      })

      const data = await User.create(user, { omitNull: false, transaction })
      console.log('user added to the database')
      const result = await Relation.bulkCreate(relations, { omitNull: false, transaction })
      console.log('Relation added to the database')

      // Its the part of code of old notification config concept, keept if required just incase
      // console.log("Users responsibility:",req.body.data.basic.responsibility);
      // if (req.body.data.basic.responsibility=="Executive"){
      //   await NotificationConfig.create(defaultExecutive, { omitNull: false,transaction});
      //   console.log("No Executive")
      // }else if(req.body.data.basic.responsibility=="Supervisor"){
      //   await NotificationConfig.create(defaultSupervisor, { omitNull: false,transaction});
      //   console.log("No Supervisor")
      // }else if(req.body.data.basic.responsibility=="Operator"){
      //   await NotificationConfig.create(defaultOperator, { omitNull: false,transaction});
      //   console.log("Operator")
      // }else{
      //   console.log("No match")
      // }
      await transaction.commit()
      res.status(201).send('User created successfully')
    } else {
      res.status(202).send('User already exist')
    }
  } catch (error) {
    if (transaction) {
      await transaction.rollback()
      const userRecord = await firebase.auth().getUserByEmail(user.email)
      await firebase.auth().deleteUser(userRecord.uid)
    }
    console.log(error)
    res.status(500).send('Some error occured')
  }
}

// Create Default Admin
exports.createDefaultAdmin = async (email = null, schema = 'public') => {
  // defining default admin details
  const user = {
    email: (email == null) ? 'admin@resonance.com' : email,
    name: 'Admin',
    role: 'Admin',
    responsibility: 'Supervisor',
    designation: 'Admin',
    countryCode: '91',
    mobileNumber: '9999999999',
    img: '',
    location: 'India'
  }

  // Keeping relations field empty
  const relations = []

  // Starting the traansaction
  try {
    const email = user.email
    const password = 'admin123'
    let userNotFoundDB

    const pgPoolsInstance = await PgPools.getInstance()
    const Result = await pgPoolsInstance.findByPrimaryKey(dbConfig.DB, 'Users', 'email', user.email, schema) // TODO: make this an object

    if (Result.rowCount === 0) {
      userNotFoundDB = true
    } else {
      userNotFoundDB = false
    }

    // if admin is not present in firebas & also in database then add admin to both the places
    // else if admin is not present in firebas then add in firebase only
    // else if admin is not present in database then add in database only
    // else present in both the places then dont add the admin
    if (userNotFoundDB) {
      const transaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
      try {
        const userModel = new User(schema)
        await userModel.create(user, transaction)
        console.log('Admin added to the database')
        const userRelation = new Relation(schema)
        await userRelation.bulkCreate(relations, transaction)
        console.log('Relation added to the database')
        // Commit the transaction
        await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
      } catch (error) {
        console.error('Error inserting user:', error)
        // Rollback the transaction in case of error
        await pgPoolsInstance.getPool(dbConfig.DB).rollbackTransaction(transaction)
      }
    } else {
      console.log('Default Admin Exists')
    }
  } catch (error) {
    console.log('error:', error)
  }
}

exports.createClientAdmin = async (req, res) => {
  const data = req.body.data
  const email = data.email
  const schema = data.schema
  try {
    await exports.createDefaultAdmin(email, schema)
    res.status(200).send(`Successfully created Admin for ${schema}`)
  } catch (error) {
    console.log('Error in createClientAdmin ', error)
    res.status(500).send(`Some error occured while creating Default Admin for  ${email}`)
  }
}

// Update user by email
exports.updateUser = async (req, res) => {
  const email = req.params.email
  console.log(email)
  const img = req.body.data.img
  const user = {
    email: req.body.data.basic.email,
    name: req.body.data.basic.name,
    role: req.body.data.basic.role,
    responsibility: req.body.data.basic.responsibility,
    designation: req.body.data.basic.designation,
    countryCode: req.body.data.basic.countryCode,
    mobileNumber: req.body.data.basic.mobileNumber,
    // img: img,
    location: req.body.data.basic.location
    // currentEquipmentType: null,
    // currentEquipment: null,
  }
  const relations = []
  const mgrList = req.body.data.relation.mgrList
  const reporteeList = req.body.data.relation.reporteeList

  // Traversing through the manager list and establishing the user-manager relation
  for (let i = 0; i < mgrList.length; i++) {
    mgrEmail = mgrList[i].email
    relations.push({ userEmail: user.email, managerEmail: mgrEmail })
  }

  // Traversing through the reportee list and establishing the user-manager relation
  for (let i = 0; i < reporteeList.length; i++) {
    reporteeEmail = reporteeList[i].email
    relations.push({ userEmail: reporteeEmail, managerEmail: user.email })
  }

  if (email != user.email) {
    console.log('Email not same')
    console.log(`Old email: ${email} : new email: ${user.email}`)
    try {
      const userRecord = await firebase.auth().getUserByEmail(email)
      console.log(userRecord)
      await firebase.auth().updateUser(userRecord.uid, {
        email: user.email
      })
      console.log('Updated in firebase')
    } catch (error) {
      console.log(error.message)
    }
  }
  console.log(relations)
  let transaction
  try {
    transaction = await sequelize.transaction()
    await User.update(user, { where: { email }, transaction })
    await Relation.destroy({ where: { userEmail: user.email }, transaction })
    await Relation.destroy({ where: { managerEmail: user.email }, transaction })
    const result = await Relation.bulkCreate(relations, { omitNull: false, transaction })
    await transaction.commit()
    res.status(200).send('Successfully updated')
  } catch (error) {
    if (transaction) {
      await transaction.rollback()
      try {
        const userRecord2 = await firebase.auth().getUserByEmail(user.email)
        await firebase.auth().updateUser(userRecord2.uid, {
          email
        })
      } catch (error) {
        console.log('Error in Updating Firebase')
      }
    }

    res.status(500).send('Some error occured while updating')
  }
}
