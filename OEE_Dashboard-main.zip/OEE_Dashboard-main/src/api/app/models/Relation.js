const dotenv = require('dotenv')
const path = require('path')
const format = require('pg-format')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class Relation {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async bulkCreate (relations, transaction) {
    if (relations.length === 0) {
      console.log('No relations to insert.')
      return []
    }

    const query = `
      INSERT INTO "${this.schema}"."Relation" (
      "userEmail",
      "managerEmail")
      VALUES %L
      RETURNING *;`

    const values = relations.map(relation => [
      relation.userEmail,
      relation.managerEmail
    ])

    const formattedValues = format('(%L)', values.join('), (')) // formattedValues ('useremail', 'manageremail = null')
    const formattedQuery = query.replace('%L', formattedValues)

    console.log(' formattedValues : ', formattedValues, 'formattedQuery', formattedQuery, ' relations ', relations)

    try {
      const res = await transaction.query(formattedQuery)
      return res.rows
    } catch (err) {
      console.error('Error inserting relations', err.stack)
      throw err
    }
  }
}

module.exports = {
  Relation
}
