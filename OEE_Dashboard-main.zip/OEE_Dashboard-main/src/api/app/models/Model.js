const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class Model {
  async createModel (model, schema, client = null) {
    const query = `
      INSERT INTO $1."Models" (
        modelId,
        modelName,
        ancillaryModelDataFile
      ) VALUES (
        COALESCE($2, DEFAULT),
        $3, $4
      )
      RETURNING *;
    `

    const values = [
      schema,
      model.modelId || null, // If id is not provided, it will use the default (auto-increment)
      model.modelName,
      model.modelDataFile
    ]

    console.log('Inside the function createModel')

    try {
      const pgPoolsInstance = await PgPools.getInstance()
      const tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client
      console.log('The query is : ', query, ' values : ', values)
      const res = await tClient.query(query, values)
      return res.rows[0]
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    }
  }
}

module.exports = {
  Model
}
