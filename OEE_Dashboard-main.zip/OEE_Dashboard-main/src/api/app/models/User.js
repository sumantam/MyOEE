const dotenv = require('dotenv')
const path = require('path')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class User {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async create (user, transaction) {
    const query = `
      INSERT INTO "${this.schema}"."Users" (
      email,
      name,
      role,
      responsibility,
      designation,
      countryCode,
      mobileNumber,
      img,
      location)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *;`

    const img = JSON.stringify(user.img)
    const values = [
      user.email, user.name, user.role, user.responsibility,
      user.designation, user.countryCode, user.mobileNumber,
      img, user.location
    ]

    try {
      // console.log('Query : ', query, ' values: ', values)
      const res = await transaction.query(query, values)
      return res.rows[0]
    } catch (err) {
      console.error('Error creating user', err.stack)
      throw err
    }
  }
}

module.exports = {
  User
}
