const router = require('express').Router()
const AuthMiddleware = require('../middlewares/auth')
const fdwRoutes = require('./fdw.routes.js')
const modelRoutes = require('./model.routes.js')

const usersRoutes = require('./user.routes.js')
// //const fileRoutes = require('./filehandle.routes.js')
// const userRoleRoutes = require('./userRoutes/index')
// //const testRoutes = require('./test.routes')
// const equipmentRoutes = require('./equipment.routes.js')
// const dashboardRoutes = require('./dashboard.routes.js')
// const smtdashboardRoutes = require('./smtdashboard.routes.js')
// const reportRoutes = require('./report.routes.js')
// const analyticsRoutes = require('./analytics.routes.js')
// const {getTilesImage} = require('../controllers/userControllers/map.controller')
// const dataSourceRoutes = require('./data.source.routes.js')
// const dataServiceRoutes = require('./data.service.routes.js')

// tiles api
// router.get("/tiles/:z(\\d+)/:x(\\d+)/:y(\\d+).:format([\\w.]+)", getTilesImage);

// Auth middleware
router.use(AuthMiddleware)

router.use('/db', fdwRoutes)
router.use('/rel', modelRoutes)
router.use('/users', usersRoutes)
// //router.use('/test', testRoutes)
// router.use('/usr', userRoleRoutes)
// //router.use('/file', fileRoutes)
// router.use('/system', equipmentRoutes)

// //routers for dashboards
// router.use('/dashboards', dashboardRoutes)
// router.use('/smtdashboards', smtdashboardRoutes)
// router.use('/analytics', analyticsRoutes)

// router.use('/report', reportRoutes)
// // router for data source
// router.use('/dataSource', dataSourceRoutes)
// // router for data source services
// router.use('/dataService', dataServiceRoutes)

module.exports = router
