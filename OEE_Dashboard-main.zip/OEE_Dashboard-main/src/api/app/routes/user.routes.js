const users = require('../controllers/users.controller.js')
// const nConfig = require('../controllers/notificationConfig.controller.js')
// const relations = require('../controllers/relation.controller.js')

const router = require('express').Router()

router.get('/ping', (req, res) => {
  console.log('Pinging .........')
  res.status(200).send('pong\n')
})
// // Create a new user in the Users table
// // router.post("/", IsAdmin, users.create);
// router.post('/', users.create)
router.post('/createClientAdmin', users.createClientAdmin)

// // Get managers list for a user by email from Relations table
// router.get('/manager/:email', relations.findManager)

// // Get reportees list for a user by email from Relations table
// router.get('/reportee/:email', relations.findReportee)

// // Retrieve all User from Users table
// router.get('/', users.findAll)

// // Search users having matched sub-string of email from Users table
// router.get('/search', users.searchUser)

// // Retrieve a single User with their email from Users table
// router.get('/userEmail/:email', users.findOne)

// router.get('/notificationConfig', nConfig.getNotificationConfigDetails)

// // Update a user with their email
// router.put('/userEmail/:email', users.updateUser)

// router.put('/notificationConfig/', nConfig.updateNotificationConfig)

// // Delete a User with email
// router.delete('/userEmail/:email', users.removeUser)

// // Get users by their responsibility from Users table
// router.get('/responsibility/search', users.getUserByResponsibility)

// // router.post("/filed/",users2.uploadFile);

module.exports = router
