const fs = require('fs')
const path = require('path')
// const sequelize = require('../utils/database')
const dotenv = require('dotenv')
const envFilePath = path.join(__dirname, '..', '..', '..', 'api', '.env')
dotenv.config({ path: envFilePath })
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

const sqlFileName001 = path.join(__dirname, '..', '..', '..', 'api', 'app', 'sql', 'fdw.sql')
const sqlFileName002 = path.join(__dirname, '..', '..', '..', 'api', 'app', 'sql', 'checkUtility.sql')

// const sqlFilename= path.join(__dirname, '..', '..', '..', 'api','app','sql','equipment_utilization.sql');
// const sqlContents = fs.readFileSync(sqlFilename, 'utf8');

// const sqlFilename1= path.join(__dirname, '..', '..', '..', 'api','app','sql','utilization_test.sql');
// const sqlContents1 = fs.readFileSync(sqlFilename1, 'utf8');

// const sqlFilename2= path.join(__dirname, '..', '..', '..', 'api','app','sql','queryHealth.sql');
// const sqlContents2 = fs.readFileSync(sqlFilename2, 'utf8');

// const sqlFilename3= path.join(__dirname, '..', '..', '..', 'api','app','sql','issues_KPI.sql');
// const sqlContents3 = fs.readFileSync(sqlFilename3, 'utf8');

// const sqlFilename4= path.join(__dirname, '..', '..', '..', 'api','app','sql','service.sql');
// const sqlContents4 = fs.readFileSync(sqlFilename4, 'utf8');

// const sqlFilename5= path.join(__dirname, '..', '..', '..', 'api','app','sql','equipment_status.sql');
// const sqlContents5 = fs.readFileSync(sqlFilename5, 'utf8');

// const sqlFilename6= path.join(__dirname, '..', '..', '..', 'api','app','sql','getNotificationSentDetails.sql');
// const sqlContents6 = fs.readFileSync(sqlFilename6, 'utf8');

// const sqlFilename7= path.join(__dirname, '..', '..', '..', 'api','app','sql','equipment_type_utilization.sql');
// const sqlContents7 = fs.readFileSync(sqlFilename7, 'utf8');

// const sqlFilename8= path.join(__dirname, '..', '..', '..', 'api','app','sql','equipment_utilization_by_equipment.sql');
// const sqlContents8 = fs.readFileSync(sqlFilename8, 'utf8');

// const sqlFilename9= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_equipment_by_user.sql');
// const sqlContents9 = fs.readFileSync(sqlFilename9, 'utf8');

// const sqlFilename10= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_equipment_type_by_user.sql');
// const sqlContents10 = fs.readFileSync(sqlFilename10, 'utf8');

// const sqlFilename11= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_param_details.sql');
// const sqlContents11 = fs.readFileSync(sqlFilename11, 'utf8');

// const sqlFilename12= path.join(__dirname, '..', '..', '..', 'api','app','sql','equipment_type_data.sql');
// const sqlContents12 = fs.readFileSync(sqlFilename12, 'utf8');

// const sqlFilename13 = path.join(__dirname, '..', '..', '..', 'api', 'app', 'sql', 'get_users_relation.sql')
// const sqlContents13 = fs.readFileSync(sqlFilename13, 'utf8')

// const sqlFilename14= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_equipment_type_data_by_loation.sql');
// const sqlContents14 = fs.readFileSync(sqlFilename14, 'utf8');

// const sqlFilename15= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_equipmentData.sql');
// const sqlContents15 = fs.readFileSync(sqlFilename15, 'utf8');

// const sqlFilename16= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_issue_details.sql');
// const sqlContents16 = fs.readFileSync(sqlFilename16, 'utf8');

// const sqlFilename17= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_equipment_data_with_aggr.sql');
// const sqlContents17 = fs.readFileSync(sqlFilename17, 'utf8');

// const sqlFilename18 = path.join(__dirname, '..', '..', '..', 'api','app','sql','defect_handler_service.sql');
// const sqlContents18 = fs.readFileSync(sqlFilename18, 'utf8');

// const sqlFilename19= path.join(__dirname, '..', '..', '..', 'api','app','sql','calculate_aggr_equipment_utilization.sql');
// const sqlContents19 = fs.readFileSync(sqlFilename19, 'utf8');

// const sqlFilename20= path.join(__dirname, '..', '..', '..', 'api','app','sql','getDefectsDataByEmail.sql');
// const sqlContents20 = fs.readFileSync(sqlFilename20, 'utf8');

// const sqlFilename21 = path.join(__dirname, '..', '..', '..', 'api', 'app', 'sql', 'get_operator.sql')
// const sqlContents21 = fs.readFileSync(sqlFilename21, 'utf8')

// const sqlFilename22= path.join(__dirname, '..', '..', '..', 'api','app','sql','getDefectsDataByAggregation.sql');
// const sqlContents22 = fs.readFileSync(sqlFilename22, 'utf8');

// const sqlFilename23= path.join(__dirname, '..', '..', '..', 'api','app','sql','CalculateIdealCycleTimeAndStore.sql');
// const sqlContents23 = fs.readFileSync(sqlFilename23, 'utf8');

// const sqlFilename24= path.join(__dirname, '..', '..', '..', 'api','app','sql','CalculateOEE.sql');
// const sqlContents24 = fs.readFileSync(sqlFilename24, 'utf8');

// const sqlFilename25= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_SMT_Qos.sql');
// const sqlContents25 = fs.readFileSync(sqlFilename25, 'utf8');

// const sqlFilename26= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_SMT_Pareto.sql');
// const sqlContents26 = fs.readFileSync(sqlFilename26, 'utf8');

// const sqlFilename27= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_SMT_production.sql');
// const sqlContents27 = fs.readFileSync(sqlFilename27, 'utf8');

// const sqlFilename28= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_SMT_changeOver.sql');
// const sqlContents28 = fs.readFileSync(sqlFilename28, 'utf8');

// const sqlFilename29= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_SMT_wait.sql');
// const sqlContents29 = fs.readFileSync(sqlFilename29, 'utf8');

// const sqlFilename30= path.join(__dirname, '..', '..', '..', 'api','app','sql','get_SMT_svg.sql');
// const sqlContents30 = fs.readFileSync(sqlFilename30, 'utf8');

// const sqlFilename31= path.join(__dirname, '..', '..', '..', 'api','app','sql','calculate_breakdown.sql');
// const sqlContents31 = fs.readFileSync(sqlFilename31, 'utf8');


// const { Sequelize } = require('sequelize')

// Set up the Sequelize connection
// const sequelize = new Sequelize('database', 'username', 'password', {
// host: 'localhost',
// dialect: 'postgres',
// });

// Function to execute the SQL file
exports.executeSqlFile = async () => {
  console.log('################## Called stored proc ####################')
  let pgPoolsInstance = null
  try {
    pgPoolsInstance = await PgPools.getInstance()
    const result001 = await pgPoolsInstance.getPool(dbConfig.DB).loadSQLFile(sqlFileName001)
    const result002 = await pgPoolsInstance.getPool(dbConfig.DB).loadSQLFile(sqlFileName002)

    // const result = await sequelize.query(sqlContents, { type: Sequelize.QueryTypes.RAW });
    // const result1 = await sequelize.query(sqlContents1, { type: Sequelize.QueryTypes.RAW });
    // const result2 = await sequelize.query(sqlContents2, { type: Sequelize.QueryTypes.RAW });
    // const result3 = await sequelize.query(sqlContents3, { type: Sequelize.QueryTypes.RAW });
    // const result4 = await sequelize.query(sqlContents4, { type: Sequelize.QueryTypes.RAW });
    // const result5 = await sequelize.query(sqlContents5, { type: Sequelize.QueryTypes.RAW });
    // const result6 = await sequelize.query(sqlContents6, { type: Sequelize.QueryTypes.RAW });
    // const result7 = await sequelize.query(sqlContents7, { type: Sequelize.QueryTypes.RAW });

    // const result8 = await sequelize.query(sqlContents8, { type: Sequelize.QueryTypes.RAW });
    // const result9 = await sequelize.query(sqlContents9, { type: Sequelize.QueryTypes.RAW });
    // const result10 = await sequelize.query(sqlContents10, { type: Sequelize.QueryTypes.RAW });
    // const result11 = await sequelize.query(sqlContents11, { type: Sequelize.QueryTypes.RAW });
    // const result12 = await sequelize.query(sqlContents12, { type: Sequelize.QueryTypes.RAW });
    // const result13 = await sequelize.query(sqlContents13, { type: Sequelize.QueryTypes.RAW });
    // const result14 = await sequelize.query(sqlContents14, { type: Sequelize.QueryTypes.RAW });
    // const result15 = await sequelize.query(sqlContents15, { type: Sequelize.QueryTypes.RAW });
    // const result16 = await sequelize.query(sqlContents16, { type: Sequelize.QueryTypes.RAW });
    // const result17 = await sequelize.query(sqlContents17, { type: Sequelize.QueryTypes.RAW });
    // const result18 = await sequelize.query(sqlContents18, { type: Sequelize.QueryTypes.RAW });
    // const result19 = await sequelize.query(sqlContents19, { type: Sequelize.QueryTypes.RAW });
    // const result20 = await sequelize.query(sqlContents20, { type: Sequelize.QueryTypes.RAW });
    // const result21 = await sequelize.query(sqlContents21, { type: Sequelize.QueryTypes.RAW });
    // const result22 = await sequelize.query(sqlContents22, { type: Sequelize.QueryTypes.RAW });
    // const result23 = await sequelize.query(sqlContents23, { type: Sequelize.QueryTypes.RAW });
    // const result24 = await sequelize.query(sqlContents24, { type: Sequelize.QueryTypes.RAW });
    // const result25 = await sequelize.query(sqlContents25, { type: Sequelize.QueryTypes.RAW });
    // const result26 = await sequelize.query(sqlContents26, { type: Sequelize.QueryTypes.RAW });
    // const result27 = await sequelize.query(sqlContents27, { type: Sequelize.QueryTypes.RAW });
    // const result28 = await sequelize.query(sqlContents28, { type: Sequelize.QueryTypes.RAW });
    // const result29 = await sequelize.query(sqlContents29, { type: Sequelize.QueryTypes.RAW });
    // const result30 = await sequelize.query(sqlContents30, { type: Sequelize.QueryTypes.RAW });
    // const result31 = await sequelize.query(sqlContents31, { type: Sequelize.QueryTypes.RAW });
    // const result32 = await sequelize.query(sqlContents32, { type: Sequelize.QueryTypes.RAW })

    console.log('SQL file executed successfully:')
  } catch (error) {
    console.error('Error executing SQL file:', error)
  }
}

// Usage example
// module.exports = executeSqlFile;
