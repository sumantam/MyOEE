DROP FUNCTION IF EXISTS "getTable";

CREATE OR REPLACE FUNCTION "getTable" (
    tableName VARCHAR,
    key VARCHAR,
    value VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS SETOF RECORD AS $$
DECLARE
    query TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = schemaName AND table_name = tableName) THEN
        query := format('SELECT %I FROM %I.%I WHERE %I = $1', key, schemaName, tableName, key);
        
        RETURN QUERY EXECUTE query USING value;
    ELSE
        RAISE NOTICE 'Table % does not exist.', tableName;
        RETURN;
    END IF;
END;
$$ LANGUAGE plpgsql;
