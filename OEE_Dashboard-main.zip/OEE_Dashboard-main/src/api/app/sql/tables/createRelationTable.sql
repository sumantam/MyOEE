DROP FUNCTION IF EXISTS createRelationTable;

CREATE OR REPLACE FUNCTION createRelationTable(
    schemaName VARCHAR
)
RETURNS BOOLEAN AS $$
DECLARE
    create_relation_command TEXT;
    create_index_command TEXT;
BEGIN

    create_relation_command := format('
        CREATE TABLE IF NOT EXISTS %I."Relation" (
            "userEmail" VARCHAR(255) NOT NULL,
            "managerEmail" VARCHAR(255) DEFAULT ''HR'',
            CONSTRAINT "relation_pkey" PRIMARY KEY ("userEmail", "managerEmail"),
            CONSTRAINT "relation_userEmail_fkey" FOREIGN KEY ("userEmail") REFERENCES "Users" ("email") ON DELETE CASCADE,
            CONSTRAINT "relation_managerEmail_fkey" FOREIGN KEY ("managerEmail") REFERENCES "Users" ("email") ON DELETE CASCADE
        )',
        schemaName
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', create_relation_command;

    -- Execute the command
    EXECUTE create_relation_command;

    create_index_command := format('
        CREATE INDEX IF NOT EXISTS
        "relation_managerEmail_userEmail_idx"
        ON %I."Relation" ("managerEmail", "userEmail");
        ', schemaName
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', create_index_command;

    -- Execute the command
    EXECUTE create_index_command;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;
