
CREATE OR REPLACE PROCEDURE create_new_materialized_view()
LANGUAGE plpgsql
AS $$
BEGIN
    -- Drop the new materialized view if it already exists
    IF EXISTS (SELECT 1 FROM pg_matviews WHERE schemaname = 'public' AND matviewname = 'new_materialized_view') THEN
        EXECUTE 'DROP MATERIALIZED VIEW public.new_materialized_view';
    END IF;

    -- Create the new materialized view with the join
    -- EXECUTE 'CREATE MATERIALIZED VIEW public.new_materialized_view AS
    --          SELECT m."eqpt_id", m."eqp_id",m."param_id",m."value",m."timestamp" , t2."warning_lower",t2."warning_upper", t2."alert_lower",t2."alert_upper" FROM public."materialized_table" m
    --          INNER JOIN public."Parameters" t2 ON m."eqpt_id" = t2."eqpt_id"';


   EXECUTE 'CREATE MATERIALIZED VIEW public.new_materialized_view AS
         SELECT m."eqpt_id", m."eqp_id", m."param_id", m."value", m."timestamp", t2."warning_lower", t2."warning_upper", t2."alert_lower", t2."alert_upper",
                CASE
                    WHEN m."value" >= t2."alert_upper" OR m."value" <= t2."alert_lower" THEN ''Alert'' 
                    WHEN m."value" >= t2."warning_upper" OR m."value" <= t2."warning_lower" THEN ''Warning'' 
                    ELSE ''Normal'' 
                END AS status,
                CASE
                    WHEN m."value" >= t2."warning_upper" THEN ''High'' 
                    WHEN m."value" <= t2."warning_lower" THEN ''Low'' 
                    ELSE null 
                END AS status_range
                
         FROM public."materialized_table" m
         INNER JOIN public."Parameters" t2 ON m."eqpt_id" = t2."eqpt_id"'; -- Use single quotes here

    -- Refresh the new materialized view (you might schedule this periodically)
    REFRESH MATERIALIZED VIEW public.new_materialized_view;
END;
$$;


CREATE OR REPLACE PROCEDURE database_service(
    --_time_interval interval DEFAULT NULL
    time_interval varchar
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Drop the materialized view if it already exists
    IF EXISTS (SELECT 1 FROM pg_matviews WHERE schemaname = 'public' AND matviewname = 'materialized_table') THEN
        EXECUTE 'DROP MATERIALIZED VIEW public.materialized_table CASCADE';
    END IF;

    -- Create the materialized view
    EXECUTE 'CREATE MATERIALIZED VIEW public.materialized_table AS
             SELECT *
             FROM public.live_data t1
             WHERE EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - t1."timestamp")) / 60 < ' || time_interval;
             --EXTRACT(EPOCH FROM _time_interval)::text;

    -- Refresh the materialized view (you might schedule this periodically)
    REFRESH MATERIALIZED VIEW public.materialized_table;

    CALL create_new_materialized_view();

    WITH CTE AS (
	select *, row_number() over ( partition by eqpt_id, eqp_id, param_id order by timestamp desc) as row_num 
	from public."new_materialized_view")
    UPDATE public."stateTables"
    SET 
        "defect_updatedAt" = (
            CASE WHEN  "state" != c1."status" OR "state_range" != c1."status_range" THEN c1."timestamp"
            ELSE "defect_updatedAt" END
        ),
        "state" = c1."status",
        "updatedAt" = c1."timestamp",
        "state_range" = c1."status_range"

    FROM (SELECT * 
    FROM    cte
    WHERE   row_num = 1) AS c1
	
    WHERE public."stateTables"."eqpt_id" = c1."eqpt_id" 
    AND public."stateTables"."eqp_id" = c1."eqp_id"
    AND public."stateTables"."param_id" = c1."param_id";

END;
$$;


-- ALTER TABLE "stateTables"
-- ADD state_range VARCHAR(255);

-- alter table public."stateTables"
-- add "defect_updatedAt" timestamp with time zone;

-- update public."stateTables"
-- set "defect_updatedAt" = "createdAt";
