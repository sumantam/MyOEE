DROP FUNCTION IF EXISTS get_users_relation;
CREATE OR REPLACE FUNCTION get_users_relation()
RETURNS TABLE (
  opEmail VARCHAR(255),
  opName text,
  supEmail VARCHAR(255),
  supName text,
  execEmail VARCHAR(255),
  execName text  
) AS $$

BEGIN

  RETURN QUERY
  select t7."opEmail", max(case when t7."responsibility" = 'Operator' then t7."name" else NULL end) as "opName",
			t7."supEmail", max(case when t7."responsibility" = 'Supervisor' then t7."name" else NULL end) as "supName",
			t7."execEmail", max(case when t7."responsibility" = 'Executive' then t7."name" else NULL end) as "execName"
    from 
    (
        select *
        from "Users" as t5
        inner join
        (
            select f."userEmail" as "opEmail", s."userEmail" as "supEmail", s."managerEmail" as "execEmail"
            from public."Relations" as f
            inner join public."Relations" as s
            on f."managerEmail" = s."userEmail"
        ) as t6
        on t5."email" = t6."opEmail"
        or t5."email" = t6."supEmail"
        or t5."email" = t6."execEmail"
    ) as t7
    group by t7."opEmail", t7."supEmail", t7."execEmail";		
    
END;
$$ LANGUAGE plpgsql;
