require('dotenv').config()
// const webSocket = require ("ws");
const express = require('express')
const app = express()
const cors = require('cors')
// const sequelize = require('./app/utils/database')
const domain = process.env.CLIENT_ORIGIN || 'http://localhost:3000'
const { createDatabase } = require('./app/utils/createDB')
const routes = require('./app/routes/index')
const PORT = process.env.PORT || 3001
const httpServer = require('http').createServer(app)
const socketio = require('socket.io')
const nodeSchedule = require('node-schedule')
// const { QueryTypes } = require('sequelize')

const { createDefaultAdmin } = require('./app/controllers/users.controller')
// const getStatus = require("./app/socket/overAllHealth")
// const getEqpTypeStatus = require("./app/socket/overAllEqptHealth")
// const getIssues = require("./app/socket/KPIs")
// const getEqpTypeCart =  require("./app/socket/eqpt_cart")
// const getEquipmentStatus = require("./app/socket/equipment_status")
// const { insertDefectRows } = require('./app/utils/generateDefects')
// const getIssueDetails = require("./app/socket/get_issueDetails")
// const getParamDetails = require("./app/socket/get_param_details")
// const getEqpDetails = require("./app/socket/get_eqp_details")
// const getutz = require("./app/socket/get_eqp_utilization")
// const getHealthChart = require("./app/socket/get_health_chart")
// const getIssueChart = require("./app/socket/get_issue_chart")
// const getDowntimeChart= require("./app/socket/get_downtime_chart")
// const getOEE = require("./app/socket/get_oee")
// const getMTTR = require("./app/socket/get_mttr")
// const cron=require("./app/sql/cron")

const server = new socketio.Server(httpServer, {
  cors: {
    origin: domain,
    allowedHeaders: ['api_key', 'Authorization', '*']
  }
})

const { logger } = require('./app/utils/logger')
const { executeSqlFile } = require('./app/sql/storedproc')
// const { resendNotification, sendNotificationToSupervisors, sendNotificationToExecutives } = require("./app/notification/job");
// const {runAnomalyDetector} = require("./app/services/anomalyDetector");
// const {insertDefectbyAnomaly} = require("./app/services/generateDefectsByAnomaly");
// const anomalyInterval = process.env.ANOMALY_INTERVAL || 60

const corsOptions = {
  origin: domain,
  allowedHeaders: ['api_key', 'Authorization', '*']
}

app.use(cors(corsOptions))

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Test the server
app.get('/', (req, res) => {
  res.json({ data: 'Welcome to Resonance Dashboard backend checked' })
});

(async () => {
  try {
    const DBRes = await createDatabase()
    if (DBRes) {
      app.use('/api', routes)
      await executeSqlFile()
      // await sequelize.sync()

      // app.listen(PORT, () => {
      //   logger.info(`Server is running on PORT ${PORT}`);
      // });
      await createDefaultAdmin()

      httpServer.listen(PORT, () => {
        console.log(`Socket.IO server running at http://localhost:${PORT}/`)
        logger.info(`Server is running on PORT ${PORT}`)
      })
    } else {
      logger.info('no database found')
    }
  } catch (error) {
    logger.error('serverjs error')
    console.log(error)
    return null
  }
})().then(
  () => {
    const job = nodeSchedule.scheduleJob('0 */2 * * * *', function () {
      const now = new Date()
      console.log('Job has been triggered at: ', now.toLocaleTimeString())
      // sequelize.query(`CALL database_service('2');`);
      // need to be merge with database_service sql
      // sequelize.query(`CALL defect_handler_service();`);
    })
    // const jobCalculateIdealcycle = nodeSchedule.scheduleJob('59 23 * * *', function(){
    //   const now = new Date();
    //   console.log('jobCalculateIdealcycle has been triggered at: ', now.toLocaleTimeString());
    //   sequelize.query(`select CalculateIdealCycleTimeAndStore();`);
    //   // other database operations if needed
    // });

    // // Job to delete live data older than 12 hours from the current time
    // const jobDeleteLiveData = nodeSchedule.scheduleJob('0 0 */5 * * *', function() {
    //   const query = `delete
    //   FROM "live_data"
    //   where AGE(now(), "timestamp") > interval '12' hour;`
    //   sequelize.query(query, {
    //     type: QueryTypes.SELECT
    //   })
    // });
    // const jobCalculateAnomaly= nodeSchedule.scheduleJob(`0 */${anomalyInterval} * * * *`, runAnomalyDetector);

    // const addAnomalyDefectInterval = parseInt(anomalyInterval - (anomalyInterval * 0.1));
    // const jobInsertDefectByAnomaly= nodeSchedule.scheduleJob(`0 */${addAnomalyDefectInterval} * * * *`, insertDefectbyAnomaly.bind(this, addAnomalyDefectInterval));

    // const jobInsertDefect = nodeSchedule.scheduleJob('0 */15 * * * *', insertDefectRows);

    // if(process.env.SENT_NOTIFICATION === 'true') {
    //   const jobResendNotif= nodeSchedule.scheduleJob('0 */15 * * * *', resendNotification);
    //   const jobGenNotiForSup= nodeSchedule.scheduleJob('0 */31 * * * *', sendNotificationToSupervisors);
    //   const jobGenNotiForExec= nodeSchedule.scheduleJob('0 */47 * * * *', sendNotificationToExecutives);
    // }
  }
)

const connections = {}
const getEqptStatusEvent = {}
const getStatusEvent = {}
const getEqpTypeCartEvent = {}
const getIssuesEvent = {}
const getEquipmentStatusEvent = {}
const getIssueDetailsEvent = {}
const getParamDetailsEvent = {}
const getutzEvent = {}
const getOeeEvent = {}
const getMTTREvent = {}
const getHealthChartEvent = {}
const getEqpDetailsEvent = {}
const getIssueChartEvent = {}
const getDowntimeChartEvent = {}

// server.use((socket, next) => {
//   const token = socket.handshake.auth.token;
//   // const {token} = socket.handshake.query;
//   if (token==="abc"){
//       console.log("Authenticated")
//       next()
//   }
//   else{
//       console.log("Authentication failed")
//       const err = new Error("not authorized");
//       err.data = { content: "Please retry later" }; // additional details
//       next(err);
//   }

// });

server.on('connection', (socket) => {
  console.log(socket.id, ' connected')
  logger.info(`Connected socket id: ${socket.id}`)

  if (!connections.hasOwnProperty(socket.id)) {
    connections[socket.id] = []
  }

  socket.on('disconnect', () => {
    console.log('Disconnected: ', socket.id)
    logger.info(`Disconnected socket id: ${socket.id}`)
    connections[socket.id].forEach(element => {
      clearInterval(element)
    })
    delete connections[socket.id]
    delete getEqptStatusEvent[socket.id]
    delete getStatusEvent[socket.id]
    delete getEqpTypeCartEvent[socket.id]
    delete getIssuesEvent[socket.id]
    delete getEquipmentStatusEvent[socket.id]
    delete getIssueDetailsEvent[socket.id]
    delete getParamDetailsEvent[socket.id]
    delete getutzEvent[socket.id]
    delete getOeeEvent[socket.id]
    delete getMTTREvent[socket.id]
    delete getHealthChartEvent[socket.id]
    delete getEqpDetailsEvent[socket.id]
    delete getIssueChartEvent[socket.id]
    delete getDowntimeChartEvent[socket.id]
  })

  // // Overall Health
  //     socket.on('getStatus', (data) => {
  //       if (!getStatusEvent.hasOwnProperty(socket.id)){
  //         console.log("getStatus Requested by: ",socket.id)
  //         logger.info(`API: Status Called By: ${data.email} socket id: ${socket.id}`);
  //         getStatus(socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         let sid=setInterval(getStatus,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getStatusEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getStatus Requested by: ",socket.id)
  //       }
  //     })
  // // Equipment Type wise overall health
  //     socket.on('getEqptStatus', (data) => {
  //       if (!getEqptStatusEvent.hasOwnProperty(socket.id)){
  //         console.log("getEqptStatus Requested by: ",socket.id)
  //         logger.info(`API: EqptStatus Called By: ${data.email} socket id: ${socket.id}`);
  //         getEqpTypeStatus(socket,data.email,data.responsibility,data.eqp_type,data.loc)
  //         let sid=setInterval(getEqpTypeStatus,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.loc)
  //         connections[socket.id].push(sid)
  //         getEqptStatusEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getEqptStatus Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getIssues', (data) => {
  //       if (!getIssuesEvent.hasOwnProperty(socket.id)){
  //         console.log("getIssues Requested by: ",socket.id)
  //         logger.info(`API: Issues Called By: ${data.email} socket id: ${socket.id}`);
  //         getIssues(socket,data.email,data.responsibility,data.eqp_type,data.loc)
  //         let sid=setInterval(getIssues,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.loc)
  //         connections[socket.id].push(sid)
  //         getIssuesEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getIssues Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getEqptCart', (data) => {
  //       if (!getEqpTypeCartEvent.hasOwnProperty(socket.id)){
  //         console.log("getEqptCart Requested by: ",socket.id)
  //         logger.info(`API: EqptCart Called By: ${data.email} socket id: ${socket.id}`);
  //         getEqpTypeCart(socket,data.email,data.responsibility,data.eqp_type,data.loc)
  //         let sid=setInterval(getEqpTypeCart,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.loc)
  //         connections[socket.id].push(sid)
  //         getEqpTypeCartEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getEqptCart Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getutz', (data) => {
  //       if (!getutzEvent.hasOwnProperty(socket.id)){
  //         console.log("getutz Requested by: ",socket.id)
  //         logger.info(`API: utz Called By: ${data.email} socket id: ${socket.id}`);
  //         getutz(socket,data.email,data.responsibility,data.eqp,data.loc)
  //         let sid=setInterval(getutz,data.latency,socket,data.email,data.responsibility,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getutzEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getutz Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getEquipmentStatus', (data) => {
  //       if (!getEquipmentStatusEvent.hasOwnProperty(socket.id)){
  //         console.log("getEqpStatus Requested by: ",socket.id)
  //         logger.info(`API: EquipmentStatus Called By: ${data.email} socket id: ${socket.id}`);
  //         getEquipmentStatus(socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         let sid=setInterval(getEquipmentStatus,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getEquipmentStatusEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getEquipmentStatus Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getIssueDetails', (data) => {
  //       if (!getIssueDetailsEvent.hasOwnProperty(socket.id)){
  //         console.log("getIssueDetails Requested by: ",socket.id)
  //         logger.info(`API: IssueDetails Called By: ${data.email} socket id: ${socket.id}`);
  //         getIssueDetails(socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         let sid=setInterval(getIssueDetails,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getIssueDetailsEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getIssueDetails Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getParamDetails', (data) => {
  //       if (!getParamDetailsEvent.hasOwnProperty(socket.id)){
  //         console.log("getParamDetails Requested by: ",socket.id)
  //         logger.info(`API: ParamDetails Called By: ${data.email} socket id: ${socket.id}`);
  //         getParamDetails(socket,data.eqp,data.display_param,data.past_data,data.loc)
  //         let sid=setInterval(getParamDetails,data.latency,socket,data.eqp,data.display_param,data.past_data,data.loc)
  //         connections[socket.id].push(sid)
  //         getParamDetailsEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getIssueDetails Requested by: ",socket.id)
  //       }
  //     })

  // // Dummy API Events
  //     socket.on('getOEE', (data) => {
  //       if (!getOeeEvent.hasOwnProperty(socket.id)){
  //         console.log("getOEE Requested by: ",socket.id)
  //         logger.info(`API: OEE Called By: ${data.email} socket id: ${socket.id}`);
  //         getOEE(socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         let sid=setInterval(getOEE,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getOeeEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getIssueDetails Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getMTTR', (data) => {
  //       if (!getMTTREvent.hasOwnProperty(socket.id)){
  //         console.log("getMTTR Requested by: ",socket.id)
  //         logger.info(`API: MTTR Called By: ${data.email} socket id: ${socket.id}`);
  //         getMTTR(socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         let sid=setInterval(getMTTR,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getMTTREvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getMTTR Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getEqpDetails', (data) => {

  //       if (!getEqpDetailsEvent.hasOwnProperty(socket.id)){
  //         console.log("getEqpDetails Requested by: ",socket.id)
  //         logger.info(`API: EqpDetails Called By: ${data.email} socket id: ${socket.id}`);
  //         getEqpDetails(socket,data.eqp)
  //         let sid=setInterval(getEqpDetails,data.latency,socket,data.eqp)
  //         connections[socket.id].push(sid)
  //         getEqpDetailsEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getEqpDetails Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getHealthChart', (data) => {
  //       if (!getHealthChartEvent.hasOwnProperty(socket.id)){
  //         console.log("getHealthChart Requested by: ",socket.id)
  //         logger.info(`API: HealthChart Called By: ${data.email} socket id: ${socket.id}`);
  //         getHealthChart(socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         let sid=setInterval(getHealthChart,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getHealthChartEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getHealthChart Requested by: ",socket.id)
  //       }

  //     })

  //     socket.on('getIssueChart', (data) => {
  //       if (!getIssueChartEvent.hasOwnProperty(socket.id)){
  //         console.log("getIssueChart Requested by: ",socket.id)
  //         logger.info(`API: IssueChart Called By: ${data.email} socket id: ${socket.id}`);
  //         getIssueChart(socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         let sid=setInterval(getIssueChart,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getIssueChartEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getIssueChart Requested by: ",socket.id)
  //       }
  //     })

  //     socket.on('getDowntimeChart', (data) => {

  //       if (!getDowntimeChartEvent.hasOwnProperty(socket.id)){
  //         console.log("getDowntimeChart Requested by: ",socket.id)
  //         logger.info(`API: DowntimeChart Called By: ${data.email} socket id: ${socket.id}`);
  //         getDowntimeChart(socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         let sid=setInterval(getDowntimeChart,data.latency,socket,data.email,data.responsibility,data.eqp_type,data.eqp,data.loc)
  //         connections[socket.id].push(sid)
  //         getDowntimeChartEvent[socket.id]=data.email
  //       }else{
  //         console.log("Duplicate getDowntimeChart Requested by: ",socket.id)
  //       }
  //     })
  // socket.on('getIssueChart', (data) => {
  //   console.log("getEqpDetails Requested by: ",socket.id)
  //   getEqpDetails(socket,data.eqp)
  // })
})
