
using System.Linq;
using System.Reflection.PortableExecutable;
using Newtonsoft.Json;

internal static class Loader
{
    static string[] shiftOwners = ["Arindam", "Probal", "Sumanta", "Debopam", "Bibartak", "Swarna"];
    static Model[] models = [
        new Model { ModelName = "L1-SWITCH-BANK_0", ChangeoverTime = 1200 },
        new Model { ModelName = "L2-SWITCH-BANK_0", ChangeoverTime = 900 },
        new Model { ModelName = "TATA-MAIN_0", ChangeoverTime = 960 },
        new Model { ModelName = "TATA-MAIN_1", ChangeoverTime = 1020 },
        new Model { ModelName = "L2-MAIN_0", ChangeoverTime = 1200 },
        new Model { ModelName = "L2-MAIN_1", ChangeoverTime = 900 },
        new Model { ModelName = "L2-MAIN_2", ChangeoverTime = 960 },
      ];

        //["L1-SWITCH-BANK_0", "L2-SWITCH-BANK_0", "TATA-MAIN_0", "TATA-MAIN_1", "L2-MAIN_0", "L2-MAIN_1", "L2-MAIN_2"];

    internal static void LoadAndPrepareData()
    {
        var data = JsonConvert.DeserializeObject<DataModel>(File.ReadAllText(@"JSON/data.json"));
        if (data is null) return;
        DataModel newData = new();
        PopulateData(data, newData);

        // /@"JSON\data_generated.json"
        using (TextWriter textWriter = File.CreateText(@"JSON/data_generated.json"))
        {
            var serializer = new JsonSerializer();
            serializer.Serialize(textWriter, newData);
        }
    }

    static void PopulateData(DataModel data, DataModel newData)
    {
        newData.Plants = data.Plants;
        newData.Lines = data.Lines;
        newData.Machine_Types = data.Machine_Types;
        newData.Downtime_Reasons = data.Downtime_Reasons;
        PopulateMachineTypes(data.Machine_Types);

        // foreach (var plant in data.Plants)
        // {
        var plant = data.Plants[1];
        List<Line> plantLines = data.Lines.Where(p => p.Plant == plant.Id).ToList();

        foreach (var plantLine in plantLines)
        {
            PopulateMachinesInPipleLine(newData, plantLine.Id);
            foreach (DateTime day in CalenderDays(Convert.ToDateTime("01-08-2024"), DateTime.Today.AddDays(-1)))
            {
                DateTime calcDayTime = new DateTime(day.Year, day.Month, day.Day, 6, 0, 0);
                PopulateShiftData(newData, calcDayTime, plantLine.Id);
            }
        }
        //}
    }

    private static void PopulateMachineTypes(List<MachineType> machine_Types)
    {
        foreach (var mt in machine_Types)
        {
            if (mt.Breakdown_Issues.Count <= 0)
            {
                var breakdownIssueCount = RandomInteger(5, 7);
                for (int i = 0; i < breakdownIssueCount; i++)
                {
                    mt.Breakdown_Issues.Add(new Issue { Id = $"{mt.Id}_BR_00{i}", Name = $"Issue_00{i}" });
                }

                var micrstopIssueCount = RandomInteger(5, 7);
                for (int i = 0; i < micrstopIssueCount; i++)
                {
                    mt.Microstop_Issues.Add(new Issue { Id = $"{mt.Id}_MS_00{i}", Name = $"Issue_00{i}" });
                }

                var qualityIssueCount = RandomInteger(3, 5);
                for (int i = 0; i < qualityIssueCount; i++)
                {
                    mt.Quality_Issues.Add(new Issue { Id = $"{mt.Id}_QU_00{i}", Name = $"Issue_00{i}" });
                }

            }
            else
            {

            }
        }
    }

    private static void PopulateMachinesInPipleLine(DataModel newData, string plantLineId)
    {
        string machineId = Ulid.NewUlid().ToString();
        string prevMachineId = "NONE";
        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT001",
            Previous_Machine_Id = prevMachineId,
            Name = "Loader",
            Preceding_Conveyor_Size = 0,
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT002",
            Previous_Machine_Id = prevMachineId,
            Name = "Marker",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT003",
            Previous_Machine_Id = prevMachineId,
            Name = "Paste-Mixer",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT004",
            Previous_Machine_Id = prevMachineId,
            Name = "Paste-Printer",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT005",
            Previous_Machine_Id = prevMachineId,
            Name = "Paste-Inspect",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT006",
            Previous_Machine_Id = prevMachineId,
            Name = "Paste-And-Place-A",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT006",
            Previous_Machine_Id = prevMachineId,
            Name = "Paste-And-Place-B",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT006",
            Previous_Machine_Id = prevMachineId,
            Name = "Paste-And-Place-C",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT006",
            Previous_Machine_Id = prevMachineId,
            Name = "Paste-And-Place-D",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT007",
            Previous_Machine_Id = prevMachineId,
            Name = "Pre-Reflow-AOI",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT008",
            Previous_Machine_Id = prevMachineId,
            Name = "Reflow-Oven",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT007",
            Previous_Machine_Id = prevMachineId,
            Name = "Post-Reflow-AOI",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });

        prevMachineId = machineId;
        machineId = Ulid.NewUlid().ToString();

        newData.Machines_In_Pipeline.Add(new PipelineMachine
        {
            Id = machineId,
            Line = plantLineId,
            Machine_Type = "MT009",
            Previous_Machine_Id = prevMachineId,
            Name = "Receiver",
            Preceding_Conveyor_Size = RandomInteger(1, 5),
            Expected_Cycle_Time = RandomInteger(0, 30)
        });


        //newData.Downtime_Instances.Add(new DownTimeInstance
        //{
        //    Downtime_Instance_Id = Ulid.NewUlid().ToString(),
        //    Downtime_Reason_Id = "DTR_0000",
        //    Machines_In_Pipeline_Id = machineId,
        //    From_Time = RandomInteger(0, 31).ToString(),
        //    To_Time = RandomInteger(31, 80).ToString(),
        //    Detailed_Reason = microstopReasons[RandomInteger(0, 5)]
        //});
    }

    private static void PopulateShiftData(DataModel newData, DateTime day, string lineId)
    {
        PipelineMachine[] machines = newData.Machines_In_Pipeline.Where(i => i.Line == lineId).ToArray();
        DateTime timeShiftStartTime = PopulateShift(newData, machines, day, lineId, "A");
        timeShiftStartTime = PopulateShift(newData, machines, timeShiftStartTime, lineId, "B");
        _ = PopulateShift(newData, machines, timeShiftStartTime, lineId, "C");
    }

    private static DateTime PopulateShift(DataModel newData, PipelineMachine[] machines, DateTime day, string lineId, string identifier)
    {
        DateTime calcTime = new DateTime(day.Year, day.Month, day.Day, day.Hour, day.Minute, day.Second);
        DateTime shiftEndTime = calcTime.AddHours(8);
        string shiftName = $"{lineId}-{day:dd-MM-yyyy}-{identifier}";
        var lineShift = CreateShiftTime(shiftName, day.ToString("o"), shiftEndTime.ToString("o"), lineId);
        newData.Line_Shift_Times.Add(lineShift);
        CreateShiftPlans(newData, machines, day, lineShift.Id);
        return shiftEndTime;
    }

    private static void CreateShiftPlans(DataModel newData, PipelineMachine[] machines, DateTime day, string shiftId)
    {
        int shiftPlanCount = RandomInteger(2, 3);

        var planStartTime = new DateTime(day.Year, day.Month, day.Day, day.Hour, day.Minute, day.Second);

        var shiftProductionSummary = new ProductionSummary { Shift_Id = shiftId };

        for (int i = 0; i < shiftPlanCount; i++)
        {
            int minutes = RandomInteger(15, 30);
            int changeOver = 40 - minutes;
            var changeOverStart = planStartTime.AddHours(2).AddMinutes(minutes);
            var changeOverEnd = changeOverStart.AddMinutes(changeOver);

            var shiftPaln = CreateShiftPlan(planStartTime, shiftId, changeOverStart);
            newData.Line_Shift_Plans.Add(shiftPaln);

            var breakdownReasons = newData.Downtime_Reasons.Where(i => i.Class == "Breakdown").ToList();
            var microstopReasons = newData.Downtime_Reasons.Where(i => i.Class == "Microstop").ToList();

            var shiftPlanProductionSummary = new ShiftPlanProductionSummary
            {
                Line_Shift_Plan_Id = shiftPaln.Plan_Id,
                Changeover_Time_Start = changeOverStart.ToString("o"),
                Changeover_Time_End = changeOverEnd.ToString("o"),
                Breakdowns = PopulateBreakdowns(newData.Machine_Types, breakdownReasons, machines, planStartTime, changeOverStart),
                Productions = PopulateProductions(newData.Machine_Types, microstopReasons, shiftPaln, machines, planStartTime, changeOverStart)
            };

            shiftProductionSummary.Data.Add(shiftPlanProductionSummary);
            planStartTime = changeOverEnd;
        }

        newData.Production_Summaries.Add(shiftProductionSummary);
    }

    private static List<Production> PopulateProductions(List<MachineType> machine_Types, List<DownTimeReason> microstopReasons, LineShiftPlan shiftPaln,
        PipelineMachine[] machines, DateTime planStartTime, DateTime changeOverStart)
    {
        List<Production> productions = new List<Production>();
        var productionCount = RandomInteger(shiftPaln.To_Produce - 30, shiftPaln.To_Produce);
        for (int i = 0; i < productionCount; i++)
        {
            int check = RandomInteger(shiftPaln.To_Produce - 30, shiftPaln.To_Produce);
            productions.Add(new Production
            {
                Barcode = Ulid.NewUlid().ToString(),
                Runs = new List<Run>
                {
                    new Run
                    {
                        Run_Number = 0,
                        Entry_Machine_Id = machines[0].Id,
                        Exit_Machine_Id= machines[machines.Length -1].Id,
                        Status = i == check ? "NG" : "OK",
                        Microstop_Instances = PopulateMicroStops(machine_Types,microstopReasons,machines,planStartTime,changeOverStart)
                    }
                }
            });
        }
        return productions;
    }

    private static List<Stopage> PopulateMicroStops(List<MachineType> machineTypes, List<DownTimeReason> microstopReasons, PipelineMachine[] machines, DateTime planStartTime, DateTime planEndTime)
    {
        int noOfMs = RandomInteger(0, 5);
        List<Stopage> mss = new();

        var totalMinutes = (int)(planEndTime.AddMinutes(-15) - planStartTime.AddMinutes(15)).TotalMinutes;
        var fromTime = planStartTime.AddMinutes(RandomInteger(15, totalMinutes - 20));
        var toTime = fromTime.AddSeconds(RandomInteger(1, 12));

        for (int i = 0; i < noOfMs; i++)
        {
            var machineIndex = RandomInteger(1, machines.Length - 1);
            var machine = machines[machineIndex];
            var downTimeReason = microstopReasons[RandomInteger(0, microstopReasons.Count - 1)];
            var machineMsIssues = machineTypes.FirstOrDefault(i => i.Id == machine.Machine_Type)!.Microstop_Issues;


            mss.Add(new Stopage
            {
                Downtime_Instance_Id = Ulid.NewUlid().ToString(),
                Machines_In_Pipeline_Id = machine.Id,
                Downtime_Reason_Id = downTimeReason.Reason_Id,
                Issue = machineMsIssues[RandomInteger(0, machineMsIssues.Count - 1)].Id,
                Action = downTimeReason.Actions[RandomInteger(0, downTimeReason.Actions.Count - 1)].AId,
                From_Time = fromTime.ToString("o"),
                To_Time = toTime.ToString("o"),
                Action_Time = string.Empty
            });

            fromTime = toTime.AddSeconds(RandomInteger(1, 5));
            toTime = fromTime.AddSeconds(RandomInteger(1, 5));
        }
        return mss;
    }

    private static List<Stopage> PopulateBreakdowns(List<MachineType> machineTypes, List<DownTimeReason> downTimeReasons,
        PipelineMachine[] machines, DateTime planStartTime, DateTime planEndTime)
    {
        var noOfBreakdown = RandomInteger(0, 1);
        List<Stopage> breakDowns = new();

        for (int i = 0; i < noOfBreakdown; i++)
        {
            var machineIndex = RandomInteger(1, machines.Length - 1);
            var machine = machines[machineIndex];
            var downTimeReason = downTimeReasons[RandomInteger(0, downTimeReasons.Count - 1)];
            var machineBreakdownIssues = machineTypes.FirstOrDefault(i => i.Id == machine.Machine_Type)!.Breakdown_Issues;
            var totalMinutes = (int)(planEndTime.AddMinutes(-15) - planStartTime.AddMinutes(15)).TotalMinutes;
            var fromTime = planStartTime.AddMinutes(RandomInteger(15, totalMinutes - 20));
            var toTime = fromTime.AddMinutes(RandomInteger(5, 20));

            breakDowns.Add(new Stopage
            {
                Downtime_Instance_Id = Ulid.NewUlid().ToString(),
                Machines_In_Pipeline_Id = machine.Id,
                Downtime_Reason_Id = downTimeReason.Reason_Id,
                Issue = machineBreakdownIssues[RandomInteger(0, machineBreakdownIssues.Count - 1)].Id,
                Action = downTimeReason.Actions[RandomInteger(0, downTimeReason.Actions.Count - 1)].AId,
                From_Time = fromTime.ToString("o"),
                To_Time = toTime.ToString("o"),
                Action_Time = toTime.AddSeconds(-RandomInteger(20, 120)).ToString("o")
            });
        }

        return breakDowns;
    }

    private static LineShiftPlan CreateShiftPlan(DateTime planStartTime, string shiftId, DateTime changeOverStart)
    {
        var model = models[RandomInteger(0, 6)];
        return new LineShiftPlan
        {
            Plan_Id = Ulid.NewUlid().ToString(),
            Shift_Id = shiftId,
            Start_Time = planStartTime.ToString("o"),
            End_Time = changeOverStart.ToString("o"),
            Changeover_Time_After = model.ChangeoverTime,
            Other_Times = 0,
            To_Produce = RandomInteger(200, 250),
            Model_Name = model.ModelName
        };
    }

    private static LineShiftTime CreateShiftTime(string shiftName, string startTime, string endTime, string lineId)
    {
        return new LineShiftTime
        {
            Id = Ulid.NewUlid().ToString(),
            Shift_Name = shiftName,
            Start = startTime,
            End = endTime,
            Shift_Owner = shiftOwners[RandomInteger(0, 5)],
            Line = lineId,
            UTC_Offset = "+0530"
        };
    }

    static int RandomInteger(int start, int end) => new Random().Next(start, end + 1);

    static IEnumerable<DateTime> CalenderDays(DateTime startDate, DateTime enddate)
    {
        for (var date = startDate.Date; date.Date <= enddate.Date; date = date.AddDays(1))
            yield return date;
    }
}