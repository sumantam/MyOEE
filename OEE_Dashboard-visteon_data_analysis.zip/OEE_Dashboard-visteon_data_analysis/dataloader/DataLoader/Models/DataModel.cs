
using System.Text.Json.Serialization;

public class DataModel
{
    public List<Plant> Plants { get; set; } = new();
    public List<Line> Lines { get; set; } = new();
    public List<MachineType> Machine_Types { get; set; } = new();
    public List<PipelineMachine> Machines_In_Pipeline { get; set; } = new();
    public List<LineShiftTime> Line_Shift_Times { get; set; } = new();
    public List<LineShiftPlan> Line_Shift_Plans { get; set; } = new();
    public List<DownTimeReason> Downtime_Reasons { get; set; } = new();
    public List<DownTimeInstance> Downtime_Instances { get; set; } = new();
    public List<ProductionSummary> Production_Summaries { get; set; } = new();
}

public class Plant
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}

public class ProductionSummary
{
    public string Shift_Id { get; set; } = string.Empty;
    public List<ShiftPlanProductionSummary> Data { get; set; } = new();
}

public class ShiftPlanProductionSummary
{
    public string Line_Shift_Plan_Id { get; set; } = string.Empty;
    public string Changeover_Time_Start { get; set; } = string.Empty;
    public string Changeover_Time_End { get; set; } = string.Empty;
    public List<Stopage> Breakdowns { get; set; } = new();
    public List<Production> Productions { get; set; } = new();
}

public class Stopage
{
    public string Downtime_Instance_Id { get; set; } = string.Empty;
    public string Machines_In_Pipeline_Id { get; set; } = string.Empty;
    public string Downtime_Reason_Id { get; set; } = string.Empty;
    public string From_Time { get; set; } = string.Empty;
    public string To_Time { get; set; } = string.Empty;
    public string Issue { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string Action_Time { get; set; } = string.Empty;
}

public class Production
{
    public string Barcode { get; set; } = string.Empty;
    public List<Run> Runs { get; set; } = new();
}

public class Run
{
    public int Run_Number { get; set; }
    public string Entry_Machine_Id { get; set; } = string.Empty;
    public string Entry_Machine_Timestamp { get; set; } = string.Empty;
    public string Exit_Machine_Id { get; set; } = string.Empty;
    public string Exit_Machine_Timestamp { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Other_Info { get; set; } = string.Empty;
    public List<Stopage> Microstop_Instances { get; set; } = new();
}

public class DownTimeInstance
{
    public string Downtime_Instance_Id { get; set; } = string.Empty;
    public string Downtime_Reason_Id { get; set; } = string.Empty;
    public string Machines_In_Pipeline_Id { get; set; } = string.Empty;
    public string From_Time { get; set; } = string.Empty;
    public string Expected_Up_Time { get; set; } = string.Empty;
    public string To_Time { get; set; } = string.Empty;
    public string Detailed_Reason { get; set; } = string.Empty;
    public string Note { get; set; } = string.Empty;
    public string GYR { get; set; } = string.Empty;

    [JsonIgnore]
    public int TimeFrom { get { return Convert.ToInt32(From_Time); } }
    [JsonIgnore]
    public int TimeTo { get { return Convert.ToInt32(To_Time); } }
}

public class DownTimeReason
{
    public string Reason_Id { get; set; } = string.Empty;
    public string Class { get; set; } = string.Empty;
    public string Root_Cause { get; set; } = string.Empty;
    public string Context { get; set; } = string.Empty;
    public List<ActionTaken> Actions { get; set; } = new();
}

public class ActionTaken
{
    public string AId { get; set; } = string.Empty;
    public string Desc { get; set; } = string.Empty;
}

public class LineShiftPlan
{
    public string Plan_Id { get; set; } = string.Empty;
    public string Shift_Id { get; set; } = string.Empty;
    public string Start_Time { get; set; } = string.Empty;
    public string End_Time { get; set; } = string.Empty;
    public int Changeover_Time_After { get; set; }
    public int Other_Times { get; set; }
    public int To_Produce { get; set; }
    public string Model_Name { get; set; } = string.Empty;
}

public class LineShiftTime
{
    public string Id { get; set; } = string.Empty;
    public string Shift_Name { get; set; } = string.Empty;
    public string Start { get; set; } = string.Empty;
    public string End { get; set; } = string.Empty;
    public string Shift_Owner { get; set; } = string.Empty;
    public string Line { get; set; } = string.Empty;
    public string UTC_Offset { get; set; } = string.Empty;
}

public class PipelineMachine
{
    public string Id { get; set; } = string.Empty;
    public string Line { get; set; } = string.Empty;
    public string Machine_Type { get; set; } = string.Empty;
    public string Previous_Machine_Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public int Preceding_Conveyor_Size { get; set; }
    public int Expected_Cycle_Time { get; set; }
}

public class MachineType
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public int Manufacturers_Cycle_Time { get; set; }
    public List<Issue> Breakdown_Issues { get; set; } = new();
    public List<Issue> Microstop_Issues { get; set; } = new();
    public List<Issue> Quality_Issues { get; set; } = new();
}

public class Line
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Plant { get; set; } = string.Empty;
    public string Details_File { get; set; } = string.Empty;
}

public class Issue
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}

public class Model
{
    public string ModelName { get; set; } = string.Empty;
    public int ChangeoverTime { get; set; }
}