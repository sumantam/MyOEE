const fs = require("fs");
let realTimeData = JSON.parse(fs.readFileSync("data/real_time_machine_data.json", "utf8"));
let eventData = JSON.parse(fs.readFileSync("data/forvia.json", "utf8"));

const setRealTimeData = (newValue) => {
    realTimeData = newValue;
};

const setEventData = (newValue) => {
    eventData = newValue;
}

const getRealTimeJsonData = () => realTimeData;
const getEventData = () =>  eventData;

module.exports = { setRealTimeData, getRealTimeJsonData, getEventData, setEventData };