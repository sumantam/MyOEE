DROP FUNCTION IF EXISTS get_operator;

CREATE OR REPLACE FUNCTION get_operator(userEmail VARCHAR)
RETURNS TABLE (
  operatorEmail VARCHAR(50)
) AS $$
DECLARE
  responsibility1 VARCHAR(50);
BEGIN
  -- Retrieve the responsibility of the user based on userEmail
  SELECT into responsibility1 "responsibility" FROM public."Users" WHERE "email" = userEmail;

  IF responsibility1 = 'Executive' THEN
    RETURN QUERY
    SELECT DISTINCT O."userEmail"
    FROM public."Relations" R1
    INNER JOIN public."Relations" R2 ON R1."managerEmail" = R2."userEmail"
    INNER JOIN public."Operators" O ON R1."userEmail" = O."userEmail"
    WHERE R2."managerEmail" = userEmail;

  ELSIF responsibility1 = 'Supervisor' THEN
    RETURN QUERY
    SELECT DISTINCT O."userEmail"
    FROM public."Relations" R1
    INNER JOIN public."Operators" O ON R1."userEmail" = O."userEmail"
    WHERE R1."managerEmail" = userEmail;

  ELSIF responsibility1 = 'Operator' THEN
    -- If the user is already an operator, return their own email
    RETURN QUERY
    SELECT userEmail;
  END IF;
END;
$$ LANGUAGE plpgsql;
