DROP FUNCTION IF EXISTS "getTable";
DROP FUNCTION IF EXISTS "fdwDbName";
DROP FUNCTION IF EXISTS "fdwDbExists";

CREATE OR REPLACE FUNCTION "getTable" (
    tableName VARCHAR,
    key VARCHAR,
    value VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS SETOF RECORD AS $$
DECLARE
    query TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = schemaName AND table_name = tableName) THEN
        query := format('SELECT %I FROM %I.%I WHERE %I = $1', key, schemaName, tableName, key);
        
        RETURN QUERY EXECUTE query USING value;
    ELSE
        RAISE NOTICE 'Table % does not exist.', tableName;
        RETURN;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Given the schemaName get the databaseName being foreign data wrapped.

CREATE OR REPLACE FUNCTION "fdwDbName" (
    schemaName  VARCHAR
)
RETURNS VARCHAR AS $$
DECLARE
    query TEXT;
    option TEXT;
    dbname VARCHAR;
    rec RECORD;
BEGIN
    query := format('
        SELECT unnest(srvoptions) AS option
        FROM pg_foreign_server
        WHERE oid = (SELECT ftserver
                    FROM pg_foreign_table ft
                    JOIN pg_class c ON c.oid = ft.ftrelid
                    JOIN pg_namespace n ON n.oid = c.relnamespace
                    WHERE n.nspname = %L
                    LIMIT 1)
        ', schemaName);

    RAISE NOTICE '%', query;

    FOR rec IN EXECUTE query LOOP
        RAISE NOTICE 'Option: %', rec.option;
        
        -- Extract the value part from the option
        IF rec.option LIKE 'dbname=%' THEN
            dbname := split_part(rec.option, '=', 2);
        END IF;
    END LOOP;

    RAISE NOTICE 'dbName: %', dbname;
    RETURN dbname;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION "fdwDbExists" (
    schemaName VARCHAR
)
RETURNS TABLE (result integer) AS $$
DECLARE
    dbName VARCHAR;
BEGIN
    dbName := "fdwDbName"(schemaName);
    RETURN QUERY
    SELECT 1
    FROM pg_database
    WHERE datname = dbName;
END;
$$ LANGUAGE plpgsql;
