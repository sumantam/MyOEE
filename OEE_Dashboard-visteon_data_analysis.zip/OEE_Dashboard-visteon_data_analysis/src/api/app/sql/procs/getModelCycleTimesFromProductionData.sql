DROP FUNCTION IF EXISTS getModelCycleTimesFromProductionData;

CREATE OR REPLACE FUNCTION getModelCycleTimesFromProductionData (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    modelName VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    Line_Id VARCHAR,
	Line_Name VARCHAR,
    Plant_Name VARCHAR,
    ActualCycleTime NUMERIC,
	StandardCycleTime NUMERIC,
	Model VARCHAR
)
AS $$
DECLARE
    command TEXT;
    ModelNames TEXT[];
	ZZZ TEXT;
BEGIN
    -- Prepare command to get ModelData
	IF modelName = 'ANY' OR modelName = 'Any' OR modelName = 'any'
	THEN
		command := format('select array_agg(modelname) from %I."Models";', userName); 
	ELSE
		command := format('select array_agg(modelname) from %I."Models" WHERE modelname=%L;', userName, modelName); 
	END IF;

	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO ModelNames;

    -- Check if Models is empty
    IF ModelNames IS NULL OR array_length(ModelNames, 1) IS NULL THEN
        RAISE NOTICE 'No Models found for the given parameters.';
        RETURN; -- Early exit if no Models
    END IF;

    command := format('
					SELECT
						a.plantname As Plant_name,
						a.line AS Line_Id,
						a.linename AS Line_Name,
						ROUND((SUM(EXTRACT(EPOCH FROM a.actualtime) - COALESCE(getBreakdownTimeForLineShiftId(a.prodshiftid, %L), 0)) / SUM(a.totalprodcount))::NUMERIC, 2)
							As Actual_CycleTime,
						COALESCE(b.cycletime, 0) AS Standard_CycleTime,
						c.ModelName AS Model
					FROM
						getDifferentProductionCountsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L) AS a
						JOIN %I."StdCycleTimes" b ON a.line = b.lineid
						JOIN %I."Models"c ON b.modelid = c.modelid
						JOIN %I."LineShiftPlans" d ON a.prodshiftid=d.id AND c.modelid=d.modelid
						WHERE c.ModelName = ANY($1)
						group by a.line, a.linename, a.plantname, c.ModelName, b.cycletime
						order by Line_Id, Standard_CycleTime, Model;',
				userName, 
				today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName, 
				userName, userName, userName
		);
    
	RAISE NOTICE 'Executing: %', command;
    RETURN QUERY EXECUTE command USING ModelNames;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error occurred: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;

