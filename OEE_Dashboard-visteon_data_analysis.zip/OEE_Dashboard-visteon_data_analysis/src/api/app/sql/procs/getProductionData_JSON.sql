DROP FUNCTION IF EXISTS getProductionData_JSON;

CREATE OR REPLACE FUNCTION getProductionData_JSON (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    modelName VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS json
LANGUAGE plpgsql
AS
$$
BEGIN
	RETURN json_build_object(
		'Plant_OEE_Data', (
			SELECT json_agg(
				json_build_object(
					'Plant', SPLIT_PART(a.plant_line, '##', 1),
					'Lines', (
						json_build_object(
							'Line_Id', a.line_id,
							'Line', SPLIT_PART(a.plant_line, '##', 2),
							'Ideal_Cycle_Time', a.idealcycletime,
							'Breakdown_Time', a.breakdowntime,
							'Planned_Production_Time', a.planned_production_time,
							'Availability', a.availability,
							'Changeover_Time', a.changeovertimeafter,
							'Total_Planned', a.total_planned,
							'Total', a.total,
							'Total_OK', a.total_ok,
							'Total_NG', a.total_ng,
							'Total_FTT', a.total_ftt,
							'Quality_Percentage', a.quality,
							'Performance_Percentage', a.performance,
							'BTS', CASE WHEN a.total > a.total_planned THEN 100.0 * (2 - a.total / a.total_planned) ELSE 100.0 * (a.total / a.total_planned) END,
							'OEE', a.availability * a.quality * a.performance / 100.0 / 100.0
						)
					)
				)
			)
			FROM getProductionData (today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, modelName, userName) AS a
		) 
	);
END;
$$;

