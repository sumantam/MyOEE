DROP FUNCTION IF EXISTS getLineAggregationRangeByLine;
DROP FUNCTION IF EXISTS getLineAggregationRangeByPlant;
DROP FUNCTION IF EXISTS getLineAggregationRange;
 
-- Function to get the Line based for the line whose name is given in Name
CREATE OR REPLACE FUNCTION getLineAggregationRangeByLine (
    Name VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public')
RETURNS TABLE (
    LineId VARCHAR,
	LineName VARCHAR,
	PlantName VARCHAR
)
AS $$
DECLARE
    command TEXT;
BEGIN
    command := format('WITH LineAndPlants AS (
            SELECT
                ml.lineId AS LineId,
                ml.linename AS LineName,
                mp.plantname AS PlantName
            FROM %I."Lines" AS ml
            JOIN %I."Plants" AS mp
            ON ml."locId" = mp.plantid
        )
        SELECT LineId, LineName, PlantName
        FROM LineAndPlants
		WHERE LineId = %L;', userName, userName, Name);

    -- Print the command
    RAISE NOTICE 'Executing: %', command;
    RETURN QUERY EXECUTE command;
END;
$$ LANGUAGE plpgsql;


-- Function to get the Plant based for the plant whose name is given in Name
CREATE OR REPLACE FUNCTION getLineAggregationRangeByPlant (
    Name VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    LineId VARCHAR,
	LineName VARCHAR,
	PlantName VARCHAR
)
AS $$
DECLARE
    command TEXT;
BEGIN

    command := format('WITH LineAndPlants AS (
            SELECT
                ml.lineId AS LineId,
                ml.linename AS LineName,
                mp.plantname AS PlantName
            FROM %I."Lines" AS ml
            JOIN %I."Plants" AS mp
            ON ml."locId" = mp.plantid
        )
        SELECT LineId, LineName, PlantName
        FROM LineAndPlants
		WHERE PlantName = %L;', userName, userName, Name);

    -- Print the command
    RAISE NOTICE 'Executing: %', command;
    RETURN QUERY EXECUTE command;
END;
$$ LANGUAGE plpgsql;



-- Function to get All Lines based on LineAggregationType
CREATE OR REPLACE FUNCTION getLineAggregationRange (
    LineAggregationType VARCHAR,
    LineAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    LineId VARCHAR,
	LineName VARCHAR,
	PlantName VARCHAR
)
AS $$
BEGIN
    CASE
        WHEN LineAggregationType = 'Line' THEN
            RETURN QUERY SELECT * FROM getLineAggregationRangeByLine(LineAggregationValue, userName, schemaName);
        WHEN LineAggregationType = 'Plant' THEN
            RETURN QUERY SELECT * FROM getLineAggregationRangeByPlant(LineAggregationValue, userName, schemaName);
    END CASE;
END;
$$ LANGUAGE plpgsql;
