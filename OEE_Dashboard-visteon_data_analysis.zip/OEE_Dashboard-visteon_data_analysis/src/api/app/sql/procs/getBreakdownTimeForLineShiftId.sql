DROP FUNCTION IF EXISTS getBreakdownTimeForLineShiftId;

CREATE OR REPLACE FUNCTION getBreakdownTimeForLineShiftId(
	lineshiftid VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS REAL
LANGUAGE plpgsql
AS
$$
DECLARE
    command TEXT;
	retVal REAL;
BEGIN
	command := format('
		SELECT GREATEST(0, (EXTRACT(EPOCH FROM LEAST(c.totime, a.changeoverendtime) - GREATEST(c.fromtime, min(b.entrymachinetimestamp))) + 1)) AS BDTIME
		FROM %I."Shifts" a 
		JOIN %I."Runs" b on a.lineshiftplanid=b.prodshiftid
		JOIN %I."Breakdowns" c on a.shiftid=c.shiftid
		WHERE a.lineshiftplanid = %L 
		GROUP BY a.shiftid, a.changeoverendtime, c.fromtime, c.totime;', userName, userName, userName, lineshiftid);
--	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO retVal;
	RETURN retVal;
END;
$$;
