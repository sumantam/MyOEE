DROP TYPE IF EXISTS Production_Counts;
CREATE TYPE Production_Counts AS (
    Planned	INTEGER,
    Total	INTEGER,
    Total_OK	INTEGER,
    Total_NG	INTEGER,
    Total_FTT	INTEGER
);

DROP FUNCTION IF EXISTS getProductionCountsForLineShiftId;
CREATE OR REPLACE FUNCTION getProductionCountsForLineShiftId(
	lineshiftid VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS VARCHAR
LANGUAGE plpgsql
AS
$$
DECLARE
    command TEXT;
	retVal Production_Counts;
BEGIN
	retVal.Planned = -1;
	retVal.Total = -1;
	retVal.Total_OK = -1;
	retVal.Total_NG = -1;
	retVal.Total_FTT = -1;
	command := format('
		SELECT toproduce 
		FROM %I."LineShiftPlans"
		WHERE id = %L;', userName, lineshiftid);
--	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO retVal.Planned;
	command := format('
		SELECT COUNT(*) 
		FROM %I."Runs"
		WHERE prodshiftid = %L;', userName, lineshiftid);
--	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO retVal.Total;
	command := format('
		SELECT COUNT(*) 
		FROM %I."Runs"
		WHERE prodshiftid = %L AND status=%L;', userName, lineshiftid, 'OK');
--	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO retVal.Total_OK;
	command := format('
		SELECT COUNT(*) 
		FROM %I."Runs"
		WHERE prodshiftid = %L AND status=%L;', userName, lineshiftid, 'NG');
--	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO retVal.Total_NG;
	command := format('
		SELECT COUNT(*) 
		FROM %I."Runs"
		WHERE prodshiftid = %L AND runnumber=0 AND status=%L;', userName, lineshiftid, 'OK');
--	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO retVal.Total_FTT;
	RETURN retVal;
END;
$$;
