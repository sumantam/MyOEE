DROP FUNCTION IF EXISTS getBreakdownActionsForTimeRangeAndLineAggregation;

CREATE OR REPLACE FUNCTION getBreakdownActionsForTimeRangeAndLineAggregation(
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
--c.lineid, c.machinename, COALESCE(EXTRACT(epoch from SUM(a.totime-a.fromtime)) + 1, 2) As Duration, b.rootcause, b.description, a.actiontime
RETURNS TABLE (
	LineId VARCHAR,
    MachineName VARCHAR,
    Duration NUMERIC,
    Issue VARCHAR,
	RootCause VARCHAR,
    Description VARCHAR,
	ActionTime TIMESTAMP WITH TIME ZONE
)
AS $$
DECLARE
    lineId TEXT[];
    startTime TIMESTAMP WITH TIME ZONE;
    endTime TIMESTAMP WITH TIME ZONE;
    query TEXT;
BEGIN
    -- Retrieve LineId based on line aggregation
    query := format(
        'SELECT array_agg(lineid) FROM getlineaggregationrange(%L, %L, %L);',
        lineAggregationType, lineAggregationValue, userName
    );

    RAISE NOTICE 'Executing %', query;
	
	EXECUTE query INTO lineId;

    -- Retrieve start and end times for the time range
    query := format(
        'SELECT datetime_1, datetime_2 FROM getTimeRange(%L, %L, %L, %L);',
        userName, today, timeAggregationType, timeAggregationValue
    );

	RAISE NOTICE 'Executing %', query;

    EXECUTE query INTO startTime, endTime;

	-- Check if lineId is empty
    IF lineId IS NULL OR array_length(lineId, 1) IS NULL THEN
        RAISE NOTICE 'No LineIds found.';
        RETURN;  -- Early exit if no LineIds
    END IF;


    -- Return Breakdown Actions that fall within the specified time range
    query := format('
			SELECT  
				c.lineid AS LineId, 
				c.machinename AS MachineName, 
				COALESCE(EXTRACT(epoch from SUM(a.totime-a.fromtime)) + 1, 2) As Duration, 
				a.issue AS Issue,
				b.rootcause AS RootCause, 
				b.description AS Description, 
				a.actiontime AS ActionTime
			FROM %I."Breakdowns" a
			JOIN %I."DowntimeReasons" b on a.downtimereasonid=b.downtimereasonid and a.action=b.actionid
			JOIN %I."MachinesInPipeline" c on a.machinesinpipelineid=c.id 
			WHERE (a.fromtime, a.totime) overlaps (%L, %L) AND c.lineid = ANY($1)
			GROUP BY c.lineid, c.machinename, b.rootcause, b.description, a.actiontime, a.issue;',
        userName, userName, userName, startTime, endTime
    );
    
	RAISE NOTICE 'Executing %', query;

    RETURN QUERY EXECUTE query USING lineId;
END;
$$ LANGUAGE plpgsql;
