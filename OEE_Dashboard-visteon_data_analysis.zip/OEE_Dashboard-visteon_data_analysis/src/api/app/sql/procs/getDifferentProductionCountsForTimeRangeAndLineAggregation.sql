DROP FUNCTION IF EXISTS public.getDifferentProductionCountsforTimeRangeAndLineAggregation;
 
CREATE OR REPLACE FUNCTION public.getDifferentProductionCountsforTimeRangeAndLineAggregation(
	today TIMESTAMP WITH TIME ZONE,
	lineaggregationtype VARCHAR,
	lineaggregationvalue VARCHAR,
	timeaggregationtype VARCHAR,
	timeaggregationvalue VARCHAR,
	username VARCHAR,
	schemaname VARCHAR DEFAULT 'public'::VARCHAR)
    RETURNS TABLE(
		shiftid VARCHAR, 
		prodshiftid VARCHAR, 
		plannedcount INT, 
		totalprodcount INT, 
		goodprodcount INT, 
		notgoodprodcount INT, 
		firsttimethroughcount INT, 
		actualtime INTERVAL, 
		changeoverstarttime TIMESTAMP WITH TIME ZONE, 
		changeoverendtime TIMESTAMP WITH TIME ZONE, 
		line VARCHAR, 
		linename VARCHAR, 
		plantname VARCHAR
) 
AS $$
DECLARE
	temp_table_name TEXT;
    command TEXT;
    retcommand TEXT;
    LineShiftPlanIds TEXT[];
    lTotalProductionCount INT;
    lGoodProductionCount INT;
    lNotGoodProductionCount INT;
    lFirstTimeThroughCount INT;
    lChangeoverStartTime TIMESTAMP WITH TIME ZONE;
    ChangeoverEndTime TIMESTAMP WITH TIME ZONE;
BEGIN
 
    -- Generate a random 5-character string
    temp_table_name := 'temp_production_counts_' || substring(md5(random()::text), 1, 5);
 
	-- Dynamically create the temporary table with the generated name
    EXECUTE format('CREATE TEMPORARY TABLE %I (
        shiftid VARCHAR,
        prodshiftid VARCHAR,
        plannedcount INT,
        totalprodcount INT,
        goodprodcount INT,
        notgoodprodcount INT,
        firsttimethroughcount INT,
        actualtime  INTERVAL,
        changeoverstarttime TIMESTAMP WITH TIME ZONE,
        changeoverendtime TIMESTAMP WITH TIME ZONE,
        line VARCHAR,
        lineName VARCHAR,
        plantName VARCHAR
    ) ON COMMIT DROP;', temp_table_name);
    command := format('
        INSERT INTO %I (
            shiftid,
            prodshiftid,
            plannedcount,
            totalprodcount,
            goodprodcount,
            notgoodprodcount,
            firsttimethroughcount,
            actualtime,
            changeoverstarttime,
            changeoverendtime,
            line,
            linename,
            plantname
        )
        SELECT
            s.shiftid,
            r.prodshiftid,
            t.toproduce,
            COUNT(DISTINCT r.barcode) AS totalprodcount,
            COUNT(DISTINCT CASE WHEN r.status = %L THEN r.barcode END) AS goodprodcount,
            COUNT(DISTINCT CASE WHEN r.status = %L THEN r.barcode END) AS notgoodprodcount,
            COUNT(DISTINCT CASE WHEN r.status = %L AND r.runnumber = 0 THEN r.barcode END) AS firsttimethroughcount,
			MAX(r.exitmachinetimestamp) - MIN(r.entrymachinetimestamp) AS actualtime,
            s.changeoverstarttime,
            s.changeoverendtime,
            u.line,
            u.linename,
            u.plantname
        FROM %I."Runs" r
        LEFT JOIN %I."Shifts" s
        ON r.prodshiftid = s.lineshiftplanid
        LEFT JOIN %I."LineShiftPlans" t
        ON r.prodshiftid = t.id
        INNER JOIN (
            SELECT id, line, linename, plantname FROM
            getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L)
        ) u ON u.id = r.prodshiftid
        GROUP BY
        s.shiftid,
        r.prodshiftid,
        s.changeoverstarttime,
        s.changeoverendtime,
        t.toproduce,
        u.line,
        u.linename,
        u.plantname
        ;',
		temp_table_name,
        'OK',
        'NG',
        'OK',
--        userName,
        userName,
        userName,
        userName,
        today,
        lineAggregationType,
        lineAggregationValue,
        timeAggregationType,
        timeAggregationValue,
        userName
    );
 
    RAISE NOTICE 'Executing: %', command;
    EXECUTE command;
    RETURN QUERY
        EXECUTE format('SELECT * FROM %I', temp_table_name);
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error occurred: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;
