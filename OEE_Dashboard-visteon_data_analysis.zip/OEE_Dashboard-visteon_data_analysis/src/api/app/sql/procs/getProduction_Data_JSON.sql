DROP FUNCTION IF EXISTS getProduction_Data;

CREATE OR REPLACE FUNCTION getProduction_Data (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS json
LANGUAGE plpgsql
AS
$$
DECLARE
row_data RECORD;
Production_Data json[];
BEGIN
	FOR row_data IN SELECT * FROM
		getDifferentProductionCountsForTimeRangeAndLineAggregation (
		today,
		lineAggregationType,
		lineAggregationValue,
		timeAggregationType,
		timeAggregationValue,
		userName
	)
	ORDER BY
		changeoverstarttime, shiftid, prodshiftid 
	LOOP
		-- Access fields of the current row
		Production_Data := Production_Data || 
			json_build_object(
				'Plant', row_data.plantname,
				'Line', row_data.linename,
				'Shift_Id', row_data.shiftid,
				'Line_Shift_Plan_Id', row_data.prodshiftid,
				'Actual_Time', row_data.actualtime,
				'Changeover_Time_Start', row_data.changeoverstarttime,
				'Changeover_Time_End', row_data.changeoverendtime,
				'Planned', row_data.plannedcount,
				'Total', row_data.totalprodcount,
				'Total_OK', row_data.goodprodcount,
				'Total_NG', row_data.notgoodprodcount,
				'Total_FTT', row_data.firsttimethroughcount
			);
	END LOOP;

	return json_agg(Production_Data);
END;
$$;

