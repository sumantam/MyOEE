DROP FUNCTION IF EXISTS getTypeNameAndChangeoverTimesForModelPair;
DROP FUNCTION IF EXISTS getCOTypesAndActualCOTimesForTimeRangeAndLineAggregation;
DROP FUNCTION IF EXISTS getCOTypesAndCOTimesTrendForTimeRangeAndLineAggregation;

CREATE OR REPLACE FUNCTION getTypeNameAndChangeoverTimesForModelPair(
	fromModel VARCHAR,
	toModel VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE
(
	ChangeoverType VARCHAR,
	ChangeoverTime NUMERIC
)
LANGUAGE plpgsql
AS
$$
DECLARE
    command TEXT;
BEGIN
	command := format('
		select
			a.changeovertype,
			b.changeovertime::NUMERIC
			FROM %I."ChangeOverTypes" a
			JOIN %I."ChangeOverTypeTimes" b
			ON a.changeovertype=b.changeovertype
			WHERE a.frommodel=%L AND a.tomodel=%L;', userName, userName, fromModel, toModel);
	RAISE NOTICE 'Executing: %', command;
	RETURN QUERY EXECUTE command;
END;
$$;



CREATE OR REPLACE FUNCTION getCOTypesAndActualCOTimesForTimeRangeAndLineAggregation(
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
	PlantName VARCHAR,
    Line VARCHAR,
	LineName VARCHAR,
	Model VARCHAR,
	NextModel VARCHAR,
	Changeover NUMERIC,
	changeovertype VARCHAR,
	changeovertime NUMERIC
)
LANGUAGE plpgsql
AS
$$
DECLARE
    command TEXT;
    ShiftIds TEXT[];
    ShiftPlanIds TEXT[];
BEGIN
    -- Prepare command to get ShiftIds
    command := format('SELECT array_agg(Id) FROM getShiftIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L);',
        today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
    
--	RAISE NOTICE 'Executing: %', command;

    EXECUTE command INTO ShiftIds;
	
    -- Prepare command to get ShiftIds
	command := format('SELECT array_agg(a.id) FROM %I."LineShiftPlans" a WHERE a.shiftid = ANY($1);', userName);

--    RAISE NOTICE 'Executing: %', command;	

    EXECUTE command INTO ShiftPlanIds USING ShiftIds;
	
	command := format('
		SELECT
			plantname,
			line,
			linename,
			getModelNameForLineShiftId(prodshiftid, %L) AS Model, 
			LEAD(getModelNameForLineShiftId(prodshiftid, %L)) OVER (ORDER BY plantname, line, changeoverstarttime) AS NextModel,
			EXTRACT(epoch FROM changeoverendtime - changeoverstarttime) AS Changeover,
			changeovertype,
			changeovertime
		FROM (
			SELECT
				a.plant AS plantname,
				a.line AS line,
				a.linename As linename,
				a.prodshiftid as prodshiftid,
				changeoverstarttime,
				changeoverendtime,
				getModelNameForLineShiftId(prodshiftid, %L) AS current_model,
				LEAD(getModelNameForLineShiftId(prodshiftid, %L)) OVER (ORDER BY a.plant, line, changeoverstarttime) AS next_model
			FROM %I."RunSummary" AS a
			WHERE a.prodshiftid = ANY($1)
		) subquery
		LEFT JOIN LATERAL (
			SELECT
				changeovertype,
				changeovertime
			FROM getTypeNameAndChangeoverTimesForModelPair(subquery.current_model, subquery.next_model, %L)
		) AS changeover_data ON TRUE
		ORDER BY plantname, line, changeoverstarttime;
		',
		userName,
		userName,
		userName,
		userName,
		userName,
		userName
	);
	
--	RAISE NOTICE 'Executing: %', command;
	RETURN QUERY EXECUTE command USING ShiftPlanIds;
END;
$$;


CREATE OR REPLACE FUNCTION getCOTypesAndCOTimesTrendForTimeRangeAndLineAggregation(
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
	TimeWhen VARCHAR,
	PlantName VARCHAR,
    Line VARCHAR,
	LineName VARCHAR,
	Model VARCHAR,
	NextModel VARCHAR,
	Changeover NUMERIC,
	changeovertype VARCHAR,
	changeovertime NUMERIC
	)
AS $$
DECLARE
	temp_table_name TEXT;
    giventoday TIMESTAMP WITH TIME ZONE;
    yesterday TIMESTAMP WITH TIME ZONE;
	lid TEXT;
	lname TEXT;
	pname TEXT;
    command TEXT;
BEGIN
	giventoday = today;
    -- Generate a random 5-character string
    temp_table_name := 'temp_changeover_prod_actual_' || substring(md5(random()::text), 1, 5);
 
	-- Dynamically create the temporary table with the generated name
	EXECUTE format('CREATE TEMPORARY TABLE %I (
		TimeWhen VARCHAR,
		PlantName VARCHAR,
		Line VARCHAR,
		LineName VARCHAR,
		Model VARCHAR,
		NextModel VARCHAR,
		Changeover NUMERIC,
		changeovertype VARCHAR,
		changeovertime NUMERIC
	) ON COMMIT DROP;', temp_table_name);

    CASE
        WHEN timeAggregationType = 'Shift' THEN
        WHEN timeAggregationType = 'Day' THEN
			FOR cnt IN 1..7 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Day';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(
					TimeWhen,
					PlantName,
					Line,
					LineName,
					Model,
					NextModel,
					Changeover,
					changeovertype,
					changeovertime
					) 
					(SELECT 
						%L AS TimeWhen, 
						PlantName,
						Line,
						LineName,
						Model,
						NextModel,
						Changeover,
						changeovertype,
						changeovertime
					from getCOTypesAndActualCOTimesForTimeRangeAndLineAggregation (%L, %L, %L, %L, %L, %L));',
					temp_table_name, DATE(yesterday), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
--				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Day';
			END LOOP;
        WHEN timeAggregationType = 'Week' THEN
			FOR cnt IN 1..8 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Week';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(
					TimeWhen,
					PlantName,
					Line,
					LineName,
					Model,
					NextModel,
					Changeover,
					changeovertype,
					changeovertime
					)
					(SELECT 
						%L AS TimeWhen,
						PlantName,
						Line,
						LineName,
						Model,
						NextModel,
						Changeover,
						changeovertype,
						changeovertime
					from getCOTypesAndActualCOTimesForTimeRangeAndLineAggregation (%L, %L, %L, %L, %L, %L));',
					temp_table_name, DATE(yesterday) || '--' || DATE(today), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
--				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Week';
			END LOOP;
        WHEN timeAggregationType = 'Month' THEN
			FOR cnt IN 1..12 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Month';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(
					TimeWhen,
					PlantName,
					Line,
					LineName,
					Model,
					NextModel,
					Changeover,
					changeovertype,
					changeovertime
					)
					(SELECT
						%L AS TimeWhen,
						PlantName,
						Line,
						LineName,
						Model,
						NextModel,
						Changeover,
						changeovertype,
						changeovertime
					from getCOTypesAndActualCOTimesForTimeRangeAndLineAggregation (%L, %L, %L, %L, %L, %L));',
					temp_table_name, DATE(yesterday) || '--' || DATE(today), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
--				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Month';
			END LOOP;
        WHEN timeAggregationType = 'Year' THEN
        ELSE
            RAISE EXCEPTION 'Invalid timeAggregationType: %', timeAggregationType;
    END CASE;

    RETURN QUERY
        EXECUTE format('SELECT * FROM %I', temp_table_name);
END;
$$ LANGUAGE plpgsql;
