DROP FUNCTION IF EXISTS getPlantLineDetailsForLineShiftId;

CREATE OR REPLACE FUNCTION getPlantLineDetailsForLineShiftId(
	lineshiftid VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE(
	prodshiftid VARCHAR, 
	plantname VARCHAR,
	line VARCHAR, 
	linename VARCHAR
) 
LANGUAGE plpgsql
AS
$$
DECLARE
    command TEXT;
BEGIN
	command := format('
		SELECT
			a.id AS prodshiftid,
			c.plantname AS plantname,
			s.line AS line,
			b.linename AS linename
		FROM %I."LineShiftPlans" a
		JOIN %I."LineShiftTimes" s
		ON a.shiftid=s.id
		JOIN %I."Lines" b
		ON b.lineid=s.line
		JOIN %I."Plants" c
		ON c.plantid=b."locId"
		WHERE a.id = %L;', userName, userName, userName, userName, lineshiftid);
	RAISE NOTICE 'Executing: %', command;
	RETURN QUERY EXECUTE command;
END;
$$;

