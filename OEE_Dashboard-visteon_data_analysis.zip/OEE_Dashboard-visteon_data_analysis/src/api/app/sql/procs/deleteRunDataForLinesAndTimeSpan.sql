DROP FUNCTION IF EXISTS deleteRunDataForLinesAndTimeSpan;

CREATE OR REPLACE FUNCTION deleteRunDataForLinesAndTimeSpan (
	today TIMESTAMP WITH TIME ZONE,
	lineAggregationType VARCHAR,
	lineAggregationValue VARCHAR,
	timeAggregationType VARCHAR,
	timeAggregationValue VARCHAR,
	span INT,
	userName VARCHAR,
	schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    Id VARCHAR
)
AS $$
DECLARE
    query TEXT;
	retVal INTEGER;
    lineId TEXT[];
    startTime TIMESTAMP WITH TIME ZONE;
    endTime TIMESTAMP WITH TIME ZONE;
BEGIN
    -- Retrieve LineId based on line aggregation
    query := format(
        'SELECT array_agg(lineid) FROM getlineaggregationrange(%L, %L, %L);',
        lineAggregationType, lineAggregationValue, userName
    );

    RAISE NOTICE 'Executing %', query;
	
	EXECUTE query INTO lineId;

    -- Retrieve start and end times for the time range
    query := format(
        'SELECT datetime_1, datetime_2 FROM getSpanForMultipleTimeRange(%L, %L, %L, %L, %L);',
        today, timeAggregationType, timeAggregationValue, span, userName
    );

	RAISE NOTICE 'Executing %', query;

    EXECUTE query INTO startTime, endTime;

    -- Return shifts that fall within the specified time range
    query := format('
		SELECT array_agg(id) FROM %I."LineShiftTimes"
        WHERE start >= %L AND start < %L AND Line = ANY($1);',
        userName, startTime, endTime
    );
    
	RAISE NOTICE 'Executing %', query;

    EXECUTE query USING lineId INTO lineId;

    -- Return shift-plans within the shifts
    query := format('
		SELECT id FROM %I."LineShiftPlans"
        WHERE shiftid = ANY($1);',
        userName
    );
    
	RAISE NOTICE 'Executing %', query;

    EXECUTE query USING lineId INTO lineId;

    -- Return runids within the runs
    query := format('
		SELECT id FROM %I."Runs"
        WHERE shiftid = ANY($1);',
        userName
    );
    
	RAISE NOTICE 'Executing %', query;

    EXECUTE query USING lineId INTO lineId;

    RETURN QUERY 
        EXECUTE query USING lineId;

    RETURN QUERY 
        EXECUTE query USING lineId;
	
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error occurred: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;

