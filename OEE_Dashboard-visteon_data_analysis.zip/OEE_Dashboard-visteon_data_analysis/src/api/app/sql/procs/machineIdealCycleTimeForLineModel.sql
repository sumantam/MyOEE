-- Drop existing function if it exists
DROP FUNCTION IF EXISTS getMachineIdealCycleTimeForLineModel;
-- Function to get Line Ideal Cycle Time
CREATE OR REPLACE FUNCTION getMachineIdealCycleTimeForLineModel (
    LineId VARCHAR,
    ModelName VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    Line VARCHAR,
    IdealCycleTime NUMERIC
)
AS $$
DECLARE
    command TEXT;
BEGIN
    command := format('SELECT
                ct.lineid AS LineId,
                cycletime AS IdealCycleTime
            FROM %I."StdCycleTimes" ct
			WHERE ct.lineId = %L AND ct.model=%L;', userName, LineId, ModelName);

    RETURN QUERY EXECUTE command;
END;
$$ LANGUAGE plpgsql;
