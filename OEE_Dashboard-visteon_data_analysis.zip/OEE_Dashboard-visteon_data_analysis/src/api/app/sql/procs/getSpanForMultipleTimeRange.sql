DROP FUNCTION IF EXISTS getSpanForMultipleTimeRange;

CREATE OR REPLACE FUNCTION getSpanForMultipleTimeRange(
    today TIMESTAMP WITH TIME ZONE,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
	span INT,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    dateTime_1 TIMESTAMP WITH TIME ZONE,
    dateTime_2 TIMESTAMP WITH TIME ZONE
)
AS $$
DECLARE
    startTime TIMESTAMP WITH TIME ZONE;
    endTime TIMESTAMP WITH TIME ZONE;
    query TEXT;
BEGIN
    -- Retrieve start and end times for the time range
    query := format(
        'SELECT datetime_1, datetime_2 FROM getTimeRange(%L, %L, %L, %L);',
        userName, today, timeAggregationType, timeAggregationValue
    );

	RAISE NOTICE 'Executing %', query;

    EXECUTE query INTO startTime, endTime;
	
	FOR cnt IN 1..Span LOOP
		CASE
			WHEN timeAggregationType = 'Shift' THEN
			WHEN timeAggregationType = 'Day' THEN
				startTime = startTime - INTERVAL '1 Day';
			WHEN timeAggregationType = 'Week' THEN
				startTime = startTime - INTERVAL '1 Week';
			WHEN timeAggregationType = 'Month' THEN
				startTime = startTime - INTERVAL '1 Month';
			WHEN timeAggregationType = 'Year' THEN
				startTime = startTime - INTERVAL '1 Year';
			ELSE
				RAISE EXCEPTION 'Invalid timeAggregationType: %', timeAggregationType;
		END CASE;
	END LOOP;
	

    -- Return the calculated time range
    RETURN QUERY SELECT startTime, endTime;
END;
$$ LANGUAGE plpgsql;
