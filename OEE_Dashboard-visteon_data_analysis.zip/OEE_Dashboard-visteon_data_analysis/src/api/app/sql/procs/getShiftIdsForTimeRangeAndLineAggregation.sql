DROP FUNCTION IF EXISTS getShiftIdsForTimeRangeAndLineAggregation;

CREATE OR REPLACE FUNCTION getShiftIdsForTimeRangeAndLineAggregation(
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
	Id VARCHAR,
    ShiftName VARCHAR,
    LineId VARCHAR
)
AS $$
DECLARE
    lineId TEXT[];
    startTime TIMESTAMP WITH TIME ZONE;
    endTime TIMESTAMP WITH TIME ZONE;
    query TEXT;
BEGIN
    -- Retrieve LineId based on line aggregation
    query := format(
        'SELECT array_agg(lineid) FROM getlineaggregationrange(%L, %L, %L);',
        lineAggregationType, lineAggregationValue, userName
    );

    RAISE NOTICE 'Executing %', query;
	
	EXECUTE query INTO lineId;

    -- Retrieve start and end times for the time range
    query := format(
        'SELECT datetime_1, datetime_2 FROM getTimeRange(%L, %L, %L, %L);',
        userName, today, timeAggregationType, timeAggregationValue
    );

	RAISE NOTICE 'Executing %', query;

    EXECUTE query INTO startTime, endTime;

	-- Check if lineId is empty
    IF lineId IS NULL OR array_length(lineId, 1) IS NULL THEN
        RAISE NOTICE 'No LineIds found.';
        RETURN;  -- Early exit if no LineIds
    END IF;

    -- Return shifts that fall within the specified time range
    query := format('
		SELECT
		Id AS ShiftId,
		ShiftName AS ShiftName,
		Line AS LineId
		FROM %I."LineShiftTimes"
        WHERE start >= %L AND start < %L AND Line = ANY($1);',
        userName, startTime, endTime
    );
    
	RAISE NOTICE 'Executing %', query;

    RETURN QUERY EXECUTE query USING lineId;
END;
$$ LANGUAGE plpgsql;
