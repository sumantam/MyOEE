DROP FUNCTION IF EXISTS getMicrostopTimes;

CREATE OR REPLACE FUNCTION getMicrostopTimes (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    TimeWhen VARCHAR,
    LineName VARCHAR,
	MachineId VARCHAR,
    MachineName VARCHAR,
    Microstop REAL,
	Issue VARCHAR
)
AS $$
DECLARE
	temp_table_name TEXT;
    yesterday TIMESTAMP WITH TIME ZONE;
    command TEXT;
BEGIN
    -- Generate a random 5-character string
    temp_table_name := 'ReturnTable_' || substring(md5(random()::text), 1, 5);

	-- Dynamically create the temporary table with the generated name
    EXECUTE format('CREATE TEMPORARY TABLE %I (
		TimeWhen VARCHAR,
		LineName VARCHAR,
		MachineId VARCHAR,
		MachineName VARCHAR,
		Microstop REAL,
		Issue VARCHAR
	) ON COMMIT DROP;', temp_table_name);

    CASE
        WHEN timeAggregationType = 'Shift' THEN
        WHEN timeAggregationType = 'Day' THEN
			FOR cnt IN 1..7 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Day';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(TimeWhen, LineName, MachineId, MachineName, Microstop, Issue) 
					(SELECT 
						%L AS TimeWhen, 
						getLineNameForLineId(b.lineid, %L) AS LineName, 
						b.id AS MachineId,
						b.machinename As MachineName, 
						COALESCE(EXTRACT(%L from SUM(a.totime-a.fromtime)), 0), a.issue
					from %I."Microstops" a
					join %I."MachinesInPipeline" b
					on a.machinesinpipelineid = b.id
					WHERE b.lineid in (Select lineid from getlineaggregationrange(%L, %L, %L))
						and (a.fromtime, a.totime) overlaps (%L, %L)
					group by b.lineid, b.machinename, b.id, a.issue);', temp_table_name,
					DATE(yesterday), userName, 'epoch', userName, userName, lineAggregationType, lineAggregationValue, userName, yesterday, today);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Day';
			END LOOP;
        WHEN timeAggregationType = 'Week' THEN
			FOR cnt IN 1..8 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Week';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(TimeWhen, LineName, MachineId, MachineName, Microstop, Issue) 
					(SELECT 
						%L AS TimeWhen, 
						getLineNameForLineId(b.lineid, %L) AS LineName, 
						b.id AS MachineId,
						b.machinename As MachineName, 
						COALESCE(EXTRACT(%L from SUM(a.totime-a.fromtime)), 0), a.issue
					from %I."Microstops" a
					join %I."MachinesInPipeline" b
					on a.machinesinpipelineid = b.id
					WHERE b.lineid in (Select lineid from getlineaggregationrange(%L, %L, %L))
						and (a.fromtime, a.totime) overlaps (%L, %L)
					group by b.lineid, b.machinename, b.id, a.issue);', temp_table_name,
					DATE(yesterday) || '--' || DATE(today), userName, 'epoch', userName, userName, lineAggregationType, lineAggregationValue, userName, yesterday, today);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Week';
			END LOOP;
        WHEN timeAggregationType = 'Month' THEN
			FOR cnt IN 1..12 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Month';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(TimeWhen, LineName, MachineId, MachineName, Microstop, Issue) 
					(SELECT 
						%L AS TimeWhen, 
						getLineNameForLineId(b.lineid, %L) AS LineName, 
						b.id AS MachineId,
						b.machinename As MachineName, 
						COALESCE(EXTRACT(%L from SUM(a.totime-a.fromtime)), 0), a.issue
					from %I."Microstops" a
					join %I."MachinesInPipeline" b
					on a.machinesinpipelineid = b.id
					WHERE b.lineid in (Select lineid from getlineaggregationrange(%L, %L, %L))
						and (a.fromtime, a.totime) overlaps (%L, %L)
					group by b.lineid, b.machinename, b.id, a.issue);', temp_table_name,
					DATE(yesterday) || '--' || DATE(today), userName, 'epoch', userName, userName, lineAggregationType, lineAggregationValue, userName, yesterday, today);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Month';
			END LOOP;
        WHEN timeAggregationType = 'Year' THEN
        ELSE
            RAISE EXCEPTION 'Invalid timeAggregationType: %', timeAggregationType;
    END CASE;

	

    RETURN QUERY
		EXECUTE format('SELECT * FROM %I', temp_table_name);	
END;
$$ LANGUAGE plpgsql;

