DROP FUNCTION IF EXISTS getBreakdownTimes;

CREATE OR REPLACE FUNCTION getBreakdownTimes (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    TimeWhen VARCHAR,
    LineName VARCHAR,
	MachineId VARCHAR,
    MachineName VARCHAR,
    Breakdown REAL,
	Issue	VARCHAR
)
AS $$
DECLARE
    yesterday TIMESTAMP WITH TIME ZONE;
    command TEXT;
BEGIN
	CREATE TEMPORARY TABLE ReturnTable (
		TimeWhen VARCHAR,
		LineName VARCHAR,
		MachineId VARCHAR,
		MachineName VARCHAR,
		Breakdown REAL,
		Issue VARCHAR
	) ON COMMIT DROP;

    CASE
        WHEN timeAggregationType = 'Shift' THEN
        WHEN timeAggregationType = 'Day' THEN
			FOR cnt IN 1..7 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Day';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO ReturnTable(TimeWhen, LineName, MachineId, MachineName, Breakdown, Issue) 
					(SELECT 
						%L AS TimeWhen, 
						getLineNameForLineId(b.lineid, %L) AS LineName,
						b.id As MachineId,
						b.machinename As MachineName, 
						COALESCE(EXTRACT(%L from SUM(a.totime-a.fromtime)) + 1, 0), a.issue 
					from %I."Breakdowns" a
					join %I."MachinesInPipeline" b
					on a.machinesinpipelineid = b.id
					WHERE b.lineid in (Select lineid from getlineaggregationrange(%L, %L, %L))
						and (a.fromtime, a.totime) overlaps (%L, %L)
					group by b.lineid, b.machinename, b.id, issue);',
					DATE(yesterday), userName, 'epoch', userName, userName, lineAggregationType, lineAggregationValue, userName, yesterday, today);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Day';
			END LOOP;
        WHEN timeAggregationType = 'Week' THEN
			FOR cnt IN 1..8 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Week';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO ReturnTable(TimeWhen, LineName, MachineId, MachineName, Breakdown, Issue) 
					(SELECT 
						%L AS TimeWhen, 
						getLineNameForLineId(b.lineid, %L) AS LineName, 
						b.id As MachineId,
						b.machinename As MachineName, 
						COALESCE(EXTRACT(%L from SUM(a.totime-a.fromtime)) + 1, 0), a.issue 
					from %I."Breakdowns" a
					join %I."MachinesInPipeline" b
					on a.machinesinpipelineid = b.id
					WHERE b.lineid in (Select lineid from getlineaggregationrange(%L, %L, %L))
						and (a.fromtime, a.totime) overlaps (%L, %L)
					group by b.lineid, b.machinename, b.id, a.issue);',
					DATE(yesterday) || '--' || DATE(today), userName, 'epoch', userName, userName, lineAggregationType, lineAggregationValue, userName, yesterday, today);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Week';
			END LOOP;
        WHEN timeAggregationType = 'Month' THEN
			FOR cnt IN 1..12 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Month';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO ReturnTable(TimeWhen, LineName, MachineId, MachineName, Breakdown, Issue) 
					(SELECT 
						%L AS TimeWhen, 
						getLineNameForLineId(b.lineid, %L) AS LineName, 
						b.id As MachineId,
						b.machinename As MachineName, 
						COALESCE(EXTRACT(%L from SUM(a.totime-a.fromtime)) + 1, 0), a.issue
					from %I."Breakdowns" a
					join %I."MachinesInPipeline" b
					on a.machinesinpipelineid = b.id
					WHERE b.lineid in (Select lineid from getlineaggregationrange(%L, %L, %L))
						and (a.fromtime, a.totime) overlaps (%L, %L)
					group by b.lineid, b.machinename, b.id, a.issue);',
					DATE(yesterday) || '--' || DATE(today), userName, 'epoch', userName, userName, lineAggregationType, lineAggregationValue, userName, yesterday, today);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Month';
			END LOOP;
        WHEN timeAggregationType = 'Year' THEN
        ELSE
            RAISE EXCEPTION 'Invalid timeAggregationType: %', timeAggregationType;
    END CASE;

	

    RETURN QUERY
        SELECT *  FROM ReturnTable;
	
END;
$$ LANGUAGE plpgsql;

