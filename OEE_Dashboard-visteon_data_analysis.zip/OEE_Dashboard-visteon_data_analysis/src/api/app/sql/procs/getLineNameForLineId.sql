DROP FUNCTION IF EXISTS getLineNameForLineId;

CREATE OR REPLACE FUNCTION getLineNameForLineId(
	lineid VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS VARCHAR
LANGUAGE plpgsql
AS
$$
DECLARE
    command TEXT;
	retVal TEXT;
BEGIN
	command := format('
		SELECT linename 
		FROM %I."Lines" 
		WHERE lineid = %L;', userName, lineid);
	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO retVal;
	RETURN retVal;
END;
$$;
