DROP FUNCTION IF EXISTS getModelCountsForTimeRangeAndLineAggregation;

CREATE OR REPLACE FUNCTION getModelCountsForTimeRangeAndLineAggregation(
	today TIMESTAMP WITH TIME ZONE,
	lineaggregationtype VARCHAR,
	lineaggregationvalue VARCHAR,
	timeaggregationtype VARCHAR,
	timeaggregationvalue VARCHAR,
	username VARCHAR,
	schemaname VARCHAR DEFAULT 'public'::VARCHAR)
    RETURNS TABLE(
		modelname VARCHAR,
		plannedcount INT, 
		totalprodcount INT, 
		goodprodcount INT, 
		notgoodprodcount INT, 
		firsttimethroughcount INT
) 
AS $$
DECLARE
    command TEXT;
    ShiftIds TEXT[];
    ShiftPlanIds TEXT[];
BEGIN
 
    -- Prepare command to get ShiftIds
    command := format('SELECT array_agg(Id) FROM getShiftIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L);',
        today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
    
--	RAISE NOTICE 'Executing: %', command;

    EXECUTE command INTO ShiftIds;
	
    -- Prepare command to get ShiftIds
	command := format('SELECT array_agg(a.id) FROM %I."LineShiftPlans" a WHERE a.shiftid = ANY($1);', userName);

    RAISE NOTICE 'Executing: %', command;	

    EXECUTE command INTO ShiftPlanIds USING ShiftIds;
 
	command := format('
		SELECT m.modelname, SUM(rs.toproduce)::INT, SUM(rs.totalcount)::INT, SUM(rs.okcount)::INT, SUM(rs.ngcount)::INT, SUM(rs.fttcount)::INT 
		FROM %I."RunSummary" rs
		JOIN %I."LineShiftPlans" ls ON ls.id=rs.prodshiftid
		JOIN %I."Models" m on  ls.modelid = m.modelid
		WHERE rs.prodshiftid = ANY($1) GROUP BY m.modelname;', 
			userName, userName, userName);
			
	RAISE NOTICE 'Executing: %', command;			
    RETURN QUERY EXECUTE command USING ShiftPlanIds;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error occurred: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;
