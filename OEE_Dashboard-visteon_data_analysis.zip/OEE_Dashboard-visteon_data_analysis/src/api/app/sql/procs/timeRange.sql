DROP FUNCTION IF EXISTS getTimeRange;

CREATE OR REPLACE FUNCTION getTimeRange (
    userName VARCHAR,
    today TIMESTAMP WITH TIME ZONE,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR DEFAULT 'None',
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    dateTime_1 TIMESTAMP WITH TIME ZONE,
    dateTime_2 TIMESTAMP WITH TIME ZONE
)
AS $$
DECLARE
    t1 TIMESTAMP WITH TIME ZONE;
    t2 TIMESTAMP WITH TIME ZONE;
BEGIN
    -- Start of the time range (default to 18 hours before the current day)
    t1 = date_trunc('day', today) - INTERVAL '18 hours' + INTERVAL '24 hours';
    t2 = t1;

    -- Handle different time aggregation types
    CASE
        WHEN timeAggregationType = 'Shift' THEN
            IF timeAggregationValue = 'A' THEN
                -- Do nothing, t1 is already set
            ELSIF timeAggregationValue = 'B' THEN
                t1 = t1 + INTERVAL '8 hours';
            ELSIF timeAggregationValue = 'C' THEN
                t1 = t1 + INTERVAL '16 hours';
            END IF;
            t2 = t1 + INTERVAL '8 hours';

        WHEN timeAggregationType = 'Day' THEN
            t1 = t1 - INTERVAL '1 day';

        WHEN timeAggregationType = 'Week' THEN
            t1 = t1 - INTERVAL '7 days';

        WHEN timeAggregationType = 'Month' THEN
            t1 = t1 - INTERVAL '1 month';

        WHEN timeAggregationType = 'Year' THEN
            t1 = t1 - INTERVAL '1 year';

        ELSE
            RAISE EXCEPTION 'Invalid timeAggregationType: %', timeAggregationType;
    END CASE;

    -- Return the calculated time range
    RETURN QUERY SELECT t1, t2;
END;
$$ LANGUAGE plpgsql;
