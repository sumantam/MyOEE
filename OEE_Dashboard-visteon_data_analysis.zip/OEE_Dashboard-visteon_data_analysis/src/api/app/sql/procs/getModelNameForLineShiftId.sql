DROP FUNCTION IF EXISTS getModelNameForLineShiftId;

CREATE OR REPLACE FUNCTION getModelNameForLineShiftId(
	lineshiftid VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS VARCHAR
LANGUAGE plpgsql
AS
$$
DECLARE
    command TEXT;
	retVal TEXT;
BEGIN
	command := format('
		SELECT b.modelname 
		FROM %I."LineShiftPlans" a, %I."Models" b 
		WHERE a.modelid = b.modelid AND a.id = %L;', userName, userName, lineshiftid);
	RAISE NOTICE 'Executing: %', command;
	EXECUTE command INTO retVal;
	RETURN retVal;
END;
$$;
