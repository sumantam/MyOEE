DROP FUNCTION IF EXISTS getProductionData;

CREATE OR REPLACE FUNCTION getProductionData (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    modelName VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    Line_Id VARCHAR,
    Plant_Line TEXT,
    IdealCycleTime NUMERIC,
    ActualCycleTime NUMERIC,
	BreakdownTime NUMERIC,
	Planned_Production_Time NUMERIC,
	Availability NUMERIC,
    ChangeoverTimeAfter NUMERIC,
    Total_Planned NUMERIC,
    Total NUMERIC,
    Total_OK NUMERIC,
	Quality NUMERIC,
    Total_NG NUMERIC,
    Total_FTT NUMERIC,
	Performance NUMERIC
)
AS $$
DECLARE
    command TEXT;
    retcommand TEXT;
    ShiftIds TEXT[];
    ShiftPlanIds TEXT[];
BEGIN
    -- Prepare command to get ShiftIds
    command := format('SELECT array_agg(Id) FROM getShiftIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L);',
        today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
    
--	RAISE NOTICE 'Executing: %', command;

    EXECUTE command INTO ShiftIds;
	
    -- Prepare command to get ShiftIds
	command := format('SELECT array_agg(a.id) FROM %I."LineShiftPlans" a WHERE a.shiftid = ANY($1);', userName);

--    RAISE NOTICE 'Executing: %', command;	

    EXECUTE command INTO ShiftPlanIds USING ShiftIds;
	
	command := format('
		SELECT
				a.line AS Line_Id,
				a.plant || %L || a.linename AS Plant_Line,
				b.CT AS IdealCycleTime,
				ROUND((SUM(EXTRACT(EPOCH FROM a.actualtime)) - COALESCE(c.bdtime, 3)) / SUM(a.totalcount), 2) AS Actual_Cycle_Time,
				COALESCE(c.bdtime::NUMERIC, 0) AS Total_Breakdown_Time,
				SUM(EXTRACT(EPOCH FROM a.actualtime))::NUMERIC AS Planned_Production_Time,
				100.0 * (SUM(EXTRACT(EPOCH FROM a.actualtime)) - COALESCE(c.bdtime, 0)) / SUM(EXTRACT(EPOCH FROM a.actualtime)) AS Availability,
				SUM(EXTRACT(EPOCH FROM a.changeoverendtime - a.changeoverstarttime))::NUMERIC AS Changeover,
				SUM(a.toproduce)::NUMERIC AS Total_Planned,
				SUM(a.totalcount)::NUMERIC AS Total,
				SUM(a.okcount)::NUMERIC AS Total_OK,
				100.0 * SUM(a.okcount) / SUM(a.totalcount) AS Quality,
				SUM(a.ngcount)::NUMERIC AS Total_NG,
				SUM(a.fttcount)::NUMERIC AS Total_FTT,
				100 * (b.CT * SUM(a.totalcount)) / SUM(EXTRACT(EPOCH FROM a.actualtime)) AS Performance
				from %I."RunSummary" AS a
				LEFT JOIN (select lineid, ROUND(AVG(cycletime)::NUMERIC, 2) AS CT from %I."StdCycleTimes" group by lineid) b on a.line=b.lineid
				LEFT JOIN getOverlappingBreakdownsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L) AS c on a.line = c.lineid 
				WHERE a.prodshiftid = ANY($1)
				group by Line_Id, Plant_Line, IdealCycleTime, c.bdtime
				order by Plant_Line;',
				'##',
--				today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, 
				userName, userName,
--				userName,
				today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName
		);
    
	RAISE NOTICE 'Executing: %', command;
    RETURN QUERY EXECUTE command USING ShiftPlanIds;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error occurred: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;

