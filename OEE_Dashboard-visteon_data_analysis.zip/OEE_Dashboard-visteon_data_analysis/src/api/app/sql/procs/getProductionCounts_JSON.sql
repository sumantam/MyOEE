DROP FUNCTION IF EXISTS getProductionCounts_JSON;

CREATE OR REPLACE FUNCTION getProductionCounts_JSON (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS json
LANGUAGE plpgsql
AS
$$
BEGIN
RETURN json_build_object(
	'Production_Counts', (
		SELECT json_agg(
			json_build_object(
				'Plant', a.Plant,
				'Line_Id', a.line_id,
				'Line_Name', a.Line_Name,
				'Shift_Id', a.Shift_Id,
				'Line_Shift_Plan_Id', a.Line_Shift_Plan_Id,
				'Actual_Time', a.Actual_Time,
				'Model_Name', getModelNameForLineShiftId(a.Line_Shift_Plan_Id, userName),
				'Changeover_Time', a.Changeover,
				'Planned', a.Total_Planned,
				'Total', a.Total,
				'Total_OK', a.Total_OK,
				'Total_NG', a.Total_NG,
				'Total_FTT', a.Total_FTT
			)
		)
		FROM 
		(
			SELECT 
				plantname AS Plant, 
				line AS Line_Id,
				lineName AS Line_Name,
				shiftid AS Shift_Id,
				prodshiftid AS Line_Shift_Plan_Id,
				EXTRACT(EPOCH FROM actualtime) AS Actual_Time,
				EXTRACT(EPOCH FROM changeoverendtime - changeoverstarttime) AS Changeover,
				SUM(plannedcount)::REAL AS Total_Planned,
				SUM(totalprodcount)::REAL AS Total, 
				SUM(goodprodcount)::REAL AS Total_OK, 
				SUM(notgoodprodcount)::REAL AS Total_NG, 
				SUM(firsttimethroughcount)::REAL AS Total_FTT
				FROM
					getDifferentProductionCountsForTimeRangeAndLineAggregation (today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName) AS a
				GROUP BY Plant, Line_Id, Line_Name, Shift_Id, Line_Shift_Plan_Id, Actual_Time, Changeover
				ORDER BY Plant, Line_Id
		) a
	)
);
END;
$$;
