DROP FUNCTION IF EXISTS getLineShiftPlanIdsForTimeRangeAndLineAggregation;

CREATE OR REPLACE FUNCTION getLineShiftPlanIdsForTimeRangeAndLineAggregation (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    Id VARCHAR,
    ShiftId VARCHAR,
    StartTime TIMESTAMP WITH TIME ZONE,
    ChangeoverTimeAfter INT,
    ToProduce INT,
    ModelName VARCHAR,
    ShiftOwnerId INT,
    Line VARCHAR,
    LineName VARCHAR,
    PlantName VARCHAR
)
AS $$
DECLARE
    command TEXT;
    retcommand TEXT;
    ShiftIds TEXT[];
BEGIN
    -- Prepare command to get ShiftIds
    command := format('SELECT array_agg(Id) FROM getShiftIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L);',
        today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
    
	RAISE NOTICE 'Executing: %', command;

    EXECUTE command INTO ShiftIds;

    -- Check if ShiftIds is empty
    IF ShiftIds IS NULL OR array_length(ShiftIds, 1) IS NULL THEN
        RAISE NOTICE 'No ShiftIds found for the given parameters.';
        RETURN; -- Early exit if no ShiftIds
    END IF;

    -- Prepare the main query to retrieve line shift plans
    retcommand := format('
        SELECT
            a.id AS Id,
            a.shiftid AS ShiftId,
            a.starttime AS StartTime,
            a.changeovertimeafter AS ChangeoverTimeAfter,
            a.toproduce AS ToProduce,
            c.modelname AS ModelName,
            b.shiftownerid AS ShiftOwnerId,
            b.line AS Line,
            t.LineName AS LineName,
            t.PlantName AS PlantName
        FROM %I."LineShiftPlans" a
        JOIN %I."LineShiftTimes" b ON b.id = a.shiftid
        JOIN %I."Models" c ON a.modelid = c.modelid
        LEFT JOIN (
            SELECT * FROM getLineAggregationRange(
                %L, %L, %L
            )
        ) t ON b.line = t.LineId
        WHERE a.shiftid = ANY($1);',
        userName,
        userName,
        userName,
        lineAggregationType,
        lineAggregationValue,
        userName
    );

    RAISE NOTICE 'Executing: %', retcommand;

    -- Return the result of the query
    RETURN QUERY EXECUTE retcommand USING ShiftIds;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error occurred: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;

