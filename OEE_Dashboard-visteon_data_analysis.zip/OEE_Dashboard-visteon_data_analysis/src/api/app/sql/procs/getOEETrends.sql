DROP FUNCTION IF EXISTS getOEETrends;
DROP FUNCTION IF EXISTS getChangeOverTrends;
DROP FUNCTION IF EXISTS getChangeOverPlanvsActualTrends;

CREATE OR REPLACE FUNCTION getChangeOverTrends (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
	model VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    TimeWhen VARCHAR,
    LineId VARCHAR,
    ObjName VARCHAR,
    Stop REAL
)
AS $$
DECLARE
	temp_table_name TEXT;
    giventoday TIMESTAMP WITH TIME ZONE;
    yesterday TIMESTAMP WITH TIME ZONE;
	lid TEXT;
	lname TEXT;
	pname TEXT;
    command TEXT;
BEGIN
	giventoday = today;
    -- Generate a random 5-character string
    temp_table_name := 'temp_production_counts_' || substring(md5(random()::text), 1, 5);
 
	-- Dynamically create the temporary table with the generated name
	
	EXECUTE format('CREATE TEMPORARY TABLE %I (
		TimeWhen VARCHAR,
		LineId VARCHAR,
		ObjName VARCHAR,
		Stop REAL
	) ON COMMIT DROP;', temp_table_name);

    CASE
        WHEN timeAggregationType = 'Shift' THEN
        WHEN timeAggregationType = 'Day' THEN
			FOR cnt IN 1..7 LOOP
				RAISE NOTICE '%', cnt;
				yesterday := today - INTERVAL '1 Day';

				CASE
					WHEN model = 'ALL' OR model = 'all' OR model = 'ANY' OR model = 'Any' OR model = 'any' THEN
						command := format('
							INSERT INTO %I(TimeWhen, LineId, ObjName, Stop)
							SELECT %L AS TimeWhen, Line AS LineId, LineName AS ObjName, SUM(changeovertimeafter) AS Stop
							FROM getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L)
							GROUP BY line, linename',
							temp_table_name, DATE(yesterday), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
					ELSE
						command := format('
							INSERT INTO %I(TimeWhen, LineId, ObjName, Stop)
							SELECT %L AS TimeWhen, line AS LineId, modelname AS ObjName, SUM(changeovertimeafter) AS Stop
							FROM getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L)
							GROUP BY line, modelname',
							temp_table_name, DATE(yesterday), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
				END CASE;

				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today := today - INTERVAL '1 Day';
			END LOOP;

        WHEN timeAggregationType = 'Week' THEN
			FOR cnt IN 1..8 LOOP
				RAISE NOTICE '%', cnt;
				yesterday := today - INTERVAL '1 Week';

				CASE
					WHEN model = 'ALL' OR model = 'all' OR model = 'ANY' OR model = 'Any' OR model = 'any' THEN
						command := format('
							INSERT INTO %I(TimeWhen, LineId, ObjName, Stop)
							SELECT %L AS TimeWhen, Line AS LineId, LineName AS ObjName, SUM(changeovertimeafter) AS Stop
							FROM getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L)
							GROUP BY line, linename',
							temp_table_name, DATE(yesterday) || '--' || DATE(today), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
					ELSE
						command := format('
							INSERT INTO %I(TimeWhen, LineId, LineName, Stop)
							SELECT %L AS TimeWhen, line AS LineId, modelname AS ObjName, SUM(changeovertimeafter) AS Stop
							FROM getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L)
							GROUP BY line, modelname',
							temp_table_name, DATE(yesterday) || '--' || DATE(today), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
				END CASE;
				
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today := today - INTERVAL '1 Week';
			END LOOP;

        WHEN timeAggregationType = 'Month' THEN
			FOR cnt IN 1..12 LOOP
				RAISE NOTICE '%', cnt;
				yesterday := today - INTERVAL '1 Month';

				CASE
					WHEN model = 'ALL' OR model = 'all' OR model = 'ANY' OR model = 'Any' OR model = 'any' THEN
						command := format('
							INSERT INTO %I(TimeWhen, LineId, ObjName, Stop)
							SELECT %L AS TimeWhen, Line AS LineId, LineName AS ObjName, SUM(changeovertimeafter) AS Stop
							FROM getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L)
							GROUP BY line, linename',
							temp_table_name, DATE(yesterday) || '--' || DATE(today), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
					ELSE
						command := format('
							INSERT INTO %I(TimeWhen, LineId, LineName, Stop)
							SELECT %L AS TimeWhen, line AS LineId, modelname AS ObjName, SUM(changeovertimeafter) AS Stop
							FROM getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L)
							GROUP BY line, modelname',
							temp_table_name, DATE(yesterday) || '--' || DATE(today), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName);
				END CASE;

				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today := today - INTERVAL '1 Month';
			END LOOP;

        WHEN timeAggregationType = 'Year' THEN
            -- Add logic for Year aggregation if needed

        ELSE
            RAISE EXCEPTION 'Invalid timeAggregationType: %', timeAggregationType;
    END CASE;

    RETURN QUERY
        EXECUTE format('SELECT * FROM %I', temp_table_name);	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION getChangeOverPlanvsActualTrends (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    TimeWhen VARCHAR,
    Line VARCHAR,
	LineName VARCHAR,
	PlantName VARCHAR,
	PlannedChangeOver REAL,
    ModelName VARCHAR,
    ActualChangeOver NUMERIC
)
AS $$
DECLARE
	temp_table_name TEXT;
    giventoday TIMESTAMP WITH TIME ZONE;
    yesterday TIMESTAMP WITH TIME ZONE;
	lid TEXT;
	lname TEXT;
	pname TEXT;
    command TEXT;
BEGIN
	giventoday = today;
    -- Generate a random 5-character string
    temp_table_name := 'temp_production_counts_' || substring(md5(random()::text), 1, 5);
 
	-- Dynamically create the temporary table with the generated name
	
	EXECUTE format('CREATE TEMPORARY TABLE %I (
		TimeWhen VARCHAR,
		Line VARCHAR,
		LineName VARCHAR,
		PlantName VARCHAR,
		PlannedChangeOver REAL,
		ModelName VARCHAR,
		ActualChangeOver NUMERIC
	) ON COMMIT DROP;', temp_table_name);

    CASE
        WHEN timeAggregationType = 'Shift' THEN
        WHEN timeAggregationType = 'Day' THEN
			FOR cnt IN 1..7 LOOP
				RAISE NOTICE '%', cnt;
				yesterday := today - INTERVAL '1 Day';
				command := format('
					INSERT INTO %I(
						TimeWhen,
						Line,
						LineName,
						PlantName,
						PlannedChangeOver,
						ModelName,
						ActualChangeOver
					)
					SELECT %L AS TimeWhen,
						aa.line, 
						aa.linename, 
						aa.plantname, 
						SUM(changeovertimeafter) AS plannedChangeOver, 
						modelname, 
						EXTRACT(epoch from SUM(bb.changeoverendtime - bb.changeoverstarttime)) AS actualChangeOver
					FROM 
						getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L) AS aa 
					JOIN 
						getdifferentproductioncountsfortimerangeandlineaggregation(%L, %L, %L, %L, %L, %L) AS bb
					ON
						aa.id = bb.prodshiftid
					GROUP BY aa.line, aa.linename, aa.plantname, modelname',
					temp_table_name, DATE(yesterday),
						today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName,
						today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName
				);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;

				today := today - INTERVAL '1 Day';
			END LOOP;

        WHEN timeAggregationType = 'Week' THEN
			FOR cnt IN 1..8 LOOP
				RAISE NOTICE '%', cnt;
				yesterday := today - INTERVAL '1 Week';
				command := format('
					INSERT INTO %I(
						TimeWhen,
						Line,
						LineName,
						PlantName,
						PlannedChangeOver,
						ModelName,
						ActualChangeOver
					)
					SELECT %L AS TimeWhen,
						aa.line, 
						aa.linename, 
						aa.plantname, 
						SUM(changeovertimeafter) AS plannedChangeOver, 
						modelname, 
						EXTRACT(epoch from SUM(bb.changeoverendtime - bb.changeoverstarttime)) AS actualChangeOver
					FROM 
						getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L) AS aa 
					JOIN 
						getdifferentproductioncountsfortimerangeandlineaggregation(%L, %L, %L, %L, %L, %L) AS bb
					ON
						aa.id = bb.prodshiftid
					GROUP BY aa.line, aa.linename, aa.plantname, modelname',
					temp_table_name, DATE(yesterday) || '--' || DATE(today),
					today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName,
					today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName
				);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today := today - INTERVAL '1 Week';
			END LOOP;

        WHEN timeAggregationType = 'Month' THEN
			FOR cnt IN 1..12 LOOP
				RAISE NOTICE '%', cnt;
				yesterday := today - INTERVAL '1 Month';
				command := format('
					INSERT INTO %I(
						TimeWhen,
						Line,
						LineName,
						PlantName,
						PlannedChangeOver,
						ModelName,
						ActualChangeOver
					)
					SELECT %L AS TimeWhen,
						aa.line,
						aa.linename,
						aa.plantname,
						SUM(changeovertimeafter) AS plannedChangeOver,
						modelname,
						EXTRACT(epoch from SUM(bb.changeoverendtime - bb.changeoverstarttime)) AS actualChangeOver
					FROM
						getLineShiftPlanIdsForTimeRangeAndLineAggregation(%L, %L, %L, %L, %L, %L) AS aa 
					JOIN
						getdifferentproductioncountsfortimerangeandlineaggregation(%L, %L, %L, %L, %L, %L) AS bb
					ON
						aa.id = bb.prodshiftid
					GROUP BY aa.line, aa.linename, aa.plantname, modelname',
					temp_table_name, DATE(yesterday) || '--' || DATE(today),
					today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName,
					today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, userName
				);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today := today - INTERVAL '1 Month';
			END LOOP;

        WHEN timeAggregationType = 'Year' THEN
            -- Add logic for Year aggregation if needed

        ELSE
            RAISE EXCEPTION 'Invalid timeAggregationType: %', timeAggregationType;
    END CASE;

    RETURN QUERY
        EXECUTE format('SELECT * FROM %I', temp_table_name);	
END;
$$ LANGUAGE plpgsql;

DROP FUNCTION IF EXISTS getOEETrends;
CREATE OR REPLACE FUNCTION getOEETrends (
    today TIMESTAMP WITH TIME ZONE,
    lineAggregationType VARCHAR,
    lineAggregationValue VARCHAR,
    timeAggregationType VARCHAR,
    timeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
--date    | availability | quality | performance |  oee
RETURNS TABLE (
	PlantLine VARCHAR,
    TimeWhen VARCHAR,
    Availability REAL,
    Quality REAL,
    Performance REAL,
    OEE REAL)
AS $$
DECLARE
	temp_table_name TEXT;
    giventoday TIMESTAMP WITH TIME ZONE;
    yesterday TIMESTAMP WITH TIME ZONE;
	lid TEXT;
	lname TEXT;
	pname TEXT;
    command TEXT;
BEGIN
	giventoday = today;
    -- Generate a random 5-character string
    temp_table_name := 'temp_production_counts_' || substring(md5(random()::text), 1, 5);
 
	-- Dynamically create the temporary table with the generated name
	EXECUTE format('CREATE TEMPORARY TABLE %I (
		PlantLine VARCHAR,
		TimeWhen VARCHAR,
		Availability REAL,
		Quality REAL,
		Performance REAL,
		OEE REAL
	) ON COMMIT DROP;', temp_table_name);

    CASE
        WHEN timeAggregationType = 'Shift' THEN
        WHEN timeAggregationType = 'Day' THEN
			FOR cnt IN 1..7 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Day';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(PlantLine, TimeWhen, Availability, Quality, Performance, OEE) 
					(SELECT 
						plant_line AS PlantLine,
						%L AS TimeWhen, 
						ROUND(availability, 3) AS Availability,
						ROUND(quality, 3) AS Quality,
						ROUND(performance, 3) AS Performance,
						ROUND(availability * quality * performance / 100.0 / 100.0, 3) AS OEE
					from getProductionData (%L, %L, %L, %L, %L, %L, %L));',
					temp_table_name, DATE(yesterday), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, 'ANY', userName);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Day';
			END LOOP;
        WHEN timeAggregationType = 'Week' THEN
			FOR cnt IN 1..8 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Week';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(PlantLine, TimeWhen, Availability, Quality, Performance, OEE) 
					(SELECT 
						plant_line AS PlantLine,
						%L AS TimeWhen, 
						ROUND(availability, 3) AS Availability,
						ROUND(quality, 3) AS Quality,
						ROUND(performance, 3) AS Performance,
						ROUND(availability * quality * performance / 100.0 / 100.0, 3) AS OEE
					from getProductionData (%L, %L, %L, %L, %L, %L, %L));',
					temp_table_name, DATE(yesterday) || '--' || DATE(today), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, 'ANY', userName);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Week';
			END LOOP;
        WHEN timeAggregationType = 'Month' THEN
			FOR cnt IN 1..12 LOOP
				RAISE NOTICE '%', cnt;
				yesterday = today - INTERVAL '1 Month';
				-- Prepare command to get ShiftIdTable
				command := format('INSERT INTO %I(PlantLine, TimeWhen, Availability, Quality, Performance, OEE) 
					(SELECT 
						plant_line AS PlantLine,
						%L AS TimeWhen, 
						ROUND(availability, 3) AS Availability,
						ROUND(quality, 3) AS Quality,
						ROUND(performance, 3) AS Performance,
						ROUND(availability * quality * performance / 100.0 / 100.0, 3) AS OEE
					from getProductionData (%L, %L, %L, %L, %L, %L, %L));',
					temp_table_name, DATE(yesterday) || '--' || DATE(today), today, lineAggregationType, lineAggregationValue, timeAggregationType, timeAggregationValue, 'ANY', userName);
				RAISE NOTICE 'Executing: %', command;
				EXECUTE command;
				today = today - INTERVAL '1 Month';
			END LOOP;
        WHEN timeAggregationType = 'Year' THEN
        ELSE
            RAISE EXCEPTION 'Invalid timeAggregationType: %', timeAggregationType;
    END CASE;

    RETURN QUERY
        EXECUTE format('SELECT * FROM %I', temp_table_name);	
END;
$$ LANGUAGE plpgsql;

