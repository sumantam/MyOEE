DROP FUNCTION IF EXISTS getOverlappingBreakdownsForTimeRangeAndLineAggregation;

CREATE OR REPLACE FUNCTION getOverlappingBreakdownsForTimeRangeAndLineAggregation
(
	today  TIMESTAMP WITH TIME ZONE,
	LineAggregationType VARCHAR,
	LineAggregationValue VARCHAR,
	TimeAggregationType  VARCHAR,
	TimeAggregationValue VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE
(
    LineId VARCHAR,
    BDTime NUMERIC
)
AS $$
DECLARE
    command TEXT;
    dtTime1 TIMESTAMP WITH TIME ZONE;
    dtTime2 TIMESTAMP WITH TIME ZONE;
BEGIN
    
    SELECT dateTime_1, dateTime_2
    INTO dtTime1, dtTime2
    FROM getTimeRange (
        userName,
        today,
        timeAggregationType,
        timeAggregationValue
    );

    command  := format('
        SELECT
        b.lineid,
        EXTRACT(
            EPOCH FROM SUM(LEAST(a.totime, %L) - GREATEST(a.fromtime, %L))
        ) + 1 AS BDTIME
        FROM %I."Breakdowns" AS a
        JOIN %I."MachinesInPipeline" AS b
        ON a.machinesinpipelineid = b.id
        WHERE b.lineid in (Select lineid from getlineaggregationrange(%L, %L, %L)) AND a.totime > %L AND a.fromtime <= %L
        GROUP BY b.lineid ;
    ',
    dtTime2,
    dtTime1,
    userName,
    userName,
	LineAggregationType,
	LineAggregationValue,
	userName,
    dtTime1,
    dtTime2
    );


    RAISE NOTICE 'Executing %', command;

    RETURN QUERY EXECUTE command;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error occurred: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;
