-- Drop existing functions if they exist
DROP FUNCTION IF EXISTS getMachineIdealCycleTime;
DROP FUNCTION IF EXISTS getLineIdealCycleTime;
DROP FUNCTION IF EXISTS getPlantIdealCycleTime;

-- Function to get Plant Ideal Cycle Time
CREATE OR REPLACE FUNCTION getPlantIdealCycleTime (
    LineAggregationValue VARCHAR,
    ModelName VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    PlantId VARCHAR,
    PlantName VARCHAR,
    IdealCycleTime INT
)
AS $$
DECLARE
    command TEXT;
BEGIN
    command := format('WITH RankedMachines AS (
            SELECT
                mip.lineId AS LineId,
                pl.plantName AS PlantName,
                mt.manufacturerscycletime AS IdealCycleTime,
                ln."locId" AS location,
                ROW_NUMBER() OVER (PARTITION BY mip.lineId ORDER BY mt.manufacturerscycletime DESC) AS rank
            FROM %I."MachinesInPipeline" AS mip
            JOIN %I."MachineTypes" AS mt
            ON mip.machinetype = mt.machinename
            JOIN %I."Lines" AS ln ON ln.lineid=mip.lineid
            LEFT JOIN %I."Plants" AS pl ON ln."locId"=pl.plantid
            AND pl.plantName=%L
        )
        SELECT LineId, PlantName, IdealCycleTime
        FROM RankedMachines
        WHERE rank <= 1;', userName, userName, userName, userName, LineAggregationValue);


    RAISE NOTICE 'Executing %', command;
    RETURN QUERY EXECUTE command;
END;
$$ LANGUAGE plpgsql;

-- Function to get Line Ideal Cycle Time
CREATE OR REPLACE FUNCTION getLineIdealCycleTime (
    LineAggregationValue VARCHAR,
    ModelName VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    LineId VARCHAR,
    IdealCycleTime INT
)
AS $$
DECLARE
    command TEXT;
BEGIN
    command := format('WITH RankedMachines AS (
            SELECT
                mip.lineId AS LineId,
                mt.manufacturerscycletime AS IdealCycleTime,
                ROW_NUMBER() OVER (PARTITION BY mip.lineId ORDER BY mt.manufacturerscycletime DESC) AS rank
            FROM %I."MachinesInPipeline" AS mip
            JOIN %I."MachineTypes" AS mt
            ON mip.machinetype = mt.machinename
            AND mip.lineId = %L
        )
        SELECT LineId, IdealCycleTime
        FROM RankedMachines
        WHERE rank <= 1;', userName, userName, LineAggregationValue);

    RETURN QUERY EXECUTE command;
END;
$$ LANGUAGE plpgsql;

-- Function to get Machine Ideal Cycle Time based on LineAggregationType
CREATE OR REPLACE FUNCTION getMachineIdealCycleTime (
    LineAggregationType VARCHAR,
    LineAggregationValue VARCHAR,
    ModelName VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS TABLE (
    LineId VARCHAR,
    IdealCycleTime INT
)
AS $$
BEGIN
    CASE
        WHEN LineAggregationType = 'Line' THEN
            RETURN QUERY SELECT * FROM getLineIdealCycleTime(LineAggregationValue, ModelName, userName, schemaName);
        WHEN LineAggregationType = 'Plant' THEN
            RETURN QUERY
                SELECT p.PlantId AS LineId,
                p.IdealCycleTime
                FROM getPlantIdealCycleTime(LineAggregationValue, ModelName, userName, schemaName) p;
    END CASE;
END;
$$ LANGUAGE plpgsql;
