DROP FUNCTION IF EXISTS updateEmptyActiontimesForMachine;

CREATE OR REPLACE FUNCTION updateEmptyActiontimesForMachine (
    today TIMESTAMP WITH TIME ZONE,
    lineId VARCHAR,
    machineName VARCHAR,
    action VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS INTEGER AS $$
DECLARE
    command TEXT;
	retVal INTEGER;
    MicrostopIds INTEGER[];
BEGIN
	command := format('SELECT array_agg(a.microstopid)
		FROM %I."Microstops" a 
		JOIN %I."MachinesInPipeline" b 
		ON a.machinesinpipelineid=b.id
		WHERE a.actiontime is NULL AND a.action=%L AND b.machinename=%L AND b.lineid=%L;',
		userName, userName, action, machineName, lineId);

	RAISE NOTICE 'Executing: %', command;
    EXECUTE command INTO MicrostopIds;
    -- Check if ShiftIds is empty
    IF MicrostopIds IS NULL OR array_length(MicrostopIds, 1) IS NULL THEN
        RAISE NOTICE 'No Microstops found for the given parameters.';
        RETURN 0; -- Early exit if no MicrostopIds
	ELSE
		retVal = array_length(MicrostopIds, 1);
    END IF;
	
	command := format('
        UPDATE %I."Microstops" SET actiontime=%L
        WHERE microstopid = ANY($1);', userName, today);
	RAISE NOTICE 'Executing: %', command;
	EXECUTE command USING MicrostopIds;
	RETURN retVal;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error occurred: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;

