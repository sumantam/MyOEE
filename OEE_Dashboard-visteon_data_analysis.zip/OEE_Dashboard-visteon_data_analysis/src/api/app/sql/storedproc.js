const path = require('path')
// const sequelize = require('../utils/database')
const dotenv = require('dotenv')
const envFilePath = path.join(__dirname, '..', '..', '..', 'api', '.env')
dotenv.config({ path: envFilePath })
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

const sqlFileName001 = path.join(__dirname, '..', '..', '..', 'api', 'app', 'sql', 'fdw.sql')
const sqlFileName002 = path.join(__dirname, '..', '..', '..', 'api', 'app', 'sql', 'checkUtility.sql')
const sqlFileName003 = path.join(__dirname, '..', '..', '..', 'api', 'app', 'sql', 'userUtils.sql')

// Function to execute the SQL file
exports.executeSqlFile = async () => {
  console.log('################## Called stored proc ####################')
  let pgPoolsInstance = null
  try {
    pgPoolsInstance = await PgPools.getInstance()
    const result001 = await pgPoolsInstance.getPool(dbConfig.DB).loadSQLFile(sqlFileName001)
    const result002 = await pgPoolsInstance.getPool(dbConfig.DB).loadSQLFile(sqlFileName002)
    const result003 = await pgPoolsInstance.getPool(dbConfig.DB).loadSQLFile(sqlFileName003)

    console.log('SQL file executed successfully:')
  } catch (error) {
    console.error('Error executing SQL file:', error)
  }
}

// Usage example
// module.exports = executeSqlFile;
