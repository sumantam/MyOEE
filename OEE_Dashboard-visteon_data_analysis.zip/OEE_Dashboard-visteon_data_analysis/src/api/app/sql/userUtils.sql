DROP FUNCTION IF EXISTS "findByPrimaryKey";
DROP FUNCTION IF EXISTS "findAll";
DROP FUNCTION IF EXISTS "updateUser";

CREATE OR REPLACE FUNCTION "findByPrimaryKey" (
    tableName VARCHAR,
    key VARCHAR,
    value VARCHAR,
    schemaName VARCHAR DEFAULT 'public',
    columns VARCHAR DEFAULT '*'
)
RETURNS SETOF RECORD AS $$
DECLARE
    query TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = schemaName AND table_name = tableName) THEN
        query := format('SELECT %s FROM %I.%I WHERE "%I" = $1', columns, schemaName, tableName, key);

        RAISE NOTICE 'Query % .', query;

        RETURN QUERY EXECUTE query USING value;

        -- RETURN QUERY EXECUTE 'SELECT * FROM tmp_results';
    ELSE
        RAISE NOTICE 'Table % does not exist.', tableName;
        RETURN;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION "findAll" (
    tableName VARCHAR,
    schemaName VARCHAR DEFAULT 'public',
    columns VARCHAR DEFAULT '*'
)
RETURNS SETOF RECORD AS $$
DECLARE
    query TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = schemaName AND table_name = tableName) THEN
        query := format('SELECT %s FROM %I.%I', columns, schemaName, tableName);

        RAISE NOTICE 'Query % .', query;

        RETURN QUERY EXECUTE query;

        -- RETURN QUERY EXECUTE 'SELECT * FROM tmp_results';
    ELSE
        RAISE NOTICE 'Table % does not exist.', tableName;
        RETURN;
    END IF;
END;
$$ LANGUAGE plpgsql;

--  ****************************************
-- Try to merge this function with findAll
--  ****************************************

CREATE OR REPLACE FUNCTION "findByResponsibility" (
    tableName VARCHAR,
    responsibility VARCHAR,
    schemaName VARCHAR DEFAULT 'public',
    columns VARCHAR DEFAULT '*'
)
RETURNS SETOF RECORD AS $$
DECLARE
    query TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE
        table_schema = schemaName AND table_name = tableName)
    THEN
        query := format('
            SELECT %s FROM %I.%I
            where responsibility=%L
        ', columns, schemaName,
        tableName, responsibility
        );

        RAISE NOTICE 'Query % .', query;

        RETURN QUERY EXECUTE query;

        -- RETURN QUERY EXECUTE 'SELECT * FROM tmp_results';
    ELSE
        RAISE NOTICE 'Table % does not exist.', tableName;
        RETURN;
    END IF;
END;
$$ LANGUAGE plpgsql;



CREATE OR REPLACE FUNCTION "updateUser" (
    tableName       VARCHAR,
    oldemail        VARCHAR,
    email           VARCHAR,
    name            VARCHAR,
    role            VARCHAR,
    responsibility  VARCHAR,
    designation     VARCHAR,
    countrycode     INTEGER,
    mobilenumber    INTEGER,
    location        VARCHAR,
    schemaName      VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    query TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = schemaName AND table_name = tableName) THEN
        query := format('
            UPDATE %I.%I
            SET email = %L,
                name = %L,
                role = %L,
                responsibility = %L,
                designation = %L,
                countrycode = %L,
                mobilenumber = %L,
                location = %L
            WHERE email = %L;
            ', schemaName, tableName,
            email, name, role, responsibility,
            designation, countrycode, mobilenumber,
            location, oldemail
        );

        EXECUTE query;

        RETURN TRUE;
    ELSE
        RAISE NOTICE 'Table % does not exist.', tableName;
        RETURN FALSE;
    END IF;
END;
$$ LANGUAGE plpgsql;
