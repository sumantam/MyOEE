DROP FUNCTION IF EXISTS foreign_data_wrapper;
DROP FUNCTION IF EXISTS run_query_based_on_user;
DROP FUNCTION IF EXISTS search_in_foreign_database;
DROP FUNCTION IF EXISTS user_db_map;
DROP FUNCTION IF EXISTS findFn;


CREATE OR REPLACE FUNCTION search_in_foreign_database(db_name TEXT, query TEXT)
RETURNS TABLE(result TEXT) AS $$
DECLARE
    target_table TEXT;
BEGIN
    -- Determine the target foreign table based on db_name
    IF db_name = 'db1' THEN
        target_table := 'public.your_table_from_db1';
    ELSIF db_name = 'db2' THEN
        target_table := 'public.your_table_from_db2';
    ELSIF db_name = 'db3' THEN
        target_table := 'public.your_table_from_db3';
    ELSE
        RAISE EXCEPTION 'Unknown database: %', db_name;
    END IF;

    -- Execute the query on the target foreign table
    RETURN QUERY EXECUTE format('SELECT * FROM %I WHERE %s', target_table, query);
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION foreign_data_wrapper(
    remote_host VARCHAR,
    port_number INTEGER,
    remote_db VARCHAR,
    remote_user VARCHAR,
    remote_server VARCHAR,
    remote_password VARCHAR
)
RETURNS BOOLEAN AS $$
DECLARE
    create_server_command TEXT;
    create_mapping_command TEXT;
    create_schema_command TEXT;
    import_foreign_schema_command TEXT;
BEGIN
    RAISE NOTICE 'Starting foreign_data_wrapper function';
    RAISE NOTICE 'Parameters: remote_host=%', remote_host;
    RAISE NOTICE 'Parameters: port_number=%', port_number;
    RAISE NOTICE 'Parameters: remote_db=%', remote_db;
    RAISE NOTICE 'Parameters: remote_user=%', remote_user;
    RAISE NOTICE 'Parameters: remote_server=%', remote_server;

-- Step 1: Create the extension (idempotent)
    IF NOT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'postgres_fdw') THEN
        EXECUTE 'CREATE EXTENSION postgres_fdw';
    END IF;

    RAISE NOTICE 'Finished creation of postgres_fdw extension';

    IF NOT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'dblink') THEN
        EXECUTE 'CREATE EXTENSION dblink';
    END IF;

    RAISE NOTICE 'Finished creation of dblink extension';


-- Step 2: Create the foreign server if it does not exist
    IF NOT EXISTS (SELECT 1 FROM pg_foreign_server WHERE srvname = remote_server) THEN
        create_server_command := format('
            CREATE SERVER %I
            FOREIGN DATA WRAPPER postgres_fdw
            OPTIONS (host %L, port %L, dbname %L)',
            remote_server, remote_host, port_number::TEXT, remote_db);

        -- Print the command
        RAISE NOTICE 'Executing: %', create_server_command;

        -- Execute the command
        EXECUTE create_server_command;

        RAISE NOTICE 'Finished creation of foreign data server';
    ELSE
        RAISE NOTICE 'Foreign data server already exists';
    END IF;

-- Step 3: Create the user mapping
    IF NOT EXISTS (SELECT 1 FROM pg_user_mappings um
        JOIN pg_foreign_server fs ON um.srvid = fs.oid
        JOIN pg_authid au ON um.umuser = au.oid
        WHERE fs.srvname = remote_server AND au.rolname = CURRENT_USER
    ) THEN
        create_mapping_command := format('
        CREATE USER MAPPING FOR CURRENT_USER
        SERVER %I
        OPTIONS (user %L, password %L)',
        remote_server, remote_user, remote_password);

        -- Print the command
        RAISE NOTICE 'Executing: %', create_mapping_command;

        -- Execute the command
        EXECUTE create_mapping_command;

        RAISE NOTICE 'Finished creation of mapping';
    ELSE
        RAISE NOTICE 'User mapping  for foreign data server already exists';
    END IF;

-- Step 4: Import foreign schema

    IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = remote_user) THEN
        create_schema_command := format('CREATE SCHEMA %I', remote_user);
        RAISE NOTICE 'Executing: %', create_schema_command;
    EXECUTE create_schema_command;
        RAISE NOTICE 'Schema created';
    ELSE
        RAISE NOTICE 'Schema already exists';
    END IF;

-- Print the command
    
    import_foreign_schema_command := format('
        IMPORT FOREIGN SCHEMA public
        FROM SERVER %I
        INTO %I',
        remote_server,
        remote_user
        );

-- Print the command
    RAISE NOTICE 'Executing: %', import_foreign_schema_command;

-- Execute the command
    
    EXECUTE import_foreign_schema_command;

    RAISE NOTICE 'Finished import of remote schema into local schema';
    
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION  user_db_map (
    username TEXT,
    database_name TEXT
)
RETURNS VOID AS $$
BEGIN

    CREATE TABLE user_database_mapping (
        username TEXT PRIMARY KEY,
        database_name TEXT NOT NULL
    );

    CREATE EXTENSION dblink;

END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION run_query_based_on_user (
    username TEXT,
    query TEXT
)
RETURNS VOID AS $$
DECLARE
    db_name TEXT;
    conn_str TEXT;
BEGIN
    -- Retrieve the database name associated with the user
    SELECT database_name INTO db_name
    FROM user_database_mapping
    WHERE username = $1;

    -- Raise an exception if no database is found for the user
    IF NOT FOUND THEN
        RAISE EXCEPTION 'No database found for user %', $1;
    END IF;

    -- Construct the connection string for dblink
    conn_str := 'dbname=' || db_name;

    -- Execute the query on the target database
    PERFORM dblink_exec(conn_str, $2);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION findFn(fnName VARCHAR)
RETURNS TABLE(schema_name TEXT, function_name TEXT, return_type TEXT, arguments TEXT) AS $$
BEGIN
    RETURN QUERY SELECT
        n.nspname::TEXT AS schema_name,
        p.proname::TEXT AS function_name,
        pg_catalog.pg_get_function_result(p.oid)::TEXT AS return_type,
        pg_catalog.pg_get_function_arguments(p.oid)::TEXT AS arguments
    FROM
        pg_catalog.pg_proc p
        JOIN pg_catalog.pg_namespace n ON n.oid = p.pronamespace
    WHERE
        p.proname = fnName
        AND n.nspname = 'public';
END;
$$ LANGUAGE plpgsql;
