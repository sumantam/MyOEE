DROP FUNCTION IF EXISTS createMachineTypesTable;
DROP FUNCTION IF EXISTS insert_bulk_issues;

CREATE OR REPLACE FUNCTION createMachineTypesTable(
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    alter_table_command TEXT;
    create_sequence_command TEXT;
    create_machinetype_command TEXT;
    create_issuetype_command TEXT;
    create_issue_command TEXT;
    remote_conn_str_command TEXT;
    import_foreign_schema_command TEXT;
    import_foreign_schema_issue_command TEXT;
    remote_conn_string TEXT;
    drop_table_command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN
    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the create table command
        create_machinetype_command := format(
            'CREATE TABLE IF NOT EXISTS %I."MachineTypes" (
                MachineName VARCHAR PRIMARY KEY,
                ManufacturersCycleTime INTEGER NOT NULL
            )',
            schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_machinetype_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_machinetype_command);

        -- Define the create table command
        create_issuetype_command := format(
            'CREATE TABLE IF NOT EXISTS %I."IssueTypes" (
                IssueTypeId SERIAL PRIMARY KEY,
                IssueTypeName VARCHAR(255) NOT NULL UNIQUE
            )',
            schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_issuetype_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_issuetype_command);

        -- Only special insertion is required.

        create_issuetype_command := format(
            'INSERT INTO %I."IssueTypes" (IssueTypeName)
            VALUES (''Breakdown''), (''Microstop''), (''Quality'')
            ON CONFLICT (IssueTypeName) DO NOTHING',
            schemaName
        );
        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_issuetype_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_issuetype_command);

        -- Define the create table command
        create_issue_command := format(
            'CREATE TABLE IF NOT EXISTS %I."Issues" (
                IssueId SERIAL PRIMARY KEY,
                MachineName VARCHAR,
                IssueTypeName VARCHAR(255),
                IssueDescription VARCHAR(255),
                FOREIGN KEY (MachineName) REFERENCES %I."MachineTypes"(MachineName),
                FOREIGN KEY (IssueTypeName) REFERENCES %I."IssueTypes"(IssueTypeName)
            )',
            schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_issue_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_issue_command);

        -- Define the create sequence command
        create_sequence_command := format(
            'CREATE SEQUENCE IF NOT EXISTS %I.issues_issueid_seq
            START WITH 1
            INCREMENT BY 1
            NO MINVALUE
            NO MAXVALUE
            CACHE 1',
            userName
        );

        EXECUTE create_sequence_command;

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'MachineTypes') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I.%I', userName, 'MachineTypes');
            RAISE NOTICE 'Dropping existing foreign table: %', 'MachineTypes';
            EXECUTE drop_table_command;
        END IF;

        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'IssueTypes') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I.%I', userName, 'IssueTypes');
            RAISE NOTICE 'Dropping existing foreign table: %', 'IssueTypes';
            EXECUTE drop_table_command;
        END IF;

        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'Issues') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I.%I', userName, 'Issues');
            RAISE NOTICE 'Dropping existing foreign table: %', 'Issues';
            EXECUTE drop_table_command;
        END IF;


        import_foreign_schema_command := format('
            IMPORT FOREIGN SCHEMA public
            LIMIT TO ("MachineTypes")
            FROM SERVER %I
            INTO %I',
            rec.srvname,
            userName
        );

        RAISE NOTICE 'Executing import command: %', import_foreign_schema_command;
        EXECUTE import_foreign_schema_command;

        import_foreign_schema_issue_command := format('
            IMPORT FOREIGN SCHEMA public
            LIMIT TO ("IssueTypes", "Issues")
            FROM SERVER %I
            INTO %I',
            rec.srvname,
            userName
        );

        RAISE NOTICE 'Executing import command: %', import_foreign_schema_issue_command;
        EXECUTE import_foreign_schema_issue_command;

    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION insert_bulk_issues(
    issues jsonb,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS VOID AS $$
DECLARE
    issue jsonb;
    insert_command TEXT;
BEGIN
    FOR issue IN SELECT * FROM jsonb_array_elements(issues) LOOP
        insert_command := format(
            'INSERT INTO %I."Issues" (IssueId, MachineName, IssueTypeName, IssueDescription) ' ||
            'SELECT nextval(''%I.issues_issueid_seq''),$1, $2, $3 FROM %I."IssueTypes" it ' ||
            'WHERE it.IssueTypeName = $2',
            userName, userName, userName
        );

        EXECUTE insert_command
        USING
            issue->>'MachineName',
            issue->>'IssueTypeName',
            issue->>'IssueDescription'
        ;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

