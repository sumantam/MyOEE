DROP FUNCTION IF EXISTS createUserTable;

CREATE OR REPLACE FUNCTION createUserTable(
    schemaName VARCHAR
)
RETURNS BOOLEAN AS $$
DECLARE
    create_user_command TEXT;
    create_authenticator_command TEXT;
BEGIN
    create_user_command := format('
        CREATE TABLE IF NOT EXISTS %I."Users" (
            email VARCHAR(255) PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            role VARCHAR(255) NOT NULL DEFAULT ''User'',
            responsibility VARCHAR(255) NOT NULL DEFAULT ''Operator'',
            designation VARCHAR(255) DEFAULT ''Senior Engineer'',
            countryCode VARCHAR(10) NOT NULL DEFAULT ''+91'',
            mobileNumber VARCHAR(20) NOT NULL,
            img JSONB DEFAULT ''{}'',
            location VARCHAR(255) NOT NULL
        );', schemaName
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', create_user_command;

    -- Execute the command
    EXECUTE create_user_command;

    create_authenticator_command := format('
        CREATE TABLE IF NOT EXISTS %I."Authenticator" (
            "userEmail" VARCHAR(255) PRIMARY KEY,
            password VARCHAR(255) NOT NULL,
            CONSTRAINT "authenticator_userEmail_fkey" FOREIGN KEY ("userEmail") REFERENCES %I."Users" ("email") ON DELETE CASCADE
        );', schemaName, schemaName
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', create_authenticator_command;

    -- Execute the command
    EXECUTE create_authenticator_command;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;
