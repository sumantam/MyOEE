DROP FUNCTION IF EXISTS createLineShiftTimesTable;
DROP FUNCTION IF EXISTS get_LineShiftTimes_procedure_body;
DROP FUNCTION IF EXISTS insertShiftOwner;

CREATE OR REPLACE FUNCTION get_LineShiftTimes_procedure_body()
RETURNS TEXT AS
$$
BEGIN
    RETURN '
        CREATE OR REPLACE PROCEDURE insert_shift_owner(
            _shift_owner VARCHAR
        )
        AS $proc$
        DECLARE
            current_version INT;
        BEGIN
            -- Check the current version
            SELECT version INTO current_version
                FROM "ShiftOwners"
                WHERE OwnerName = _shift_owner;

            -- Perform the insert or update
            IF current_version IS NULL THEN
                INSERT INTO "ShiftOwners" (OwnerName, version)
                VALUES (_shift_owner, 1)
                ON CONFLICT (OwnerName) DO NOTHING;
            END IF;
        END;
        $proc$ LANGUAGE plpgsql;
    ';
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION createLineShiftTimesTable(
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public',
    procedure_body TEXT DEFAULT get_LineShiftTimes_procedure_body()
)
RETURNS BOOLEAN AS $$
DECLARE
    create_lineshifttimes_command TEXT;
    create_shiftowners_command TEXT;
    remote_conn_str_command TEXT;
    import_foreign_schema_command TEXT;
    remote_conn_string TEXT;
    drop_table_command TEXT;
    drop_procedure_command TEXT;
    create_sequence_command TEXT;
    rec RECORD;
    combined_options TEXT[];
    max_retries INTEGER := 3;
    retry_count INTEGER;
    success BOOLEAN := FALSE;
    table_exists BOOLEAN;
BEGIN
    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Drop the procedure if it exists
        drop_procedure_command := 'DROP PROCEDURE IF EXISTS insert_shift_owner';
        PERFORM dblink_exec(remote_conn_string, drop_procedure_command);

        -- Define the create table command
        create_shiftowners_command := format('
            CREATE TABLE IF NOT EXISTS %I."ShiftOwners" (
                OwnerId SERIAL PRIMARY KEY,
                OwnerName VARCHAR NOT NULL UNIQUE,
                version INT
            )', schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_shiftowners_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_shiftowners_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'ShiftOwners') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I.%I', userName, 'ShiftOwners');
            RAISE NOTICE 'Dropping existing foreign table: %', 'ShiftOwners';
            EXECUTE drop_table_command;
        END IF;

        import_foreign_schema_command := format('
            IMPORT FOREIGN SCHEMA public
            LIMIT TO ("ShiftOwners")
            FROM SERVER %I
            INTO %I',
            rec.srvname,
            userName
        );

        RAISE NOTICE 'Executing import command: %', import_foreign_schema_command;
        EXECUTE import_foreign_schema_command;

        -- Define the create sequence command
        create_sequence_command := format(
            'CREATE SEQUENCE IF NOT EXISTS %I.shiftownerid_seq
            START WITH 1
            INCREMENT BY 1
            NO MINVALUE
            NO MAXVALUE
            CACHE 1',
            userName
        );

        EXECUTE create_sequence_command;

        -- Define the create table command
        create_lineshifttimes_command := format(
            'CREATE TABLE IF NOT EXISTS %I."LineShiftTimes" (
                Id VARCHAR PRIMARY KEY,
                ShiftName VARCHAR NOT NULL,
                Start TIMESTAMP WITH TIME ZONE NOT NULL,
                Stop TIMESTAMP WITH TIME ZONE NOT NULL,
                ShiftOwnerId INT NOT NULL,
                Line VARCHAR NOT NULL,
                UTCOffset VARCHAR NOT NULL,
                FOREIGN KEY (ShiftOwnerId) REFERENCES %I."ShiftOwners"(OwnerId),
                FOREIGN KEY (Line) REFERENCES %I."Lines"(LineId)
            )', schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_lineshifttimes_command;

        -- Execute the create table command on the remote database
        retry_count := 0;

        WHILE NOT success AND retry_count < max_retries LOOP
            BEGIN
                PERFORM dblink_exec(remote_conn_string, create_lineshifttimes_command);

                SELECT EXISTS (
                    SELECT 1
                    FROM dblink(remote_conn_string, 
                        format('SELECT 1 FROM information_schema.tables WHERE table_schema = %L AND table_name = %L', 
                            schemaName, 'LineShiftTimes'))
                    AS check_table(exists BOOLEAN)
                ) INTO table_exists;

                IF table_exists THEN
                    success := TRUE;
                ELSE
                    retry_count := retry_count + 1;
                    RAISE NOTICE 'Retrying table creation (%).', retry_count;
                    PERFORM pg_sleep(0.5);
                END IF;
            EXCEPTION WHEN OTHERS THEN
                retry_count := retry_count + 1;
                RAISE NOTICE 'Retry % failed; retrying...', retry_count;
                PERFORM pg_sleep(0.5);
            END;
        END LOOP;
        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'LineShiftTimes') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I."LineShiftTimes"', userName);
            RAISE NOTICE 'Dropping existing foreign table: %', 'LineShiftTimes';
            EXECUTE drop_table_command;
        END IF;

        import_foreign_schema_command := format('
            IMPORT FOREIGN SCHEMA public
            LIMIT TO ("LineShiftTimes")
            FROM SERVER %I
            INTO %I',
            rec.srvname,
            userName
        );

        RAISE NOTICE 'Executing import command: %', import_foreign_schema_command;

        RAISE NOTICE ' remote connection string: %', remote_conn_string;
        -- Perform creation of the procedure in the child database
        PERFORM dblink_exec(remote_conn_string, procedure_body);


        IF success THEN 
            EXECUTE import_foreign_schema_command;
        END IF;

    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION insertShiftOwner(
    shiftOwner VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    remote_conn_str_command TEXT;
    import_foreign_schema_command TEXT;
    remote_conn_string TEXT;
    command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN
    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the command to call the procedure
        
        command := format('
		CALL %I.insert_shift_owner(%L)
        ', schemaName, shiftOwner
        );

        -- Execute the command in the remote database
        PERFORM dblink_exec(remote_conn_string, command);

    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;
