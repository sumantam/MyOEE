DROP FUNCTION IF EXISTS createShiftsTable;
DROP FUNCTION IF EXISTS get_Shifts_procedure_body;
DROP FUNCTION IF EXISTS insertShifts;
DROP FUNCTION IF EXISTS chk_barcode_procedure;
DROP FUNCTION IF EXISTS get_Breakdown_procedure_body;
DROP FUNCTION IF EXISTS get_MicroStops_procedure_body;
DROP FUNCTION IF EXISTS get_Runs_procedure_body;
DROP FUNCTION IF EXISTS get_Shifts_procedure_body;
DROP FUNCTION IF EXISTS createShiftsTable;
DROP FUNCTION IF EXISTS insertShifts;
DROP FUNCTION IF EXISTS insertRuns;
DROP FUNCTION IF EXISTS insertMicroStops;
DROP FUNCTION IF EXISTS insertBreakdowns;
DROP FUNCTION IF EXISTS RunSummaryData;


CREATE OR REPLACE FUNCTION chk_barcode_procedure()
RETURNS TEXT AS
$$
BEGIN
    RETURN '
        DO $_$
        BEGIN
            IF EXISTS (
                SELECT 1
                FROM pg_trigger
                WHERE tgname = ''validate_barcode_prefix''
            ) THEN
                EXECUTE ''DROP TRIGGER validate_barcode_prefix ON "Runs"'';
            END IF;
        END;
        $_$;
        
        DROP FUNCTION IF EXISTS check_prefix;

        CREATE OR REPLACE FUNCTION check_prefix()
        RETURNS TRIGGER AS $_$
        DECLARE
            prefix_match BOOLEAN;
        BEGIN
            -- Extract the first three characters as the prefix
            prefix_match := EXISTS (
                SELECT 1
                FROM "Models"
                WHERE barcode_prefix = SUBSTRING(NEW.barcode FROM 1 FOR 3)
            );

            IF NOT prefix_match THEN
                RAISE EXCEPTION ''The prefix of the barcode (%s) does not match any allowed prefixes in the Models table'', SUBSTRING(NEW.barcode FROM 1 FOR 3);
            END IF;
            
            RETURN NEW;
        END;
        $_$ LANGUAGE plpgsql;

        CREATE TRIGGER validate_barcode_prefix
            BEFORE INSERT OR UPDATE ON "Runs"
            FOR EACH ROW EXECUTE FUNCTION check_prefix();
    ';
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION get_Breakdown_procedure_body()
RETURNS TEXT AS
$$
BEGIN
    RETURN '
        DROP PROCEDURE IF EXISTS insert_breakdowns;

        CREATE OR REPLACE PROCEDURE insert_breakdowns(
            _shiftId VARCHAR,
            _downtimeInstanceId VARCHAR,
			_machinesInPipelineId VARCHAR,
			_downtimeReasonId VARCHAR,
			_fromTime TIMESTAMP WITH TIME ZONE,
			_toTime TIMESTAMP WITH TIME ZONE,
			_issue VARCHAR,
			_action VARCHAR,
			_actionTime TIMESTAMP WITH TIME ZONE
        )
        AS $proc$
        DECLARE
            current_version INT;
        BEGIN
            INSERT INTO "Breakdowns" (
                ShiftId,
                DowntimeInstanceId,
                MachinesInPipelineId,
                DowntimeReasonId,
                FromTime,
                ToTime,
                Issue,
                Action,
                ActionTime
            )
                VALUES (
                    _shiftId,
                    _downtimeInstanceId,
                    _machinesInPipelineId,
                    _downtimeReasonId,
                    _fromTime,
                    _toTime,
                    _issue,
                    _action,
                    _actionTime
                )
                ON CONFLICT (ShiftId, MachinesInPipelineId, FromTime) DO NOTHING;
        END;
        $proc$ LANGUAGE plpgsql;
    ';
END;
$$ LANGUAGE plpgsql;



CREATE OR REPLACE FUNCTION get_MicroStops_procedure_body()
RETURNS TEXT AS
$$
BEGIN
    RETURN '
        DROP PROCEDURE IF EXISTS insert_microstops;

        CREATE OR REPLACE PROCEDURE insert_microstops(
            _runId INT,
            _downtimeInstanceId VARCHAR,
            _machinesInPipelineId VARCHAR,
            _downtimeReasonId VARCHAR,
            _fromTime TIMESTAMP WITH TIME ZONE,
            _toTime TIMESTAMP WITH TIME ZONE,
            _issue VARCHAR,
            _action VARCHAR,
            _actionTime TIMESTAMP WITH TIME ZONE
        )
        AS $proc$
        DECLARE
            current_version INT;
        BEGIN
            INSERT INTO "Microstops" (
                RunId,
                DowntimeInstanceId,
                MachinesInPipelineId,
                DowntimeReasonId,
                FromTime,
                ToTime,
                Issue,
                Action,
                ActionTime
            )
                VALUES (
                    _runId,
                    _downtimeInstanceId,
                    _machinesInPipelineId,
                    _downtimeReasonId,
                    _fromTime,
                    _toTime,
                    _issue,
                    _action,
                    _actionTime
                )
                ON CONFLICT (RunId, MachinesInPipelineId, FromTime) DO NOTHING;
        END;
        $proc$ LANGUAGE plpgsql;
    ';
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION get_Runs_procedure_body()
RETURNS TEXT AS
$$
BEGIN
    RETURN '
        CREATE OR REPLACE PROCEDURE insert_runs(
            _prodShiftId VARCHAR,
            _barcode VARCHAR,
            _runNumber INT,
            _entryMachineId VARCHAR,
            _entryMachineTimeStamp TIMESTAMP WITH TIME ZONE,
            _exitMachineId VARCHAR,
            _exitMachineTimeStamp TIMESTAMP WITH TIME ZONE,
            _status VARCHAR,
            _otherInfo VARCHAR
        )
        AS $proc$
        DECLARE
            current_version INT;
        BEGIN
            INSERT INTO "Runs" (
                ProdShiftId,
                Barcode,
                RunNumber,
                EntryMachineId,
                EntryMachineTimeStamp,
                ExitMachineId,
                ExitMachineTimeStamp,
                Status,
                OtherInfo
            )
                VALUES (
                    _prodShiftId,
                    _barcode,
                    _runNumber,
                    _entryMachineId,
                    _entryMachineTimeStamp,
                    _exitMachineId,
                    _exitMachineTimeStamp,
                    _status,
                    _otherInfo
                )
                ON CONFLICT (Barcode, RunNumber) DO NOTHING;
        END;
        $proc$ LANGUAGE plpgsql;
    ';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION get_Shifts_procedure_body()
RETURNS TEXT AS
$$
BEGIN
    RETURN '
        CREATE OR REPLACE PROCEDURE insert_shifts(
            _shift_id VARCHAR,
            _lineshift_plan_id VARCHAR,
            _change_start_time TIMESTAMP WITH TIME ZONE,
            _change_end_time TIMESTAMP WITH TIME ZONE,
            _planned_production INT,
            _total_production INT,
            _total_ok INT
        )
        AS $proc$
        DECLARE
            current_version INT;
        BEGIN
            INSERT INTO "Shifts" (
                ShiftId,
                LineShiftPlanId,
                ChangeoverStartTime,
                ChangeoverEndTime,
                PlannedProduction,
                TotalProduction,
                TotalOK
            )
                VALUES (
                    _shift_id,
                    _lineshift_plan_id,
                    _change_start_time,
                    _change_end_time,
                    _planned_production,
                    _total_production,
                    _total_ok
                )
                ON CONFLICT (LineShiftPlanId) DO NOTHING;
        END;
        $proc$ LANGUAGE plpgsql;
    ';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION get_RunSummary_procedure_body()
RETURNS TEXT AS
$$
BEGIN
    RETURN '
        CREATE OR REPLACE PROCEDURE insert_runsummary()
        AS $proc$
        DECLARE
            current_version INT;
        BEGIN
            INSERT INTO "RunSummary" (
                prodshiftid,
                line,
                linename,
                plant,
                toproduce,
                totalcount,
                okcount,
                ngcount,
                fttcount,
                actualtime,
                changeoverstarttime,
                changeoverendtime
            )
        SELECT
            r.prodshiftid,
            l.lineid AS line,
            l.linename,
            p.plantname,
            t.toproduce,
            COUNT(DISTINCT r.barcode) AS totalcount,
            COUNT(DISTINCT CASE WHEN r.status = ''OK'' THEN r.barcode END) AS okcount,
            COUNT(DISTINCT CASE WHEN r.status = ''NG'' THEN r.barcode END) AS ngcount,
            COUNT(DISTINCT CASE WHEN r.status = ''OK'' AND r.runnumber = 0 THEN r.barcode END) AS fttcount,
            MAX(r.exitmachinetimestamp) - MIN(r.entrymachinetimestamp) AS actualtime,
            s.changeoverstarttime AS changeoverstart,
            s.changeoverendtime AS changeoverend
            FROM "Runs" r
            LEFT JOIN "Shifts" s ON r.prodshiftid = s.lineshiftplanid
            LEFT JOIN "LineShiftPlans" t ON r.prodshiftid = t.id
            LEFT JOIN "LineShiftTimes" ls ON t.shiftid = ls.id
            LEFT JOIN "Lines" l ON l.lineid = ls.line
            LEFT JOIN "Plants" p ON p.plantid = l."locId"
            GROUP BY r.prodshiftid, l.lineid, t.toproduce, s.changeoverendtime, s.changeoverstarttime, p.plantname
            ON CONFLICT ON CONSTRAINT Run_Summary_Constraint
            DO NOTHING;
        END;
        $proc$ LANGUAGE plpgsql;
    ';
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION createShiftsTable(
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public',
    shift_procedure_body TEXT DEFAULT get_Shifts_procedure_body(),
    run_procedure_body TEXT DEFAULT get_Runs_procedure_body(),
    microstop_procedure_body TEXT DEFAULT get_MicroStops_procedure_body(),
    brkdown_procedure_body TEXT DEFAULT get_Breakdown_procedure_body(),
    chk_barcode_procedure_body TEXT DEFAULT chk_barcode_procedure(),
    runsummary_procedure_body TEXT DEFAULT get_RunSummary_procedure_body()
)
RETURNS BOOLEAN AS $$
DECLARE
    create_shifts_command TEXT;
    create_prod_command TEXT;
    create_run_command TEXT;
    create_breakdowntbl_command TEXT;
    create_microstoptbl_command TEXT;
    remote_conn_str_command TEXT;
    import_foreign_schema_command TEXT;
    create_runsummarytbl_command TEXT;
    remote_conn_string TEXT;
    drop_table_command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN
    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the create table command
        create_shifts_command := format(
            'CREATE TABLE IF NOT EXISTS %I."Shifts" (
                ShiftId VARCHAR,
                LineShiftPlanId VARCHAR,
                ChangeoverStartTime TIMESTAMP WITH TIME ZONE NOT NULL,
                ChangeoverEndTime   TIMESTAMP WITH TIME ZONE NOT NULL,
                PlannedProduction INT,
                TotalProduction INT,
                TotalOK INT,
                CONSTRAINT  LineShift_PlanId UNIQUE (LineShiftPlanId),
                FOREIGN KEY (ShiftId) REFERENCES %I."LineShiftTimes"(Id),
                FOREIGN KEY (LineShiftPlanId) REFERENCES %I."LineShiftPlans"(Id)
            )', schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_shifts_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_shifts_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'Shifts') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I."Shifts"', userName);
            RAISE NOTICE 'Dropping existing foreign table: %', 'Shifts';
            EXECUTE drop_table_command;
        END IF;


        -- create_prod_command := format(
        --     'CREATE TABLE IF NOT EXISTS %I."Production" (
        --         ProductionId SERIAL PRIMARY KEY,
        --         ProdShiftId VARCHAR,
        --         Barcode VARCHAR,
        --         FOREIGN KEY (ProdShiftId) REFERENCES %I."Shifts"(ShiftId)
        --     )', schemaName, schemaName
        -- );

        -- -- Print the command
        -- RAISE NOTICE 'Executing create table command: %', create_prod_command;

        -- -- Execute the create table command on the remote database
        -- PERFORM dblink_exec(remote_conn_string, create_prod_command);

        -- -- Drop the foreign table if it exists
        -- IF EXISTS (
        --     SELECT 1 FROM information_schema.tables
        --     WHERE table_schema = userName AND table_name = 'Production') THEN
        --     drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I."Production"', userName);
        --     RAISE NOTICE 'Dropping existing foreign table: %', 'Production';
        --     EXECUTE drop_table_command;
        -- END IF;

        create_run_command := format(
            'CREATE TABLE IF NOT EXISTS %I."Runs" (
                RunId SERIAL PRIMARY KEY,
                ProdShiftId VARCHAR,
                Barcode VARCHAR,
                RunNumber INT,
                EntryMachineId VARCHAR,
                EntryMachineTimeStamp TIMESTAMP WITH TIME ZONE NOT NULL,
                ExitMachineId VARCHAR,
                ExitMachineTimeStamp TIMESTAMP WITH TIME ZONE NOT NULL,
                Status VARCHAR,
                OtherInfo VARCHAR,
                CONSTRAINT  Barcode_RunNo UNIQUE (Barcode, RunNumber),
                FOREIGN KEY (ProdShiftId) REFERENCES %I."Shifts"(LineShiftPlanId),
                FOREIGN KEY (EntryMachineId) REFERENCES %I."MachinesInPipeline"(Id),
                FOREIGN KEY (ExitMachineId) REFERENCES %I."MachinesInPipeline"(Id)
            )', schemaName, schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_run_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_run_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'Runs') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I."Runs"', userName);
            RAISE NOTICE 'Dropping existing foreign table: %', 'Runs';
            EXECUTE drop_table_command;
        END IF;


        create_breakdowntbl_command := format(
            'CREATE TABLE IF NOT EXISTS %I."Breakdowns" (
                BreakdownId SERIAL PRIMARY KEY,
                ShiftId VARCHAR,
                -- ProductionId INT,
                DowntimeInstanceId VARCHAR,
				MachinesInPipelineId VARCHAR,
				DowntimeReasonId VARCHAR,
				FromTime TIMESTAMP WITH TIME ZONE NOT NULL,
				ToTime TIMESTAMP WITH TIME ZONE NOT NULL,
				Issue VARCHAR,
				Action VARCHAR,
                CONSTRAINT  Shift_Machine_Time UNIQUE (ShiftId, MachinesInPipelineId, FromTime),
				ActionTime TIMESTAMP WITH TIME ZONE NOT NULL,
                -- FOREIGN KEY (ProductionId) REFERENCES %I."Production"(ProductionId),
                FOREIGN KEY (MachinesInPipelineId) REFERENCES %I."MachinesInPipeline"(Id)
            )', schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_breakdowntbl_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_breakdowntbl_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'Breakdowns') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I."Breakdowns"', userName);
            RAISE NOTICE 'Dropping existing foreign table: %', 'Breakdowns';
            EXECUTE drop_table_command;
        END IF;

        create_microstoptbl_command := format(
            'CREATE TABLE IF NOT EXISTS %I."Microstops" (
                MicrostopId SERIAL PRIMARY KEY,
                RunId INT,
                DowntimeInstanceId VARCHAR,
				MachinesInPipelineId VARCHAR,
				DowntimeReasonId VARCHAR,
				FromTime TIMESTAMP WITH TIME ZONE NOT NULL,
				ToTime   TIMESTAMP WITH TIME ZONE NOT NULL,
				Issue VARCHAR,
				Action VARCHAR,
				ActionTime  TIMESTAMP WITH TIME ZONE,
                CONSTRAINT  Time_Machine_Run UNIQUE (RunId, MachinesInPipelineId, FromTime),
                FOREIGN KEY (RunId) REFERENCES %I."Runs"(RunId),
                FOREIGN KEY (MachinesInPipelineId) REFERENCES %I."MachinesInPipeline"(Id)
            )', schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_microstoptbl_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_microstoptbl_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'Microstops') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I."Microstops"', userName);
            RAISE NOTICE 'Dropping existing foreign table: %', 'Microstops';
            EXECUTE drop_table_command;
        END IF;

        create_runsummarytbl_command := format(
            'CREATE TABLE IF NOT EXISTS %I."RunSummary" (
                prodshiftid VARCHAR,
                line VARCHAR,
                linename VARCHAR,
                plant VARCHAR,
                toproduce INT DEFAULT 0,
                totalcount INT DEFAULT 0,
                okcount INT DEFAULT 0,
                ngcount INT DEFAULT 0,
                fttcount INT DEFAULT 0,
                actualtime  INTERVAL,
                changeoverstarttime TIMESTAMP WITH TIME ZONE,
                changeoverendtime TIMESTAMP WITH TIME ZONE,
                CONSTRAINT  Run_Summary_Constraint UNIQUE (prodshiftid, line, linename, plant, changeoverstarttime, changeoverendtime),
                -- FOREIGN KEY (prodshiftid) REFERENCES %I."LineShiftTimes"(id),
                FOREIGN KEY (line) REFERENCES %I."Lines"(lineId),
                -- FOREIGN KEY (linename) REFERENCES %I."Lines"(linename),
                FOREIGN KEY (plant) REFERENCES %I."Plants"(plantname)
                -- ,
                -- FOREIGN KEY (changeoverstarttime) REFERENCES %I."Shifts"(changeoverstarttime),
                -- FOREIGN KEY (changeoverendtime) REFERENCES %I."Shifts"(changeoverendtime)
            )', schemaName, schemaName, schemaName, schemaName, schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_runsummarytbl_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_runsummarytbl_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'RunSummary') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I."RunSummary"', userName);
            RAISE NOTICE 'Dropping existing foreign table: %', 'RunSummary';
            EXECUTE drop_table_command;
        END IF;

        import_foreign_schema_command := format('
            IMPORT FOREIGN SCHEMA public
            LIMIT TO ("Shifts","Runs", "Breakdowns", "Microstops", "RunSummary")
            FROM SERVER %I
            INTO %I',
            rec.srvname,
            userName
        );

        RAISE NOTICE 'Executing import command: %', import_foreign_schema_command;
        EXECUTE import_foreign_schema_command;

        RAISE NOTICE ' remote connection string: %', remote_conn_string;
        -- Perform creation of the procedure in the child database
        PERFORM dblink_exec(remote_conn_string, shift_procedure_body);

        RAISE NOTICE ' remote connection string: %', remote_conn_string;
        -- Perform creation of the procedure in the child database
        PERFORM dblink_exec(remote_conn_string, run_procedure_body);

        RAISE NOTICE ' remote connection string: %', remote_conn_string;
        -- Perform creation of the procedure in the child database
        PERFORM dblink_exec(remote_conn_string, microstop_procedure_body);

        RAISE NOTICE ' remote connection string: %', remote_conn_string;
        -- Perform creation of the procedure in the child database
        PERFORM dblink_exec(remote_conn_string, brkdown_procedure_body);

        RAISE NOTICE ' remote connection string: %', remote_conn_string;
        -- Perform creation of the procedure and the trigger in the child database
        PERFORM dblink_exec(remote_conn_string, chk_barcode_procedure_body);

        RAISE NOTICE ' remote connection string: %', remote_conn_string;
        -- Perform creation of the procedure in the child database
        PERFORM dblink_exec(remote_conn_string, runsummary_procedure_body);

    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION insertShifts(
    shiftId VARCHAR,
    lineShiftPlanId VARCHAR,
    changeoverStartTime TIMESTAMP WITH TIME ZONE,
    changeoverEndTime TIMESTAMP WITH TIME ZONE,
    plannedProduction INT,
    totalProduction INT,
    totalOK INT,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    remote_conn_str_command TEXT;
    remote_conn_string TEXT;
    command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN
    -- Ensure required fields are not NULL
    IF shiftId IS NULL OR lineShiftPlanId IS NULL OR changeoverStartTime IS NULL OR changeoverEndTime IS NULL THEN
        RAISE EXCEPTION 'shiftId, lineShiftPlanId, changeoverStartTime, and changeoverEndTime cannot be NULL';
    END IF;

    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the command to call the procedure
        command := format('
		CALL %I.insert_shifts(%L, %L, %L, %L, %L, %L, %L)
        ',
            schemaName,
            shiftId,
            lineShiftPlanId,
            changeoverStartTime,
            changeoverEndTime,
            plannedProduction,
            totalProduction,
            totalOK
        );

        -- Execute the command in the remote database
        PERFORM dblink_exec(remote_conn_string, command);
    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION insertRuns(
    prodShiftId VARCHAR,
    barcode VARCHAR,
    runNumber INT,
    entryMachineId VARCHAR,
    exitMachineId VARCHAR,
    entryMachineTimeStamp TIMESTAMP WITH TIME ZONE,
    exitMachineTimeStamp TIMESTAMP WITH TIME ZONE,
    status VARCHAR,
    otherInfo VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    remote_conn_str_command TEXT;
    remote_conn_string TEXT;
    command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN

    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the command to call the procedure
        command := format('
		CALL %I.insert_runs(%L, %L, %L, %L, %L, %L, %L, %L, %L)
        ',
            schemaName,
            prodShiftId,
            barcode,
            runNumber,
            entryMachineId,
            entryMachineTimeStamp,
            exitMachineId,
            exitMachineTimeStamp,
            status,
            otherInfo
        );

        -- Execute the command in the remote database
        PERFORM dblink_exec(remote_conn_string, command);
    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION insertMicroStops(
    runId INT,
    downtimeInstanceId VARCHAR,
    machinesInPipelineId VARCHAR,
    downtimeReasonId VARCHAR,
    fromTime TIMESTAMP WITH TIME ZONE,
    toTime TIMESTAMP WITH TIME ZONE,
    issue VARCHAR,
    action VARCHAR,
    actionTime TIMESTAMP WITH TIME ZONE,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    remote_conn_str_command TEXT;
    remote_conn_string TEXT;
    command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN

    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the command to call the procedure
        command := format('
		CALL %I.insert_microstops(%L, %L, %L, %L, %L, %L, %L, %L, %L)
        ',
            schemaName,
            runId,
            downtimeInstanceId,
            machinesInPipelineId,
            downtimeReasonId,
            fromTime,
            toTime,
            issue,
            action,
            actionTime
        );

        -- Execute the command in the remote database
        PERFORM dblink_exec(remote_conn_string, command);
    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION insertBreakdowns(
    shiftId VARCHAR,
    downtimeInstanceId VARCHAR,
    machinesInPipelineId VARCHAR,
    downtimeReasonId VARCHAR,
    fromTime TIMESTAMP WITH TIME ZONE,
    toTime TIMESTAMP WITH TIME ZONE,
    issue VARCHAR,
    action VARCHAR,
    actionTime TIMESTAMP WITH TIME ZONE,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    remote_conn_str_command TEXT;
    remote_conn_string TEXT;
    command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN

    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the command to call the procedure
        command := format('
		CALL %I.insert_breakdowns(%L, %L, %L, %L, %L, %L, %L, %L, %L)
        ',
            schemaName,
            shiftId,
            downtimeInstanceId,
            machinesInPipelineId,
            downtimeReasonId,
            fromTime,
            toTime,
            issue,
            action,
            actionTime
        );

        -- Execute the command in the remote database
        PERFORM dblink_exec(remote_conn_string, command);
    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION insertRunSummary(
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    remote_conn_str_command TEXT;
    remote_conn_string TEXT;
    command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN

    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the command to call the procedure
        command := format('
		CALL %I.insert_runsummary()
        ',
            schemaName
        );

        -- Execute the command in the remote database
        PERFORM dblink_exec(remote_conn_string, command);
    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

-- CREATE OR REPLACE FUNCTION RunSummaryData (
-- 	prodshiftid VARCHAR,
-- 	userName VARCHAR,
--     schemaName VARCHAR DEFAULT 'public'
-- )
-- RETURNS TABLE (
--     lineId VARCHAR,
--     line VARCHAR,
--     plantname VARCHAR,
--     toproduce INTEGER
-- ) AS
-- $$
-- DECLARE
-- create_run_summary_command TEXT;
-- BEGIN
-- 	create_run_summary_command := format(
--         'SELECT
--             l.lineId,
--             l.linename,
--             p.plantname,
--             t.toproduce
--         FROM %I."LineShiftPlans" t
--         LEFT JOIN %I."LineShiftTimes" ls ON t.shiftid = ls.id
--         LEFT JOIN %I."Lines" l ON l.lineid = ls.line
--         LEFT JOIN %I."Plants" p ON p.plantid = l."locId"
--         WHERE t.id = $1',
--         userName, userName, userName, userName
-- 	);
	
-- 	RAISE NOTICE 'Executing run summary command %', create_run_summary_command;
	
-- 	RETURN QUERY EXECUTE create_run_summary_command USING prodshiftid;
-- END;
-- $$ LANGUAGE plpgsql;