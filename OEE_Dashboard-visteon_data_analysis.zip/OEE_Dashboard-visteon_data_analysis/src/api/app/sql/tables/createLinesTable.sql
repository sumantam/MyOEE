DROP FUNCTION IF EXISTS createLinesTable;

CREATE OR REPLACE FUNCTION createLinesTable(
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    alter_table_command TEXT;
    create_line_command TEXT;
    create_sequence_command TEXT;
    remote_conn_str_command TEXT;
    import_foreign_schema_command TEXT;
    remote_conn_string TEXT;
    drop_table_command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN
    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the create table command
        create_line_command := format(
            'CREATE TABLE IF NOT EXISTS %I."Lines" (
                LineId VARCHAR PRIMARY KEY,
                LineName VARCHAR(255) NOT NULL,
                "locId" INTEGER NOT NULL,
                ancillarylinedatafile VARCHAR(255),
                CONSTRAINT "line_loc_fkey" FOREIGN KEY ("locId")
                REFERENCES "Plants" (plantId) ON DELETE CASCADE
            )', schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_line_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_line_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'Lines') THEN
            drop_table_command := format('DROP FOREIGN TABLE %I.%I', userName, 'Lines');
            RAISE NOTICE 'Dropping existing foreign table: %', 'Lines';
            EXECUTE drop_table_command;
        END IF;

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'DowntimeInstances') THEN
            drop_table_command := format('DROP FOREIGN TABLE %I.%I', userName, 'DowntimeInstances');
            RAISE NOTICE 'Dropping existing foreign table: %', 'DowntimeInstances';
            EXECUTE drop_table_command;
        END IF;

        import_foreign_schema_command := format('
            IMPORT FOREIGN SCHEMA public
            LIMIT TO ("Lines")
            FROM SERVER %I
            INTO %I',
            rec.srvname,
            userName
        );

        RAISE NOTICE 'Executing import command: %', import_foreign_schema_command;
        EXECUTE import_foreign_schema_command;

    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;
