DROP FUNCTION IF EXISTS createLineShiftPlansTable;
DROP FUNCTION IF EXISTS get_LineShiftPlans_procedure_body;
DROP FUNCTION IF EXISTS insertModel;

CREATE OR REPLACE FUNCTION get_LineShiftPlans_procedure_body()
RETURNS TEXT AS
$$
BEGIN
    RETURN '
        DROP PROCEDURE IF EXISTS insert_model;

        CREATE OR REPLACE PROCEDURE insert_model(
            _model_name VARCHAR,
            _barcode_name VARCHAR
        )
        AS $proc$
        DECLARE
            current_version INT;
        BEGIN
            INSERT INTO "Models" (ModelName, barcode_prefix)
                VALUES (_model_name, _barcode_name)
                ON CONFLICT (ModelName) DO NOTHING;
        END;
        $proc$ LANGUAGE plpgsql;
    ';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION createLineShiftPlansTable(
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public',
    procedure_body TEXT DEFAULT get_LineShiftPlans_procedure_body()
)
RETURNS BOOLEAN AS $$
DECLARE
    create_lineshiftplans_command TEXT;
    remote_conn_str_command TEXT;
    import_foreign_schema_command TEXT;
    remote_conn_string TEXT;
    drop_table_command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN
    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the create table command
        create_lineshiftplans_command := format(
            'CREATE TABLE IF NOT EXISTS %I."LineShiftPlans" (
                Id VARCHAR PRIMARY KEY,
                ShiftId VARCHAR,
                StartTime TIMESTAMP WITH TIME ZONE NOT NULL,
                ChangeoverTimeAfter INT,
                OtherTimes  INT,
                ToProduce INT,
                ModelId INT,
                FOREIGN KEY (ShiftId) REFERENCES %I."LineShiftTimes"(Id),
                FOREIGN KEY (ModelId) REFERENCES %I."Models"(ModelId)
            )', schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_lineshiftplans_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_lineshiftplans_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'LineShiftPlans') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I."LineShiftPlans"', userName);
            RAISE NOTICE 'Dropping existing foreign table: %', 'LineShiftPlans';
            EXECUTE drop_table_command;
        END IF;

        import_foreign_schema_command := format('
            IMPORT FOREIGN SCHEMA public
            LIMIT TO ("LineShiftPlans")
            FROM SERVER %I
            INTO %I',
            rec.srvname,
            userName
        );

        RAISE NOTICE 'Executing import command: %', import_foreign_schema_command;
        EXECUTE import_foreign_schema_command;

        RAISE NOTICE ' remote connection string: %', remote_conn_string;
        -- Perform creation of the procedure in the child database
        PERFORM dblink_exec(remote_conn_string, procedure_body);

    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION insertModel(
    modelName VARCHAR,
    barcodePrefix VARCHAR,
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    remote_conn_str_command TEXT;
    remote_conn_string TEXT;
    command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN
    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the command to call the procedure
        
        command := format('
		CALL %I.insert_model(%L, %L)
        ', schemaName, modelName, barcodePrefix
        );

        -- Execute the command in the remote database
        PERFORM dblink_exec(remote_conn_string, command);

    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;