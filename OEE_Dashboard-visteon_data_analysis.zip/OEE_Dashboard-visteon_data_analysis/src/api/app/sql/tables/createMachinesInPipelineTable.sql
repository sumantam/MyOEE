DROP FUNCTION IF EXISTS createMachinesInPipelineTable;

CREATE OR REPLACE FUNCTION createMachinesInPipelineTable(
    userName VARCHAR,
    schemaName VARCHAR DEFAULT 'public'
)
RETURNS BOOLEAN AS $$
DECLARE
    create_machineinpipeline_command TEXT;
    remote_conn_str_command TEXT;
    import_foreign_schema_command TEXT;
    remote_conn_string TEXT;
    drop_table_command TEXT;
    rec RECORD;
    combined_options TEXT[];
BEGIN
    -- Define the remote connection string command
    remote_conn_str_command := format(
        'SELECT srv.oid, srv.srvname,
                srv.srvowner, srv.srvfdw,
                array_cat(srv.srvoptions, um.umoptions) AS combined_options
        FROM pg_foreign_server AS srv
        JOIN pg_user_mappings AS um ON srv.oid = um.srvid
        WHERE %L = ANY (um.umoptions)',
        format('user=%s', userName)
    );

    -- Print the command
    RAISE NOTICE 'Executing: %', remote_conn_str_command;

    -- Execute the command and fetch the result into rec
    FOR rec IN EXECUTE remote_conn_str_command LOOP
        RAISE NOTICE 'oid: %, srvname: %, srvowner: %, srvfdw: %, combined_options: %',
            rec.oid, rec.srvname, rec.srvowner, rec.srvfdw, rec.combined_options;
        
        -- Extract the combined options into a text array
        combined_options := rec.combined_options;
        
        -- Build the connection string
        remote_conn_string := array_to_string(combined_options, ' ');

        -- Define the create table command
        create_machineinpipeline_command := format(
            'CREATE TABLE IF NOT EXISTS %I."MachinesInPipeline" (
                Id VARCHAR PRIMARY KEY,
                LineId VARCHAR NOT NULL,
                MachineType VARCHAR NOT NULL,
                PreviousMachineId VARCHAR,
                MachineName VARCHAR NOT NULL,
                PrecedingConveyorSize INTEGER NOT NULL,
                ExpectedCycleTime INTEGER NOT NULL,
                FOREIGN KEY (LineId) REFERENCES %I."Lines"(LineId),
                FOREIGN KEY (MachineType) REFERENCES %I."MachineTypes"(MachineName),
                FOREIGN KEY (PreviousMachineId) REFERENCES %I."MachinesInPipeline"(Id)
            )',
            schemaName, schemaName, schemaName, schemaName
        );

        -- Print the command
        RAISE NOTICE 'Executing create table command: %', create_machineinpipeline_command;

        -- Execute the create table command on the remote database
        PERFORM dblink_exec(remote_conn_string, create_machineinpipeline_command);

        -- Drop the foreign table if it exists
        IF EXISTS (
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = userName AND table_name = 'MachinesInPipeline') THEN
            drop_table_command := format('DROP FOREIGN TABLE IF EXISTS %I.%I', userName, 'MachinesInPipeline');
            RAISE NOTICE 'Dropping existing foreign table: %', 'MachinesInPipeline';
            EXECUTE drop_table_command;
        END IF;



        import_foreign_schema_command := format('
            IMPORT FOREIGN SCHEMA public
            LIMIT TO ("MachinesInPipeline")
            FROM SERVER %I
            INTO %I',
            rec.srvname,
            userName
        );

        RAISE NOTICE 'Executing import command: %', import_foreign_schema_command;
        EXECUTE import_foreign_schema_command;

    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

