const path = require('path');
const sequelize = require('../utils/database')
const dotenv = require('dotenv');
const nodeSchedule = require('node-schedule');
const envFilePath = path.join(__dirname, '..', '..', '..', 'api', '.env');
dotenv.config({ path: envFilePath });

const job = nodeSchedule.scheduleJob('*/1 * * * *', function(){
   const now = new Date();	
   console.log('Job has been triggered at: ', now.toLocaleTimeString());
/*   sequelize.query('CALL database_service(300);');
*/
});
/*
sequelize.query('CALL database_service(300);').spread(
    console.log(" It is inside the stored procedure call ");
);
*/
