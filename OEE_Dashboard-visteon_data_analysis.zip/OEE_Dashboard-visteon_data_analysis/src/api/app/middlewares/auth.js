const firebase = require("../utils/firebase");
const { logger } = require('../utils/logger')

function authMiddleware(request, response, next) {
  logger.info(`path: ${request.path}`)
  const headerToken = request.headers.authorization;
  const apiHeader = request.headers.api_key;
  //console.log(request.headers);

  console.log(request.headers);
  console.log(apiHeader);
  if(apiHeader && apiHeader === '4870f96b-6590-43ef-bde5-ad20afdf3daa'){
    next();
  } else{
    if (!headerToken) {
      return response.send({ message: "No token provided" }).status(401);
    }

    if (headerToken && headerToken.split(" ")[0] !== "Bearer") {
      response.send({ message: "Invalid token" }).status(401);
    }

    const token = headerToken.split(" ")[1];
    firebase
      .auth()
      .verifyIdToken(token)
      .then(decodedIdToken => {
        console.log('ID Token correctly decoded', decodedIdToken);
        request.uid = decodedIdToken.uid;
        request.email = decodedIdToken.email;
        next();
       })
       .catch(error => {
        console.error('Error while verifying ID token:', error);
        response.status(403).json({error: 'Unauthorized'});
       });
  }
}

module.exports = authMiddleware;
