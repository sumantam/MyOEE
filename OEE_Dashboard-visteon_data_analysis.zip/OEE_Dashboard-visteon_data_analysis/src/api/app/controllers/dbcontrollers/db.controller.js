const FDW = require('../../utils/FDW')
const { PgPools } = require('../../utils/pgPool')
const { Model } = require('../../models/Model')
const { Plant } = require('../../models/Plant')
const { Line } = require('../../models/Line')
const { MachineType } = require('../../models/MachineType')
const { LineShiftTime } = require('../../models/LineShiftTime')
const { LineShiftPlan } = require('../../models/LineShiftPlan')
const { MachinesInPipeline } = require('../../models/MachinesInPipeline')
const { IssueType } = require('../../models/IssueType')
const { Production } = require('../../models/Production')
const { DowntimeReason } = require('../../models/DowntimeReason')
const { ChangeOverTypeTimes } = require('../../models/ChangeOverTypeTimes')
const { StdCycleTimes } = require('../../models/StdCycleTimes')
const dbConfig = require('../../config/db.config')
const ClientStoredProc = require('../../utils/clientstoredproc')

// ####################################################
// Create a new DataBase by Super Admin
exports.createAuxDB = async (req, res) => {
  const data = req.body.data
  const remoteHost = data.remote_host
  const portNumber = data.port_number
  const remoteDb = data.remote_db
  const remoteServer = data.remote_server ? data.remote_server : remoteDb + '_server'
  const user = data.user

  console.log('Creating Auxilliary DataBase')

  try {
    // TODO : Modify the call below to account for creation of the database on a remote host
    await FDW.createFDWDatabase(remoteDb, user)
    res.status(200).send('Foreign DataBase for Data Wrapper created successfully')
  } catch (error) {
    console.error('Error in creating Foreign Data Wrapper', error.message)
    res.status(500).send(error.message)
  };
}

// ####################################################
// Create Foreign Data Wrapper by Super Admin
exports.createFDW = async (req, res) => {
  const data = req.body.data
  const remoteHost = data.remote_host
  const portNumber = data.port_number
  const remoteDb = data.remote_db
  const remoteServer = data.remote_server ? data.remote_server : remoteDb + '_server'
  const remoteUser = data.user

  console.log('Creating Foreign Data Wrapper')

  try {
    // create the foreign data wrapper of a database
    // const status = await FDW.createFDW(remote_host,port_number,remote_db,remote_server);

    const status = await FDW.createFDW(
      remoteUser,
      remoteHost,
      portNumber,
      remoteDb,
      remoteServer
    )

    res.status(200).send('Result of creating foreign data wrapper = ' + status)
  } catch (error) {
    console.error('Error in creating Foreign Data Wrapper', error.message)
    res.status(500).send(error.message)
  };
}

// ####################################################
// Create Client Tables
exports.createClientTables = async (req, res) => {
  const data = req.body.data
  const schemaName = data.schemaName
  // 'host=localhost port=5432 dbname=resonance_db10 user=dbUser1 password=passdbUser1'

  console.log('Creating New Tables')

  try {
    const status1 = await ClientStoredProc.executeClientSqlFile(schemaName)
    const status2 = await ClientStoredProc.executeClientUtilityFile(schemaName)

    res.status(200).send('Result of creating Client Tables = ' + status1 + status2)
  } catch (error) {
    console.error('Error in creating Client Tables', error.message)
    res.status(500).send(error.message)
  };
}

exports.createModels = async (req, res) => {
  const data = req.body.data
  const { schemaName, database, modelName, modelId = null, modelDataFile = null } = data
  try {
    const modelData = {
      modelId,
      modelName,
      modelDataFile
    }

    // Test the database exists
    let client = await PgPools.getPool().getClient()
    const query = 'SELECT 1 FROM pg_database WHERE datname = $1;'
    const result = await client.query(query, [database])
    client.release(true)

    if (result.rowCount > 0) {
      // Test or create the Model Table
      await PgPools.getPool(dbConfig.DB).createTable('Model', schemaName)

      client = await PgPools.getPool(dbConfig.DB).getClient()
      const designModel = new Model()
      const status = designModel.createModel(modelData, schemaName)
      client.release(true)
      res.status(200).send('Result of creating Models = ' + status)
    } else {
      console.error('Error: Database is not present')
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating Models', error.message)
    res.status(500).send(error.message)
  }
}

exports.createLocations = async (req, res) => {
  const data = req.body.data
  const { schemaName, plantName, isReturn = false, plantId = null, plantDataFile = null } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designPlant = new Plant(schemaName)

      plantName.forEach(async element => {
        const PlantData = {
          plantName: element.Name,
          plantDataFile
        }
        await designPlant.createPlant(PlantData)
      })
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the Plants' }
      }
      res.status(200).send('Successfully created the Plants')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating Plants', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating Plants' }
    }
    res.status(500).send(error.message)
  }
}

exports.createStandardCycleTimes = async (req, res) => {
  const data = req.body.data
  const { schemaName, stdCycleTimes, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designstdcycleTimes = new StdCycleTimes(schemaName)

      stdCycleTimes.forEach(async element => {
        if (Object.keys(element).length === 0) {
          return
        }

        const plant = element["Plant"]
        const line = element["Line"]
        const cycleTimes = element["Cycle_Times"]

        cycleTimes.forEach(async obj => {
          if (Object.keys(obj).length === 0) {
            return
          }
          const [key, value] = Object.entries(obj)[0]

          const StdCycleTimesData = {
            Plant: plant,
            Line: line,
            Model: key,
            CycleTime: value
          }
          await designstdcycleTimes.createStdCycleTimes(StdCycleTimesData)
        })
      })
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating stdCycleTimes', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating stdCycleTimes' }
    }
    res.status(500).send(error.message)
  }
}

exports.createChangeOverTypeTimes = async (req, res) => {
  const data = req.body.data
  const { schemaName, changeoverTypeTimes, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designChangeoverTypeTimes = new ChangeOverTypeTimes(schemaName)

      changeoverTypeTimes.forEach(async element => {
        if (Object.keys(element).length === 0) {
          return
        }
        const [key, value] = Object.entries(element)[0]
        const ChangeOverTimesData = {
          changeoverTypeTimesKey: key,
          changeoverTypeTimesVal: value
        }
        await designChangeoverTypeTimes.createChangeOverTypeTimes(ChangeOverTimesData)
      })
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the changeoverTypeTimes' }
      }
      res.status(200).send('Successfully created the changeoverTypeTimes ')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating changeoverTypeTimes', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating changeoverTypeTimes' }
    }
    res.status(500).send(error.message)
  }
}

exports.createChangeOverTypes = async (req, res) => {
  const data = req.body.data
  const { schemaName, changeoverTypes, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designChangeoverTypes = new ChangeOverTypeTimes(schemaName)

      changeoverTypes.forEach(async element => {
        if (Object.keys(element).length === 0) {
          return
        }

        const From = element["From"]
        const ToList = element["To"]

        ToList.forEach(async obj => {
          const [key, value] = Object.entries(obj)[0]
          const ChangeOverTypesData = {
            fromTypes: From,
            toTypes: key,
            Val: value
          }

          await designChangeoverTypes.createChangeOverTypes(ChangeOverTypesData)
        })
      })
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the changeoverTypes' }
      }
      res.status(200).send('Successfully created the changeoverTypes ')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating changeoverTypes', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating changeoverTypes' }
    }
    res.status(500).send(error.message)
  }
}

exports.createDowntimeReasons = async (req, res) => {
  const data = req.body.data
  const { schemaName, downtimeReasons, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designDowntimeReason = new DowntimeReason(schemaName)

      downtimeReasons.forEach(async element => {
        if (Object.keys(element).length === 0) {
          return
        }

        const actionArray = element.Actions
        let i = 0

        do {
          const downtimeReasonData = {
            downtimeReasonId: element.Reason_Id,
            class: element.Class,
            rootCause: element.Root_Cause,
            context: element.Context,
            actionId: (actionArray?.length > 0) ? actionArray[i].AId : null,
            desc: (actionArray?.length > 0) ? actionArray[i].Desc : null
          }
          i++
          await designDowntimeReason.createDowntimeReason(downtimeReasonData)
        } while (i < actionArray?.length)
      })
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the Downtime Reasons' }
      }
      res.status(200).send('Successfully created the Downtime Reasons')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating Plants', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating Downtime Instances' }
    }
    res.status(500).send(error.message)
  }
}

function convertToJSON(plantArray) {
  const result = {}

  plantArray.forEach(plant => {
    result[plant.plantname] = plant.plantid
  })
  return result
}

exports.createLines = async (req, res) => {
  const data = req.body.data
  const { schemaName, Lines, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designLine = new Line(schemaName)

      // Since the number of plants would be small
      const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
      const query = `SELECT PlantName, Plantid FROM ${schemaName}."Plants";`
      const queryRes = await client.query(query)
      const jsonResult = convertToJSON(queryRes.rows)
      // console.log(queryRes.rows)
      client.release(true)

      Lines.forEach(async element => {
        if (jsonResult[element.Plant]) {
          const LineData = {
            lineId: element.Id,
            lineName: element.Name,
            locId: jsonResult[element.Plant],
            lineDetailsFile: element.Details_File
          }

          // console.log('LineData : => ', LineData)
          await designLine.createLine(LineData)
        }
      })
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the Lines' }
      }
      res.status(200).send('Successfully created the Lines')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating Lines', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating Lines' }
    }
    res.status(500).send(error.message)
  }
}

exports.createMachineTypes = async (req, res) => {
  const data = req.body.data
  const { schemaName, MachineTypes, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designMachineType = new MachineType(schemaName)
      const designIssueType = new IssueType(schemaName)

      MachineTypes.forEach(async element => {
        if (Object.keys(element).length === 0) {
          return
        }
        const MachineTypeData = {
          MachineName: element.Name,
          CycleTime: element.Manufacturers_Cycle_Time
        }

        const BreakDown = element.Breakdown_Issues
        const Microstop = element.Microstop_Issues
        const Quality = element.Quality_Issues

        // console.log('MachineTypeData : => ', MachineTypeData)
        const transaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
        await designMachineType.createMachineType(MachineTypeData, transaction)
        await designIssueType.createIssueType('Breakdown', MachineTypeData.MachineName, BreakDown, transaction)
        await designIssueType.createIssueType('Microstop', MachineTypeData.MachineName, Microstop, transaction)
        await designIssueType.createIssueType('Quality', MachineTypeData.MachineName, Quality, transaction)
        await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
      })
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the MachineTypes' }
      }
      res.status(200).send('Successfully created the MachineTypes')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating MachineTypes', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating MachineTypes' }
    }
    res.status(500).send(error.message)
  }
}

exports.createMachinesInPipeline = async (req, res) => {
  const data = req.body.data
  const { schemaName, MachinesInPipelines, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designMachinesInPipeline = new MachinesInPipeline(schemaName)

      for (const element of MachinesInPipelines) {
        if (Object.keys(element).length === 0) {
          continue
        }
        const MachinesInPipelineData = {
          Id: element.Id,
          Line: element.Line,
          MachineType: element.Machine_Type,
          PreviousMachineId: element.Previous_Machine_Id,
          MachineName: element.Name,
          PrecedingConveyorSize: element.Preceding_Conveyor_Size,
          ExpectedCycleTime: element.Expected_Cycle_Time
        }

        // console.log('MachinesInPipelineData : => ', MachinesInPipelineData)
        const transaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
        await designMachinesInPipeline.createMachineInPipeline(MachinesInPipelineData, transaction)
        await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
      }
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the MachineInPipeline' }
      }
      res.status(200).send('Successfully created the MachineInPipeline')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating MachineInPipeline', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating MachineInPipeline' }
    }
    res.status(500).send(error.message)
  }
}

exports.createLineShiftTimes = async (req, res) => {
  const data = req.body.data
  const { schemaName, LineShiftTimes, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designLineShiftTime = new LineShiftTime(schemaName)

      LineShiftTimes.forEach(async element => {
        if (Object.keys(element).length === 0) {
          return
        }
        const LineShiftTimeData = {
          Id: element.Id,
          ShiftName: element.Shift_Name,
          Start: element.Start_Time,
          Stop: element.End_Time,
          ShiftOwner: element.Shift_Owner,
          Line: element.Line,
          UTCOffset: element.UTC_Offset
        }

        // console.log('MachinesInPipelineData : => ', MachinesInPipelineData)
        const transaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
        await designLineShiftTime.createLineShiftTime(LineShiftTimeData, transaction)
        await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
      })
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the LineShiftTimes' }
      }
      res.status(200).send('Successfully created the LineShiftTimes')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating MachineInPipeline', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating LineShiftTimes' }
    }
    res.status(500).send(error.message)
  }
}

exports.createLineShiftPlans = async (req, res) => {
  const data = req.body.data
  const { schemaName, LineShiftPlans, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designLineShiftPlan = new LineShiftPlan(schemaName)

      LineShiftPlans.forEach(async element => {
        if (Object.keys(element).length === 0) {
          return
        }
        const LineShiftPlanData = {
          Id: element.Id,
          ShiftId: element.Shift_Id,
          StartTime: element.Start_Time,
          ChangeoverTimeAfter: element.Changeover_Time_After,
          OtherTimes: element.Other_Times,
          ToProduce: element.To_Produce,
          ModelName: element.Model_Name,
          barCodePrefix: element.Barcode_Prefix
        }

        // console.log('MachinesInPipelineData : => ', MachinesInPipelineData)
        const transaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
        await designLineShiftPlan.createLineShiftPlan(LineShiftPlanData, transaction)
        await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
      })
      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the LineShiftPlans' }
      }
      res.status(200).send('Successfully created the LineShiftPlans')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating LineShiftPlans', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating LineShiftPlans' }
    }
    res.status(500).send(error.message)
  }
}

exports.createProductionSummary = async (req, res) => {
  const data = req.body.data
  const { schemaName, ProdSummary, isReturn = false } = data
  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = 'SELECT * FROM "fdwDbExists"($1)'
    const result = await client.query(query, [schemaName])
    client.release(true)

    if (result.rowCount > 0) {
      const designProd = new Production(schemaName)

      ProdSummary.forEach(async element => {
        if (Object.keys(element).length === 0) {
          return
        }

        for (const subelement of element.Data) {
          if (Object.keys(subelement).length === 0) {
            continue
          }
          const ProdSummaryData = {
            ShiftId: element.Shift_Id,
            LineShiftPlanId: subelement.Line_Shift_Plan_Id,
            ChangeoverTimeStart: subelement.Changeover_Time_Start,
            ChangeoverTimeEnd: subelement.Changeover_Time_End,
            Planned: subelement.Planned,
            Total: subelement.Total,
            TotalOK: subelement.Total_OK
          }

          const prodtransaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
          await designProd.createProduction(ProdSummaryData, prodtransaction)
          await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(prodtransaction)

          const brktransaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()

          for (const brkdownelement of subelement.Breakdowns) {
            if (Object.keys(brkdownelement).length === 0) {
              continue
            }
            const BreakdownData = {
              ShiftId: element.Shift_Id,
              DowntimeInstanceId: brkdownelement.Downtime_Instance_Id,
              MachinesInPipelineId: brkdownelement.Machines_In_Pipeline_Id,
              DowntimeReasonId: brkdownelement.Downtime_Reason_Id,
              FromTime: brkdownelement.From_Time,
              ToTime: brkdownelement.To_Time,
              Issue: brkdownelement.Issue,
              ActionId: brkdownelement.Action,
              ActionTime: brkdownelement.Action_Time
            }
            await designProd.createBreakdown(BreakdownData, brktransaction)
          }
          await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(brktransaction)

          const microStopList = []
          const runtransaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()

          for (const productionelement of subelement.Productions) {
            if (Object.keys(productionelement).length === 0) {
              continue
            }

            for (const runelement of productionelement.Runs) {
              if (Object.keys(runelement).length === 0) {
                continue
              }
              const RunData = {
                ProdShiftId: subelement.Line_Shift_Plan_Id,
                Barcode: productionelement.Barcode,
                RunNumber: runelement.Run_Number,
                EntryMachineId: runelement.Entry_Machine_Id,
                ExitMachineId: runelement.Exit_Machine_Id,
                EntryMachineTimestamp: runelement.Entry_Machine_Timestamp,
                ExitMachineTimestamp: runelement.Exit_Machine_Timestamp,
                Status: runelement.Status,
                OtherInfo: runelement.Other_Info
              }
              await designProd.createRuns(RunData, runtransaction)

              const Microstops = runelement.Microstop_Instances

              Microstops.forEach(async microstop => {
                if (Object.keys(microstop).length !== 0) {
                  const microstopData = {
                    Barcode: productionelement.Barcode,
                    RunNumber: runelement.Run_Number,
                    DowntimeInstanceId: microstop.Downtime_Instance_Id,
                    MachinesInPipelineId: microstop.Machines_In_Pipeline_Id,
                    DowntimeReasonId: microstop.Downtime_Reason_Id,
                    FromTime: microstop.From_Time,
                    ToTime: microstop.To_Time,
                    Issue: microstop.Issue,
                    Action: microstop.Action,
                    ActionTime: microstop.Action_Time
                  }

                  microStopList.push(microstopData)
                }
              })
            }
          }
          await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(runtransaction)

          const microstoptransaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()

          await Promise.all(microStopList.map(async (value) => {
            return designProd.createMicroStops(value, microstoptransaction)
          }))

          await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(microstoptransaction)
        }
      })

      const runsummarytransaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
      await designProd.createRunSummary(runsummarytransaction)
      await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(runsummarytransaction)

      console.log('Successfully exiting after inserting into table')
      if (isReturn) {
        return { status: true, msg: 'Successfully created the Production' }
      }
      res.status(200).send('Successfully created the Production')
    } else {
      console.error('Error: Database is not present')
      if (isReturn) {
        return { status: false, msg: 'Database does not exist' }
      }
      res.status(500).send('Database does not exist')
    }
  } catch (error) {
    console.error('Error in creating Production', error.message)
    if (isReturn) {
      return { status: false, msg: 'Error in creating Production' }
    }
    res.status(500).send(error.message)
  }
}
