const firebase = require('../utils/firebase')
const { User } = require('../models/User')
const { Relation } = require('../models/Relation')
// const sequelize = require('../utils/database')
const { Op } = require('sequelize')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

function parseDomainName (email) {
  // Split the email address at the '@' symbol
  const parts = email.split('@')
  if (parts.length !== 2) {
    throw new Error('Invalid email address')
  }
  const domain = parts[1]
  const companyName = domain.split('.')[0]
  return companyName
}



// ###############################################
// Get all users info
exports.findAll = async (req, res) => {
  // save user in database
  const { schema } = req.query
  try {
    const userModel = new User(schema)
    const data = await userModel.findAll()

    console.log('findAll called')
    if (data) {
      res.status(200).send(data)
    } else {
      res.status(404).send({ error_msg: 'Data Not Found' })
    }
  } catch (err) {
    res.status(500).send({
      message: err.message || 'Some error occurred while finding Users.'
    })
  }
}

// ###############################################
// find by primary Key
exports.findOne = async (req, res) => {
  const { email } = req.query
  console.log('Find One calling')
  const schema = parseDomainName(email)
  try {
    const userModel = new User(schema)
    const data = await userModel.findByPrimaryKey(email)

    console.log('findOne called')
    if (data) {
      res.status(200).send(data)
    } else {
      res.status(404).send({ error_msg: 'Data Not Found' })
    }
  } catch (err) {
    res.status(500).send({
      message: err.message || 'Some error occurred while finding the User.'
    })
  }
}

// ####################################################
// Delete by user email
exports.removeUser = async (req, res) => {
  const email = req.params.email
  console.log(`Deleting user: ${email}`)
  try {
    // deleting from database
    await User.destroy({ where: { email } })
    const userRecord = await firebase.auth().getUserByEmail(email)
    // deleting from firebase
    await firebase.auth().deleteUser(userRecord.uid)
    res.status(200).send(`user ${email} removed successfuly`)
  } catch (error) {
    console.error('Error in deleting the user:', error.message)
    res.status(500).send(error.message)
  };
}

// #########################################################
// get all matched substring usernames
exports.searchUser = (req, res) => {
  const { q } = req.query
  console.log(q)

  User.findAll({
    where: {
      email: {
        [Op.iLike]: `%${q}%`
      }
    }
  })
    .then((data) => {
      // console.log(data)
      res.status(200).send(data)
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || 'Some error occurred while removing the User.'
      })
    })
}

// #######################################################################
// get all matched substring usernames
exports.getUserByResponsibility = async (req, res) => {
  const { q, schema } = req.query
  try {
    const userModel = new User(schema)
    const data = await userModel.findByResponsibility(q)
    console.log('findUserByResponsibility called')
    if (data) {
      res.status(200).send(data)
    } else {
      res.status(404).send({ error_msg: 'Data Not Found' })
    }
    console.log('Get user by Responsbility')
  } catch (err) {
    console.log('Error with responsibility')
    res.status(500).send({
      message: err.message || 'Some error occurred while getting the User by responsibility.'
    })
  }
}

// ##############################################################

// create user
// may require some modification similar to createDefaultAdmin
exports.create = async (req, res) => {
  console.log(req.body.data)

  // storing the image here maybe need to use the file handling multer here.
  const img = req.body.data.img

  // extracting users basic details
  const user = {
    email: req.body.data.email,
    name: req.body.data.name,
    role: req.body.data.role,
    responsibility: req.body.data.responsibility,
    designation: req.body.data.designation,
    countryCode: req.body.data.countryCode,
    mobileNumber: req.body.data.mobileNumber,
    img,
    location: req.body.data.location,
    password: req.body.data.password
  }

  const schema = parseDomainName(user.email)

  // validate required data here

  // extracting the relations
  const relations = []
  const mgrList = req.body.data.mgrList
  const reporteeList = req.body.data.reporteeList

  // Traversing through the manager list and establishing the user-manager relation
  for (let i = 0; i < mgrList.length; i++) {
    const mgrEmail = mgrList[i].email
    relations.push({ userEmail: user.email, managerEmail: mgrEmail })
  }

  for (let i = 0; i < reporteeList.length; i++) {
    const reporteeEmail = reporteeList[i].email
    relations.push({ userEmail: reporteeEmail, managerEmail: user.email })
  }

  // Starting the transaction
  try {
    let userNotFoundDB

    const pgPoolsInstance = await PgPools.getInstance()
    const Result = await pgPoolsInstance.findByPrimaryKey(dbConfig.DB, 'Users', 'email', user.email, schema) // TODO: make this an object

    if (Result.rowCount === 0) {
      userNotFoundDB = true
    } else {
      userNotFoundDB = false
    }

    if (userNotFoundDB) {
      const transaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
      try {
        const userModel = new User(schema)
        await userModel.create(user, transaction)
        console.log('User added to the database')
        const userRelation = new Relation(schema)
        await userRelation.bulkCreate(relations, transaction)
        console.log('Relation added to the database')
        // Commit the transaction
        await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
        res.status(201).send('User created successfully')
      } catch (error) {
        console.error('Error inserting user:', error)
        // Rollback the transaction in case of error
        await pgPoolsInstance.getPool(dbConfig.DB).rollbackTransaction(transaction)
      }
    } else {
      res.status(202).send('User already exist')
    }
  } catch (error) {
    console.log('error:', error)
    res.status(500).send('Some error occured', error.toString())
  }
}

// Create Default Admin
exports.createDefaultAdmin = async (email = null, schema = 'public') => {
  // defining default admin details
  const user = {
    email: (email == null) ? 'admin@resonance.com' : email,
    name: 'Admin',
    role: 'Admin',
    responsibility: 'Supervisor',
    designation: 'Admin',
    countryCode: '91',
    mobileNumber: '9999999999',
    img: '',
    location: 'India',
    password: 'admin123'
  }

  // Keeping relations field empty
  const relations = []

  // Starting the traansaction
  try {
    const email = user.email
    let userNotFoundDB

    const pgPoolsInstance = await PgPools.getInstance()
    const Result = await pgPoolsInstance.findByPrimaryKey(dbConfig.DB, 'Users', 'email', user.email, schema) // TODO: make this an object

    if (Result.rowCount === 0) {
      userNotFoundDB = true
    } else {
      userNotFoundDB = false
    }

    // if admin is not present in firebas & also in database then add admin to both the places
    // else if admin is not present in firebas then add in firebase only
    // else if admin is not present in database then add in database only
    // else present in both the places then dont add the admin
    if (userNotFoundDB) {
      const transaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
      try {
        const userModel = new User(schema)
        await userModel.create(user, transaction)
        console.log('Admin added to the database')
        const userRelation = new Relation(schema)
        await userRelation.bulkCreate(relations, transaction)
        console.log('Relation added to the database')
        // Commit the transaction
        await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
      } catch (error) {
        console.error('Error inserting user:', error)
        // Rollback the transaction in case of error
        await pgPoolsInstance.getPool(dbConfig.DB).rollbackTransaction(transaction)
      }
    } else {
      console.log('Default Admin Exists')
    }
  } catch (error) {
    console.log('error:', error)
  }
}

exports.createClientAdmin = async (req, res) => {
  const data = req.body.data
  const email = data.email
  const schema = parseDomainName(email)
  try {
    await exports.createDefaultAdmin(email, schema)
    res.status(200).send(`Successfully created Admin for ${schema}`)
  } catch (error) {
    console.log('Error in createClientAdmin ', error)
    res.status(500).send(`Some error occured while creating Default Admin for  ${email}`)
  }
}

// Update user by email
exports.updateUser = async (req, res) => {
  const oldEmail = req.params.email // search with this email and then remove
  const schema = parseDomainName(oldEmail)
  console.log(oldEmail)

  const user = {
    email: req.body.data.email,
    name: req.body.data.name,
    role: req.body.data.role,
    responsibility: req.body.data.responsibility,
    designation: req.body.data.designation,
    countryCode: req.body.data.countryCode,
    mobileNumber: req.body.data.mobileNumber,
    location: req.body.data.location,
    img: req.body.data.img
  }
  const relations = []
  const mgrList = req.body.data.mgrList
  const reporteeList = req.body.data.reporteeList

  // Traversing through the manager list and establishing the user-manager relation
  for (let i = 0; i < mgrList.length; i++) {
    const mgrEmail = mgrList[i].email
    relations.push({ userEmail: user.email, managerEmail: mgrEmail })
  }

  // Traversing through the reportee list and establishing the user-manager relation
  for (let i = 0; i < reporteeList.length; i++) {
    const reporteeEmail = reporteeList[i].email
    relations.push({ userEmail: reporteeEmail, managerEmail: user.email })
  }

  const pgPoolsInstance = await PgPools.getInstance()
  const transaction = await pgPoolsInstance.getPool(dbConfig.DB).startTransaction()
  try {
    if (oldEmail !== user.email) {
      const userModel = new User(schema)
      await userModel.update(user, oldEmail, transaction)
      console.log('User added to the database')
      const userRelation = new Relation(schema)
      await userRelation.bulkCreate(relations, transaction)
      console.log('Relation added to the database')
      // Commit the transaction
      await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
      res.status(201).send('User updated successfully')
    } else {
      const userModel = new User(schema)
      await userModel.update(user, transaction)
      await pgPoolsInstance.getPool(dbConfig.DB).commitTransaction(transaction)
      res.status(201).send('User updated successfully')
    }
  } catch (error) {
    console.error('Error inserting user:', error)
    // Rollback the transaction in case of error
    await pgPoolsInstance.getPool(dbConfig.DB).rollbackTransaction(transaction)
  }
}

// if (email != user.email) {
//   console.log('Email not same')
//   console.log(`Old email: ${email} : new email: ${user.email}`)
//   try {
//     const userRecord = await firebase.auth().getUserByEmail(email)
//     console.log(userRecord)
//     await firebase.auth().updateUser(userRecord.uid, {
//       email: user.email
//     })
//     console.log('Updated in firebase')
//   } catch (error) {
//     console.log(error.message)
//   }
// }
// console.log(relations)
// let transaction
// try {
//   transaction = await sequelize.transaction()
//   await User.update(user, { where: { email }, transaction })
//   await Relation.destroy({ where: { userEmail: user.email }, transaction })
//   await Relation.destroy({ where: { managerEmail: user.email }, transaction })
//   const result = await Relation.bulkCreate(relations, { omitNull: false, transaction })
//   await transaction.commit()
//   res.status(200).send('Successfully updated')
// } catch (error) {
//   if (transaction) {
//     await transaction.rollback()
//     try {
//       const userRecord2 = await firebase.auth().getUserByEmail(user.email)
//       await firebase.auth().updateUser(userRecord2.uid, {
//         email
//       })
//     } catch (error) {
//       console.log('Error in Updating Firebase')
//     }
//   }

//   res.status(500).send('Some error occured while updating')
// }
// }
