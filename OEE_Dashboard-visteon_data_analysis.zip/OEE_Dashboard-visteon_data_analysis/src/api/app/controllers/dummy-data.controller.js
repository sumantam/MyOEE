const dummyData2 = [];
const UtilityMethods = require("../utils/utility.methods").UtilityMethods;

const calculateAvailability = (allShiftsForDay) => {
  let locRuntimeOfDay = 0;
  let plannedProductionTimeOfDay = 0;
  let totalBdTime = 0;
  allShiftsForDay.forEach((item) => {
    let filteredLineShiftTime = UtilityMethods.getFilteredLineShiftTime(
      item["Id"],
      dummyData2["Line_Shift_Times"]
    );
    let plannedProductionTime = UtilityMethods.getPlannedProductionTime(
      filteredLineShiftTime
    );
    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        [item["Id"]],
        dummyData2["Production_Summaries"]
      );
    let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
      filteredProductionSummaries
    );
    let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);
    totalBdTime += totalBreakdownTime;
    let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime([
      totalChangeoverTime, totalBreakdownTime
    ]);
    let runTime = UtilityMethods.getRunTime(
      plannedProductionTime,
      totalNonProductionTime
    );
    locRuntimeOfDay += runTime;
    plannedProductionTimeOfDay += plannedProductionTime;
  });
  return UtilityMethods.getAvailability(
    locRuntimeOfDay,
    plannedProductionTimeOfDay
  );
};

const calculatePerformance = (allShiftsForDay) => {
  let locRuntimeOfDay = 0;
  let idealCycleTimeForDay = 0;
  let locTotalCountForDay = 0;

  allShiftsForDay.forEach((item) => {
    let filteredLineShiftTime = UtilityMethods.getFilteredLineShiftTime(
      item["Id"],
      dummyData2["Line_Shift_Times"]
    );

    let plannedProductionTime = UtilityMethods.getPlannedProductionTime(
      filteredLineShiftTime
    );

    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachineInPipeLine(
        filteredLineShiftTime["Line"],
        dummyData2["Machines_In_Pipeline"]
      );

    idealCycleTimeForDay = UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        [item["Id"]],
        dummyData2["Production_Summaries"]
      );

    let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
      filteredProductionSummaries
    );
    let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

    let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime([
      totalChangeoverTime, totalBreakdownTime
    ]);
    let runTime = UtilityMethods.getRunTime(
      plannedProductionTime,
      totalNonProductionTime
    );
    locRuntimeOfDay += runTime;

    locTotalCountForDay += UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries
    );
  });
  return UtilityMethods.getPerformance(
    idealCycleTimeForDay,
    locTotalCountForDay,
    locRuntimeOfDay
  );
};

const calculateQuality = (allShiftsForDay) => {
  let locGoodCountForDay = 0;
  let locTotalCountForDay = 0;
  allShiftsForDay.forEach((item) => {
    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        [item["Id"]],
        dummyData2["Production_Summaries"]
      );
    locGoodCountForDay += UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries,
      "good"
    );
    locTotalCountForDay += UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries
    );
  });

  return UtilityMethods.getQuality(locGoodCountForDay, locTotalCountForDay);
};

const calculateScrap = (allShiftsForDay) => {
  let locBadCountForDay = 0;
  let locTotalCountForDay = 0;
  allShiftsForDay.forEach((item) => {
    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        [item["Id"]],
        dummyData2["Production_Summaries"]
      );
    locBadCountForDay += UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries, "bad"
    );
    locTotalCountForDay += UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries
    )
  });
  return UtilityMethods.getScrap(locBadCountForDay, locTotalCountForDay);
}

const calcultateOee = (allShiftsForDay) => {
  let plannedProductionTimeOfDay = 0;
  let locGoodCountForDay = 0;
  let idealCycleTimeForDay = 0;

  allShiftsForDay.forEach((item) => {
    let filteredLineShiftTime = UtilityMethods.getFilteredLineShiftTime(
      item["Id"],
      dummyData2["Line_Shift_Times"]
    );
    let plannedProductionTime = UtilityMethods.getPlannedProductionTime(
      filteredLineShiftTime
    );
    plannedProductionTimeOfDay += plannedProductionTime;

    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        [item["Id"]],
        dummyData2["Production_Summaries"]
      );
    locGoodCountForDay += UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries,
      "good"
    );

    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachineInPipeLine(
        filteredLineShiftTime["Line"],
        dummyData2["Machines_In_Pipeline"]
      );

    idealCycleTimeForDay =
      UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);
  });
  return UtilityMethods.getOee2(locGoodCountForDay, idealCycleTimeForDay, plannedProductionTimeOfDay);
}

const calculateLineWiseProductOfGoodCountAndIdealCycleTime = (allShiftsForDay) => {
  let idealCycleTimeForDay = 0;
  let locGoodCountForDay = 0;
  allShiftsForDay.forEach(item => {
    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        [item["Id"]],
        dummyData2["Production_Summaries"]
      );
    locGoodCountForDay += UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries,
      "good"
    );
    let filteredLineShiftTime = UtilityMethods.getFilteredLineShiftTime(
      item["Id"],
      dummyData2["Line_Shift_Times"]
    );
    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachineInPipeLine(
        filteredLineShiftTime["Line"],
        dummyData2["Machines_In_Pipeline"]
      );

    idealCycleTimeForDay =
      UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);
  })
  return UtilityMethods.getProductOfGoodCountAndIdealCycleTime(locGoodCountForDay, idealCycleTimeForDay);
}

const calculateLineWsiePlannedProductionTime = (allShiftsForDay) => {
  let plannedProductionTimeOfDay = 0;
  allShiftsForDay.forEach((item) => {
    let filteredLineShiftTime = UtilityMethods.getFilteredLineShiftTime(
      item["Id"],
      dummyData2["Line_Shift_Times"]
    );
    let plannedProductionTime = UtilityMethods.getPlannedProductionTime(
      filteredLineShiftTime
    );
    plannedProductionTimeOfDay += plannedProductionTime;
  });
  return plannedProductionTimeOfDay;
}

const calculateBts = (allShiftsForDay) => {
  let totalTarget = 0;
  let totalAdjustedForAllShifts = 0;
  allShiftsForDay.forEach(item => {
    let filteredLineShiftPlans = UtilityMethods.getFilteredLineShiftPlans(
      [item["Id"]],
      dummyData2["Line_Shift_Plans"]
    );
    let target = 0
    filteredLineShiftPlans.forEach(p => target += p["To_Produce"]);
    totalTarget += target;
    let filetredProductionSummaries = UtilityMethods.getFilteredProductionSummaries([item["Id"]], dummyData2["Production_Summaries"]);
    let actual = UtilityMethods.getProductionCountBasedOnType(filetredProductionSummaries);
    let adjustedAdherence = UtilityMethods.getAdjustedAdherence(target, actual);
    totalAdjustedForAllShifts += UtilityMethods.getTotalAdjusted(target, adjustedAdherence);
  })
  return UtilityMethods.getBts(totalAdjustedForAllShifts, totalTarget);
}

const calculateFtt = (allShiftsForDay) => {
  let totalActual = 0;
  let totalFtt = 0;
  allShiftsForDay.forEach(item => {
    let filteredLineShiftTime = UtilityMethods.getFilteredLineShiftTime(
      item["Id"],
      dummyData2["Line_Shift_Times"]
    );
    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachineInPipeLine(
        filteredLineShiftTime["Line"],
        dummyData2["Machines_In_Pipeline"]
      );
    let receiverMachineId = filteredMachinesInPipeLine.find(p => p["Name"] === "Receiver")["Id"];

    let filetredProductionSummaries = UtilityMethods.getFilteredProductionSummaries([item["Id"]], dummyData2["Production_Summaries"]);
    totalActual += UtilityMethods.getProductionCountBasedOnType(filetredProductionSummaries);
    totalFtt += UtilityMethods.getProductionCountBasedOnExitMachineType(filetredProductionSummaries, receiverMachineId)
  });
  return UtilityMethods.getFtt(totalActual, totalFtt);
}

exports.getAvailability = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );
  let availability = calculateAvailability(allShiftsForDay);
  return res.status(200).send({ availability: availability });
};

exports.getPerformance = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );
  let performance = calculatePerformance(allShiftsForDay);
  return res.status(200).send({ performance: performance });
};

exports.getQuality = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );
  let quality = calculateQuality(allShiftsForDay);
  return res.status(200).send({ quality: quality });
};

exports.getOee = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );
  // let oee = calcultateOee(allShiftsForDay);
  let oee = UtilityMethods.getOee(
    calculateAvailability(allShiftsForDay),
    calculatePerformance(allShiftsForDay),
    calculateQuality(allShiftsForDay)
  );
  return res.status(200).send({ oee: oee });
};

exports.getOeeForPlantLevel = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  let prodOfGoodCountAndIdealCycleTime = 0
  let plannedProductionTime = 0;
  lines.forEach(line => {
    const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
      (d) =>
        line === d.Line &&
        d.Start != undefined &&
        d.End != undefined &&
        (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
        && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
    );
    prodOfGoodCountAndIdealCycleTime += calculateLineWiseProductOfGoodCountAndIdealCycleTime(allShiftsForDay);
    plannedProductionTime += calculateLineWsiePlannedProductionTime(allShiftsForDay);
  })
  let oeeForPlant = prodOfGoodCountAndIdealCycleTime / plannedProductionTime
  return res.status(200).send({ oee: oeeForPlant });
}

exports.getBts = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );
  let bts = calculateBts(allShiftsForDay);
  return res.status(200).send({ bts: bts });
}

exports.getFtt = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );
  let ftt = calculateFtt(allShiftsForDay);
  return res.status(200).send({ ftt: ftt });
}

exports.getScrap = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );
  let scrap = calculateScrap(allShiftsForDay);
  return res.status(200).send({ scrap: scrap });
}

exports.getOeeTrend = async (req, res) => {
  let locOeeTrend = [];
  let oeeTrendTitles = ["Availibility", "Performance", "Quality", "OEE"];
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0);
  else lines.push(line);


  let timeQ = UtilityMethods.createTimeQuantumRangeForTrend(req.params["timeQ"]);
  let startDay = new Date(timeQ["start"]);
  let DAY_MS = 86400000;
  let timeRangesArray = [];
  let valuesForAvailibility = [];
  let valuesForPerformance = [];
  let valuesForQuality = [];
  let valuesForOee = [];

  if (req.params["timeQ"] == "day") {
    for (let i = 0; i < 7; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": UtilityMethods.createDateFormat(start)
      });
    }
  }
  else if (req.params["timeQ"] == "week") {
    for (let i = 0; i < 8; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 7));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 7))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Week " + (i + 1)
      });
    }
  }

  else if (req.params["timeQ"] == "month") {
    for (let i = 0; i < 12; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 30));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 30))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Month " + (i + 1)
      });
    }
  }

  else {
    for (let i = 0; i < 5; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 365));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 365))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Year " + (i + 1)
      });
    }
  }

  timeRangesArray.forEach(timeRange => {
    let allShiftsForTimeRange = dummyData2.Line_Shift_Times.filter(d =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (timeRange["From_Time"] <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < timeRange["To_Time"])
    )
    let filteredLineShiftTimes = UtilityMethods.getFilteredLineShiftTimes(
      allShiftsForTimeRange.map(p => p.Id),
      dummyData2["Line_Shift_Times"]
    );
    let plannedProductionTime = UtilityMethods.getPlannedProductionTimeForLineShiftTimes(
      filteredLineShiftTimes
    );
    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        allShiftsForTimeRange.map(p => p.Id),
        dummyData2["Production_Summaries"]
      );
    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachinesInPipeLines(
        filteredLineShiftTimes.map(p => p["Line"]),
        dummyData2["Machines_In_Pipeline"]
      );

    let idealCycleTime =
      UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

    let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
      filteredProductionSummaries
    );
    let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

    let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime(
      [totalChangeoverTime, totalBreakdownTime]
    );
    let runTime = UtilityMethods.getRunTime(
      plannedProductionTime,
      totalNonProductionTime
    );
    let totalCount = UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries
    );
    let goodCount = UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries,
      "good"
    );
    let availability = UtilityMethods.getAvailability(
      runTime,
      plannedProductionTime
    )
    valuesForAvailibility.push({
      range: timeRange["X_Axis"],
      value: isNaN(availability) ? 0 : availability,
    });
    let performance = UtilityMethods.getPerformance(
      idealCycleTime,
      totalCount,
      runTime
    )
    valuesForPerformance.push({
      range: timeRange["X_Axis"],
      value: isNaN(performance) ? 0 : performance,
    });
    let quality = UtilityMethods.getQuality(goodCount, totalCount)
    valuesForQuality.push({
      range: timeRange["X_Axis"],
      value: isNaN(quality) ? 0 : quality,
    });
    let oee = UtilityMethods.getOee(availability, performance, quality);
    valuesForOee.push({
      range: timeRange["X_Axis"],
      value: isNaN(oee) ? 0 : oee
    })
  })
  oeeTrendTitles.forEach((item) => {
    switch (item) {
      case "Availibility":
        locOeeTrend.push({ title: item, values: valuesForAvailibility });
        break;
      case "Performance":
        locOeeTrend.push({ title: item, values: valuesForPerformance });
        break;
      case "Quality":
        locOeeTrend.push({ title: item, values: valuesForQuality });
        break;
      case "OEE":
        locOeeTrend.push({ title: item, values: valuesForOee });
        break;
    }
  })
  locOeeTrend.forEach(item => {
    item["values"].forEach(val => val["value"] = parseFloat((val["value"] * 100).toFixed(2)))
  })

  return res.status(200).send({ oeeTrend: locOeeTrend });
};

exports.getOeeTrendPlantLevel = async (req, res) => {
  let locOeeTrend = [];
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0);
  else lines.push(line);

  let timeQ = UtilityMethods.createTimeQuantumRangeForTrend(req.params["timeQ"]);
  let startDay = new Date(timeQ["start"]);
  let DAY_MS = 86400000;
  let timeRangesArray = [];
  // let valuesForAvailibility = [];
  // let valuesForPerformance = [];
  // let valuesForQuality = [];
  // let valuesForOee = [];
  if (req.params["timeQ"] == "day") {
    for (let i = 0; i < 7; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": UtilityMethods.createDateFormat(start)
      });
    }
  }
  else if (req.params["timeQ"] == "week") {
    for (let i = 0; i < 8; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 7));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 7))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Week " + (i + 1)
      });
    }
  }

  else if (req.params["timeQ"] == "month") {
    for (let i = 0; i < 12; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 30));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 30))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Month " + (i + 1)
      });
    }
  }

  else {
    for (let i = 0; i < 5; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 365));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 365))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Year " + (i + 1)
      });
    }
  }

  lines.forEach(line => {
    let valuesForOee = [];
    timeRangesArray.forEach(timeRange => {
      let allShiftsForTimeRange = dummyData2.Line_Shift_Times.filter(d =>
        [line["Id"]].includes(d.Line) &&
        d.Start != undefined &&
        d.End != undefined &&
        (timeRange["From_Time"] <= new Date(UtilityMethods.getTimeStamp(d.Start)))
        && (new Date(UtilityMethods.getTimeStamp(d.Start)) < timeRange["To_Time"])
      )
      let filteredLineShiftTimes = UtilityMethods.getFilteredLineShiftTimes(
        allShiftsForTimeRange.map(p => p.Id),
        dummyData2["Line_Shift_Times"]
      );
      let plannedProductionTime = UtilityMethods.getPlannedProductionTimeForLineShiftTimes(
        filteredLineShiftTimes
      );
      let filteredProductionSummaries =
        UtilityMethods.getFilteredProductionSummaries(
          allShiftsForTimeRange.map(p => p.Id),
          dummyData2["Production_Summaries"]
        );
      let filteredMachinesInPipeLine =
        UtilityMethods.getFilteredMachinesInPipeLines(
          filteredLineShiftTimes.map(p => p["Line"]),
          dummyData2["Machines_In_Pipeline"]
        );

      let idealCycleTime =
        UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

      let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
        filteredProductionSummaries
      );
      let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

      let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime(
        [totalChangeoverTime, totalBreakdownTime]
      );
      let runTime = UtilityMethods.getRunTime(
        plannedProductionTime,
        totalNonProductionTime
      );
      let totalCount = UtilityMethods.getProductionCountBasedOnType(
        filteredProductionSummaries
      );
      let goodCount = UtilityMethods.getProductionCountBasedOnType(
        filteredProductionSummaries,
        "good"
      );
      let availability = UtilityMethods.getAvailability(
        runTime,
        plannedProductionTime
      )
      let performance = UtilityMethods.getPerformance(
        idealCycleTime,
        totalCount,
        runTime
      )
      let quality = UtilityMethods.getQuality(goodCount, totalCount)
      let oee = UtilityMethods.getOee(availability, performance, quality);
      valuesForOee.push({
        range: timeRange["X_Axis"],
        availabilityVal: isNaN(availability) ? 0 : availability,
        qualityVal: isNaN(quality) ? 0 : quality,
        performanceVal: isNaN(performance) ? 0 : performance,
        oeeVal: isNaN(oee) ? 0 : oee
      })
    })
    locOeeTrend.push({ title: line["Name"], values: valuesForOee });
  })

  locOeeTrend.forEach(item => {
    item["values"].forEach(item => {
      item["availabilityVal"] = parseFloat((item["availabilityVal"] * 100).toFixed(2));
      item["qualityVal"] = parseFloat((item["qualityVal"] * 100).toFixed(2));
      item["performanceVal"] = parseFloat((item["performanceVal"] * 100).toFixed(2));
      item["oeeVal"] = parseFloat((item["oeeVal"] * 100).toFixed(2));
    })
  })

  return res.status(200).send({ oeeTrend: locOeeTrend });
};

exports.getOeeParetoPlantLevel = async (req, res) => {
  let locOeePareto = [];
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"]
      .filter((d) => plants.indexOf(d.Plant) >= 0)
  else lines.push(line);

  lines.forEach(line => {
    let barObject = { "line": line["Name"] };
    const allShiftsForTimeRange = dummyData2.Line_Shift_Times.filter(
      (d) =>
        [line["Id"]].includes(d.Line) &&
        d.Start != undefined &&
        d.End != undefined &&
        (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
        && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
    );
    let filteredLineShiftTimes = UtilityMethods.getFilteredLineShiftTimes(
      allShiftsForTimeRange.map(p => p.Id),
      dummyData2["Line_Shift_Times"]
    );
    let plannedProductionTime = UtilityMethods.getPlannedProductionTimeForLineShiftTimes(
      filteredLineShiftTimes
    );
    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        allShiftsForTimeRange.map(p => p.Id),
        dummyData2["Production_Summaries"]
      );
    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachinesInPipeLines(
        filteredLineShiftTimes.map(p => p["Line"]),
        dummyData2["Machines_In_Pipeline"]
      );

    let idealCycleTime =
      UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

    let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
      filteredProductionSummaries
    );
    let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

    let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime(
      [totalChangeoverTime, totalBreakdownTime]
    );
    let runTime = UtilityMethods.getRunTime(
      plannedProductionTime,
      totalNonProductionTime
    );
    let totalCount = UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries
    );
    let goodCount = UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries,
      "good"
    );
    let availability = UtilityMethods.getAvailability(
      runTime,
      plannedProductionTime
    )
    let performance = UtilityMethods.getPerformance(
      idealCycleTime,
      totalCount,
      runTime
    )
    let quality = UtilityMethods.getQuality(goodCount, totalCount)
    let oee = UtilityMethods.getOee(availability, performance, quality);
    barObject["availabilityVal"] = isNaN(availability) ? 0 : parseFloat((availability * 100).toFixed(2));
    barObject["availabilityPer"] = 0;

    barObject["qualityVal"] = isNaN(quality) ? 0 : parseFloat((quality * 100).toFixed(2));
    barObject["qualityPer"] = 0;

    barObject["performanceVal"] = isNaN(performance) ? 0 : parseFloat((performance * 100).toFixed(2));
    barObject["performancePer"] = 0;

    barObject["oeeVal"] = isNaN(oee) ? 0 : parseFloat((oee * 100).toFixed(2));
    barObject["oeePer"] = 0;

    locOeePareto.push(barObject);
  })
 
  return res
    .status(200)
    .send({ oeePareto: locOeePareto });
}

exports.getOeeTrendBar = async (req, res) => {
  let locOeeTrend = [];
  let oeeTrendTitles = ["Availibility", "Performance", "Quality", "OEE"];
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0);
  else lines.push(line);


  let timeQ = UtilityMethods.createTimeQuantumRangeForTrend(req.params["timeQ"]);
  let startDay = new Date(timeQ["start"]);
  let DAY_MS = 86400000;
  let timeRangesArray = [];

  if (req.params["timeQ"] == "day") {
    for (let i = 0; i < 7; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": UtilityMethods.createDateFormat(start)
      });
    }
  }
  else if (req.params["timeQ"] == "week") {
    for (let i = 0; i < 8; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 7));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 7))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Week " + (i + 1)
      });
    }
  }

  else if (req.params["timeQ"] == "month") {
    for (let i = 0; i < 12; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 30));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 30))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Month " + (i + 1)
      });
    }
  }

  else {
    for (let i = 0; i < 5; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 365));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 365))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Year " + (i + 1)
      });
    }
  }

  timeRangesArray.forEach(timeRange => {
    let allShiftsForTimeRange = dummyData2.Line_Shift_Times.filter(d =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (timeRange["From_Time"] <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < timeRange["To_Time"])
    )
    let filteredLineShiftTimes = UtilityMethods.getFilteredLineShiftTimes(
      allShiftsForTimeRange.map(p => p.Id),
      dummyData2["Line_Shift_Times"]
    );
    let plannedProductionTime = UtilityMethods.getPlannedProductionTimeForLineShiftTimes(
      filteredLineShiftTimes
    );
    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        allShiftsForTimeRange.map(p => p.Id),
        dummyData2["Production_Summaries"]
      );
    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachinesInPipeLines(
        filteredLineShiftTimes.map(p => p["Line"]),
        dummyData2["Machines_In_Pipeline"]
      );

    let idealCycleTime =
      UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

    let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
      filteredProductionSummaries
    );
    let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

    let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime(
      [totalChangeoverTime, totalBreakdownTime]
    );
    let runTime = UtilityMethods.getRunTime(
      plannedProductionTime,
      totalNonProductionTime
    );
    let totalCount = UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries
    );
    let goodCount = UtilityMethods.getProductionCountBasedOnType(
      filteredProductionSummaries,
      "good"
    );
    let availability = UtilityMethods.getAvailability(
      runTime,
      plannedProductionTime
    )
    let performance = UtilityMethods.getPerformance(
      idealCycleTime,
      totalCount,
      runTime
    )
    let quality = UtilityMethods.getQuality(goodCount, totalCount)
    let oee = UtilityMethods.getOee(availability, performance, quality);

    locOeeTrend.push({
      "time": timeRange["X_Axis"],
      "availability": isNaN(availability) ? 0 : parseFloat((availability * 100).toFixed(2)),
      "performance": isNaN(performance) ? 0 : parseFloat((performance * 100).toFixed(2)),
      "quality": isNaN(quality) ? 0 : parseFloat((quality * 100).toFixed(2)),
      "oee": isNaN(oee) ? 0 : parseFloat((oee * 100).toFixed(2))
    })
  })

  return res.status(200).send({ oeeTrendBar: locOeeTrend });
};

exports.getOeeTrendBarPlantLevel = async (req, res) => {
  let locOeeTrend = [];
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0);
  else lines.push(line);


  let timeQ = UtilityMethods.createTimeQuantumRangeForTrend(req.params["timeQ"]);
  let startDay = new Date(timeQ["start"]);
  let DAY_MS = 86400000;
  let timeRangesArray = [];

  if (req.params["timeQ"] == "day") {
    for (let i = 0; i < 7; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": UtilityMethods.createDateFormat(start)
      });
    }
  }
  else if (req.params["timeQ"] == "week") {
    for (let i = 0; i < 8; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 7));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 7))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Week " + (i + 1)
      });
    }
  }

  else if (req.params["timeQ"] == "month") {
    for (let i = 0; i < 12; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 30));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 30))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Month " + (i + 1)
      });
    }
  }

  else {
    for (let i = 0; i < 5; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 365));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 365))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Year " + (i + 1)
      });
    }
  }

  timeRangesArray.forEach(timeRange => {
    let barObject = { "time": timeRange["X_Axis"] };
    lines.forEach(line => {
      let allShiftsForTimeRange = dummyData2.Line_Shift_Times.filter(d =>
        [line["Id"]].includes(d.Line) &&
        d.Start != undefined &&
        d.End != undefined &&
        (timeRange["From_Time"] <= new Date(UtilityMethods.getTimeStamp(d.Start)))
        && (new Date(UtilityMethods.getTimeStamp(d.Start)) < timeRange["To_Time"])
      )
      let filteredLineShiftTimes = UtilityMethods.getFilteredLineShiftTimes(
        allShiftsForTimeRange.map(p => p.Id),
        dummyData2["Line_Shift_Times"]
      );
      let plannedProductionTime = UtilityMethods.getPlannedProductionTimeForLineShiftTimes(
        filteredLineShiftTimes
      );
      let filteredProductionSummaries =
        UtilityMethods.getFilteredProductionSummaries(
          allShiftsForTimeRange.map(p => p.Id),
          dummyData2["Production_Summaries"]
        );
      let filteredMachinesInPipeLine =
        UtilityMethods.getFilteredMachinesInPipeLines(
          filteredLineShiftTimes.map(p => p["Line"]),
          dummyData2["Machines_In_Pipeline"]
        );

      let idealCycleTime =
        UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

      let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
        filteredProductionSummaries
      );
      let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

      let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime(
        [totalChangeoverTime, totalBreakdownTime]
      );
      let runTime = UtilityMethods.getRunTime(
        plannedProductionTime,
        totalNonProductionTime
      );
      let totalCount = UtilityMethods.getProductionCountBasedOnType(
        filteredProductionSummaries
      );
      let goodCount = UtilityMethods.getProductionCountBasedOnType(
        filteredProductionSummaries,
        "good"
      );
      let availability = UtilityMethods.getAvailability(
        runTime,
        plannedProductionTime
      )
      let performance = UtilityMethods.getPerformance(
        idealCycleTime,
        totalCount,
        runTime
      )
      let quality = UtilityMethods.getQuality(goodCount, totalCount)
      let oee = UtilityMethods.getOee(availability, performance, quality);
      barObject[line["Name"] + "_availabilityVal"] = isNaN(availability) ? 0 : parseFloat((availability * 100).toFixed(2));
      barObject[line["Name"] + "_qualityVal"] = isNaN(quality) ? 0 : parseFloat((quality * 100).toFixed(2));
      barObject[line["Name"] + "_performanceVal"] = isNaN(performance) ? 0 : parseFloat((performance * 100).toFixed(2));
      barObject[line["Name"] + "_oeeVal"] = isNaN(oee) ? 0 : parseFloat((oee * 100).toFixed(2));
    })

    locOeeTrend.push(barObject)
  })

  return res.status(200).send({ oeeTrendBar: locOeeTrend });
};

exports.getDontimeTrend = async (req, res) => {
  let locDowntimeTrend = [];
  let downtimeTrendTitles = ["Changeover", "Breakdown", "Quality", "Performance"];
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0);
  else lines.push(line);


  let timeQ = UtilityMethods.createTimeQuantumRangeForTrend(req.params["timeQ"]);
  let startDay = new Date(timeQ["start"]);
  let DAY_MS = 86400000;
  let timeRangesArray = [];
  let valuesForChangeover = [];
  let valuesForBreadown = [];
  let valuesForQuality = [];
  let valuesForPerformance = [];

  if (req.params["timeQ"] == "day") {
    for (let i = 0; i < 7; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": UtilityMethods.createDateFormat(start)
      });
    }
  }
  else if (req.params["timeQ"] == "week") {
    for (let i = 0; i < 8; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 7));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 7))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Week " + (i + 1)
      });
    }
  }

  else if (req.params["timeQ"] == "month") {
    for (let i = 0; i < 12; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 30));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 30))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Month " + (i + 1)
      });
    }
  }

  else {
    for (let i = 0; i < 5; i++) {
      let start = new Date(startDay.getTime() + (i * DAY_MS * 365));
      let end = new Date(startDay.getTime() + ((i + 1) * DAY_MS * 365))
      timeRangesArray.push({
        "To_Time": end,
        "From_Time": start,
        "X_Axis": "Year " + (i + 1)
      });
    }
  }

  timeRangesArray.forEach(timeRange => {
    let allShiftsForTimeRange = dummyData2.Line_Shift_Times.filter(d =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (timeRange["From_Time"] <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < timeRange["To_Time"])
    )

    let filteredLineShiftTimes = UtilityMethods.getFilteredLineShiftTimes(
      allShiftsForTimeRange.map(p => p.Id),
      dummyData2["Line_Shift_Times"]
    );

    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        allShiftsForTimeRange.map(p => p.Id),
        dummyData2["Production_Summaries"]
      );
    let changeoverStopTime = UtilityMethods.getTotalChangeoverTime(
      filteredProductionSummaries
    );
    let breakdownStopTime = UtilityMethods.getTotalBreakdownTime(
      filteredProductionSummaries
    );
    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachinesInPipeLines(
        lines,
        dummyData2["Machines_In_Pipeline"]
      );

    let idealCycleTime = UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);
    let totalcount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries);
    let totalGoodCount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries, "good");
    let qualityStopTime = (totalcount - totalGoodCount) * idealCycleTime;

    let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
      filteredProductionSummaries
    );
    let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

    let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime([
      totalChangeoverTime, totalBreakdownTime
    ]);

    let plannedProductionTime = UtilityMethods.getPlannedProductionTimeForLineShiftTimes(
      filteredLineShiftTimes
    );

    let performanceLossTime = plannedProductionTime - totalNonProductionTime - (totalcount * idealCycleTime);

    valuesForChangeover.push({
      range: timeRange["X_Axis"],
      value: isNaN(changeoverStopTime) ? 0 : changeoverStopTime / 60,
    });

    valuesForBreadown.push({
      range: timeRange["X_Axis"],
      value: isNaN(breakdownStopTime) ? 0 : breakdownStopTime / 60,
    });

    valuesForQuality.push({
      range: timeRange["X_Axis"],
      value: isNaN(qualityStopTime) ? 0 : qualityStopTime / 60,
    });
    valuesForPerformance.push({
      range: timeRange["X_Axis"],
      value: isNaN(performanceLossTime) ? 0 : performanceLossTime / 60
    })
  })

  downtimeTrendTitles.forEach((item) => {
    switch (item) {
      case "Changeover":
        locDowntimeTrend.push({ title: item, values: valuesForChangeover });
        break;
      case "Breakdown":
        locDowntimeTrend.push({ title: item, values: valuesForBreadown });
        break;
      case "Quality":
        locDowntimeTrend.push({ title: item, values: valuesForQuality });
        break;
      case "Performance":
        locDowntimeTrend.push({ title: item, values: valuesForPerformance });
        break;
    }
  })

  return res.status(200).send({ downtimeTrend: locDowntimeTrend });
}

exports.getDownTimeParetoByProductionLine = async (req, res) => {
  let locDownTimeParetoByProductionLine = [];
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];
  let plants = [];
  if (plant === "all")
    plants = dummyData2["Plants"];
  else
    plants.push(plant);
  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"]
      .filter((d) => plants.indexOf(d.Plant) >= 0)
      .map((item) => item["Id"]);
  else lines.push(line);

  let filteredLineShiftTimes = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );

  let lineIdShiftIdPairs = UtilityMethods.getFilteredLineIdShiftIdPairs(
    lines,
    filteredLineShiftTimes,
    dummyData2["Lines"]
  )
  let plantName = plant !== "all" ? dummyData2["Plants"].find(p => p["Id"] === plant || p["Name"] === plant)["Name"] : "";
  lineIdShiftIdPairs.forEach((item) => {
    let filteredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        item["Shifts"],
        dummyData2["Production_Summaries"]
      );
    let filteredMachinesInPipeLine =
      UtilityMethods.getFilteredMachinesInPipeLines(
        lines,
        dummyData2["Machines_In_Pipeline"]
      );
    let idealCycleTime =
      UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

    let totalcount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries);
    let totalGoodCount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries, "good");
    let qualityStopTime = (totalcount - totalGoodCount) * idealCycleTime;


    let plannedProductionTime = 0
    item["Shifts"].forEach((shift) => {
      let filteredLineShiftTime = UtilityMethods.getFilteredLineShiftTime(
        shift,
        dummyData2["Line_Shift_Times"]
      );

      plannedProductionTime += UtilityMethods.getPlannedProductionTime(
        filteredLineShiftTime
      );
    })
    let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
      filteredProductionSummaries
    );

    let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(
      filteredProductionSummaries
    );

    let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime([
      totalChangeoverTime, totalBreakdownTime
    ]);

    let performanceLossTime = plannedProductionTime - totalNonProductionTime - (totalcount * idealCycleTime);


    if (filteredProductionSummaries.length > 0) {
      let count = totalChangeoverTime +
        qualityStopTime +
        totalBreakdownTime +
        performanceLossTime
      locDownTimeParetoByProductionLine.push({
        line: plantName + " - " + item["LineName"],
        stopTime: count / 60,
        percentage: 0,
      });
    }
  });
  locDownTimeParetoByProductionLine.forEach(
    (item) =>
    (item["percentage"] =
      (item["stopTime"] /
        UtilityMethods.getSumOfStopTimes(
          locDownTimeParetoByProductionLine,
          "stopTime"
        )) *
      100)
  );

  return res.status(200).send({
    downTimeParetoByProductionLine: locDownTimeParetoByProductionLine,
  });
};

exports.getDownTimeParetoByCause = async (req, res) => {
  let locDownTimeParetoByCause = [];
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"]
      .filter((d) => plants.indexOf(d.Plant) >= 0)
      .map((item) => item["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );

  let filteredMachineIdsnPipeline =
    UtilityMethods.getFilteredMachineIdsInPipeLine(
      lines,
      dummyData2["Machines_In_Pipeline"]
    );

  let filteredDowntimeClassNames = ["Changeover", "Breakdown", "Quality", "Performance"];
  let filteredProductionSummaries =
    UtilityMethods.getFilteredProductionSummaries(
      allShiftsForDay.map((p) => p["Id"]),
      dummyData2["Production_Summaries"]
    );
  if (filteredProductionSummaries.length > 0 && filteredDowntimeClassNames.length > 0) {
    filteredDowntimeClassNames.forEach((item) => {
      let changeoverStopTime = UtilityMethods.getTotalChangeoverTime(
        filteredProductionSummaries
      );
      let breakdownStopTime = UtilityMethods.getTotalBreakdownTime(
        filteredProductionSummaries
      );
      let filteredMachinesInPipeLine =
        UtilityMethods.getFilteredMachinesInPipeLines(
          lines,
          dummyData2["Machines_In_Pipeline"]
        );

      let idealCycleTime = UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

      let totalcount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries);
      let totalGoodCount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries, "good");
      let qualityStopTime = (totalcount - totalGoodCount) * idealCycleTime;

      let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime([
        changeoverStopTime, breakdownStopTime
      ]);


      let plannedProductionTime = 0
      allShiftsForDay.forEach((item) => {
        let filteredLineShiftTime = UtilityMethods.getFilteredLineShiftTime(
          item["Id"],
          dummyData2["Line_Shift_Times"]
        );

        plannedProductionTime += UtilityMethods.getPlannedProductionTime(
          filteredLineShiftTime
        );
      })

      let performanceLossTime = plannedProductionTime - totalNonProductionTime - (totalcount * idealCycleTime);

      switch (item) {
        case "Changeover":
          locDownTimeParetoByCause.push({
            line: item,
            stopTime: changeoverStopTime / 60,
            percentage: 0,
          });
          break;
        case "Breakdown":
          locDownTimeParetoByCause.push({
            line: item,
            stopTime: breakdownStopTime / 60,
            percentage: 0,
          });
          break;
        case "Quality":
          locDownTimeParetoByCause.push({
            line: item,
            stopTime: qualityStopTime / 60,
            percentage: 0,
          });
          break;
        case "Performance":

          locDownTimeParetoByCause.push({
            line: item + " (*Mostly due to Microstops)",
            stopTime: performanceLossTime / 60,
            percentage: 0,
          });
          break;
      }
    });
  }

  locDownTimeParetoByCause = locDownTimeParetoByCause.sort((a, b) => b["stopTime"] - a["stopTime"]);

  let percentage = 0;
  locDownTimeParetoByCause.forEach(
    item => {
      percentage += (item["stopTime"] /
        UtilityMethods.getSumOfStopTimes(
          locDownTimeParetoByCause,
          "stopTime"
        )) *
        100
      item["percentage"] = percentage
    }
  );

  return res
    .status(200)
    .send({ downTimeParetoByCause: locDownTimeParetoByCause });
};

exports.getProductionByLine = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];
  const totalRequired = req.params["totalRequired"]

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"]
      .filter((d) => plants.indexOf(d.Plant) >= 0)
      .map((item) => item["Id"]);
  else lines.push(line);

  let filteredLineShiftTimes = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );

  let lineIdShiftIdPairs = UtilityMethods.getFilteredLineIdShiftIdPairs(
    lines,
    filteredLineShiftTimes,
    dummyData2["Lines"]
  );
  let viewByLineObjects = [];
  lineIdShiftIdPairs.forEach((pair) => {
    let locfiletredProductionSummaries =
      UtilityMethods.getFilteredProductionSummaries(
        pair["Shifts"],
        dummyData2["Production_Summaries"]
      );
    if (locfiletredProductionSummaries.length > 0)
      viewByLineObjects.push(
        UtilityMethods.getActualVsPlanDataByLine(
          pair,
          locfiletredProductionSummaries,
          dummyData2["Line_Shift_Plans"]
        )
      );

  });
  if (totalRequired == "true") {
    let totalPlan = 0;
    let totalActual = 0;
    viewByLineObjects.forEach(item => {
      totalPlan += item["plan"]
      totalActual += item["actual"]
    });
    viewByLineObjects.splice(0, 0, { "line": "Total", "plan": totalPlan, "actual": totalActual });
  }
  return res.status(200).send({ viewByLineObjects: viewByLineObjects });
};

exports.getProductionByModel = async (req, res) => {
  const timeQ = UtilityMethods.createTimeQuantumRange(req.params["timeQ"]);
  const plant = req.params["plant"];
  const line = req.params["line"];
  const totalRequired = req.params["totalRequired"]

  let plants = [];
  if (plant === "all") plants = dummyData2["Plants"];
  else plants.push(plant);

  let lines = [];
  if (line === "all")
    lines = dummyData2["Lines"].filter((d) => plants.indexOf(d.Plant) >= 0).map(p => p["Id"]);
  else lines.push(line);

  const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
    (d) =>
      lines.includes(d.Line) &&
      d.Start != undefined &&
      d.End != undefined &&
      (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
      && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
  );

  let filteredLineShiftPlans = UtilityMethods.getFilteredLineShiftPlans(
    allShiftsForDay.map((p) => p["Id"]),
    dummyData2["Line_Shift_Plans"]
  );
  let filetredProductionSummaries =
    UtilityMethods.getFilteredProductionSummaries(
      allShiftsForDay.map((p) => p["Id"]),
      dummyData2["Production_Summaries"]
    );
  let viewByModelObjcts = UtilityMethods.getActualVsPlanDataByModelForShifts(
    filteredLineShiftPlans,
    filetredProductionSummaries
  );
  if (totalRequired == "true") {
    let totalPlan = 0;
    let totalActual = 0;
    viewByModelObjcts.forEach(item => {
      totalPlan += item["plan"]
      totalActual += item["actual"]
    });
    viewByModelObjcts.splice(0, 0, { "model": "Total", "plan": totalPlan, "actual": totalActual });
  }
  return res.status(200).send({ viewByModelObjcts: viewByModelObjcts });
};