const methods = require("../utils/common/microstop-methods");
const { UtilityMethods } = require("../utils/utility.methods");

exports.getMicrostopDataByPlant = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const plantName = req.params["plant"];
  const { schemaName, date } = req.query;

  try {
    const data = await methods.getMicrostopDataByPlant(plantName, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getMicrostopDataByLine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const { schemaName, date } = req.query;

  try {
    const data = await methods.getMicrostopDataByLine(lineId, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getMicrostopDataByMachine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const machineId = req.params["machineId"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getMicrostopDataByMachine(lineId, timeQ, date, schemaName, machineId);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getMicrostopActionsByLine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getMicrostopActionsByLine(lineId, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getMicrostopActionsByMachine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const machineName = req.params["machineName"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getMicrostopActionsByMachine(lineId, timeQ, date, schemaName, machineName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getMicrostopTrendByMachine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const machineId = req.params["machineId"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getMicrostopTrendByMachine(lineId, timeQ, date, schemaName, machineId);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getMicrostopTrendByLine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getMicrostopTrendByLine(lineId, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getMicrostopTrendByPlant = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const plantName = req.params["plant"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getMicrostopTrendByPlant(plantName, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    console.log(e);
    return res.status(500).send(e);
  }
};

