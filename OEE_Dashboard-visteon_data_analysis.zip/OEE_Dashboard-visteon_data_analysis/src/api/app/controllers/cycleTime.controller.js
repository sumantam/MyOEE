const methods = require("../utils/common/cycleTime-method");
const { UtilityMethods } = require("../utils/utility.methods");

exports.getCycleTimeDataByPlant = async (req, res) => {
    const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
    const plantName = req.params["plant"];
    const { schemaName, date } = req.query;
  
    try {
      const data = await methods.getCycleTimeDataByPlantMethodByDB(plantName, timeQ, date, schemaName);
      return res.status(200).send(data);
    } catch (e) {
      return res.status(500).send(e);
    }
  };

  exports.getRealTimeDataAndStats = async (req, res) => {
  
    try {
      const data = await methods.getRunDataAndStatsFromRealTimeData();
      return res.status(200).send(data);
    } catch (e) {
      return res.status(500).send(e);
    }
  };

  exports.getStdCycleTime = async (req, res) => {
    try {
      const data = await methods.getStdCycleTimeData();
      return res.status(200).send(data);
    } catch (e) {
      return res(500).send(e);
    }
  }

  exports.updateStdCycleTime = async (req, res) => {
    const newStdCycleTime = Number(req.body?.["newStdCycleTime"]);
    try {
      await methods.updateStdCycleTime(newStdCycleTime);
      return res.status(200).send({ "message": "Std Cycle Time updated successfully" });
    } catch (e) {
      return res.status(500).send({ "message": "Error updating Std Cycle Time" });
    }
  };

  exports.insertRealTimeData = async (req, res) => {
    const realTimeData = req.body;
    try {
      await methods.insertRealTimeData(realTimeData);
      return res.status(200).send({ "message": "Real time data updated successfully" });
    } catch (e) {
      return res.status(500).send({ "message": "Error updating real time data" });
    }
  };