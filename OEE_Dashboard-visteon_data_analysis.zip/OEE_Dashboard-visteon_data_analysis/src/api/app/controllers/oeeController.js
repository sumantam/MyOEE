const UtilityMethods = require("../utils/utility.methods").UtilityMethods;
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

const TIME_QUANTUM_MAPPER = {
  'day': 'Day',
  'week': 'Week',
  'month': 'Month',
  'year': 'Year'
}

/**
 * 
 * @param {Date} date 
 */
function dateToDBString(date) {
  date = new Date(date);
  let month = (date.getMonth() < 9 ? '0' : '') + (date.getMonth() + 1);
  let day = (date.getDate() <= 9 ? '0' : '') + date.getDate();
  let year = '' + date.getFullYear();

  return `${year}-${month}-${day}`;
}

function getDBDateRanges(lastDate, timeQuantum) {
  return timeQuantum === 'Day' ?
    [...Array(7)].map(function (value, index, arr) {
      let d = new Date(lastDate);
      d.setDate(d.getDate() - index);
      return dateToDBString(d);
    })
    : timeQuantum === 'Week' ?
      [...Array(8)].map(function (value, index, arr) {
        let d = new Date(lastDate);
        d.setDate(d.getDate() - index * 7);
        return dateToDBString(d);
      })
      : timeQuantum === 'Month' ?
        [...Array(12)].map(function (value, index, arr) {
          let d = new Date(lastDate);
          d.setMonth(d.getMonth() - index);
          return dateToDBString(d);
        })
        : timeQuantum === 'Year' ?
          [...Array(5)].map(function (value, index, arr) {
            let d = new Date(lastDate);
            d.setFullYear(d.getFullYear() - index);
            return dateToDBString(d);
          })
          : [];
}

exports.getOeeTrend = async (req, res) => {
  const plantName = req.params["plant"];
  const lineName = req.params["line"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  let query = '';
  if (lineName === 'all') {
    query = `SELECT
        timewhen as Date,
        availability AS Availability,
        quality AS Quality,
        performance AS Performance,
        oee AS OEE
      FROM getOEETrends ('${date}', 'Plant', '${plantName}', '${timeQuantum}', 'A', '${schemaName}')`;
  }
  else {
    query = `SELECT
        timewhen as Date,
        availability AS Availability,
        quality AS Quality,
        performance AS Performance,
        oee AS OEE
      FROM getOEETrends ('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A', '${schemaName}')`;
  }

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true);

    const dateRange = UtilityMethods.getTimeSeriesRanges(timeQuantum, new Date(date));
    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,availability:number,quality:number,performance:number,oee:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const dataPerDate = result.rows;
      const modifiedData = [];

      ["Availability", "Performance", "Quality", "OEE"].forEach(title => {
        let object = {
          title: title,
          values: []
        }
        dateRange.forEach(date => {
          let foundIndex = -1;
          foundIndex = dataPerDate.findIndex(p => p.date === date.time);
          object.values.push({
            range: date.indicator,
            value: foundIndex === -1 ? 0 : Number(dataPerDate[foundIndex][title.toLowerCase()])
          })

        })
        modifiedData.push(object)
      })

      const respJSON = {
        oeeTrend: modifiedData
      };

      res.status(200).send(respJSON)
    } else {
      res.status(200).send({ oeeTrend: [] })
    }

  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

exports.getOeeTrendForPlant = async (req, res) => {
  const plantName = req.params["plant"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  let query = `SELECT
        timewhen as Date,
        plantline as linename,
        availability AS Availability,
        quality AS Quality,
        performance AS Performance,
        oee AS OEE
      FROM getOEETrends ('${date}', 'Plant', '${plantName}', '${timeQuantum}', 'A', '${schemaName}')`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query);
    client.release(true);

    const dateRanges = UtilityMethods.getTimeSeriesRanges(timeQuantum, new Date(date));
    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,linename:string,availability:number,quality:number,performance:number,oee:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const modifiedData = [];
      const uniqueTitles = [...new Set(result.rows.map(p => p.linename.substring(p.linename.lastIndexOf('#') + 1)))];

      uniqueTitles.forEach(title => {
        let object = {
          title: title,
          values: []
        };
        dateRanges.forEach(date => {
          let foundIndex = result.rows.findIndex(p => p.linename.substring(p.linename.lastIndexOf('#') + 1) === title && p.date === date.time);
          let foundObject = foundIndex === -1 ? undefined : result.rows[foundIndex];
          if (foundObject !== undefined) {
            object.values.push({
              range: date.indicator,
              availabilityVal: Number(result.rows[foundIndex].availability),
              qualityVal: Number(result.rows[foundIndex].quality),
              performanceVal: Number(result.rows[foundIndex].performance),
              oeeVal: Number(result.rows[foundIndex].oee)
            })
          }
          else {
            object.values.push({
              range: date.indicator,
              availabilityVal: 0,
              qualityVal: 0,
              performanceVal: 0,
              oeeVal: 0
            })
          }
        })
        modifiedData.push(object);
      })

      modifiedData.sort((a, b) => a.title.toLowerCase().localeCompare(b.title.toLowerCase()));
      const respJSON = {
        oeeTrend: modifiedData
      }
      res.status(200).send(respJSON);
    } else {
      res.status(200).send({ oeeTrend: [] });
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

exports.getOeeParetoForPlant = async (req, res) => {
  const plantName = req.params["plant"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  let query = `SELECT
      plant_line as linename,
      ROUND(a.availability, 3) AS Availability,
      ROUND(a.quality, 3) AS Quality,
      ROUND(a.performance, 3) AS Performance,
      ROUND(a.availability * a.quality * a.performance / 100.0 / 100.0, 3) AS OEE
    FROM getProductionData ('${date}', 'Plant', '${plantName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}') AS a`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query);
    client.release(true);
    if (result.rowCount > 0) {
      /**
       * @typedef {{linename:string,availability:number,quality:number,performance:number,oee:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = result.rows;

      const respJSON = {
        oeePareto: data.map(p => ({
          line: p.linename.substring(p.linename.lastIndexOf('#') + 1),
          availabilityVal: Number(p.availability),
          availabilityPer: 0,
          qualityVal: Number(p.quality),
          qualityPer: 0,
          performanceVal: Number(p.performance),
          performancePer: 0,
          oeeVal: Number(p.oee),
          oeePer: 0
        }))
      }
      res.status(200).send(respJSON);
    } else {
      res.status(200).send({ oeePareto: [] });
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

exports.getOeeTrendBarForPlant = async (req, res) => {
  const plantName = req.params["plant"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  let linesGetterQuery = `
        SELECT
        l.linename AS linename
        FROM ${schemaName}."Lines" l
        JOIN ${schemaName}."Plants" p
        ON l."locId"=p.plantid
        WHERE plantname='${plantName}';
      `;

  let query = `
        SELECT
        timewhen as Date,
        plantline as linename,
        availability AS Availability,
        quality AS Quality,
        performance AS Performance,
        oee AS OEE
      FROM getOEETrends ('${date}', 'Plant', '${plantName}', '${timeQuantum}', 'A', '${schemaName}')`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query);
    const linesResult = await client.query(linesGetterQuery);
    client.release(true);

    const dateRanges = UtilityMethods.getTimeSeriesRanges(timeQuantum, new Date(date));
    if (result.rowCount > 0) {
      /**
        * @typedef {{date:string,linename:string,availability:number,quality:number,performance:number,oee:number}} DataRow
        */

      /**
       * @type {[DataRow]}
       */
      const modifiedData = []
      linesResult.rows.sort((a, b) => a.linename.toLowerCase().localeCompare(b.linename.toLowerCase()));
      dateRanges.forEach(date => {
        let object = { date: date.indicator }
        linesResult.rows.forEach(line => {
          let foundIndex = result.rows.findIndex(p => p.linename.substring(p.linename.lastIndexOf('#') + 1) === line.linename && p.date === date.time);
          let foundObject = foundIndex === -1 ? undefined : result.rows[foundIndex];
          if (foundObject !== undefined) {
            object[`${line.linename}_availabilityVal`] = Number(result.rows[foundIndex].availability);
            object[`${line.linename}_qualityVal`] = Number(result.rows[foundIndex].availability);
            object[`${line.linename}_performanceVal`] = Number(result.rows[foundIndex].availability);
            object[`${line.linename}_oeeVal`] = Number(result.rows[foundIndex].availability);
          }
          else {
            object[`${line.linename}_availabilityVal`] = 0;
            object[`${line.linename}_qualityVal`] = 0;
            object[`${line.linename}_performanceVal`] = 0;
            object[`${line.linename}_oeeVal`] = 0;
          }
        })
        modifiedData.push(object);
      })


      const respJSON = {
        oeeTrendBar: modifiedData
      }
      res.status(200).send(respJSON);

    }
    else {
      res.status(200).send({ oeeTrendBar: [] });
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

exports.getOeeTrendBar = async (req, res) => {
  const lineName = req.params["line"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  let query = `SELECT
        timewhen as date,
        availability AS availability,
        quality AS quality,
        performance AS performance,
        oee AS oee
      FROM getOEETrends ('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A', '${schemaName}')`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query);
    client.release(true);

    const dateRanges = UtilityMethods.getTimeSeriesRanges(timeQuantum, new Date(date));
    if (result.rowCount > 0) {
      /**
        * @typedef {{date:string,availability:number,quality:number,performance:number,oee:number}} DataRow
        */

      /**
       * @type {[DataRow]}
       */
      const modifiedData = []
      dateRanges.forEach(date => {
        let dataObject = { "range": date.indicator };
        let foundIndex = result.rows.findIndex(p => p.date === date.time);
        let foundObject = foundIndex === -1 ? undefined : result.rows[foundIndex];
        if (foundObject !== undefined) {
          dataObject["availability"] = Number(foundObject["availability"]);
          dataObject["quality"] = Number(foundObject["quality"]);
          dataObject["performance"] = Number(foundObject["performance"]);
          dataObject["oee"] = Number(foundObject["oee"]);

        }
        else {
          dataObject["availability"] = 0;
          dataObject["quality"] = 0;
          dataObject["performance"] = 0;
          dataObject["oee"] = 0;
        }
        modifiedData.push(dataObject);
      })

      const respJSON = {
        oeeTrendBar: modifiedData
      }
      res.status(200).send(respJSON);

    }
    else {
      res.status(200).send({ oeeTrendBar: [] });
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

exports.getOeeParetoAndBar = async (req, res) => {
  const plantName = req.params["plant"];
  const lineName = req.params["line"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  const dateRange = getDBDateRanges(date, timeQuantum);
  let query = '';
  if (lineName === 'all') {
    query = dateRange.map(
      (d, index, arr) => `SELECT
        '${d}' as Date,
        a.plant_line as line,
        ROUND(a.availability, 3) AS Availability,
        ROUND(a.quality, 3) AS Quality,
        ROUND(a.performance, 3) AS Performance,
        ROUND(a.availability * a.quality * a.performance / 100.0 / 100.0, 3) AS OEE
      FROM getProductionData ('${d}', 'Plant', '${plantName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}') AS a`
    ).join("\nUNION\n");
  }
  else {
    query = dateRange.map(
      (d, index, arr) => `SELECT
        '${d}' as Date,
        a.plant_line as line,
        ROUND(a.availability, 3) AS Availability,
        ROUND(a.quality, 3) AS Quality,
        ROUND(a.performance, 3) AS Performance,
        ROUND(a.availability * a.quality * a.performance / 100.0 / 100.0, 3) AS OEE
      FROM getProductionData ('${d}', 'Line', '${lineName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}') AS a`
    ).join("\nUNION\n");
  }

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true)

    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,line:string,availability:number,quality:number,performance:number,oee:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const dataPerDate = result.rows;
      const respJSON = {
        oeeParetoAndBar: dataPerDate.map(row => ({
          time: row.date,
          line: row.line.substring(row.line.lastIndexOf('#') + 1),
          availability: Number(row.availability),
          availabilityPer: 0,
          quality: Number(row.quality),
          qualityPer: 0,
          performance: Number(row.performance),
          performancePer: 0,
          oee: Number(row.oee),
          oeePer: 0

        }))
      };

      res.status(200).send(respJSON)
    } else {
      res.status(404).send({
        error: 'No Data found',
      })
    }

  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

exports.getDownTimeTrend = async (req, res) => {
  const lineName = req.params["line"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  const dateRange = getDBDateRanges(date, timeQuantum);
  let queryForQualityStop = dateRange.map(
    (d, index, arr) => `SELECT
      '${d}' as range,
      ROUND((a.idealcycletime * a.total_ng) / 60) as value
    FROM getProductionData ('${d}', 'Line', '${lineName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}') AS a`
  ).join("\nUNION\n");

  let queryForBreakdown = `select
      timewhen as range,
      ROUND(breakdown / 60) as value
     from getBreakdownTimes('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A','${schemaName}')`;

  let queryForPerformance = `select
      timewhen as range,
      ROUND(microstop / 60) as value
     from getMicrostopTimes('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A','${schemaName}')`;

  let queryForChangeover = `select
      starttime as range,
      ROUND(changeovertimeafter / 60) as value
     from getLineShiftPlanIdsForTimeRangeAndLineAggregation('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A','${schemaName}')`

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const resultForQualityStop = await client.query(queryForQualityStop);
    const resultForBreakdown = await client.query(queryForBreakdown);
    const resultForPerformance = await client.query(queryForPerformance);
    const resultForChangeover = await client.query(queryForChangeover);

    client.release(true);
    let downtimeTrend = [];
    let downtimeTrendTitles = ["Changeover", "Breakdown", "Quality", "Performance"]
    let breakdownStopdata = [];
    let performanceStopdata = [];
    let qualityStopData = [];
    let changeoverData = [];

    const dateRanges = UtilityMethods.getTimeSeriesRanges(timeQuantum, date);
    if (resultForBreakdown.rowCount > 0) {
      /**
       * @typedef {{range:string,value:number}} DataRowForBreakdown
       */

      /**
       * @type {[DataRowForBreakdown]}
       */
      let data = [];
      resultForBreakdown.rows.reduce(function (res, item) {
        let key = item.range;
        if (!res[key]) {
          res[key] = { value: 0, range: item.range };
          data.push(res[key])
        }
        res[key].value += item.value;
        return res;
      }, {});

      dateRanges.forEach(date => {
        let foundIndex = data.findIndex(p => p.range === date.time);
        breakdownStopdata.push({
          range: date.indicator,
          value: foundIndex === -1 ? 0 : data[foundIndex].value
        })
      })
    }

    if (resultForPerformance.rowCount > 0) {
      /**
       * @typedef {{range:string,value:number}} DataRowForPerformance
       */

      /**
       * @type {[DataRowForPerformance]}
       */
      let data = [];
      resultForPerformance.rows.reduce(function (res, item) {
        let key = item.range;
        if (!res[key]) {
          res[key] = { value: 0, range: item.range };
          data.push(res[key])
        }
        res[key].value += item.value;
        return res;
      }, {});

      dateRanges.forEach(date => {
        let foundIndex = data.findIndex(p => p.range === date.time);
        performanceStopdata.push({
          range: date.indicator,
          value: foundIndex === -1 ? 0 : data[foundIndex].value
        })
      })
    }

    if (resultForChangeover.rowCount > 0) {
      /**
       * @typedef {{range:string,value:number}} DataRowForPerformance
       */

      /**
       * @type {[DataRowForPerformance]}
       */
      let data = [];
      let locChangeoverData = resultForChangeover.rows;

      locChangeoverData.forEach(p => p.range = UtilityMethods.createDateFormat(p.range));
      locChangeoverData.reduce(function (res, item) {
        let key = item.range;
        if (!res[key]) {
          res[key] = { value: 0, range: item.range };
          data.push(res[key])
        }
        res[key].value += item.value;
        return res;
      }, {});

      dateRanges.forEach(date => {
        let foundIndex = -1;
        if (timeQuantum === 'Day')
          foundIndex = data.findIndex(p => p.range === date.indicator);
        else {
          let start = new Date(date.time.substring(0, 10)).getTime();
          let end = new Date(date.time.substring(12)).getTime();
          foundIndex = data.findIndex(p => new Date(p.range).getTime() > start && new Date(p.range).getTime() <= end);
        }
        changeoverData.push({
          range: date.indicator,
          value: foundIndex === -1 ? 0 : data[foundIndex].value
        })
      })
    }

    if (resultForQualityStop.rowCount > 0) {
      /**
       * @typedef {{range:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      let data = resultForQualityStop.rows;
      data.forEach(p => p.value = Number(p.value));
      dateRanges.forEach(date => {
        let foundIndex = -1;
        if (timeQuantum === 'Day')
          foundIndex = data.findIndex(p => p.range === date.indicator);
        else {
          let start = new Date(date.time.substring(0, 10)).getTime();
          let end = new Date(date.time.substring(12)).getTime();
          foundIndex = data.findIndex(p => new Date(p.range).getTime() > start && new Date(p.range).getTime() <= end);
        }
        qualityStopData.push({
          range: date.indicator,
          value: foundIndex === -1 ? 0 : data[foundIndex].value
        })
      })
    }

    downtimeTrendTitles.forEach(p => {
      downtimeTrend.push({
        title: p,
        values: p === "Breakdown" ? breakdownStopdata :
          p === "Performance" ? performanceStopdata :
            p === "Quality" ? qualityStopData : changeoverData
      })
    })

    if (downtimeTrend.length > 0) {
      const respJSON = {
        downtimeTrend: downtimeTrend
      }
      res.status(200).send(respJSON)
    }
    else {
      res.status(404).send({
        error: 'No Data found',
      })
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })

  }

}

exports.getProductionByModel = async (req, res) => {
  const plantName = req.params["plant"];
  const lineName = req.params["line"];
  const totalRequired = req.params["totalRequired"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  let query = '';

  if (lineName === "all")
    query = `SELECT
   modelname AS model,
  plannedcount AS plan,
  totalprodcount AS actual
  from getModelCountsForTimeRangeAndLineAggregation('${date}', 'Plant', '${plantName}', '${timeQuantum}', 'A',  '${schemaName}')`;
  else
    query = `SELECT
   modelname AS model,
  plannedcount AS plan,
  totalprodcount AS actual
  from getModelCountsForTimeRangeAndLineAggregation('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A',  '${schemaName}')`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query);

    if (result.rowCount > 0) {
      /**
        * @typedef {{model:string,plan:number,actual:number}} DataRow
        */

      /**
       * @type {[DataRow]}
       */
      const data = [];
      if (totalRequired === "true") {
        let totalObject = {
          model: "Total",
          plan: result.rows.reduce((accumulator, current) => accumulator + Number(current.plan), 0),
          actual: result.rows.reduce((accumulator, current) => accumulator + Number(current.actual), 0)
        }
        data.push(totalObject);
      }
      result.rows.forEach(p => data.push({
        model: p.model,
        plan: Number(p.plan),
        actual: Number(p.actual)
      }));
      const respJSON = {
        viewByModelObjcts: data
      }
      res.status(200).send(respJSON)
    }
    else {
      res.status(404).send({
        error: 'No Data found',
      })
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

exports.getDownTimeParetoByCause = async (req, res) => {
  const lineName = req.params["line"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  let queryForQualityStop = `SELECT
      ROUND(a.idealcycletime * a.total_ng) as value,
      0 as percentage
    FROM getProductionData ('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}') AS a`;

  let queryForBreakdown = `select
      ROUND(SUM(breakdown) / 60) as value,
      0 as percentage
     from getBreakdownTimes('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A','${schemaName}')`;

  let queryForPerformance = `select
      ROUND(SUM(microstop) / 60) as value,
      0 as percentage
     from getMicrostopTimes('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A','${schemaName}')`;

  let queryForChangeover = `select
      ROUND(SUM(changeovertimeafter) / 60) as value,
      0 as percentage
     from getLineShiftPlanIdsForTimeRangeAndLineAggregation('${date}', 'Line', '${lineName}', '${timeQuantum}', 'A','${schemaName}')`

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const resultForQualityStop = await client.query(queryForQualityStop);
    const resultForBreakdown = await client.query(queryForBreakdown);
    const resultForPerformance = await client.query(queryForPerformance);
    const resultForChangeover = await client.query(queryForChangeover);

    client.release(true);
    let downtimePareto = [];
    let downtimeParetoTitles = ["Changeover", "Breakdown", "Quality", "Performance (*Mostly due to Microstops)"]
    let breakdownStopdata = [];
    let performanceStopdata = [];
    let qualityStopData = [];
    let changeoverData = [];

    if (resultForBreakdown.rowCount > 0) {
      /**
       * @typedef {{value:number,percentage:number}} DataRowForBreakdown
       */

      /**
       * @type {[DataRowForBreakdown]}
       */
      breakdownStopdata = resultForBreakdown.rows;

    }

    if (resultForPerformance.rowCount > 0) {
      /**
       * @typedef {{value:number,percentage:number}} DataRowForPerformance
       */

      /**
       * @type {[DataRowForPerformance]}
       */
      performanceStopdata = resultForPerformance.rows;
    }

    if (resultForChangeover.rowCount > 0) {
      /**
       * @typedef {{value:number,percentage:number}} DataRowForPerformance
       */

      /**
       * @type {[DataRowForPerformance]}
       */
      changeoverData = resultForChangeover.rows;
      changeoverData.forEach(p => p.value = Number(p.value));
    }

    if (resultForQualityStop.rowCount > 0) {
      /**
       * @typedef {{value:number,percentage:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      qualityStopData = resultForQualityStop.rows;
      qualityStopData.forEach(p => p.value = Number(p.value));
    }

    downtimeParetoTitles.forEach(p => {
      downtimePareto.push({
        name: p,
        value: p === "Breakdown" ? breakdownStopdata[0]["value"] :
          p === "Performance (*Mostly due to Microstops)" ? performanceStopdata[0]["value"] :
            p === "Quality" ? qualityStopData[0]["value"] : changeoverData[0]["value"],

        percentage: p === "Breakdown" ? breakdownStopdata[0]["percentage"] :
          p === "Performance (*Mostly due to Microstops)" ? performanceStopdata[0]["percentage"] :
            p === "Quality" ? qualityStopData[0]["percentage"] : changeoverData[0]["percentage"]
      })
    })

    downtimePareto = downtimePareto.sort((a, b) => b["value"] - a["value"]);
    let percentage = 0;
    downtimePareto.forEach(
      item => {
        percentage += (item["value"] /
          UtilityMethods.getSumOfStopTimes(
            downtimePareto,
            "value"
          )) *
          100
        item["percentage"] = percentage
      }
    );

    if (downtimePareto.length > 0) {
      const respJSON = {
        downtimePareto: downtimePareto
      }
      res.status(200).send(respJSON)
    }
    else {
      res.status(404).send({
        error: 'No Data found',
      })
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })

  }
}

exports.getPerformanceOrQualityLoss = async (req, res) => {
  const plantName = req.params["plant"];
  const type = req.params["type"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;

  let query = '';
  if (type === 'Quality')
    query = `SELECT
        plant_line as linename,
        ROUND((total_ng * idealcycletime) / 60) AS value
      FROM getProductionData ('${date}', 'Plant', '${plantName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}')`;
  else
    query = `SELECT
        plant_line as linename,
        ROUND((planned_production_time - changeovertimeafter - breakdowntime - (total * idealcycletime)) / 60) AS value
      FROM getProductionData ('${date}', 'Plant', '${plantName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}')`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query);
    client.release(true);

    if (result.rowCount > 0) {
      /**
       * @typedef {{linename:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = result.rows;
      const respJSON = {
        lossData: data.map(p => ({
          name: p.linename.substring(p.linename.lastIndexOf('#') + 1),
          value: Number(p.value),
          percentage: 0
        }))
      }
      res.status(200).send(respJSON);
    } else {
      res.status(200).send({ lossData: [] });
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

exports.getPerformanceOrQualityLossTrend = async (req, res) => {
  const plantName = req.params["plant"];
  const type = req.params["type"];
  const timeQuantum = TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const { schemaName, date } = req.query;
  const dateRange = getDBDateRanges(date, timeQuantum);

  let linesGetterQuery = `
        SELECT
        l.linename AS linename
        FROM ${schemaName}."Lines" l
        JOIN ${schemaName}."Plants" p
        ON l."locId"=p.plantid
        WHERE plantname='${plantName}';
      `;

  let query = '';
  if (type === 'Quality')
    query = dateRange.map(
      (d, index, arr) => `SELECT
      '${d}' as range,
        plant_line as linename,
        ROUND((total_ng * idealcycletime) / 60) AS value
      FROM getProductionData ('${d}', 'Plant', '${plantName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}')`
    ).join("\nUNION\n");
  else
    query = dateRange.map(
      (d, index, arr) => `SELECT
      '${d}' as range,
        plant_line as linename,
        ROUND((planned_production_time - changeovertimeafter - breakdowntime - (total * idealcycletime)) / 60) AS value
      FROM getProductionData ('${d}', 'Plant', '${plantName}', '${timeQuantum}', 'A', 'ANY', '${schemaName}')`
    ).join("\nUNION\n");

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query);
    const linesResult = await client.query(linesGetterQuery);
    client.release(true);

    const dateRanges = UtilityMethods.getTimeSeriesRanges(timeQuantum, new Date(date));
    if (result.rowCount > 0) {
      /**
       * @typedef {{range:string,linename:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = [];

      const modifiedData = [];

      result.rows.sort((a, b) => a.linename.toLowerCase().localeCompare(b.linename.toLowerCase()));

      linesResult.rows.forEach(line => {
        dateRanges.forEach(date => {
          let foundIndex = -1;

          if (timeQuantum === 'Day')
            foundIndex = result.rows.findIndex(p => p.linename.substring((p.linename.lastIndexOf('#') + 1) === line.linename) && p.range === date.time);
          else {
            let start = new Date(date.time.substring(0, 10)).getTime();
            let end = new Date(date.time.substring(12)).getTime();
            foundIndex = result.rows.findIndex(p => p.linename.substring((p.linename.lastIndexOf('#') + 1) === line.linename) && new Date(p.range).getTime() > start && new Date(p.range).getTime() <= end);
          }

          modifiedData.push({
            linename: line.linename,
            value: foundIndex === -1 ? 0 : result.rows[foundIndex].value,
            date: date.indicator
          })
        })
      })

      modifiedData.reduce(function (res, item) {
        let key = item.linename;
        let range = item.date;

        if (!res[key]) {
          res[key] = { title: item.linename, data: [{ range: range, value: Number(item.value) }] };
          data.push(res[key])
        }
        else
          res[key].data.push({ range: range, value: Number(item.value) });
        return res;
      }, {});
      const respJSON = {
        lossTrendData: data
      }
      res.status(200).send(respJSON);
    } else {
      res.status(200).send({ lossTrendData: [] });
    }
  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
}

