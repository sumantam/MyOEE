const methods = require("../utils/common/changeOver-methods");

exports.getChangeoverDataByPlant = async (req, res) => {
  const timeQ = getTimeQ(req.params["timeQ"]);
  const plantId = req.params["plant"];  

  try {
    const data = await methods.getChangeoverDataByPlant(plantId, timeQ);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getChangeoverDataByLine = async (req, res) => {
  const timeQ = getTimeQ(req.params["timeQ"]);
  const lineId = req.params["line"];
  try {
    const data = await methods.getChangeoverDataByLine(lineId, timeQ);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getChangeOverTrendByLine = async (req, res) => {
  const timeQ = req.params["timeQ"];
  const lineId = req.params["line"];
  try {
    const data = await methods.getChangeOverTrendByLine(lineId, timeQ);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getChangeoverTrendByPlant = async (req, res) => {
  const timeQ = req.params["timeQ"];
  const plantId = req.params["plant"];
  try {
    const data = await methods.getChangeoverDataByPlantMethod2(plantId, timeQ);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getChangeoverGridDataByPlant = async (req, res) => {
  const timeQ = getTimeQ(req.params["timeQ"]);
  const plantId = req.params["plant"];  

  try {
    const data = await methods.getCgangeOverGridDataByPlant(plantId, timeQ);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getChangeoverGridTrendDataCountByLine = async (req, res) => {
  const lineId = req.params["line"];
  try {
    const data = await methods.getCgangeOverGridTrendDataCountByLine(lineId, req.params["timeQ"]);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getChangeoverGridTotalTrendDataByPlant = async (req, res) => {
  const plantId = req.params["plant"];
  try {
    const data = await methods.getCgangeOverGridTotalTrendDataByPlant(plantId, req.params["timeQ"]);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

const getTimeQ = (tq) =>
  ({
    day: { start: "2024-08-22T06:00:00", end: "2024-08-23T06:00:00" },
    week: { start: "2024-08-16T06:00:00", end: "2024-08-23T06:00:00" },
    month: { start: "2024-08-01T06:00:00", end: "2024-08-25T06:00:00" },
    year: { start: "2023-08-01T06:00:00", end: "2024-08-25T06:00:00" }
  }[tq]);
