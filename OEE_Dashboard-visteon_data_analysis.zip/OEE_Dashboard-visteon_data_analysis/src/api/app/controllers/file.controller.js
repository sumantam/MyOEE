const fs = require('fs')
const csv = require('csv-parser');
const { formidable } = require('formidable')
const {
  createLocations,
  createDowntimeReasons,
  createProductionSummary,
  createLines,
  createMachineTypes,
  createMachinesInPipeline,
  createLineShiftTimes,
  createLineShiftPlans,
  createChangeOverTypeTimes,
  createChangeOverTypes,
  createStandardCycleTimes
} = require('./dbcontrollers/db.controller')
const { getEventData, setEventData } = require("../../data-loader");

exports.readFile = async (req, res) => {
  const form = formidable({
    multiples: true,
    maxFileSize: 400 * 1024 * 1024,
    maxTotalFileSize: 600 * 1024 * 1024
  })
  const { schema } = req.query

  console.log('The schema is :', schema)
  // console.log('The req is :', req)

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error(err)
      res.status(500).send('Error parsing form')
      return
    }

    try {
      const buffer = fs.readFileSync(files.file[0].filepath)
      const objects = JSON.parse(buffer)
      const keys = Object.keys(objects)

      for (const key of keys) {
        console.log('The key is ', key)
        switch (key) {
          case 'Plants': {
            const locReq = {
              body: {
                data: {
                  plantName: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createLocations(locReq, res)
            console.log('PlantResponse = ', response)
          }
            break
          case 'Lines': {
            const locReq = {
              body: {
                data: {
                  Lines: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createLines(locReq, res)
            console.log('LineResponse = ', response)
          }
            break
          case 'Machine_Types': {
            const locReq = {
              body: {
                data: {
                  MachineTypes: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createMachineTypes(locReq, res)
            console.log('MachineTypesResponse = ', response)
          }
            break
          case 'Machines_In_Pipeline': {
            const locReq = {
              body: {
                data: {
                  MachinesInPipelines: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createMachinesInPipeline(locReq, res)
            console.log('MachinesInPipeline = ', response)
          }
            break
          case 'Line_Shift_Times': {
            const locReq = {
              body: {
                data: {
                  LineShiftTimes: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createLineShiftTimes(locReq, res)
            console.log('LineShiftTimes = ', response)
          }
            break
          case 'Line_Shift_Plans': {
            const locReq = {
              body: {
                data: {
                  LineShiftPlans: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createLineShiftPlans(locReq, res)
            console.log('LineShiftPlans = ', response)
          }
            break
          case 'Production_Summary': {
            const locReq = {
              body: {
                data: {
                  ProdSummary: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createProductionSummary(locReq, res)
            console.log('ProductionSummary = ', response)
          }
            break
          case 'Downtime_Reasons': {
            const locReq = {
              body: {
                data: {
                  downtimeReasons: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createDowntimeReasons(locReq, res)
            console.log('DowntimeReasons = ', response)
          }
            break
          case 'Changeover_Type_Times': {
            const locReq = {
              body: {
                data: {
                  changeoverTypeTimes: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createChangeOverTypeTimes(locReq, res)
            console.log('ChangeoverTypeTimes = ', response)
          }
            break
          case 'Changeover_Types': {
            const locReq = {
              body: {
                data: {
                  changeoverTypes: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createChangeOverTypes(locReq, res)
            console.log('ChangeoverTypes = ', response)
          }
            break
          case 'Standard_Cycle_Times': {
            const locReq = {
              body: {
                data: {
                  stdCycleTimes: objects[key],
                  schemaName: schema,
                  isReturn: true
                }
              }
            }
            const response = await createStandardCycleTimes(locReq, res)
            console.log('Standard_Cycle_Times = ', response)
          }
            break
          default: {
            // Handle other cases
          }
        }
      }
      res.status(200).send('File processed successfully')
    } catch (error) {
      console.error(error)
      res.status(500).send('Error processing file')
    }
  })
}

const getDate = (date) => {
  return `${date.substring(0, date.indexOf('/'))}-${date.substring(5, 7)}-${date.substring(date.lastIndexOf('/') + 1)}`;
}

const getFromTime = (time) => {
  let hour = time.substring(0, time.indexOf(':'));
  if ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9].includes(hour))
    hour = `0${hour}`;
  return hour + time.substring(time.indexOf(':')) + '.00';
}

const getToTime = (fromTime, time) => {
  let timeFirstPart = fromTime.substring(0, fromTime.lastIndexOf('.'));
  let timeTaken = time.substring(time.indexOf('.'));
  return `${timeFirstPart}${timeTaken}`;
}

const generateRandomHexColor = () => {
  return `#${Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0')}`;
}

const assignColorsToArray = (dataArray) => {
  return dataArray.map((item) => ({
    ...item,
    color: generateRandomHexColor(),
  }));
}

exports.readForbiaCsvFileAndMakeJosn = async (req, res) => {
  const form = formidable({
    multiples: true,
    maxFileSize: 400 * 1024 * 1024,
    maxTotalFileSize: 600 * 1024 * 1024
  })

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error(err)
      res.status(500).send('Error parsing form')
      return
    }
    try {
      // Input and output file paths
      // const inputCsvFile = 'data/forbia.csv';
      if (fs.existsSync('data/forvia.json'))
        fs.unlinkSync('data/forvia.json');
      const outputJsonFile = 'data/forvia.json';
      // const outputJsonFile = 'data/forbia_panel_production_start_end.json';

      let jsonData = [];
      let uniquePcbIdsAndColors = [];
      // fs.createReadStream(inputCsvFile)
      fs.createReadStream(files.file[0].filepath)
        .pipe(csv())
        .on('data', (row) => {

          // let hour = row["LNB Time"].substring(0, row["LNB Time"].indexOf(':'));
          // let minute = Number(row["LNB Time"].substring(row["LNB Time"].indexOf(':') + 1, row["LNB Time"].lastIndexOf(':')));
          // // if (hour === '00' && (row["Event Desc"] === "Panel Loaded" || row["Event Desc"] === "Panel Unloaded")) {
          // if (hour === '00' && (row["Event Desc"] === "Panel Production Start" || row["Event Desc"] === "Panel Production End")) {

          // }
          if (row["LNB Date"] !== undefined && row["LNB Date"] !== null) {
            let foundIndex = uniquePcbIdsAndColors.findIndex(p => p["pcbId"] === row["PCBID"]);
            if (foundIndex === -1)
              uniquePcbIdsAndColors.push({ "pcbId": row["PCBID"] })

            let object = {
              "machine": `Machine ${row["MCNo"]} ${row["Event Desc"]}`,
              "pcbId": row["PCBID"],
              "fromDate": `${getDate(row["LNB Date"])}T${getFromTime(row["LNB Time"])}`,
              "toDate": `${getDate(row["LNB Date"])}T${getToTime(getFromTime(row["LNB Time"]), row["#CIMC Time"])}`,
              "event": row["Event Desc"]
            }
            jsonData.push(object);
          }
        })
        .on('end', () => {
          console.log('CSV file successfully processed.');

          // Write data to a JSON file
          jsonData = jsonData.sort((a, b) => (a.machine > b.machine) ? 1 : ((b.machine > a.machine) ? -1 : 0));
          const coloredData = assignColorsToArray(uniquePcbIdsAndColors);

          let finalJsonData = [];
          jsonData.forEach(p => {
            let colorIndex = coloredData.findIndex(x => x["pcbId"] === p["pcbId"]);
            p["color"] = coloredData[colorIndex]["color"];
            finalJsonData.push(p);
          })

          fs.writeFile(outputJsonFile, JSON.stringify(finalJsonData, null, 2), (err) => {
            if (err) {
              console.error('Error writing to JSON file:', err);
              res.status(500).send('Error writing to JSON file')
            } else {
              console.log('Data written to JSON file:', outputJsonFile);
              setEventData(JSON.parse(fs.readFileSync("data/forvia.json", "utf8")));
              res.status(200).send('Data written to JSON file successfully')
            }
          });
        })
        .on('error', (err) => {
          console.error('Error reading CSV file:', err);
          res.status(500).send('Error reading CSV file')
        });
    } catch (e) {
      console.error(e)
      res.status(500).send('Error processing file')
    }
    // Read the CSV file
  })
}

exports.getUniqueEventsPair = async (req, res) => {
  try {
    let data = getEventData();
    let uniqueEvents = [];
    let uniqueEventsPairs = [];
    data.forEach(p => {
      let found = uniqueEvents.findIndex(x => x === p["event"]);
      if (found === -1)
        uniqueEvents.push(p["event"]);
    })
    uniqueEvents.forEach(p => {
      let pairedEvent = '';
      if (p.endsWith('Start') || p.endsWith('Loaded')) {
        pairedEvent += `${p} - `;
        let eventPrefix = p.substring(0, p.lastIndexOf(' ') + 1);
        let endEvent = p.endsWith('Start') ? uniqueEvents.find(x => x === eventPrefix + "End") :
          uniqueEvents.find(x => x === eventPrefix + "Unloaded");
        pairedEvent += endEvent;
        uniqueEventsPairs.push(pairedEvent);
      }
      else if (p.endsWith('End') || p.endsWith('Unloaded')) {
        // Do nothing
      }
      else if (p.endsWith('Wait For Post Process End') || p.endsWith('Wait For Pre Process End') || p.endsWith('Not Available')) {
        pairedEvent = p.endsWith('Wait For Post Process End') ? 'Wait For Post Process - Wait For Post Process End' :
          p.endsWith('Wait For Pre Process End') ? 'Wait For Pre Process - Wait For Pre Process End' :
            'Panel Available - Panel Not Available'
        uniqueEventsPairs.push(pairedEvent);
      }
      else if (p.endsWith('Wait For Post Process') || p.endsWith('Wait For Pre Process') || p.endsWith('Available')) {
        // Do nothing
      }
      else
        uniqueEventsPairs.push(p);
    })
    res.status(200).send({
      events: uniqueEventsPairs
    })
  } catch (e) {
    console.log(e);
    res.status(500).send('Error processing ata')
  }
}

exports.getEventSpecificTimeseriesData = async (req, res) => {
  const fromTime = Number(req.params["fromTime"]);
  const toTime = Number(req.params["toTime"]);
  const { event } = req.query;

  try {
    const data = getEventData();
    let filteredData = [];
    let events = []
    if (event.endsWith("End") || event.endsWith("Unloaded") || event.endsWith("Wait For Post Process End") || event.endsWith("Wait For Pre Process End") || event.endsWith('Not Available')) {
      let firstEvent = event.substring(0, event.indexOf('-') - 1);
      let secondEvent = event.substring(event.indexOf('-') + 2);
      events.push(firstEvent);
      events.push(secondEvent);
    }
    else
      events.push(event);
    data.forEach(p => {
      let startTime = new Date(p["fromDate"]).getTime();
      let endTime = new Date(p["toDate"]).getTime();
      if (events.includes(p["event"]) && startTime >= fromTime && endTime <= toTime)
        filteredData.push(p);
    })
    res.status(200).send({
      timeSeriesData: filteredData
    })
  } catch (e) {
    console.log(e);
    res.status(500).send('Error processing data')
  }
}

exports.getSampleCsvFile = async (req, res) => {
  try {
    const filePath = 'data/sample.csv';
    const fileStream = fs.createReadStream(filePath);

    // Handle errors during stream
    fileStream.on('error', (err) => {
      console.error('Stream error:', err);
      res.status(500).send('File could not be downloaded.');
    });

    // Set headers and pipe file to response
    res.setHeader('Content-Disposition', 'attachment; filename="sample.csv"');
    fileStream.pipe(res);
  } catch (e) {
    console.log(e);
    res.status(500).send('Error downloading file')
  }
}
