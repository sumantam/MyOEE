const methods = require("../utils/common/brekdown-methods");
const { UtilityMethods } = require("../utils/utility.methods");

exports.getBreakdownDataByPlant = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const plantName = req.params["plant"];
  const { schemaName, date } = req.query;

  try {
    const data = await methods.getBreakdownDataByPlant(plantName, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getBreakdownDataByLine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getBreakdownDataByLine(lineId, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getBreakdownDataByMachine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const machineId = req.params["machineId"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getBreakdownDataByMachine(lineId, timeQ, date, schemaName, machineId);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getBreakdownActionsByLine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getBreakdownActionsByLine(lineId, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getBreakdownActionsByMachine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const machineName = req.params["machineName"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getBreakdownActionsByMachine(lineId, timeQ, date, schemaName, machineName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getBreakdownTrendByMachine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const machineId = req.params["machineId"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getBreakdownTrendByMachine(lineId, timeQ, date, schemaName, machineId);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getBreakdownTrendByLine = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const lineId = req.params["line"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getBreakdownTrendByLine(lineId, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};

exports.getBreakdownTrendByPlant = async (req, res) => {
  const timeQ = UtilityMethods.TIME_QUANTUM_MAPPER[req.params["timeQ"]];
  const plantName = req.params["plant"];
  const { schemaName, date } = req.query;
  try {
    const data = await methods.getBreakdownTrendByPlant(plantName, timeQ, date, schemaName);
    return res.status(200).send(data);
  } catch (e) {
    return res.status(500).send(e);
  }
};
