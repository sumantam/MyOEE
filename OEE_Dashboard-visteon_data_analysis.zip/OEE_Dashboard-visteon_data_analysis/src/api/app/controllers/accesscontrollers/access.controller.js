const { PgPools } = require('../../utils/pgPool')
const dbConfig = require('../../config/db.config')
const UtilityMethods = require('../../utils/utility.methods').UtilityMethods;
// const format = require('pg-format')

// ####################################################

exports.getLastDate = async (req, res) => {
  const { schemaName } = req.query
  try {
    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = `
    SELECT 
    exitmachinetimestamp AS lastdate
    FROM ${schemaName}."Runs"
    ORDER BY "exitmachinetimestamp" DESC
    LIMIT 1`;

    const result = await client.query(query)
    client.release(true);

    if (result.rowCount > 0) {
      const data = result.rows[0]["lastdate"];
      res.status(200).send({ "lastDate": UtilityMethods.dateToDBString(data) });
    } else {
      res.status(200).send({ "lastDate": "1900-01-01" });
    }

  } catch (error) {
    res.status(500).send(error.message)
  }
}

exports.getPlants = async (req, res) => {
  const { schemaName } = req.query

  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = `
        SELECT
        PlantId AS "Id",
        PlantName AS "Name",
        (ancillaryplantdatafile::jsonb ->> 'Lat') AS "Lat",
        (ancillaryplantdatafile::jsonb ->> 'Long') AS "Long"
        FROM ${schemaName}."Plants";
      `

    const result = await client.query(query)
    client.release(true)

    if (result.rowCount > 0) {
      const data = result.rows.map(x => ({ ...x, Lat: Number(x.Lat), Long: Number(x.Long) }));
      res.status(200).send(data)
    } else {
      res.status(404).send('No plants found')
    }
  } catch (error) {
    res.status(500).send(error.message)
  }
}

exports.getLines = async (req, res) => {
  const { plantName } = req.params
  const { schemaName } = req.query

  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const query = `
        SELECT
        l.lineId AS "Id",
        l.lineName AS "Name",
        p.plantName AS "PlantName"
        FROM ${schemaName}."Lines" l
        JOIN ${schemaName}."Plants" p
        ON l."locId"=p.plantid
        WHERE plantname='${plantName}';
      `

    const result = await client.query(query)
    client.release(true)

    if (result.rowCount > 0) {
      const data = result.rows
      res.status(200).send(data)
    } else {
      res.status(404).send('No lines found')
    }
  } catch (error) {
    res.status(500).send(error.message)
  }
}

exports.getOeeParameters = async (req, res) => {
  const { plantName } = req.params
  const { lineName } = req.params
  const { timeQuantum } = req.params

  const { schemaName, date } = req.query

  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const LineAggregatorType = (lineName === 'All' || lineName === 'all') ? 'Plant' : 'Line'
    const LineAggregatorValue = (lineName === 'All' || lineName === 'all') ? plantName : lineName
    let TimeAggregatorValue = timeQuantum.toUpperCase()

    if (TimeAggregatorValue === 'DAY') { TimeAggregatorValue = 'Day' } else if (TimeAggregatorValue === 'WEEK') { TimeAggregatorValue = 'Week' } else if (TimeAggregatorValue === 'MONTH') { TimeAggregatorValue = 'Month' } else if (TimeAggregatorValue === 'YEAR') { TimeAggregatorValue = 'Year' }

    const query = `
        SELECT *
        FROM getProductionData('${date}',
        '${LineAggregatorType}', '${LineAggregatorValue}',
        '${TimeAggregatorValue}', 'A', 'ABC', '${schemaName}'
        );
      `

    const result = await client.query(query)
    client.release(true)

    if (result.rowCount > 0) {
      let responseData = {};
      const data = result.rows
      const consData = data
      if (consData === null) {
        responseData = {}
      }

      else if (consData.length === 1) {
        let dataObj = consData[0];
        responseData = {
          Plant: plantName,
          Lines: {
            Line_Id: dataObj.line_id,
            Line:  dataObj.plant_line.substring(dataObj.plant_line.lastIndexOf('#') + 1),
            Ideal_Cycle_Time: Number(dataObj.idealcycletime),
            Breakdown_Time: Number(dataObj.breakdowntime),
            Planned_Production_Time: Number(dataObj.planned_production_time),
            Availability:  parseFloat(Number(dataObj.availability).toFixed(2)),
            Changeover_Time: Number(dataObj.changeovertimeafter),
            Total_Planned: Number(dataObj.total_planned),
            Total: Number(dataObj.total),
            Total_OK: Number(dataObj.total_ok),
            Total_NG: Number(dataObj.total_ng),
            Total_FTT: Number(dataObj.total_ftt),
            Quality_Percentage: parseFloat(Number(dataObj.quality).toFixed(2)),
            Performance_Percentage: parseFloat(Number(dataObj.performance).toFixed(2)),
            BTS: parseFloat(UtilityMethods.getBts(UtilityMethods.getTotalAdjusted(Number(dataObj.total_planned), UtilityMethods.getAdjustedAdherence(Number(dataObj.total_planned), Number(dataObj.total))), Number(dataObj.total_planned)).toFixed(2)),
            OEE: parseFloat((UtilityMethods.getOee((Number(dataObj.availability) / 100), (Number(dataObj.performance) / 100), (Number(dataObj.quality) / 100)) * 100).toFixed(2))
          }
        };
      } 
      else {
        const aggregatedJson = {
          Plant: plantName,
          Lines: {
            Line_Id: 'All',
            Line: 'All',
            Ideal_Cycle_Time: 0,
            Breakdown_Time: 0,
            Planned_Production_Time: 0,
            Availability: 0,
            Changeover_Time: 0,
            Total_Planned: 0,
            Total: 0,
            Total_OK: 0,
            Total_NG: 0,
            Total_FTT: 0,
            Quality_Percentage: 0,
            Performance_Percentage: 0,
            BTS: 0,
            OEE: 0
          }
        }

        const totalEntries = consData.length

        consData.forEach((item) => {
          const line = item

          aggregatedJson.Lines.Ideal_Cycle_Time += Number(line.idealcycletime)
          aggregatedJson.Lines.Breakdown_Time += Number(line.breakdowntime)
          aggregatedJson.Lines.Planned_Production_Time += Number(line.planned_production_time)
          aggregatedJson.Lines.Changeover_Time += Number(line.changeovertimeafter)
          aggregatedJson.Lines.Total_Planned += Number(line.total_planned)
          aggregatedJson.Lines.Total += Number(line.total)
          aggregatedJson.Lines.Total_OK += Number(line.total_ok)
          aggregatedJson.Lines.Total_NG += Number(line.total_ng)
          aggregatedJson.Lines.Total_FTT += Number(line.total_ftt)

          // Summing for averages
          aggregatedJson.Lines.Availability += Number(line.availability)
          aggregatedJson.Lines.Quality_Percentage += Number(line.quality)
          aggregatedJson.Lines.Performance_Percentage += Number(line.performance)
          aggregatedJson.Lines.BTS += UtilityMethods.getBts(UtilityMethods.getTotalAdjusted(Number(line.total_planned), UtilityMethods.getAdjustedAdherence(Number(line.total_planned), Number(line.total))), Number(line.total_planned))
          aggregatedJson.Lines.OEE += UtilityMethods.getOee((Number(line.availability) / 100), (Number(line.performance) / 100), (Number(line.quality) / 100)) * 100
        })

        // Averaging the necessary fields
        aggregatedJson.Lines.Ideal_Cycle_Time /= totalEntries
        aggregatedJson.Lines.Availability /= totalEntries
        aggregatedJson.Lines.Quality_Percentage /= totalEntries
        aggregatedJson.Lines.Performance_Percentage /= totalEntries
        aggregatedJson.Lines.BTS /= totalEntries
        aggregatedJson.Lines.OEE /= totalEntries

        aggregatedJson.Lines.Availability = parseFloat(aggregatedJson.Lines.Availability.toFixed(2));        
        aggregatedJson.Lines.Quality_Percentage = parseFloat(aggregatedJson.Lines.Quality_Percentage.toFixed(2));
        aggregatedJson.Lines.Performance_Percentage = parseFloat(aggregatedJson.Lines.Performance_Percentage.toFixed(2));
        aggregatedJson.Lines.BTS = parseFloat(aggregatedJson.Lines.BTS.toFixed(2));
        aggregatedJson.Lines.OEE = parseFloat(aggregatedJson.Lines.OEE.toFixed(2));

        responseData = aggregatedJson;
      }
      res.status(200).send(responseData)
    } else {
      res.status(200).send({})
    }
  } catch (error) {
    console.log(error)
    res.status(500).send(error.message)
  }
}

exports.getOeeTrend = async (req, res) => {
  const { plantName } = req.params
  const { lineName } = req.params
  const { timeQuantum } = req.params

  const { schemaName, date } = req.query
  let client = null

  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const LineAggregatorType = (lineName === 'All') ? 'Plant' : 'Line'
    const LineAggregatorValue = (lineName === 'All') ? plantName : lineName
    let TimeAggregatorValue = timeQuantum.toUpperCase()

    if (TimeAggregatorValue === 'DAY') { TimeAggregatorValue = 'Day' }
    else if (TimeAggregatorValue === 'WEEK') { TimeAggregatorValue = 'Week' }
    else if (TimeAggregatorValue === 'MONTH') { TimeAggregatorValue = 'Month' }
    else if (TimeAggregatorValue === 'YEAR') { TimeAggregatorValue = 'Year' }

    let count = 1
    if (TimeAggregatorValue === 'Day') { count = 7 }
    else if (TimeAggregatorValue === 'Week') { count = 8 }
    else if (TimeAggregatorValue === 'Month') { count = 12 }
    else if (TimeAggregatorValue === 'Year') { count = 1 }

    const dateobj = new Date(date)

    let oeeTrend = []

    while (count > 0) {
      const oeeValues = {
        range: 0,
        Availability: 0,
        Performance: 0,
        Quality: 0,
        OEE: 0
      }

      const d = dateobj.toISOString().slice(0, 10)

      const query = `
          SELECT availability, quality, performance
          FROM getProductionData('${d}',
          '${LineAggregatorType}', '${LineAggregatorValue}',
          '${TimeAggregatorValue}', 'A', 'ABC', '${schemaName}'
          );
        `

      const result = await client.query(query)

      if (result.rowCount > 0) {
        const data = result.rows
        const consData = data[0]

        oeeValues.range = dateobj.toISOString().slice(0, 10)
        oeeValues.Availability = consData.availability
        oeeValues.Performance = consData.performance
        oeeValues.Quality = consData.quality
        oeeValues.OEE = (consData.availability / 100.0) * (consData.performance / 100.0) * (consData.quality / 100.0) * 100

        count = count - 1
        if (TimeAggregatorValue === 'Day') { dateobj.setDate(dateobj.getDate() - 1) }
        else if (TimeAggregatorValue === 'Week') { dateobj.setDate(dateobj.getDate() - 7) }
        else if (TimeAggregatorValue === 'Month') { dateobj.setMonth(dateobj.getMonth() - 1) }
        else if (TimeAggregatorValue === 'Year') { dateobj.setFullYear(dateobj.getFullYear() - 1) }

        oeeTrend.push(oeeValues)
      }
    }
    res.status(200).send(JSON.stringify(oeeTrend, null, 2))
  } catch (error) {
    res.status(500).send(error.message)
  } finally {
    if (client) { client.release(true) }
  }
}


exports.getTrendOee = async (req, res) => {
  const { plantName } = req.params
  const { lineName } = req.params
  const { timeQuantum } = req.params

  const { schemaName, date } = req.query
  let client = null

  try {
    // Test the database exists

    const pgPoolsInstance = await PgPools.getInstance()
    client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const LineAggregatorType = (lineName === 'All') ? 'Plant' : 'Line'
    const LineAggregatorValue = (lineName === 'All') ? plantName : lineName
    let TimeAggregatorValue = timeQuantum.toUpperCase()

    if (TimeAggregatorValue === 'DAY') { TimeAggregatorValue = 'Day' }
    else if (TimeAggregatorValue === 'WEEK') { TimeAggregatorValue = 'Week' }
    else if (TimeAggregatorValue === 'MONTH') { TimeAggregatorValue = 'Month' }
    else if (TimeAggregatorValue === 'YEAR') { TimeAggregatorValue = 'Year' }

    let count = 1
    if (TimeAggregatorValue === 'Day') { count = 7 }
    else if (TimeAggregatorValue === 'Week') { count = 8 }
    else if (TimeAggregatorValue === 'Month') { count = 12 }
    else if (TimeAggregatorValue === 'Year') { count = 1 }

    const dateobj = new Date(date)

    let oeeTrend = []
    let availTrend = []
    let performTrend = []
    let qualityTrend = []

    while (count > 0) {
      const AvailValues = {
        range: 0,
        Availability: 0
      }

      const PerformanceValues = {
        range: 0,
        Performance: 0
      }

      const QualityValues = {
        range: 0,
        Quality: 0
      }

      const oeeValues = {
        range: 0,
        OEE: 0
      }

      const d = dateobj.toISOString().slice(0, 10)

      const query = `
          SELECT availability, quality, performance
          FROM getProductionData('${d}',
          '${LineAggregatorType}', '${LineAggregatorValue}',
          '${TimeAggregatorValue}', 'A', 'ABC', '${schemaName}'
          );
        `

      const result = await client.query(query)

      if (result.rowCount > 0) {
        const data = result.rows
        const consData = data[0]

        AvailValues.range = dateobj.toISOString().slice(0, 10)
        AvailValues.Availability = consData.availability

        PerformanceValues.range = dateobj.toISOString().slice(0, 10)
        PerformanceValues.Performance = consData.performance

        QualityValues.range = dateobj.toISOString().slice(0, 10)
        QualityValues.Quality = consData.quality

        oeeValues.range = dateobj.toISOString().slice(0, 10)
        oeeValues.OEE = (consData.availability / 100.0) * (consData.performance / 100.0) * (consData.quality / 100.0) * 100

        count = count - 1
        if (TimeAggregatorValue === 'Day') { dateobj.setDate(dateobj.getDate() - 1) }
        else if (TimeAggregatorValue === 'Week') { dateobj.setDate(dateobj.getDate() - 7) }
        else if (TimeAggregatorValue === 'Month') { dateobj.setMonth(dateobj.getMonth() - 1) }
        else if (TimeAggregatorValue === 'Year') { dateobj.setFullYear(dateobj.getFullYear() - 1) }

        availTrend.push(AvailValues)
        performTrend.push(PerformanceValues)
        qualityTrend.push(QualityValues)
        oeeTrend.push(oeeValues)
      }
    }

    res.status(200).send(JSON.stringify({ availTrend, performTrend, qualityTrend, oeeTrend }, null, 2))
  } catch (error) {
    res.status(500).send(error.message)
  } finally {
    if (client) { client.release(true) }
  }
}

exports.getProductionByLine = async (req, res) => {
  const { plantName } = req.params
  const { lineName } = req.params
  const { timeQuantum } = req.params
  const { totalreqd } = req.params

  const { schemaName, date } = req.query
  let client = null

  let TimeAggregatorValue = timeQuantum.toUpperCase()

  if (TimeAggregatorValue === 'DAY') { TimeAggregatorValue = 'Day' }
  else if (TimeAggregatorValue === 'WEEK') { TimeAggregatorValue = 'Week' }
  else if (TimeAggregatorValue === 'MONTH') { TimeAggregatorValue = 'Month' }
  else if (TimeAggregatorValue === 'YEAR') { TimeAggregatorValue = 'Year' }

  try {
    // Test the database exists
    const production_array = []
    const pgPoolsInstance = await PgPools.getInstance()
    client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const plantIdQuery = `
      SELECT plantid from ${schemaName}."Plants" where plantname='${plantName}'
    `
    const result = await client.query(plantIdQuery)

    if (result.rowCount > 0) {
      let data
      if (lineName.toUpperCase() === 'ALL') {
        const locId = result.rows[0].plantid
        let Query = `
          SELECT  plant_line AS line, total_planned AS plan, total as actual
          FROM getProductionData('${date}', 'Plant', '${plantName}', '${TimeAggregatorValue}', 'A', 'ABC', '${schemaName}')
        `
        if (totalreqd) {
          Query += `
            UNION ALL
              SELECT
                'Total' AS line,
                SUM(total_planned) AS plan,
                SUM(total) AS actual
              FROM
                getProductionData('${date}', 'Plant', '${plantName}', '${TimeAggregatorValue}', 'A', 'ABC', '${schemaName}')
            `
        }
        let prodResult = await client.query(Query);
        if (prodResult.rowCount === 1 && prodResult.rows[0]["plan"] === null && prodResult.rows[0]["actual"] === null)
          res.status(200).send({ viewByLineObjects: [] })
        else {
          data = prodResult.rows.map(p => ({
            line: p.line.substring(p.line.lastIndexOf('#') + 1),
            plan: Number(p.plan),
            actual: Number(p.actual)
          }))
          data.forEach(function (item, i) {
            if (item.line === "Total") {
              data.splice(i, 1);
              data.unshift(item);
            }
          });
          res.status(200).send({ viewByLineObjects: data })
        }

      } else {
        const Query = `
          SELECT lineid from ${schemaName}."Lines" where lineId='${lineName}'
        `
        data = (await client.query(Query)).rows
      }
    } else {
      res.status(200).send({ viewByLineObjects: [] })
    }
  } catch (error) {
    res.status(500).send(error.message)
  } finally {
    if (client) { client.release(true) }
  }
}

exports.getChangeOver = async (req, res) => {
  const { plantName } = req.params
  const { lineName } = req.params
  const { timeQuantum } = req.params

  const { schemaName, date } = req.query
  let client = null

  let TimeAggregatorValue = timeQuantum.toUpperCase()

  if (TimeAggregatorValue === 'DAY') { TimeAggregatorValue = 'Day' }
  else if (TimeAggregatorValue === 'WEEK') { TimeAggregatorValue = 'Week' }
  else if (TimeAggregatorValue === 'MONTH') { TimeAggregatorValue = 'Month' }
  else if (TimeAggregatorValue === 'YEAR') { TimeAggregatorValue = 'Year' }
  try {
    // Test the database exists
    const pgPoolsInstance = await PgPools.getInstance()
    client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const plantIdQuery = `
      SELECT plantid from ${schemaName}."Plants" where plantname='${plantName}'
    `
    const result = await client.query(plantIdQuery)

    if (result.rowCount > 0) {
      let data
      if (lineName.toUpperCase() === 'ALL') {
        const Query = `
          SELECT linename AS name, ROUND(SUM(changeovertimeafter) / 60) AS value
          FROM getLineShiftPlanIdsForTimeRangeAndLineAggregation('${date}', 'Plant', '${plantName}', '${TimeAggregatorValue}', 'A', '${schemaName}') 
          GROUP BY line, linename
        `
        data = (await client.query(Query)).rows
        data.sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
        res.status(200).send(data)
      } else {
        const Query = `
          SELECT modelname AS name, ROUND(SUM(changeovertimeafter) / 60) AS value
          FROM getLineShiftPlanIdsForTimeRangeAndLineAggregation('${date}', 'Plant', '${plantName}', '${TimeAggregatorValue}', 'A', '${schemaName}') 
          WHERE line='${lineName}'
          GROUP BY line, modelname
        `
        data = (await client.query(Query)).rows
        res.status(200).send(data)
      }
    } else {
      res.status(200).send([])
    }
  } catch (error) {
    res.status(500).send(error.message)
  } finally {
    if (client) { client.release(true) }
  }
}

exports.getChangeOverTrend = async (req, res) => {
  const { plantName } = req.params
  const { lineName } = req.params
  const { timeQuantum } = req.params

  const { schemaName, date } = req.query
  let client = null

  let TimeAggregatorValue = timeQuantum.toUpperCase()

  if (TimeAggregatorValue === 'DAY') { TimeAggregatorValue = 'Day' }
  else if (TimeAggregatorValue === 'WEEK') { TimeAggregatorValue = 'Week' }
  else if (TimeAggregatorValue === 'MONTH') { TimeAggregatorValue = 'Month' }
  else if (TimeAggregatorValue === 'YEAR') { TimeAggregatorValue = 'Year' }
  try {
    // Test the database exists
    const pgPoolsInstance = await PgPools.getInstance()
    client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()

    let linesGetterQuery = `
        SELECT
        l.linename AS linename
        FROM ${schemaName}."Lines" l
        JOIN ${schemaName}."Plants" p
        ON l."locId"=p.plantid
        WHERE plantname='${plantName}';
      `;

    const plantIdQuery = `
      SELECT plantid from ${schemaName}."Plants" where plantname='${plantName}'
    `
    const result = await client.query(plantIdQuery);
    const linesResult = await client.query(linesGetterQuery);

    if (result.rowCount > 0) {
      let Query
      let groupedData = [];

      if (lineName.toUpperCase() === 'ALL') {
        Query = `
          SELECT
          timewhen AS range,
          lineid AS lineId,
          objname AS title,
          ROUND(stop / 60) AS value
          from getChangeOverTrends('${date}', 'Plant', '${plantName}', '${TimeAggregatorValue}', 'A', 'ALL', '${schemaName}');
        `
        const rawData = (await client.query(Query)).rows;

        const dateRange = UtilityMethods.getTimeSeriesRanges(TimeAggregatorValue, new Date(date));

        const modifiedData = [];
        if (rawData.length > 0) {
          rawData.sort((a, b) => a.title.toLowerCase().localeCompare(b.title.toLowerCase()));
          linesResult.rows.forEach(line => {
            dateRange.forEach(date => {
              let foundIndex = rawData.findIndex(p => p.title === line.linename && date.time === p.range);
              modifiedData.push({
                title: line.linename,
                value: foundIndex === -1 ? 0 : rawData[foundIndex].value,
                range: date.indicator
              })
            })
          })
          groupedData = modifiedData.reduce((result, { range, title, modelname, value }) => {
            // Check if the time already exists in the result object
            if (!result[title]) {
              // If not, initialize it with an empty data array
              result[title] = { title, data: [] }
            }

            if (!result[title].data[range]) {
              // Add the current entry to the data array for this specific time
              result[title].data.push({ range, value })
            }
            else {
              result[title].data[range] += value
            }


            return result
          }, {})
        }

      } else {
        Query = `
          SELECT
          timewhen AS time,
          lineid AS lineId,
          objname AS modelName,
          stop AS stop
          from getChangeOverTrends('${date}', 'Plant', '${plantName}', '${TimeAggregatorValue}', 'A', 'Model', '${schemaName}');
        `

        const rawData = (await client.query(Query)).rows;
        if (rawData.length > 0) {
          groupedData = rawData.reduce((result, { time, lineid, modelname, stop }) => {
            // Check if the time already exists in the result object
            if (!result[lineid]) {
              // If not, initialize it with an empty data array
              result[lineid] = { lineid, data: [] }
            }
            // Add the current entry to the data array for this specific time
            result[lineid].data.push({ time, modelname, stop })

            return result
          }, {})
        }

      }
      // Converting the result object values to an array
      const formattedData = Object.values(groupedData)

      res.status(200).send(formattedData)
    } else {
      res.status(200).send([])
    }
  } catch (error) {
    res.status(500).send(error.message)
  } finally {
    if (client) { client.release(true) }
  }
}

exports.getChangeOverPlannedVsActual = async (req, res) => {
  const { plantName } = req.params
  const { lineName } = req.params
  const { timeQuantum } = req.params
  const { totalreqd } = req.params

  const { schemaName, date } = req.query
  let client = null

  let TimeAggregatorValue = timeQuantum.toUpperCase()

  if (TimeAggregatorValue === 'DAY') { TimeAggregatorValue = 'Day' }
  else if (TimeAggregatorValue === 'WEEK') { TimeAggregatorValue = 'Week' }
  else if (TimeAggregatorValue === 'MONTH') { TimeAggregatorValue = 'Month' }
  else if (TimeAggregatorValue === 'YEAR') { TimeAggregatorValue = 'Year' }

  try {
    // Test the database exists
    const pgPoolsInstance = await PgPools.getInstance()
    client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const plantIdQuery = `
      SELECT plantid from ${schemaName}."Plants" where plantname='${plantName}'
    `
    const result = await client.query(plantIdQuery)

    let rawData
    let Query

    if (result.rowCount > 0) {
      if (lineName.toUpperCase() === 'ALL') {
        Query = `
          SELECT
          line,
          linename,
          model,
          ROUND(SUM(changeover) / 60) as ActualChangeOver,
          ROUND(SUM(changeovertime) / 60) as PlannedChangeOver,
          COUNT(*) AS EntryCount
          FROM
            getCOTypesAndActualCOTimesForTimeRangeAndLineAggregation(
              '${date}',
              'Plant',
              '${plantName}',
              '${TimeAggregatorValue}',
              'A',
              '${schemaName}'
            )
          GROUP BY line, linename, model
        `
        rawData = (await client.query(Query)).rows
      } else {
        Query = `
          SELECT
          line,
          linename,
          model,
          ROUND(SUM(changeover) / 60) as ActualChangeOver,
          ROUND(SUM(changeovertime) / 60) as PlannedChangeOver,
          COUNT(*) AS EntryCount
          FROM
            getCOTypesAndActualCOTimesForTimeRangeAndLineAggregation(
              '${date}',
              'Line',
              '${lineName}',
              '${TimeAggregatorValue}',
              'A',
              '${schemaName}'
            )
          GROUP BY line, linename, model
        `
        rawData = (await client.query(Query)).rows
      }

      const groupedData = rawData.reduce((result, { line, linename, model, actualchangeover, plannedchangeover, entrycount }) => {
        // Check if the time already exists in the result object
        if (!result[linename]) {
          // If not, initialize it with an empty data array
          result[linename] = { lineId: line, lineName: linename, data: { actual: [], plan: [] } }
        }
        // Add the current entry to the data array for this specific time
        result[linename].data.actual.push({
          modelName: model,
          value: Number(actualchangeover),
          count: Number(entrycount)
        })
        result[linename].data.plan.push({
          modelName: model,
          value: Number(plannedchangeover),
          count: Number(entrycount)
        })

        return result
      }, {})

      // Converting the result object values to an array
      // let formattedData

      if (totalreqd.toUpperCase() === 'TRUE') {
        // const totalData = []

        let actualCount, actualsum, planCount, plansum

        for (const [totalKey, totalValue] of Object.entries(groupedData)) {
          actualCount = totalValue.data.actual.reduce((acc, obj) => acc + parseFloat(obj.count), 0)
          actualsum = totalValue.data.actual.reduce((acc, obj) => acc + parseFloat(obj.value), 0)
          planCount = totalValue.data.plan.reduce((acc, obj) => acc + parseFloat(obj.count), 0)
          plansum = totalValue.data.plan.reduce((acc, obj) => acc + parseFloat(obj.value), 0)

          totalValue.data.actual.push({
            modelName: 'Total',
            value: actualsum,
            count: actualCount
          })

          totalValue.data.plan.push({
            modelName: 'Total',
            value: plansum,
            count: planCount
          })
        }
      }
      // totalData[totalValue.linename] = {
      //   line: totalValue.line,
      //   linename: totalKey,
      //   data: {
      //     actual: [{ Model: 'Total', Actual: actualsum, Count: actualCount }],
      //     plan: [{ Model: 'Total', Plan: plansum, Count: planCount }]
      //   }
      // }

      //   formattedData = Object.values(totalData)
      // } else {
      //   formattedData = Object.values(groupedData)
      // }

      res.status(200).send(Object.values(groupedData))
    }
  } catch (error) {
    res.status(500).send(error.message)
  } finally {
    if (client) { client.release(true) }
  }
}

exports.getChangeOverPlannedVsActualTrend = async (req, res) => {
  const { plantName } = req.params
  const { lineName } = req.params
  const { timeQuantum } = req.params
  const { totalreqd } = req.params

  const { schemaName, date } = req.query
  let client = null

  let TimeAggregatorValue = timeQuantum.toUpperCase()

  if (TimeAggregatorValue === 'DAY') { TimeAggregatorValue = 'Day' }
  else if (TimeAggregatorValue === 'WEEK') { TimeAggregatorValue = 'Week' }
  else if (TimeAggregatorValue === 'MONTH') { TimeAggregatorValue = 'Month' }
  else if (TimeAggregatorValue === 'YEAR') { TimeAggregatorValue = 'Year' }

  try {
    // Test the database exists
    const pgPoolsInstance = await PgPools.getInstance()
    client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const plantIdQuery = `
      SELECT plantid from ${schemaName}."Plants" where plantname='${plantName}'
    `
    const result = await client.query(plantIdQuery)

    let rawData
    let Query

    if (result.rowCount > 0) {
      if (lineName.toUpperCase() === 'ALL') {
        Query = `
          SELECT
          timewhen,
          'Total' AS line,
          'Total' AS linename,
          'Total' AS Model,
          ROUND(SUM(changeover) / 60) as ActualChangeOver,
          ROUND(SUM(changeovertime) / 60) as PlannedChangeOver,
          COUNT(*) AS EntryCount
          FROM
            getCOTypesAndCOTimesTrendForTimeRangeAndLineAggregation(
              '${date}',
              'Plant',
              '${plantName}',
              '${TimeAggregatorValue}',
              'A',
              '${schemaName}'
            )
          GROUP BY timewhen
          ORDER BY timewhen
        `
        rawData = (await client.query(Query)).rows
      } else {
        Query = `
          SELECT
          timewhen,
          line,
          linename,
          'Total' AS Model,
          ROUND(SUM(changeover) / 60) as ActualChangeOver,
          ROUND(SUM(changeovertime) / 60) as PlannedChangeOver,
          COUNT(*) AS EntryCount
          FROM
            getCOTypesAndCOTimesTrendForTimeRangeAndLineAggregation(
              '${date}',
              'Line',
              '${lineName}',
              '${TimeAggregatorValue}',
              'A',
              '${schemaName}'
            )
          GROUP BY timewhen, line, linename
          ORDER BY timewhen
        `
        rawData = (await client.query(Query)).rows
      }
      const dateRanges = UtilityMethods.getTimeSeriesRanges(TimeAggregatorValue, date);

      if (!Array.isArray(rawData) || rawData.length === 0) {
        console.log(' rawData is empty or not an array.')
      } else {
        const groupedData = rawData.reduce((result, { timewhen, line, linename, model, actualchangeover, plannedchangeover, entrycount }) => {
          if (!result[timewhen]) {
            result[timewhen] = { range: timewhen, data: {} }
          }

          let lineEntry = {
            lineId: line,
            lineName: linename,
            data: {
              actual: {},
              plan: {}
            }
          }

          // if (!lineEntry) {
          //   lineEntry = {
          //     line,
          //     linename,
          //     data: {
          //       actual: [],
          //       plan: []
          //     }
          //   }
          //   result[timewhen].data.push(lineEntry)
          // }

          result[timewhen].data = lineEntry

          lineEntry.data.actual = {
            modelName: model,
            value: Number(actualchangeover),
            count: Number(entrycount)
          }
          lineEntry.data.plan = {
            modelName: model,
            value: Number(plannedchangeover),
            count: Number(entrycount)
          }
          return result
        }, {})

        let preModifiedData = Object.values(groupedData);

        const modifiedData = [];
        dateRanges.forEach(date => {
          let object = { range: date.indicator, data: {} };
          let foundIndex = preModifiedData.findIndex(p => p.range === date.time);
          object.data = foundIndex === - 1 ? {} : preModifiedData[foundIndex].data;
          modifiedData.push(object);
        })

        res.status(200).send(modifiedData)
      }
      // Converting the result object values to an array
      // let formattedData

      // if (totalreqd.toUpperCase() === 'TRUE') {
      //   const totalData = []

      //   for (const [totalKey, totalValue] of Object.entries(groupedData)) {
      //     const actualCount = totalValue.data.actual.length
      //     const actualsum = totalValue.data.actual.reduce((acc, obj) => acc + parseFloat(obj.Actual), 0)
      //     const planCount = totalValue.data.plan.length
      //     const plansum = totalValue.data.plan.reduce((acc, obj) => acc + parseFloat(obj.Planned), 0)

      //     totalData[totalValue.linename] = {
      //       line: totalValue.line,
      //       linename: totalKey,
      //       data: {
      //         actual: [{ Model: 'Total', Actual: actualsum, Count: actualCount }],
      //         plan: [{ Model: 'Total', Plan: plansum, Count: planCount }]
      //       }
      //     }
      //   }
      //   formattedData = Object.values(totalData)
      // } else {
      //   formattedData = Object.values(groupedData)
      // }
    }
  } catch (error) {
    res.status(500).send(error.message)
  } finally {
    if (client) { client.release(true) }
  }
}

