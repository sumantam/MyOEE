const express = require('express')
const router = express.Router()
const accessController = require('../controllers/accesscontrollers/access.controller')

router.get('/lastDate', accessController.getLastDate);
router.get('/plants', accessController.getPlants)
router.get('/lines/:plantName', accessController.getLines)
router.get('/oeeParameters/:plantName/:lineName/:timeQuantum', accessController.getOeeParameters)
router.get('/oeeTrend/:plantName/:lineName/:timeQuantum', accessController.getOeeTrend)
router.get('/Trendoee/:plantName/:lineName/:timeQuantum', accessController.getTrendOee)
router.get('/changeover/:plantName/:lineName/:timeQuantum', accessController.getChangeOver)
router.get('/changeoverTrend/:plantName/:lineName/:timeQuantum', accessController.getChangeOverTrend)
router.get('/productionByLine/:plantName/:lineName/:timeQuantum/:totalreqd', accessController.getProductionByLine)
router.get('/changeoverPlannedvsActual/:plantName/:lineName/:timeQuantum/:totalreqd', accessController.getChangeOverPlannedVsActual)
router.get('/changeoverPlannedvsActualTrend/:plantName/:lineName/:timeQuantum/:totalreqd', accessController.getChangeOverPlannedVsActualTrend)
module.exports = router
