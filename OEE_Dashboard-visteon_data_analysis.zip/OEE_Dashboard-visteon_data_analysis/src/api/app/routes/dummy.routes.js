const dummy = require("../controllers/dummy-data.controller");
const router = require("express").Router();

router.get('/availability/:plant/:line/:timeQ', dummy.getAvailability);
router.get('/performance/:plant/:line/:timeQ', dummy.getPerformance);
router.get('/quality/:plant/:line/:timeQ', dummy.getQuality);
router.get('/oee/:plant/:line/:timeQ', dummy.getOee);
router.get('/oeeForPlantLevel/:plant/:line/:timeQ', dummy.getOeeForPlantLevel);
router.get('/bts/:plant/:line/:timeQ', dummy.getBts);
router.get('/ftt/:plant/:line/:timeQ', dummy.getFtt);
router.get('/scrap/:plant/:line/:timeQ', dummy.getScrap);
router.get('/oeeTrend/:plant/:line/:timeQ', dummy.getOeeTrend);
router.get('/oeeTrendForPlantLevel/:plant/:line/:timeQ', dummy.getOeeTrendPlantLevel);
router.get('/oeeParetoForPlantLevel/:plant/:line/:timeQ', dummy.getOeeParetoPlantLevel);
router.get('/oeeTrendBar/:plant/:line/:timeQ', dummy.getOeeTrendBar);
router.get('/oeeTrendBarPlantLevel/:plant/:line/:timeQ', dummy.getOeeTrendBarPlantLevel);
router.get('/downTimeParetoByProductionLine/:plant/:line/:timeQ', dummy.getDownTimeParetoByProductionLine);
router.get('/downTimeTrend/:plant/:line/:timeQ', dummy.getDontimeTrend);
router.get('/downTimeParetoByCause/:plant/:line/:timeQ', dummy.getDownTimeParetoByCause);
router.get('/productionByLine/:plant/:line/:timeQ/:totalRequired', dummy.getProductionByLine);
router.get('/productionByModel/:plant/:line/:timeQ/:totalRequired', dummy.getProductionByModel);

module.exports = router;
