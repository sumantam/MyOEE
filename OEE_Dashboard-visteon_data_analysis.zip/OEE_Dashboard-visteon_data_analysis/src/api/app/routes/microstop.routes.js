const microstopController = require('../controllers/microstopController');
const router = require("express").Router();

router.get("/byPlant/:plant/:timeQ", microstopController.getMicrostopDataByPlant);
router.get("/byLine/:line/:timeQ", microstopController.getMicrostopDataByLine);
router.get("/byMachine/:line/:timeQ/:machineId", microstopController.getMicrostopDataByMachine);
router.get("/trend/byPlant/:plant/:timeQ", microstopController.getMicrostopTrendByPlant);
router.get("/trend/byLine/:line/:timeQ", microstopController.getMicrostopTrendByLine);
router.get("/trend/byMachine/:line/:timeQ/:machineId", microstopController.getMicrostopTrendByMachine);
router.get("/actions/byLine/:line/:timeQ", microstopController.getMicrostopActionsByLine);
router.get("/actions/byMachine/:line/:timeQ/:machineName", microstopController.getMicrostopActionsByMachine);

module.exports = router;