const controller = require('../controllers/oeeController');
const router = require("express").Router();


router.get("/performanceOrQualityLoss/:plant/:timeQ/:type", controller.getPerformanceOrQualityLoss);
router.get("/performanceOrQualityLossTrend/:plant/:timeQ/:type", controller.getPerformanceOrQualityLossTrend);
router.get('/oeeTrend/:plant/:line/:timeQ', controller.getOeeTrend);
router.get('/oeeTrendBar/:line/:timeQ', controller.getOeeTrendBar);
router.get('/oeeTrendForPlant/:plant/:timeQ', controller.getOeeTrendForPlant);
router.get('/oeeParetoForPlant/:plant/:timeQ', controller.getOeeParetoForPlant);
router.get('/oeeTrendBarForPlant/:plant/:timeQ', controller.getOeeTrendBarForPlant);
router.get('/oeeParetoAndBar/:plant/:line/:timeQ', controller.getOeeParetoAndBar);
router.get('/downTimeTrend/:plant/:line/:timeQ', controller.getDownTimeTrend);
router.get('/downTimeParetoByCause/:plant/:line/:timeQ', controller.getDownTimeParetoByCause);
router.get('/productionByModel/:plant/:line/:timeQ/:totalRequired', controller.getProductionByModel);

module.exports = router;