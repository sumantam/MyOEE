const express = require('express')
const router = express.Router()
const databaseController = require('../controllers/dbcontrollers/db.controller')

router.post('/createDowntimeReasons', databaseController.createDowntimeReasons)

module.exports = router
