const router = require('express').Router()
const AuthMiddleware = require('../middlewares/auth')
const fdwRoutes = require('./fdw.routes.js')
const modelRoutes = require('./model.routes.js')
const plantRoutes = require('./plant.routes.js')
const lineRoutes = require('./line.routes.js')
const machinetypeRoutes = require('./machinetype.routes.js')
const machinesinpipelineRoutes = require('./machinesinpipeline.routes.js')
const lineshifttimeRoutes = require('./lineshifttime.routes.js')
const downtimeReasonRoutes = require('./downtimereasons.routes.js')
const productionRoutes = require('./production.routes.js')
const accessreaderRoutes = require('./accessreader.routes.js')

const usersRoutes = require('./user.routes.js')
const readerRoutes = require('./fileReader.routes.js')
const breakdownRoutes = require('./breakdown.routes.js')
const microstopRoutes = require('./microstop.routes.js')
const changeOverRoutes = require('./changeOver.routes.js')
const oeeRoutes = require('./oee.routes.js')
const cycleTimeRoutes = require('./cycleTime.routes.js');
// //const fileRoutes = require('./filehandle.routes.js')
// const userRoleRoutes = require('./userRoutes/index')
// //const testRoutes = require('./test.routes')
// const equipmentRoutes = require('./equipment.routes.js')
// const dashboardRoutes = require('./dashboard.routes.js')
// const smtdashboardRoutes = require('./smtdashboard.routes.js')
// const reportRoutes = require('./report.routes.js')
// const analyticsRoutes = require('./analytics.routes.js')
// const {getTilesImage} = require('../controllers/userControllers/map.controller')
// const dataSourceRoutes = require('./data.source.routes.js')
// const dataServiceRoutes = require('./data.service.routes.js')

// tiles api
// router.get("/tiles/:z(\\d+)/:x(\\d+)/:y(\\d+).:format([\\w.]+)", getTilesImage);

// Auth middleware
router.use(AuthMiddleware)

router.use('/db', fdwRoutes)
router.use('/rel', modelRoutes)
router.use('/rel', plantRoutes)
router.use('/rel', lineRoutes)
router.use('/rel', machinetypeRoutes)
router.use('/rel', machinesinpipelineRoutes)
router.use('/rel', lineshifttimeRoutes)
router.use('/rel', downtimeReasonRoutes)
router.use('/rel', productionRoutes)
router.use('/users', usersRoutes)
router.use('/files', readerRoutes)
router.use('/access', accessreaderRoutes)
// //router.use('/test', testRoutes)
// router.use('/usr', userRoleRoutes)
// //router.use('/file', fileRoutes)
// router.use('/system', equipmentRoutes)

// //routers for dashboards
// router.use('/dashboards', dashboardRoutes)
// router.use('/smtdashboards', smtdashboardRoutes)
// router.use('/analytics', analyticsRoutes)

// router.use('/report', reportRoutes)
// // router for data source
// router.use('/dataSource', dataSourceRoutes)
// // router for data source services
// router.use('/dataService', dataServiceRoutes)

router.use('/breakdown', breakdownRoutes)
router.use('/microstop', microstopRoutes)
router.use('/changeOver', changeOverRoutes)
router.use('/oee', oeeRoutes)
router.use('/cycleTime', cycleTimeRoutes)

module.exports = router
