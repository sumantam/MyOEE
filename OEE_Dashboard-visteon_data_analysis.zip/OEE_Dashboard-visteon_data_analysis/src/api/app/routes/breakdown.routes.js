const breakdownController = require('../controllers/breakdownController');
const router = require("express").Router();

router.get("/byPlant/:plant/:timeQ", breakdownController.getBreakdownDataByPlant);
router.get("/byLine/:line/:timeQ", breakdownController.getBreakdownDataByLine);
router.get("/byMachine/:line/:timeQ/:machineId", breakdownController.getBreakdownDataByMachine);
router.get("/trend/byPlant/:plant/:timeQ", breakdownController.getBreakdownTrendByPlant);
router.get("/trend/byLine/:line/:timeQ", breakdownController.getBreakdownTrendByLine);
router.get("/trend/byMachine/:line/:timeQ/:machineId", breakdownController.getBreakdownTrendByMachine);
router.get("/actions/byLine/:line/:timeQ", breakdownController.getBreakdownActionsByLine);
router.get("/actions/byMachine/:line/:timeQ/:machineName", breakdownController.getBreakdownActionsByMachine);

module.exports = router;