const controller = require('../controllers/changeOverController');
const router = require("express").Router();


router.get("/byPlant/:timeQ/:plant", controller.getChangeoverDataByPlant);
router.get("/byLine/:timeQ/:line", controller.getChangeoverDataByLine);
router.get("/trend/byLine/:timeQ/:line", controller.getChangeOverTrendByLine);
router.get("/trend/byPlant/:timeQ/:plant", controller.getChangeoverTrendByPlant);
router.get("/grid/byPlant/:timeQ/:plant", controller.getChangeoverGridDataByPlant);
router.get("/grid/trend/count/byLine/:timeQ/:line", controller.getChangeoverGridTrendDataCountByLine);
router.get("/grid/trend/total/byPlant/:timeQ/:plant", controller.getChangeoverGridTotalTrendDataByPlant);

module.exports = router;