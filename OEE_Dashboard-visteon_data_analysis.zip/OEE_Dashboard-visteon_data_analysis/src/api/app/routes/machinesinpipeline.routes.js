const express = require('express')
const router = express.Router()
const databaseController = require('../controllers/dbcontrollers/db.controller')

router.post('/createMachinesInPipeline', databaseController.createMachinesInPipeline)

module.exports = router