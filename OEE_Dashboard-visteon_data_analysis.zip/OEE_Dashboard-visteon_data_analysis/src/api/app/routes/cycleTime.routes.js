const cycleTimeController = require("../controllers/cycleTime.controller");
const router = require("express").Router();

router.get("/cycleTimeDataByPlant/:plant/:timeQ", cycleTimeController.getCycleTimeDataByPlant);
router.get("/realTimeDataAndStats", cycleTimeController.getRealTimeDataAndStats);
router.get("/stdCycleTime", cycleTimeController.getStdCycleTime);
router.put("/updateStdCycleTime", cycleTimeController.updateStdCycleTime);
router.post("/insertRealTimeData", cycleTimeController.insertRealTimeData);

module.exports = router;