const fileHandler = require('../controllers/file.controller.js')
const router = require('express').Router()

router.post('/readFile', fileHandler.readFile)
router.post('/readForbiaCsvAndPrepareJson', fileHandler.readForbiaCsvFileAndMakeJosn);
router.get('/getUniqueEventPairs', fileHandler.getUniqueEventsPair);
router.get('/getEventSpecificTimeSeriesData/:fromTime/:toTime', fileHandler.getEventSpecificTimeseriesData);
router.get('/downloadSampleFile', fileHandler.getSampleCsvFile);
module.exports = router
