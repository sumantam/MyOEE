class UtilityMethods {
  /**
   * This method filters Line_Shift_Plans using a given plan id and returns shift id of the first element of the filtered Line_Shift_Plans array
   * @param {string} planId Id of the plan
   * @param {object[]} lineShiftPlans Line_Shift_Plans array
   * @returns Shift Id of the first element of the filtered Line_Shift_Plans array
   */
  static getFilteredShiftId = (planId, lineShiftPlans) => {
    return lineShiftPlans.filter((item) => item.Plan_Id == planId)[0].Shift_Id;
  };

  static TIME_QUANTUM_MAPPER = {
    'day': 'Day',
    'week': 'Week',
    'month': 'Month',
    'year': 'Year'
  }

  /**
 * 
 * @param {Date} date 
 */
  static dateToDBString(date) {
    date = new Date(date);
    let month = (date.getMonth() < 9 ? '0' : '') + (date.getMonth() + 1);
    let day = (date.getDate() <= 9 ? '0' : '') + date.getDate();
    let year = '' + date.getFullYear();
    return `${year}-${month}-${day}`;
  }

  /**
   * 
   * @param {Date} date 
   */
  static formatDateForFilter(date) {
    date = new Date(date);
    let month = (date.getMonth() < 9 ? '0' : '') + (date.getMonth() + 1);
    let day = (date.getDate() <= 9 ? '0' : '') + date.getDate() - 1;
    let year = '' + date.getFullYear();

    return `${year}-${month}-${day}`;
  }

  static getDBDateRanges(lastDate, timeQuantum) {
    try {
      return timeQuantum === 'Day' ?
        [...Array(7)].map((value, index, arr) => {
          let d = new Date(lastDate);
          d.setDate(d.getDate() - index);
          return this.dateToDBString(d);
        })
        : timeQuantum === 'Week' ?
          [...Array(8)].map((value, index, arr) => {
            let d = new Date(lastDate);
            d.setDate(d.getDate() - index * 7);
            return this.dateToDBString(d);
          })
          : timeQuantum === 'Month' ?
            [...Array(12)].map((value, index, arr) => {
              let d = new Date(lastDate);
              d.setMonth(d.getMonth() - index);
              return this.dateToDBString(d);
            })
            : timeQuantum === 'Year' ?
              [...Array(5)].map((value, index, arr) => {
                let d = new Date(lastDate);
                d.setFullYear(d.getFullYear() - index);
                return this.dateToDBString(d);
              })
              : [];
    } catch (e) {
      console.log(e);
    }
  }

  /**
   * This method filters Line_Shift_Times using a given shift id and returns line id of the first element of the filtered Line_Shift_Times array
   * @param {string} shiftId Id of the shift
   * @param {object[]} lineShiftTimes Line_Shift_Times array
   * @returns Line Id of the first element of the filtered Line_Shift_Times array
   */
  static getFilteredLineId = (shiftId, lineShiftTimes) => {
    return lineShiftTimes.filter((item) => item["Id"] == shiftId)[0].Line;
  };

  static getFilteredLineIdShiftIdPairs = (lineIds, lineShiftTimes, lines) => {
    let lineIdShiftIdPairs = [];
    let filteredLineShiftTimes = lineShiftTimes.filter((item) =>
      lineIds.includes(item["Line"])
    );
    let setOfLineIds = [
      ...new Set(filteredLineShiftTimes.map((obj) => obj["Line"])),
    ];
    setOfLineIds.forEach((item) => {
      let shifts = filteredLineShiftTimes
        .filter((ls) => ls["Line"] == item)
        .map((p) => p["Id"]);
      lineIdShiftIdPairs.push({ Line: item, Shifts: shifts, LineName: lines.find(p => p["Id"] == item).Name });
    });
    return lineIdShiftIdPairs;
  };

  /**
   * This method filters Machines_In_Pipeline using a given line id and returns an array of the names of Machine_Types
   * @param {string} lineId Id of the line
   * @param {object[]} machinesInPipeLine Machines_In_Pipeline array
   * @returns an array of the names of Machine_Types
   */
  static getFilteredMachineNamesInPipeLine = (lineId, machinesInPipeLine) => {
    return machinesInPipeLine
      .filter((item) => item.Line == lineId)
      .map((item) => item["Name"]);
  };

  static getFilteredMachineInPipeLine = (lineId, machinesInPipeLine) => {
    return machinesInPipeLine
      .filter((item) => item.Line == lineId)
  };

  static getFilteredMachineNamesInPipeLines = (lineIds, machinesInPipeLine) => {
    return machinesInPipeLine
      .filter((item) => lineIds.includes(item.Line))
      .map((item) => item["Name"]);
  };

  static getFilteredMachinesInPipeLines = (lineIds, machinesInPipeLine) => {
    return machinesInPipeLine
      .filter((item) => lineIds.includes(item.Line))
  };

  static getFilteredDowntimeInstances = (machineIds, downtimeInstances) => {
    return downtimeInstances
      .filter((item) => machineIds.includes(item["Machines_In_Pipeline_Id"]))
      .map((item) => item["Downtime_Reason_Id"]);
  };

  static getFilteredDowntimeClassNames = (
    downtimeReasonIds,
    downtimeReasons
  ) => {
    return downtimeReasons
      .filter((item) => downtimeReasonIds.includes(item["Reason_Id"]))
      .map((item) => item["Class"]);
  };

  /**
   * This method filters Machine_Types using an array of names of Machine_Types and returns an array of Machine_Types
   * @param {string[]} machineTypeNames Array of the names of Machine_Types
   * @param {object[]} machineTypes Machine_Types array
   * @returns an array of Machine_Types
   */
  static getFilteredMachineTypes = (machineTypeNames, machineTypes) => {
    return machineTypes.filter((item) => machineTypeNames.includes(item.Name));
  };

  /**
   * This method returns maximum value of the Manufacturers_Cycle_Time from an given array of Machine_Types
   * @param {object[]} machineTypes Machine_Types array
   * @returns maximum value of the Manufacturers_Cycle_Time
   */
  static getIdealCycleTime = (machineTypes, threshHoldValue = 1) => {
    return Math.max(...machineTypes.map(x => x.Manufacturers_Cycle_Time)) + threshHoldValue;
  }

  static getIdealCycleTime2 = (machineInPipelines, threshHoldValue = 1) => {
    return Math.max(...machineInPipelines.map(x => x.Expected_Cycle_Time)) + threshHoldValue;
  }

  /**
   * This method filters Production_Summary using a line id and returns an array of Production_Summary
   * @param {string[]} shiftId shift ids
   * @param {object[]} productionSummaries Production_Summary array
   * @returns an array of Production_Summary
   */
  static getFilteredProductionSummaries = (shiftIds, productionSummaries) => {
    return productionSummaries.filter((item) =>
      shiftIds.includes(item.Shift_Id)
    );
  };

  /**
   * This method filters Production_Summary using a shift id and returns an array of Production_Summary
   * @param {string} shiftId shift id
   * @param {object[]} productionSummaries Production_Summary array
   * @returns an array of Production_Summary
   */
  static getFilteredProductionSummariesByShift = (
    shiftId,
    productionSummaries
  ) => {
    return productionSummaries.filter((item) => item.Shift_Id == shiftId)[0];
  };

  static getSumOfStopTimes = (data, field) => {
    let sum = 0;
    data.forEach((item) => (sum += item[field]));
    return sum;
  };

  /**
   * This method returns good count if isGoodCount is true. Otherwise it returns total count
   * @param {object[]} productionSummaries Production_Summary array
   * @param {boolean} isGoodCount Flag to indicate whether to determine total count or good count
   * @returns total count or good count
   */
  static getProductionCountBasedOnType = (productionSummaries, countType = "total") => {
    let runStatusArray = [];
    productionSummaries.forEach((ps) => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach((item) => {
          let productions = item["Productions"];
          if (productions != undefined && productions.length > 0) {
            productions.forEach((prod) => {
              let runs = prod["Runs"];
              if (runs != undefined && runs.length > 0) {
                runs.forEach((x) => runStatusArray.push(x["Status"]));
              }
            });
          }
        });
      }
    });
    return countType === "good"
      ? runStatusArray.filter((item) => item == "OK").length
      : countType === "bad" ? runStatusArray.filter((item) => item == "NG").length
        : runStatusArray.length;
  };

  static getProductionCountBasedOnExitMachineType = (productionSummaries, exitMachineId) => {
    let runStatusArray = [];
    productionSummaries.forEach((ps) => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach((item) => {
          let productions = item["Productions"];
          if (productions != undefined && productions.length > 0) {
            productions.forEach((prod) => {
              let runs = prod["Runs"];
              if (runs != undefined && runs.length > 0) {
                runs.forEach((x) => {
                  if (x["Exit_Machine_Id"] === exitMachineId)
                    runStatusArray.push(x["Status"])
                });
              }
            });
          }
        });
      }
    });
    return runStatusArray.filter((item) => item == "OK").length;
  }

  /**
   * This method filters Line_Shift_Times using a shift id and returns first entry of the filtered Line_Shift_Times
   * @param {}string shiftId Shift Id
   * @param {*} lineShiftTimes Line_Shift_Times array
   * @returns first entry of the filtered Line_Shift_Times
   */
  static getFilteredLineShiftTime = (shiftId, lineShiftTimes) => {
    return lineShiftTimes.filter((item) => item["Id"] == shiftId)[0];
  };

  static getFilteredLineShiftTimes = (shiftIds, lineShiftTimes) => {
    return lineShiftTimes.filter((item) => shiftIds.includes(item["Id"]));
  };

  /**
   * This method returns planned production time
   * @param {object} lineShiftTime Details of a shift
   * @param {number} shutdownDuration Duration of a shutdown
   * @returns planned production time
   */
  static getPlannedProductionTime = (lineShiftTime, shutdownDuration = 0) => {
    return (
      this.getTimeInSeconds(lineShiftTime["Start"], lineShiftTime["End"]) -
      shutdownDuration
    ); // 8 hrs
  };

  static getPlannedProductionTimeForLineShiftTimes = (lineShiftTimes, shutdownDuration = 0) => {
    let time = 0;
    lineShiftTimes.forEach(item => time += this.getTimeInSeconds(item["Start"], item["End"]) -
      shutdownDuration)
    return time;
  }

  /**
   * This method filters Machines_In_Pipeline using a given line id and returns an array of the ids of Machine_Types
   * @param {string} shiftId Id of the line
   * @param {object[]} machinesInPipeLine Machines_In_Pipeline array
   * @returns an array of the ids of Machine_Types
   */
  static getFilteredMachineIdsInPipeLine = (line, machinesInPipeLine) => {
    return machinesInPipeLine
      .filter((item) => line == item["Line"])
      .map((item) => item.Id);
  };
  static getFilteredMachineIdsInPipeLines = (lineIds, machinesInPipeLine) => {
    return machinesInPipeLine
      .filter((item) => lineIds.includes(item["Line"]))
      .map((item) => item.Id);
  };
  static getTotalBreakdownTime = (productionSummaries) => {
    let totalBreakdownTime = 0;
    productionSummaries.forEach((ps) => {
      if (ps != undefined) {
        let data = ps["Data"];
        if (data != undefined && data.length > 0)
          data.forEach((item) => {
            let breakdowns = item["Breakdowns"];
            if (breakdowns != null && breakdowns.length > 0) {
              breakdowns.forEach((bd) => {
                if (
                  (bd["From_Time"] != null ||
                    bd["From_Time"] != undefined ||
                    bd["From_Time"] != "") &&
                  (bd["To_Time"] != null ||
                    bd["To_Time"] != undefined ||
                    bd["To_Time"] != "")
                )
                  totalBreakdownTime += this.getTimeInSeconds(
                    bd["From_Time"],
                    bd["To_Time"]
                  );
              });
            }
          });
      }
    });
    return totalBreakdownTime;
  };
  /**
   * This method returns sum of all changeover instances time
   * @param {object[]} productionSummaries Production_Summary array
   * @returns sum of all changeover instances time
   */
  static getTotalChangeoverTime = (productionSummaries) => {
    let totalChangeoverTime = 0;
    productionSummaries.forEach((ps) => {
      if (ps != undefined) {
        let data = ps["Data"];
        if (data != undefined && data.length > 0)
          data.forEach((item) => {
            if ((item["Changeover_Time_Start"] != null || item["Changeover_Time_Start"] != undefined || item["Changeover_Time_Start"] != "") && (item["Changeover_Time_End"] != null || item["Changeover_Time_End"] != undefined || item["Changeover_Time_End"] != ""))
              totalChangeoverTime += this.getTimeInSeconds(
                item["Changeover_Time_Start"],
                item["Changeover_Time_End"]
              );
          });
      }
    });
    return totalChangeoverTime;
  };

  static getTotalBreakdownCount = (productionSummaries) => {
    let count = 0;
    productionSummaries.forEach(ps => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach(item => {
          let breakdowns = item["Breakdowns"];
          if (breakdowns != null && breakdowns.length > 0)
            breakdowns.forEach(bd => count += (bd["From_Time"] != null || bd["From_Time"] != undefined || bd["From_Time"] != "") && (bd["To_Time"] != null || bd["To_Time"] != undefined || bd["To_Time"] != "") ? 1 : 0);
        })
      }
    })
    return count;
  }

  static getTotalBreakdownTime = (productionSummaries) => {
    let totalBreakdownTime = 0;
    productionSummaries.forEach(ps => {
      if (ps != undefined) {
        let data = ps["Data"];
        if (data != undefined && data.length > 0)
          data.forEach(item => {
            let breakdowns = item["Breakdowns"];
            if (breakdowns != null && breakdowns.length > 0) {
              breakdowns.forEach(bd => {
                if ((bd["From_Time"] != null || bd["From_Time"] != undefined || bd["From_Time"] != "") && (bd["To_Time"] != null || bd["To_Time"] != undefined || bd["To_Time"] != ""))
                  totalBreakdownTime += this.getTimeInSeconds(bd["From_Time"], bd["To_Time"])
              });
            }
          });
      }
    })
    return totalBreakdownTime;
  }

  static getTotalQualityLossTime = (productionSummaries, idealCycleTime) => {
    let totalQualityLossTime = 0;
    let totalCount = 0;
    let totalOkCount = 0;
    productionSummaries.forEach(ps => {
      let totalCount = 0;
      let totalOkCount = 0;
      if (ps != undefined) {
        let data = ps["Data"];
        if (data != undefined && data.length > 0)
          data.forEach(item => {
            let productions = item["Productions"];
            if (productions != undefined && productions.length > 0) {
              productions.forEach(prod => {
                let runs = prod["Runs"];
                if (runs != undefined && runs.length > 0) {
                  runs.forEach(run => {
                    if (run != undefined && run != null) {
                      totalCount += 1;
                      totalOkCount += run["Status"] == "OK" ? 1 : 0;
                    }
                  })
                }
              })
            }
            // if ((item["Total"] != undefined || item["Total"] != null) && (item["Total_OK"] != undefined || item["Total_OK"] != null))
            //   totalQualityLossTime += (item["Total"] - item["Total_OK"]) * idealCycleTime;
          });
      }
    })
    totalQualityLossTime = (totalCount - totalOkCount) * idealCycleTime;
    return totalQualityLossTime;
  }

  static getTotalPerformanceLossTime = (productionSummaries, idealCycleTime) => {
    let totalPerformanceLossTime = 0;
    productionSummaries.forEach(ps => {
      let totalCount = 0;
      if (ps != undefined) {
        let data = ps["Data"];
        if (data != undefined && data.length > 0)
          data.forEach(item => {
            let productions = item["Productions"];
            if (productions != undefined && productions.length > 0) {
              productions.forEach(prod => {
                let runs = prod["Runs"];
                if (runs != undefined && runs.length > 0) {
                  runs.forEach(run => {
                    if (run != undefined && run != null)
                      totalCount += 1;
                  })
                }
              })
            }
            // if ((item["Total"] != undefined || item["Total"] != null) && (item["Total_OK"] != undefined || item["Total_OK"] != null))
            //   totalQualityLossTime += (item["Total"] - item["Total_OK"]) * idealCycleTime;
            totalPerformanceLossTime = totalCount * idealCycleTime;
          });
      }
    })
    return totalPerformanceLossTime;
  }

  static getTotalChangeoverCount = (productionSummaries) => {
    let count = 0;
    productionSummaries.forEach(ps => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach(item => count += (item["Changeover_Time_Start"] != null || item["Changeover_Time_Start"] != undefined || item["Changeover_Time_Start"] != "") && (item["Changeover_Time_end"] != null || item["Changeover_Time_end"] != undefined || item["Changeover_Time_end"] != "") ? 1 : 0);
      }
    })
    return count;
  }

  static getTotalMicrostopCount = (productionSummaries) => {
    let count = 0;
    productionSummaries.forEach(ps => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach(item => {
          let productions = item["Productions"];
          if (productions != undefined && productions.length > 0) {
            productions.forEach(prod => {
              let runs = prod["Runs"];
              if (runs != undefined && runs.length > 0) {
                runs.forEach(run => {
                  let microstopInstances = run["Microstop_Instances"];
                  if (microstopInstances != undefined && microstopInstances.length > 0)
                    microstopInstances.forEach(mi => count += (mi["From_Time"] != null || mi["From_Time"] != undefined || mi["From_Time"] != "") && (mi["To_Time"] != null || mi["To_Time"] != undefined || mi["To_Time"] != "") ? 1 : 0);
                })
              }
            })
          }
        })
      }
    })
    return count;
  }

  /**
   * This method returns sum of other downtime instances except changeover for a particular shift
   * @param {string[]} machineIdsInPipeline Array of the ids of Machine_Types
   * @param {*} downtimeInstances Downtime_Instances array
   * @returns sum of other downtime instances except changeover for a particular shift
   */
  static getSumOfOtherDowntimeInstances = (
    machineIdsInPipeline,
    downtimeInstances
  ) => {
    let filteredDowntimeInstances = downtimeInstances.filter(
      (item) =>
        item.Downtime_Reason_Id != "DTR_0001" &&
        machineIdsInPipeline.includes(item.Machines_In_Pipeline_Id)
    );
    let sum = 0;
    filteredDowntimeInstances.forEach(
      (item) => (sum += this.getTimeInSeconds(item.From_Time, item.To_Time))
    );
    return sum;
  };

  /**
   * This method returns sum of all microstop instances time
   * @param {object[]} productionSummaries Production_Summary Array
   * @returns sum of all microstop instances time
   */
  static getTotalMicrostopInstancesTime = (productionSummaries) => {
    var totalMicostopInstancesTime = 0;
    productionSummaries.forEach((ps) => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach((item) => {
          let productions = item["Productions"];
          if (productions != undefined && productions.length > 0) {
            productions.forEach((prod) => {
              let runs = prod["Runs"];
              if (runs != undefined && runs.length > 0) {
                runs.forEach((run) => {
                  let microstopInstances = run["Microstop_Instances"];
                  if (
                    microstopInstances != undefined &&
                    microstopInstances.length > 0
                  ) {
                    microstopInstances.forEach((mi) => {
                      if ((mi["From_Time"] != null || mi["From_Time"] != undefined || mi["From_Time"] != "") && (mi["To_Time"] != null || mi["To_Time"] != undefined || mi["To_Time"] != ""))
                        totalMicostopInstancesTime += this.getTimeInSeconds(
                          mi["From_Time"],
                          mi["To_Time"]
                        );
                    });
                  }
                });
              }
            });
          }
        });
      }
    });
    return totalMicostopInstancesTime;
  };

  /**
   * This method returns difference between two times in seconds
   * @param {string} fromTime From time
   * @param {string} toTime To time
   * @returns difference between two times in seconds
   */
  static getTimeInSeconds = (fromTime, toTime) => {
    return (
      (new Date(this.getTimeStamp(toTime)) -
        new Date(this.getTimeStamp(fromTime))) /
      1000
    );
  };

  static getTimeStamp = (dateString) => {
    if (dateString.indexOf(":") == -1) {
      let firstPart = dateString.substring(0, dateString.indexOf("T") + 1);
      let secondPart = dateString.substring(dateString.indexOf("T") + 1);
      let modifiedSecondPart = secondPart.match(/.{1,2}/g).join(":");
      return firstPart + modifiedSecondPart;
    } else return dateString;
  };

  /**
   * This method returns sum of all non production times
   * @param {number[]} nonProductionTimes Array of non production times
   * @returns sum of all non production times
   */
  static getTotalNonProductionTime = (nonProductionTimes) => {
    let sum = 0;
    nonProductionTimes.forEach((item) => (sum += item));
    return sum;
  };

  /**
   * This method returns rum time by subtracting non production time from planned production time
   * @param {number} plannedProductionTime Planned production time
   * @param {number} nonProductionTime Non production time
   * @returns Run time
   */
  static getRunTime = (plannedProductionTime, nonProductionTime) => {
    return plannedProductionTime - nonProductionTime;
  };

  /**
   * This method returns availability as quotient of run time and planned production time
   * @param {number} runTime Run time
   * @param {number} plannedProductionTime Planned production time
   * @returns Availability
   */
  static getAvailability = (runTime, plannedProductionTime) => {
    return runTime / plannedProductionTime;
  };

  static getScrap = (badCount, totalCount) => {
    return badCount / totalCount;
  };

  /**
   * This method returns performance dividing the product of ideal cycle time, total count by run time
   * @param {number} idealCycleTime Ideal cycle time
   * @param {number} totalCount Total count
   * @param {number} runTime Run time
   * @returns Performance
   */
  static getPerformance = (idealCycleTime, totalCount, runTime) => {
    return (idealCycleTime * totalCount) / runTime;
  };

  /**
   * This method returns quality as quotient of good count and total count
   * @param {number} goodCount Good count
   * @param {number} totalCount Total count
   * @returns Quality
   */
  static getQuality = (goodCount, totalCount) => {
    return goodCount / totalCount;
  };

  /**
   * This method returns OEE as a product of availability, performance and quality
   * @param {number} availability Availability
   * @param {number} performance Performance
   * @param {number} quality Quality
   * @returns OEE
   */
  static getOee = (availability, performance, quality) => {
    return availability * performance * quality;
  };

  static getOee2 = (goodCount, idealCycleTime, plannedProductionTime) => {
    return (goodCount * idealCycleTime) / plannedProductionTime;
  }

  static getProductOfGoodCountAndIdealCycleTime = (goodCount, idealCycleTime) => {
    return goodCount * idealCycleTime;
  }

  /**
   * This method returns adjusted adherence percentage
   * @param {number} target Target count
   * @param {number} actual Actual count
   * @returns Adjusted Adherence Percentage
   */
  static getAdjustedAdherence = (target, actual) => {
    return target > actual
      ? (actual / target) * 100
      : (2 - actual / target) * 100;
  };

  static getTotalAdjusted = (target, adjustedAdherence) => {
    return target * adjustedAdherence;
  }

  static getBts = (totalAdjusted, totalTarget) => {
    return totalAdjusted / totalTarget;
  }

  static getFtt = (totalcount, fttCount) => {
    return fttCount / totalcount * 100;
  }

  static getFilteredLineShiftPlans = (shiftIds, lineShiftPlans) => {
    return lineShiftPlans.filter((item) => shiftIds.includes(item.Shift_Id));
  };

  static getFilteredLineShiftPlan = (planId, lineShiftPlans) => {
    return lineShiftPlans.filter((item) => item.Plan_Id == planId)[0];
  };

  static getFilteredLineShiftPlans = (shiftIds, lineShiftPlans) => {
    return lineShiftPlans.filter((item) => shiftIds.includes(item["Shift_Id"]));
  };

  static getActualVsPlanDataByModelForShifts = (
    lineShiftPlans,
    productionSummaries
  ) => {
    let retVal = [];
    productionSummaries.forEach((ps) => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach((item) => {
          let filteredLineShiftPlan = this.getFilteredLineShiftPlan(
            item["Line_Shift_Plan_Id"],
            lineShiftPlans
          );
          let productions = item["Productions"];
          let actualProduced = 0;
          if (productions != undefined && productions.length > 0) {
            productions.forEach((prod) => {
              let runs = prod["Runs"];
              if (runs != undefined && runs.length > 0)
                runs.forEach(
                  (run) => (actualProduced += run["Status"] == "OK" ? 1 : 0)
                );
            });
            let existingObjectIndex = retVal.findIndex(p => p["model"] == filteredLineShiftPlan["Model_Name"]);
            if (existingObjectIndex == -1) {
              retVal.push({
                model: filteredLineShiftPlan["Model_Name"],
                plan: filteredLineShiftPlan["To_Produce"],
                actual: actualProduced,
              });
            }
            else {
              let updatedRetValObject = {
                model: retVal[existingObjectIndex]["model"],
                plan: retVal[existingObjectIndex]["plan"] + filteredLineShiftPlan["To_Produce"],
                actual: retVal[existingObjectIndex]["actual"] + actualProduced,
              }
              retVal[existingObjectIndex] = updatedRetValObject;
            }
          }
        });
      }
    });
    return retVal;
  };

  static getActualVsPlanDataByLine = (
    lineIdShiftIdPair,
    productionSummaries,
    lineShiftPlans
  ) => {
    let actualProduced = 0;
    let filteredLineShiftPlans = this.getFilteredLineShiftPlans(
      lineIdShiftIdPair["Shifts"],
      lineShiftPlans
    );
    let plan = 0;
    filteredLineShiftPlans.forEach((item) => (plan += item[["To_Produce"]]));

    productionSummaries.forEach((ps) => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach((item) => {
          let productions = item["Productions"];
          if (productions != undefined && productions.length > 0) {
            productions.forEach((prod) => {
              let runs = prod["Runs"];
              if (runs != undefined && runs.length > 0)
                runs.forEach(
                  (run) => (actualProduced += run["Status"] == "OK" ? 1 : 0)
                );
            });
          }
        });
      }
    });
    return {
      line: lineIdShiftIdPair["LineName"],
      plan: plan,
      actual: actualProduced,
    };
  };

  /**
   * This method returns sum of all microstop instances time
   * @param {object[]} productionSummaries Production_Summary Array
   * @returns sum of all microstop instances time
   */
  static getTotalMicrostopInstances = (productionSummaries) => {
    var totalMicostopInstances = [];
    productionSummaries.forEach((ps) => {
      let data = ps["Data"];
      if (data != undefined && data.length > 0) {
        data.forEach((item) => {
          let productions = item["Productions"];
          if (productions != undefined && productions.length > 0) {
            productions.forEach((prod) => {
              let runs = prod["Runs"];
              if (runs != undefined && runs.length > 0) {
                runs.forEach((run) => {
                  let microstopInstances = run["Microstop_Instances"];
                  if (
                    microstopInstances != undefined &&
                    microstopInstances.length > 0
                  ) {
                    microstopInstances.forEach((mi) => {
                      if (mi["Start"] != undefined && mi["End"] != undefined)
                        totalMicostopInstances.push({
                          machine: mi.Machine,
                          time: this.getTimeInSeconds(mi["Start"], mi["End"]),
                        });
                    });
                  }
                });
              }
            });
          }
        });
      }
    });

    return totalMicostopInstances;
  };

  /**
   * This method filters Production_Summary using a shift id and returns an array of Production_Summary
   * @param {string} shiftId shift id
   * @param {object[]} productionSummaries Production_Summary array
   * @returns an array of Production_Summary
   */
  static getFilteredBreakdownsByMachine = (
    shiftId,
    machineId,
    productionSummaries
  ) => {
    let brekdowns = [];
    const productionSummary = productionSummaries.filter(
      (item) => item.Shift_Id == shiftId
    )[0];
    if (
      productionSummary &&
      productionSummary.Data &&
      productionSummary.Data.length > 0
    ) {
      const allBrekdowns = productionSummary.Data.flatMap((i) => {
        if (i.Breakdowns.length > 0) return i.Breakdowns;
      });
      const filtered = allBrekdowns.filter(
        (i) => i && i.Machines_In_Pipeline_Id == machineId
      );
      brekdowns = brekdowns.concat(filtered);
    }
    return brekdowns;
  };

  /**
   * This method filters Production_Summary using a shift id and returns an array of Production_Summary
   * @param {string} shiftId shift id
   * @param {object[]} productionSummaries Production_Summary array
   * @returns an array of Production_Summary
   */
  static getFilteredMicrostopsByMachine = (
    shiftId,
    machineId,
    productionSummaries
  ) => {
    let microtops = [];
    const productionSummary = productionSummaries.filter(
      (item) => item.Shift_Id == shiftId
    )[0];
    if (
      productionSummary &&
      productionSummary.Data &&
      productionSummary.Data.length > 0
    ) {
      productionSummary.Data.forEach((d) => {
        d.Productions.forEach((p) => {
          p.Runs.forEach((r) => {
            microtops = microtops.concat(
              r.Microstop_Instances.filter(
                (i) => i && i.Machines_In_Pipeline_Id == machineId
              )
            );
          });
        });
      });
    }
    return microtops;
  };

  /**
   * This method filters Production_Summary using a shift id and returns an array of Production_Summary
   * @param {string} shiftId shift id
   * @param {object[]} productionSummaries Production_Summary array
   * @returns an array of Production_Summary
   */
  static getFilteredBreakdownsByLine = (shiftId, productionSummaries) => {
    let brekdowns = [];
    const productionSummary = productionSummaries.filter(
      (item) => item.Shift_Id == shiftId
    )[0];
    if (
      productionSummary &&
      productionSummary.Data &&
      productionSummary.Data.length > 0
    ) {
      const allBrekdowns = productionSummary.Data.flatMap((i) => {
        if (i.Breakdowns.length > 0) return i.Breakdowns;
      });
      const filtered = allBrekdowns.filter((i) => i);
      brekdowns = brekdowns.concat(filtered);
    }
    return brekdowns;
  };
  static getTotalQualityLossTime = (productionSummaries, idealCycleTime) => {
    let totalQualityLossTime = 0;
    productionSummaries.forEach((ps) => {
      let totalCount = 0;
      let totalOkCount = 0;
      if (ps != undefined) {
        let data = ps["Data"];
        if (data != undefined && data.length > 0)
          data.forEach((item) => {
            let productions = item["Productions"];
            if (productions != undefined && productions.length > 0) {
              productions.forEach((prod) => {
                let runs = prod["Runs"];
                if (runs != undefined && runs.length > 0) {
                  runs.forEach((run) => {
                    if (run != undefined && run != null) {
                      totalCount += 1;
                      totalOkCount += run["Status"] == "OK" ? 1 : 0;
                    }
                  });
                }
              });
            }
            // if ((item["Total"] != undefined || item["Total"] != null) && (item["Total_OK"] != undefined || item["Total_OK"] != null))
            //   totalQualityLossTime += (item["Total"] - item["Total_OK"]) * idealCycleTime;
            totalQualityLossTime = (totalCount - totalOkCount) * idealCycleTime;
          });
      }
    });
    return totalQualityLossTime;
  };

  static getTotalPerformanceLossTime = (
    productionSummaries,
    idealCycleTime
  ) => {
    try {
      let totalPerformanceLossTime = 0;
      productionSummaries.forEach((ps) => {
        let totalCount = 0;
        if (ps) {
          let data = ps["Data"];
          if (data && data.length > 0) {
            data.forEach((item) => {
              let productions = item["Productions"];
              if (productions != undefined && productions.length > 0) {
                productions.forEach((prod) => {
                  let runs = prod["Runs"];
                  if (runs != undefined && runs.length > 0) {
                    totalCount += runs.length;
                  }
                });
              }

              totalPerformanceLossTime = totalCount * idealCycleTime;
            });
          }
        }
      });
      return totalPerformanceLossTime;
    } catch (e) {
      return 0;
    }
  };

  /**
   * This method filters Production_Summary using a shift id and returns an array of Production_Summary
   * @param {string} shiftId shift id
   * @param {object[]} productionSummaries Production_Summary array
   * @returns an array of Production_Summary
   */
  static getFilteredMicrostopsByLine = (shiftId, productionSummaries) => {
    let microtops = [];
    const productionSummary = productionSummaries.filter(
      (item) => item.Shift_Id == shiftId
    )[0];
    if (
      productionSummary &&
      productionSummary.Data &&
      productionSummary.Data.length > 0
    ) {
      productionSummary.Data.forEach((d) => {
        d.Productions.forEach((p) => {
          p.Runs.forEach((r) => {
            microtops = microtops.concat(
              r.Microstop_Instances.filter((i) => i)
            );
          });
        });
      });
    }
    return microtops;
  };

  /**
   * This method filters Production_Summary using a shift id and returns an array of Production_Summary
   * @param {string} shiftId shift id
   * @param {object[]} productionSummaries Production_Summary array
   * @returns an array of Production_Summary
   */
  static getActions = (reasonId, downtimeReasons) => {
    return downtimeReasons
      .filter((i) => i.Reason_Id == reasonId)
      .flatMap((i) => i.Actions);
  };

  /**
   * 
   * @param {string} dateString 
   */
  static correctDateFormat = (dateString) => {
    let datePart = dateString.substring(0, dateString.indexOf('T'));
    let timePart = dateString.substring(dateString.indexOf('T'));
    let day = datePart.substring(0, 2);
    let month = '';
    let year = '';
    if (datePart.length === 8) {
      month = datePart.substring(2, 4);
      year = datePart.substring(4);
    }
    else {
      month = this.getMonthNumberFromShortName(datePart.substring(2, 5));
      year = datePart.substring(5);
    }
    return `${year}-${month}-${day}${timePart}`;
  }

  /**
   * 
   * @param {Date} dateString 
   */
  static createDateFormat = (dateString) => {
    let dateIsoStr = dateString.toISOString();
    return dateIsoStr.substring(0, dateIsoStr.indexOf('T'));
  }

  static createTimeQuantumRangeForTrend = (rangeIndicator, year = 2024, date = 26, month = 7) => {
    let dayInMs = 86400000;
    let dayInMsToBeSubtracted = rangeIndicator == "day" ? 7 * dayInMs : rangeIndicator == "week" ? 56 * dayInMs : rangeIndicator == "month" ? 360 * dayInMs : 1825 * dayInMs;
    let todayStartingFromSixAm = new Date(year, month, date, 11, 30, 0);
    let endDate = new Date(todayStartingFromSixAm.getTime() - dayInMs);
    let startDate = new Date(endDate.getTime() - dayInMsToBeSubtracted);
    return { "start": startDate, "end": endDate };
  }

  static createTimeQuantumRange = (rangeIndicator, year = 2024, date = 26, month = 7) => {
    let dayInMs = 86400000;
    let dayInMsToBeSubtracted = rangeIndicator == "day" ? dayInMs : rangeIndicator == "week" ? 7 * dayInMs : rangeIndicator == "month" ? 28 * dayInMs : 365 * dayInMs;
    let todayStartingFromSixAm = new Date(year, month, date, 11, 30, 0);
    let endDate = new Date(todayStartingFromSixAm.getTime() - dayInMs);
    let startDate = new Date(endDate.getTime() - dayInMsToBeSubtracted);
    let start = startDate.toISOString();
    let end = endDate.toISOString();
    let startStr = start.substring(0, start.indexOf('.'));
    let endStr = end.substring(0, end.indexOf('.'));
    return { "start": startStr, "end": endStr };
  }

  static getTimeSeriesRanges = (timeQ, lastDate) => {
    // let DAY_MS = 86400000;
    let timeRangesArray = [];

    if (timeQ === "Day") {
      let days = [...Array(7)].map((value, index, arr) => {
        let d = new Date(lastDate);
        d.setDate(d.getDate() - index);
        return this.dateToDBString(d);
      });
      days.reverse();
      for (let i = 0; i < days.length; i++) {
        timeRangesArray.push({
          "time": this.dateToDBString(days[i]),
          "indicator": this.dateToDBString(days[i])
        });
      }

      // for (let i = 1; i <= 7; i++) {
      //   let start = this.dateToDBString(new Date(lastDay.getTime() - (i * DAY_MS)));
      //   timeRangesArray.push({
      //     "time": start,
      //     "indicator": start
      //   });
      // }
    }

    else if (timeQ === "Week") {
      let weeks = [...Array(9)].map((value, index, arr) => {
        let d = new Date(lastDate);
        d.setDate(d.getDate() - index * 7);
        return this.dateToDBString(d);
      })
      weeks.reverse();
      for (let i = 1; i < weeks.length; i++) {
        timeRangesArray.push({
          "time": `${this.dateToDBString(weeks[i - 1])}--${this.dateToDBString(weeks[i])}`,
          "indicator": `Week ${i}`
        });
      }
      // let end = new Date(startDay.getTime());
      // let end2 = end;
      // for (let i = 1; i <= 8; i++) {
      //   let start = new Date(end.getTime() - (i * DAY_MS * 7));
      //   timeRangesArray.push({
      //     "time": `${this.dateToDBString(start)}--${this.dateToDBString(end2)}`,
      //     "indicator": `Week ${i}`
      //   });
      //   end2 = start;
      // }
    }

    else if (timeQ === "Month") {
      let months = [...Array(13)].map((value, index, arr) => {
        let d = new Date(lastDate);
        d.setMonth(d.getMonth() - index);
        return this.dateToDBString(d);
      });
      months.reverse();
      for (let i = 1; i < months.length; i++) {
        timeRangesArray.push({
          "time": `${this.dateToDBString(months[i - 1])}--${this.dateToDBString(months[i])}`,
          "indicator": `Month ${i}`
        });
      }

      // let end = new Date(startDay.getTime());
      // let end2 = end;
      // for (let i = 1; i <= 12; i++) {
      //   let start = new Date(end.getTime() - (i * DAY_MS * 30));
      //   timeRangesArray.push({
      //     "time": `${this.dateToDBString(start)}--${this.dateToDBString(end2)}`,
      //     "indicator": `Month ${i}`
      //   });
      //   end2 = start;
      // }
    }

    else {
      let years = [...Array(6)].map((value, index, arr) => {
        let d = new Date(lastDate);
        d.setFullYear(d.getFullYear() - index);
        return this.dateToDBString(d);
      });
      years.reverse();
      for (let i = 1; i < years.length; i++) {
        timeRangesArray.push({
          "time": `${this.dateToDBString(years[i - 1])}--${this.dateToDBString(years[i])}`,
          "indicator": `Year ${i}`
        });
      }
      // let end = new Date(startDay.getTime());
      // let end2 = end;
      // for (let i = 1; i <= 5; i++) {
      //   let start = new Date(end.getTime() - (i * DAY_MS * 365));
      //   timeRangesArray.push({
      //     "time": `${this.dateToDBString(start)}--${this.dateToDBString(end2)}`,
      //     "indicator": `Year ${i}`
      //   });
      //   end2 = start;
      // }
    }
    return timeRangesArray;
  }

  static getTimeSeriesRangesForPareto = (timeQ, lastDate) => {
    // let DAY_MS = 86400000;
    let timeRangesArray = [];

    if (timeQ === "Day") {
      let days = [...Array(1)].map((value, index, arr) => {
        let d = new Date(lastDate);
        d.setDate(d.getDate() - index - 1);
        return this.dateToDBString(d);
      });
      days.reverse();
      for (let i = 0; i < days.length; i++) {
        timeRangesArray.push({
          "time": this.dateToDBString(days[i]),
          "indicator": this.dateToDBString(days[i])
        });
      }

      // for (let i = 1; i <= 7; i++) {
      //   let start = this.dateToDBString(new Date(lastDay.getTime() - (i * DAY_MS)));
      //   timeRangesArray.push({
      //     "time": start,
      //     "indicator": start
      //   });
      // }
    }

    else if (timeQ === "Week") {
      let weeks = [...Array(2)].map((value, index, arr) => {
        let d = new Date(lastDate);
        d.setDate(d.getDate() - index * 7);
        return this.dateToDBString(d);
      })
      weeks.reverse();
      for (let i = 1; i < weeks.length; i++) {
        timeRangesArray.push({
          "time": `${this.dateToDBString(weeks[i - 1])}--${this.dateToDBString(weeks[i])}`,
          "indicator": `Week ${i}`
        });
      }
      // let end = new Date(startDay.getTime());
      // let end2 = end;
      // for (let i = 1; i <= 8; i++) {
      //   let start = new Date(end.getTime() - (i * DAY_MS * 7));
      //   timeRangesArray.push({
      //     "time": `${this.dateToDBString(start)}--${this.dateToDBString(end2)}`,
      //     "indicator": `Week ${i}`
      //   });
      //   end2 = start;
      // }
    }

    else if (timeQ === "Month") {
      let months = [...Array(2)].map((value, index, arr) => {
        let d = new Date(lastDate);
        d.setMonth(d.getMonth() - index);
        return this.dateToDBString(d);
      });
      months.reverse();
      for (let i = 1; i < months.length; i++) {
        timeRangesArray.push({
          "time": `${this.dateToDBString(months[i - 1])}--${this.dateToDBString(months[i])}`,
          "indicator": `Month ${i}`
        });
      }

      // let end = new Date(startDay.getTime());
      // let end2 = end;
      // for (let i = 1; i <= 12; i++) {
      //   let start = new Date(end.getTime() - (i * DAY_MS * 30));
      //   timeRangesArray.push({
      //     "time": `${this.dateToDBString(start)}--${this.dateToDBString(end2)}`,
      //     "indicator": `Month ${i}`
      //   });
      //   end2 = start;
      // }
    }

    else {
      let years = [...Array(2)].map((value, index, arr) => {
        let d = new Date(lastDate);
        d.setFullYear(d.getFullYear() - index);
        return this.dateToDBString(d);
      });
      years.reverse();
      for (let i = 1; i < years.length; i++) {
        timeRangesArray.push({
          "time": `${this.dateToDBString(years[i - 1])}--${this.dateToDBString(years[i])}`,
          "indicator": `Year ${i}`
        });
      }
      // let end = new Date(startDay.getTime());
      // let end2 = end;
      // for (let i = 1; i <= 5; i++) {
      //   let start = new Date(end.getTime() - (i * DAY_MS * 365));
      //   timeRangesArray.push({
      //     "time": `${this.dateToDBString(start)}--${this.dateToDBString(end2)}`,
      //     "indicator": `Year ${i}`
      //   });
      //   end2 = start;
      // }
    }
    return timeRangesArray;
  }

  static getStatus = (actionTime) => {
    let status = '';
    if (actionTime !== null) {
      const actualTime = new Date(actionTime);
      const incidentTime = new Date(new Date(actualTime).getTime() - 4 * 86400000);
      const targetTime = new Date(new Date(incidentTime).getTime() + 7 * 86400000);
      const actualTimeStr = actualTime !== "" ? actualTime.toISOString().substring(0, actualTime.toISOString().indexOf('T')) : "";
      status = actualTimeStr === "" ? "Y" :
        targetTime.getTime() >= actualTime.getTime() ? "G" : "R";
    }
    return status;
  }

  static getMarkerMapper = (actionTime, timeQ, lastDate) => {
    let markerMapper = '';
    if (actionTime !== null) {
      actionTime = new Date(actionTime);
      if (timeQ === 'Day')
        markerMapper = actionTime.toISOString().substring(0, actionTime.toISOString().indexOf('T'));
      else {
        let timeRange = UtilityMethods.createTimeQuantumRangeForTrend(timeQ, lastDate.getFullYear(), lastDate.getDate(), lastDate.getMonth());
        let timeRanges = UtilityMethods.getTimeSeriesRanges(timeQ, new Date(timeRange["end"]))
        for (let i = 0; i < timeRanges.length; i++) {
          let start = new Date(timeRanges[i].time.substring(0, 10)).getTime();
          let end = new Date(timeRanges[i].time.substring(12)).getTime();
          if (actionTime.getTime() > start && actionTime.getTime() <= end) {
            markerMapper = timeRanges[i]["indicator"];
            break;
          }
        }
      }
    }
    return markerMapper;
  }

  static getMonthWiseDate = (month) =>
  ({
    0: 31,
    1: 28,
    2: 31,
    3: 30,
    4: 31,
    5: 30,
    6: 31,
    7: 31,
    8: 30,
    9: 31,
    10: 30,
    11: 31
  }[month]);

  static getMonthNumberFromShortName = (month) =>
  ({
    "JAN": "01",
    "FEB": "02",
    "MAR": "03",
    "APR": "04",
    "MAY": "05",
    "JUN": "06",
    "JUL": "07",
    "AUG": "08",
    "SEP": "09",
    "OCT": "10",
    "NOV": "11",
    "DEC": "12",
  }[month])

  static checkLeapYear = (year) => {
    return (0 == year % 4) && (0 != year % 100) || (0 == year % 400)
  }
}

module.exports = {
  UtilityMethods,
};
