const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

// Function to execute the SQL file
const executeClientSqlFile = async (schemaName) => {
  console.log('################## Called stored proc ####################')
  let pgPoolsInstance = null
  try {
    pgPoolsInstance = await PgPools.getInstance()
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('Model', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('Plants', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('Lines', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('MachineTypes', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('MachinesInPipeline', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('LineShiftTimes', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('LineShiftPlans', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('DowntimeReason', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('Shifts', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('ChangeOverTypeTimes', schemaName)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('StdCycleTimes', schemaName)
    console.log('SQL file executed successfully:')
    return true
  } catch (error) {
    console.error('Error executing SQL file:', error)
    return false
  }
}

// Function to execute the SQL file
const executeClientUtilityFile = async (schemaName) => {
  console.log('################## Called Utility proc ####################')
  let pgPoolsInstance = null
  try {
    pgPoolsInstance = await PgPools.getInstance()
    await pgPoolsInstance.getPool(dbConfig.DB).createProc('main', schemaName)
    console.log('Utility proc executed successfully:')
    return true
  } catch (error) {
    console.error('Error executing SQL file:', error)
    return false
  }
}

// Usage example
module.exports = {
  executeClientSqlFile,
  executeClientUtilityFile
}
