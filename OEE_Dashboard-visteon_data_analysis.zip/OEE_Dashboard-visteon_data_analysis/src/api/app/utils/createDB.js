const dbConfig = require('../config/db.config')
const { PgPools } = require('./pgPool')

const createDatabase = async () => {
  let client = null
  let pgPoolsInstance = null
  try {
    console.log('Entering createDatabase ')
    pgPoolsInstance = await PgPools.getInstance()

    console.log(' Before creating the client ....')
    client = await pgPoolsInstance.getPool().getClient()
    console.log('Before select ')

    const result = await client.query("SELECT 1 FROM pg_database where datname = '" + dbConfig.DB + "'")
    console.log('After select')

    if (result.rowCount === 0) {
      console.log('Needs to create a new database ')
      await client.query('CREATE DATABASE ' + dbConfig.DB)
      console.log('Successful in creating a new database ')
    } else {
      console.log('Database exists ', dbConfig.DB)
    }

    console.log(' It has reached upto here ........')
    await pgPoolsInstance.addPool(dbConfig.DB)
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('User')
    await pgPoolsInstance.getPool(dbConfig.DB).createTable('Relation')

    return true
  } catch (error) {
    console.error(error.stack + 'createDataBase')
    return false
  } finally {
    await client.release(true)
  }
}

module.exports = {
  createDatabase
}
