const UtilityMethods = require("../utility.methods").UtilityMethods;
const dummyData2 = [];

const getLossByPlantMethod = async (plantId, timeQ, type) => {
  var filteredLines = dummyData2.Lines.filter((p) => p.Plant == plantId);
  const lst = [];
  try {
    filteredLines.forEach((line) => {
      const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
        (d) =>
          line["Id"] === d.Line &&
          d.Start != undefined &&
          d.End != undefined &&
          (new Date(timeQ["start"]) <= new Date(UtilityMethods.getTimeStamp(d.Start)))
          && (new Date(UtilityMethods.getTimeStamp(d.Start)) < new Date(timeQ["end"]))
      );
      let filteredProductionSummaries =
        UtilityMethods.getFilteredProductionSummaries(
          allShiftsForDay.map((p) => p["Id"]),
          dummyData2["Production_Summaries"]
        );
      if (filteredProductionSummaries.length > 0) {
        let filteredLineShiftTimes = UtilityMethods.getFilteredLineShiftTimes(
          allShiftsForDay.map(p => p.Id),
          dummyData2["Line_Shift_Times"]
        );
        let filteredMachinesInPipeLine =
          UtilityMethods.getFilteredMachinesInPipeLines(
            filteredLineShiftTimes.map(p => p["Line"]),
            dummyData2["Machines_In_Pipeline"]
          );
        let idealCycleTime =
          UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

        let totalcount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries);
        let totalGoodCount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries, "good");
        let qualityStopTime = (totalcount - totalGoodCount) * idealCycleTime;

        let plannedProductionTime = allShiftsForDay.reduce(
          (acc, item) =>
            (acc += UtilityMethods.getTimeInSeconds(item.Start, item.End)),
          0
        );

        let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
          filteredProductionSummaries
        );
        let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

        let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime([
          totalChangeoverTime, totalBreakdownTime
        ]);

        let performanceLossTime = plannedProductionTime - totalNonProductionTime - (totalcount * idealCycleTime);

        switch (type) {
          case "Quality":
            lst.push({
              id: line.Id,
              name: line.Name,
              stop: qualityStopTime / 60,
              percentage: 0,
            });
            break;
          case "Performance":
            lst.push({
              id: line.Id,
              name: line.Name,
              stop:
                performanceLossTime / 60,
              percentage: 0,
            });
            break;
        }
      }
    });
  } catch (e) {
    console.log(e);
  }
  return lst;
};

const getLossByPlantMethod2 = async (plantId, timeQ, type) => {
  const trendData = [];
  const timeSeries = getTimeSeries(timeQ);
  var filteredLines = dummyData2.Lines.filter((p) => p.Plant == plantId);
  try {
    filteredLines.forEach((line) => {
      const lst = [];
      for (let j = 0; j < timeSeries.length; j++) {
        const allShiftsForDay = dummyData2.Line_Shift_Times.filter(
          (d) =>
            line.Id == d.Line &&
            d.Start != undefined &&
            d.End != undefined &&
            new Date(UtilityMethods.getTimeStamp(timeSeries[j]["start"])) <=
            new Date(UtilityMethods.getTimeStamp(d.Start)) &&
            new Date(UtilityMethods.getTimeStamp(d.Start)) <
            new Date(UtilityMethods.getTimeStamp(timeSeries[j]["end"]))
        );

        let filteredProductionSummaries =
          UtilityMethods.getFilteredProductionSummaries(
            allShiftsForDay.map((p) => p["Id"]),
            dummyData2["Production_Summaries"]
          );
        if (filteredProductionSummaries.length > 0) {

          let filteredLineShiftTimes = UtilityMethods.getFilteredLineShiftTimes(
            allShiftsForDay.map(p => p.Id),
            dummyData2["Line_Shift_Times"]
          );
          let filteredMachinesInPipeLine =
            UtilityMethods.getFilteredMachinesInPipeLines(
              filteredLineShiftTimes.map(p => p["Line"]),
              dummyData2["Machines_In_Pipeline"]
            );

          let idealCycleTime =
            UtilityMethods.getIdealCycleTime2(filteredMachinesInPipeLine);

          let totalcount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries);
          let totalGoodCount = UtilityMethods.getProductionCountBasedOnType(filteredProductionSummaries, "good");
          let qualityStopTime = (totalcount - totalGoodCount) * idealCycleTime;

          let plannedProductionTime = allShiftsForDay.reduce(
            (acc, item) =>
              (acc += UtilityMethods.getTimeInSeconds(item.Start, item.End)),
            0
          );
          let totalChangeoverTime = UtilityMethods.getTotalChangeoverTime(
            filteredProductionSummaries
          );
          let totalBreakdownTime = UtilityMethods.getTotalBreakdownTime(filteredProductionSummaries);

          let totalNonProductionTime = UtilityMethods.getTotalNonProductionTime([
            totalChangeoverTime, totalBreakdownTime
          ]);
          let performanceLossTime = plannedProductionTime - totalNonProductionTime - (totalcount * idealCycleTime);
          switch (type) {
            case "Quality":
              lst.push({
                id: timeSeries[j].text,
                name: timeSeries[j].text,
                stop: qualityStopTime / 60,
                percentage: 0,
              });
              break;
            case "Performance":
              lst.push({
                id: timeSeries[j].text,
                name: timeSeries[j].text,
                stop:
                  performanceLossTime / 60,
                percentage: 0,
              });
              break;
          }
        }
        else {
          switch (type) {
            case "Quality":
              lst.push({
                id: timeSeries[j].text,
                name: timeSeries[j].text,
                stop: 0,
                percentage: 0,
              });
              break;
            case "Performance":
              lst.push({
                id: timeSeries[j].text,
                name: timeSeries[j].text,
                stop: 0,
                percentage: 0,
              });
              break;
          }
        }
      }
      trendData.push({ reference: line.Name, data: lst })
    });
  }
  catch (e) {
    return [];
  }
  return trendData;
};

const getLossTrendByPlantMethod = async (plantId, timeQ, type) => {
  const timeSeries = getTimeSeries(timeQ);
  const trendData = [];
  for (let i = 0; i < timeSeries.length; i++) {
    const data = await getLossByPlantMethod(plantId, timeSeries[i], type);
    trendData.push({ reference: timeSeries[i].text, data: data });
  }
  return trendData;
};
const getTimeSeries = (tq) =>
({
  day: [
    {
      start: "2024-08-18T06:00:00",
      end: "2024-08-19T06:00:00",
      text: "2024-08-18",
    },
    {
      start: "2024-08-19T06:00:00",
      end: "2024-08-20T06:00:00",
      text: "2024-08-19",
    },
    {
      start: "2024-08-20T06:00:00",
      end: "2024-08-21T06:00:00",
      text: "2024-08-20",
    },
    {
      start: "2024-08-21T06:00:00",
      end: "2024-08-22T06:00:00",
      text: "2024-08-21",
    },
    {
      start: "2024-08-22T06:00:00",
      end: "2024-08-23T06:00:00",
      text: "2024-08-22",
    },
    {
      start: "2024-08-23T06:00:00",
      end: "2024-08-24T06:00:00",
      text: "2024-08-23",
    },
    {
      start: "2024-08-24T06:00:00",
      end: "2024-08-25T06:00:00",
      text: "2024-08-24",
    },
  ],
  week: [
    { start: "2024-06-31T06:00:00", end: "2024-07-06T06:00:00", text: "Week 1" },
    { start: "2024-07-07T06:00:00", end: "2024-07-13T06:00:00", text: "Week 2" },
    { start: "2024-07-14T06:00:00", end: "2024-07-20T06:00:00", text: "Week 3" },
    { start: "2024-07-21T06:00:00", end: "2024-07-27T06:00:00", text: "Week 4" },
    { start: "2024-07-28T06:00:00", end: "2024-08-04T06:00:00", text: "Week 5" },
    { start: "2024-08-04T06:00:00", end: "2024-08-10T06:00:00", text: "Week 6" },
    { start: "2024-08-11T06:00:00", end: "2024-08-17T06:00:00", text: "Week 7" },
    { start: "2024-08-18T06:00:00", end: "2024-08-25T06:00:00", text: "Week 8" }
  ],
  month: [{ start: "2023-09-01T06:00:00", end: "2023-09-30T06:00:00", text: "Month 1" },
  { start: "2023-10-01T06:00:00", end: "2023-10-30T06:00:00", text: "Month 2" },
  { start: "2023-11-01T06:00:00", end: "2023-11-30T06:00:00", text: "Month 3" },
  { start: "2023-12-01T06:00:00", end: "2023-12-30T06:00:00", text: "Month 4" },
  { start: "2024-01-01T06:00:00", end: "2024-01-30T06:00:00", text: "Month 5" },
  { start: "2024-02-01T06:00:00", end: "2024-02-28T06:00:00", text: "Month 6" },
  { start: "2024-03-01T06:00:00", end: "2024-03-30T06:00:00", text: "Month 7" },
  { start: "2024-04-01T06:00:00", end: "2024-04-30T06:00:00", text: "Month 8" },
  { start: "2024-05-01T06:00:00", end: "2024-05-30T06:00:00", text: "Month 9" },
  { start: "2024-06-01T06:00:00", end: "2024-06-30T06:00:00", text: "Month 10" },
  { start: "2024-07-01T06:00:00", end: "2024-07-30T06:00:00", text: "Month 11" },
  { start: "2024-08-01T06:00:00", end: "2024-08-25T06:00:00", text: "Month 12" }
  ],
  year: [{ start: "2020-01-01T06:00:00", end: "2020-12-31T06:00:00", text: "Year 1" },
  { start: "2021-01-01T06:00:00", end: "2021-12-31T06:00:00", text: "Year 2" },
  { start: "2022-01-01T06:00:00", end: "2022-12-31T06:00:00", text: "Year 3" },
  { start: "2023-01-01T06:00:00", end: "2023-12-31T06:00:00", text: "Year 4" },
  { start: "2024-01-01T06:00:00", end: "2024-12-31T06:00:00", text: "Year 5" }]
}[tq]);
exports.getLossByPlant = getLossByPlantMethod;
exports.getLossTrendByPlant = getLossTrendByPlantMethod;
exports.getLossByPlantMethod2 = getLossByPlantMethod2;
