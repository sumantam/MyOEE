const commonMethods = require("./common-methods");
const models = require("../../models/stopage");
const UtilityMethods = require("../utility.methods").UtilityMethods;
const dummyData = [];

const modelTypes = [
  { type: "Type A", models: ["L1-SWITCH-BANK_0", "L2-SWITCH-BANK_0"] },
  { type: "Type B", models: ["TATA-MAIN_0", "TATA-MAIN_1"] },
  { type: "Type C", models: ["L2-MAIN_0", "L2-MAIN_1", "L2-MAIN_2"] },
];

const getChangeoverDataByPlantMethod = async (plantId, timeQ) => {
  let lines = dummyData["Lines"].filter((d) => d.Plant == plantId);
  const totalStops = [];
  for (let i = 0; i < lines.length; i++) {
    const delaysByline = await getChangeoverDataByLineMethod(
      lines[i].Id,
      timeQ
    );
    const totalDelay = delaysByline.reduce((acc, curr) => acc + curr.stop, 0);
    totalStops.push(
      new models.stopageByLine(lines[i].Id, lines[i].Name, totalDelay)
    );
  }
  return totalStops;
};

const getChangeoverDataByPlantMethod2 = async (plantId, timeQ) => {
  const trendData = [];
  const timeSeries = getTimeSeries(timeQ);
  let lines = dummyData["Lines"].filter((d) => d.Plant == plantId);
  for (let i = 0; i < lines.length; i++) {
    try {
      const totalStops = [];
      for (let j = 0; j < timeSeries.length; j++) {
        const delaysByline = await getChangeoverDataByLineMethod(
          lines[i].Id,
          timeSeries[j]
        );
        const totalDelay = delaysByline.reduce(
          (acc, curr) => acc + curr.stop,
          0
        );
        totalStops.push(
          new models.stopageByLine(
            timeSeries[j].text,
            timeSeries[j].text,
            totalDelay
          )
        );
      }
      trendData.push({ reference: lines[i].Name, data: totalStops });
    } catch (e) {
      return [];
    }
  }
  return trendData;
};

const getChangeoverDataByLineMethod = async (lineId, timeQ) => {
  const totalStops = [];
  const stopageTimes = await getStopageTimesByLine(lineId, timeQ);

  stopageTimes.forEach((stopage) => {
    const machineTypeInserted = totalStops.find(
      (i) => i.modelName == stopage.modelName
    );
    if (machineTypeInserted) machineTypeInserted.stop += stopage.stop;
    else totalStops.push(stopage);
  });

  return totalStops;
};

const getChangeOverTrendByLineMethod = async (lineId, timeQ) => {
  const timeSeries = getTimeSeries(timeQ);
  const trendData = [];
  for (let i = 0; i < timeSeries.length; i++) {
    const data = await getChangeoverDataByLineMethod(lineId, timeSeries[i]);
    trendData.push({ reference: timeSeries[i].text, data: data });
  }
  return trendData;
};

const getChangeoverTrendByPlantMethod = async (plantId, timeQ) => {
  const timeSeries = getTimeSeries(timeQ);
  const trendData = [];
  for (let i = 0; i < timeSeries.length; i++) {
    const data = await getChangeoverDataByPlantMethod(plantId, timeSeries[i]);
    trendData.push({ reference: timeSeries[i].text, data: data });
  }
  return trendData;
};

const getStopageTimesByLine = async (lineId, timeQ) => {
  const lineShiftIds = await commonMethods.getFilteredShiftIds(
    lineId,
    dummyData["Line_Shift_Times"],
    timeQ
  );

  let stopageTimes = [];

  lineShiftIds.forEach((shiftId) => {
    const filetredData = dummyData["Production_Summaries"].find(
      (i) => i.Shift_Id == shiftId
    ).Data;
    filetredData.forEach((d) => {
      const plan = dummyData["Line_Shift_Plans"].find(
        (i) => i.Plan_Id == d["Line_Shift_Plan_Id"]
      );
      stopageTimes.push(
        new models.changeOverStopageByModel(
          plan.Model_Name,
          UtilityMethods.getTimeInSeconds(
            d["Changeover_Time_Start"],
            d["Changeover_Time_End"]
          ) / 60
        )
      );
    });
  });

  return stopageTimes;
};

const getCgangeOverGridDataByPlantMethod = async (plantId, timeQ) => {
  const changeovarData = [];
  let lines = dummyData["Lines"].filter((d) => d.Plant == plantId);

  for (let i = 0; i < lines.length; i++) {
    const chData = await getStopageTimesGridByLine(lines[i].Id, timeQ);
    const planCount = chData.plan.reduce((acc, curr) => {
      return (acc = acc + curr.count);
    }, 0);
    const planStop = chData.plan.reduce((acc, curr) => {
      return (acc = acc + curr.stop);
    }, 0);

    const actCount = chData.actual.reduce((acc, curr) => {
      return (acc = acc + curr.count);
    }, 0);
    const actStop = chData.actual.reduce((acc, curr) => {
      return (acc = acc + curr.stop);
    }, 0);
    const chDataByType = { plan: [], actual: [] };
    modelTypes.forEach((m) => {
      const planData = chData.plan.filter(
        (p) => m.models.indexOf(p.modelName) >= 0
      );
      const actData = chData.actual.filter(
        (p) => m.models.indexOf(p.modelName) >= 0
      );
      if (!planData || planData.length <= 0) {
        chDataByType.plan.push(
          new models.changeOverStopageByModelNew(m.type, 0, 0)
        ),
          chDataByType.actual.push(
            new models.changeOverStopageByModelNew(m.type, 0, 0)
          );
      } else {
        const planCountTyp = planData.reduce((acc, curr) => {
          return (acc = acc + curr.count);
        }, 0);
        const planStopTyp = planData.reduce((acc, curr) => {
          return (acc = acc + curr.stop);
        }, 0);

        const actCountTyp = actData.reduce((acc, curr) => {
          return (acc = acc + curr.count);
        }, 0);
        const actStopTyp = actData.reduce((acc, curr) => {
          return (acc = acc + curr.stop);
        }, 0);
        chDataByType.plan.push(
          new models.changeOverStopageByModelNew(
            m.type,
            planStopTyp,
            planCountTyp
          )
        ),
          chDataByType.actual.push(
            new models.changeOverStopageByModelNew(
              m.type,
              actStopTyp,
              actCountTyp
            )
          );
      }
    });

    chDataByType.plan.splice(
      0,
      0,
      new models.changeOverStopageByModelNew("Total", planStop, planCount)
    );
    chDataByType.actual.splice(
      0,
      0,
      new models.changeOverStopageByModelNew("Total", actStop, actCount)
    );

    changeovarData.push({
      lineId: lines[i].Id,
      lineName: lines[i].Name,
      data: chDataByType,
    });
  }
  return changeovarData;
};

const getCgangeOverGridTrendDataCountByLineMethod = async (lineId, timeQ) => {
  const timeSeries = getTimeSeries(timeQ);
  const trendData = [];
  for (let i = 0; i < timeSeries.length; i++) {
    const chData = await getStopageTimesGridByLine(lineId, timeSeries[i]);
    const chDataByType = { plan: [], actual: [] };

    const planCount = chData.plan.reduce((acc, curr) => {
      return (acc = acc + curr.count);
    }, 0);
    const planStop = chData.plan.reduce((acc, curr) => {
      return (acc = acc + curr.stop);
    }, 0);

    const actCount = chData.actual.reduce((acc, curr) => {
      return (acc = acc + curr.count);
    }, 0);
    const actStop = chData.actual.reduce((acc, curr) => {
      return (acc = acc + curr.stop);
    }, 0);

    trendData.push({
      reference: timeSeries[i].text,
      data: {
        lineId: lineId,
        lineName: dummyData["Lines"].find((d) => d.Id == lineId)?.Name,
        data: {
          plan: new models.changeOverStopageByModelNew(
            "Total",
            planStop / 60,
            planCount
          ),
          actual: new models.changeOverStopageByModelNew(
            "Total",
            actStop / 60,
            actCount
          ),
        },
      },
    });
  }
  return trendData;
};

const getCgangeOverGridTotalTrendDataByPlantMethod = async (plantId, timeQ) => {
  const changeovarTotalTrendData = [];
  let lines = dummyData["Lines"].filter((d) => d.Plant == plantId);
  for (let i = 0; i < lines.length; i++) {
    const data = await getCgangeOverGridTrendDataCountByLineMethod(
      lines[i].Id,
      timeQ
    );
    changeovarTotalTrendData.push(data);
  }

  const references = changeovarTotalTrendData[0].map((i) => i.reference);
  const returnData = [];
  references.forEach((ref) => {
    const dataObj = {
      reference: ref,
      data: {
        lineId: "Total",
        lineName: "Total",
        data: { plan: { modelName: 'Total', stop: 0, count: 0 }, actual: { modelName: 'Total', stop: 0, count: 0 } },
      },
    };

    for (let i = 0; i < changeovarTotalTrendData.length; i++) {
      const refData = changeovarTotalTrendData[i].find(j => j.reference == ref);
      dataObj.data.data.plan.count += refData.data.data.plan.count;
      dataObj.data.data.plan.stop += refData.data.data.plan.stop;
      dataObj.data.data.actual.stop += refData.data.data.actual.stop;
      dataObj.data.data.actual.count += refData.data.data.actual.count;
    }

    returnData.push(dataObj);

  });

  return returnData;
};

const getStopageTimesGridByLine = async (lineId, timeQ) => {
  const lineShiftIds = await commonMethods.getFilteredShiftIds(
    lineId,
    dummyData["Line_Shift_Times"],
    timeQ
  );

  let stopageTimes = [];
  let plannedChangeOvers = [];

  lineShiftIds.forEach((shiftId) => {
    const filetredData = dummyData["Production_Summaries"].find(
      (i) => i.Shift_Id == shiftId
    ).Data;
    filetredData.forEach((d) => {
      const plan = dummyData["Line_Shift_Plans"].find(
        (i) => i.Plan_Id == d["Line_Shift_Plan_Id"]
      );
      const existingChPlan = plannedChangeOvers.find(
        (i) => i.modelName == plan.Model_Name
      );
      const existingChActual = stopageTimes.find(
        (i) => i.modelName == plan.Model_Name
      );
      if (existingChPlan && existingChActual) {
        existingChPlan.count += 1;
        existingChPlan.stop += plan.Changeover_Time_After;

        existingChActual.stop += UtilityMethods.getTimeInSeconds(
          d["Changeover_Time_Start"],
          d["Changeover_Time_End"]
        );
        existingChActual.count += 1;
        const x = 10;
      } else {
        plannedChangeOvers.push(
          new models.changeOverStopageByModelNew(
            plan.Model_Name,
            plan.Changeover_Time_After,
            1
          )
        );
        stopageTimes.push(
          new models.changeOverStopageByModelNew(
            plan.Model_Name,
            UtilityMethods.getTimeInSeconds(
              d["Changeover_Time_Start"],
              d["Changeover_Time_End"]
            ),
            1
          )
        );
      }
    });
  });

  return { plan: plannedChangeOvers, actual: stopageTimes };
};

const getTimeSeries = (tq) =>
({
  day: [
    { start: "2024-08-18T06:00:00", end: "2024-08-19T06:00:00", text: "2024-08-18" },
    { start: "2024-08-19T06:00:00", end: "2024-08-20T06:00:00", text: "2024-08-19" },
    { start: "2024-08-20T06:00:00", end: "2024-08-21T06:00:00", text: "2024-08-20" },
    { start: "2024-08-21T06:00:00", end: "2024-08-22T06:00:00", text: "2024-08-21" },
    { start: "2024-08-22T06:00:00", end: "2024-08-23T06:00:00", text: "2024-08-22" },
    { start: "2024-08-23T06:00:00", end: "2024-08-24T06:00:00", text: "2024-08-23" },
    { start: "2024-08-24T06:00:00", end: "2024-08-25T06:00:00", text: "2024-08-24" }
  ],
  week: [
    {
      start: "2024-06-31T06:00:00",
      end: "2024-07-06T06:00:00",
      text: "Week 1",
    },
    {
      start: "2024-07-07T06:00:00",
      end: "2024-07-13T06:00:00",
      text: "Week 2",
    },
    {
      start: "2024-07-14T06:00:00",
      end: "2024-07-20T06:00:00",
      text: "Week 3",
    },
    {
      start: "2024-07-21T06:00:00",
      end: "2024-07-27T06:00:00",
      text: "Week 4",
    },
    {
      start: "2024-07-28T06:00:00",
      end: "2024-08-04T06:00:00",
      text: "Week 5",
    },
    {
      start: "2024-08-04T06:00:00",
      end: "2024-08-10T06:00:00",
      text: "Week 6",
    },
    {
      start: "2024-08-11T06:00:00",
      end: "2024-08-17T06:00:00",
      text: "Week 7",
    },
    {
      start: "2024-08-18T06:00:00",
      end: "2024-08-25T06:00:00",
      text: "Week 8",
    },
  ],
  month: [
    {
      start: "2023-09-01T06:00:00",
      end: "2023-09-30T06:00:00",
      text: "Month 1",
    },
    {
      start: "2023-10-01T06:00:00",
      end: "2023-10-30T06:00:00",
      text: "Month 2",
    },
    {
      start: "2023-11-01T06:00:00",
      end: "2023-11-30T06:00:00",
      text: "Month 3",
    },
    {
      start: "2023-12-01T06:00:00",
      end: "2023-12-30T06:00:00",
      text: "Month 4",
    },
    {
      start: "2024-01-01T06:00:00",
      end: "2024-01-30T06:00:00",
      text: "Month 5",
    },
    {
      start: "2024-02-01T06:00:00",
      end: "2024-02-28T06:00:00",
      text: "Month 6",
    },
    {
      start: "2024-03-01T06:00:00",
      end: "2024-03-30T06:00:00",
      text: "Month 7",
    },
    {
      start: "2024-04-01T06:00:00",
      end: "2024-04-30T06:00:00",
      text: "Month 8",
    },
    {
      start: "2024-05-01T06:00:00",
      end: "2024-05-30T06:00:00",
      text: "Month 9",
    },
    {
      start: "2024-06-01T06:00:00",
      end: "2024-06-30T06:00:00",
      text: "Month 10",
    },
    {
      start: "2024-07-01T06:00:00",
      end: "2024-07-30T06:00:00",
      text: "Month 11",
    },
    {
      start: "2024-08-01T06:00:00",
      end: "2024-08-25T06:00:00",
      text: "Month 12",
    },
  ],
  year: [
    {
      start: "2020-01-01T06:00:00",
      end: "2020-12-31T06:00:00",
      text: "Year 1",
    },
    {
      start: "2021-01-01T06:00:00",
      end: "2021-12-31T06:00:00",
      text: "Year 2",
    },
    {
      start: "2022-01-01T06:00:00",
      end: "2022-12-31T06:00:00",
      text: "Year 3",
    },
    {
      start: "2023-01-01T06:00:00",
      end: "2023-12-31T06:00:00",
      text: "Year 4",
    },
    {
      start: "2024-01-01T06:00:00",
      end: "2024-12-31T06:00:00",
      text: "Year 5",
    },
  ],
}[tq]);

exports.getChangeoverDataByPlant = getChangeoverDataByPlantMethod;
exports.getChangeoverDataByLine = getChangeoverDataByLineMethod;
exports.getChangeOverTrendByLine = getChangeOverTrendByLineMethod;
exports.getChangeoverTrendByPlant = getChangeoverTrendByPlantMethod;
exports.getChangeoverDataByPlantMethod2 = getChangeoverDataByPlantMethod2;
exports.getCgangeOverGridDataByPlant = getCgangeOverGridDataByPlantMethod;
exports.getCgangeOverGridTrendDataCountByLine =
  getCgangeOverGridTrendDataCountByLineMethod;
exports.getCgangeOverGridTotalTrendDataByPlant =
  getCgangeOverGridTotalTrendDataByPlantMethod;
