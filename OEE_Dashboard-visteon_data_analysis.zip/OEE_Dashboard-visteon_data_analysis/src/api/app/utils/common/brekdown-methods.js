const UtilityMethods = require("../utility.methods").UtilityMethods;
const { PgPools } = require('../../utils/pgPool')
const dbConfig = require('../../config/db.config')

const getBreakdownDataByPlant = async (plantName, timeQ, date, schemaName) => {
  let query = `select
      timewhen as date,
      linename as lineid,
      linename as linename,
      ROUND(breakdown / 60) as value
     from getBreakdownTimes('${date}', 'Plant', '${plantName}', '${timeQ}', 'A','${schemaName}')`;
  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true);

    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,lineid:string,linename:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = [];
      const dateRange = UtilityMethods.getTimeSeriesRangesForPareto(timeQ, new Date(date));
      const dateFilteredData = result.rows.filter(p => p.date === dateRange[0].time);

      dateFilteredData.reduce(function (res, item) {
        if (!res[item.linename]) {
          res[item.linename] = { linename: item.linename, value: 0, lineid: item.lineid };
          data.push(res[item.linename])
        }
        res[item.linename].value += item.value;
        return res;
      }, {});

      data.sort((a, b) => a.linename.toLowerCase().localeCompare(b.linename.toLowerCase()));

      const respJSON = {
        breakdownData: data.map(row => ({
          name: row["linename"],
          id: row["lineid"],
          value: row["value"]
        }))
      }
      return respJSON
    }
    else {
      return { breakdownData : [] }
    }

  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
};

const getBreakdownDataByLine = async (lineId, timeQ, date, schemaName) => {
  let query = `select
      timewhen as date,
      machineid as machineid,
      machinename as machinename,
      ROUND(breakdown / 60) as value
     from getBreakdownTimes('${date}', 'Line', '${lineId}', '${timeQ}', 'A','${schemaName}')`;
  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true);

    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,machineid:string,machinename:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = [];
      const dateRange = UtilityMethods.getTimeSeriesRangesForPareto(timeQ, new Date(date));
      const dateFilteredData = result.rows.filter(p => p.date === dateRange[0].time);
      dateFilteredData.reduce(function (res, item) {
        if (!res[item.machinename]) {
          res[item.machinename] = { machinename: item.machinename, value: 0, machineid: item.machineid };
          data.push(res[item.machinename])
        }
        res[item.machinename].value += item.value;
        return res;
      }, {});

      const respJSON = {
        breakdownData: data.map(row => ({
          name: row["machinename"],
          id: row["machineid"],
          value: row["value"]
        }))
      }
      return respJSON
    }
    else {
      return { breakdownData : [] }
    }

  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
};

const getBreakdownDataByMachine = async (lineId, timeQ, date, schemaName, machineId) => {
  let query = `select
      timewhen as date,
      machineid as machineid,
      issue as issueid,
      issue as issuename,
      ROUND(breakdown / 60) as value
     from getBreakdownTimes('${date}', 'Line', '${lineId}', '${timeQ}', 'A','${schemaName}')`;
  console.log(query);
  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true);

    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,machineid:string,issueid:string,issuename:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = [];
      const dateRange = UtilityMethods.getTimeSeriesRangesForPareto(timeQ, new Date(date));
      const dateFilteredData = result.rows.filter(p => p.date === dateRange[0].time && p.machineid === machineId);
      dateFilteredData.reduce(function (res, item) {
        if (!res[item.issuename]) {
          res[item.issuename] = { issuename: item.issuename, value: 0, issueid: item.issueid };
          data.push(res[item.issuename])
        }
        res[item.issuename].value += item.value;
        return res;
      }, {});

      const respJSON = {
        breakdownData: data.map(row => ({
          name: row["issuename"],
          id: row["issueid"],
          value: row["value"]
        }))
      }
      return respJSON
    }
    else {
      return { breakdownData : [] }
    }

  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
};

const getBreakdownTrendByPlant = async (plantName, timeQ, date, schemaName) => {
  let linesGetterQuery = `
        SELECT
        l.linename AS linename
        FROM ${schemaName}."Lines" l
        JOIN ${schemaName}."Plants" p
        ON l."locId"=p.plantid
        WHERE plantname='${plantName}';
      `;

  let query = `select
      timewhen as date,
      linename as lineid,
      linename as linename,
      ROUND(breakdown / 60) as value
     from getBreakdownTimes('${date}', 'Plant', '${plantName}', '${timeQ}', 'A','${schemaName}')`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    const linesResult = await client.query(linesGetterQuery);
    client.release(true);

    const dateRange = UtilityMethods.getTimeSeriesRanges(timeQ, new Date(date));
    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,lineid:string,linename:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = [];
      result.rows.reduce(function (res, item) {
        let key = item.linename + '|' + item.date;
        if (!res[key]) {
          res[key] = { linename: item.linename, value: 0, lineid: item.lineid, date: item.date };
          data.push(res[key])
        }
        res[key].value += item.value;
        return res;
      }, {});

      data.sort((a, b) => a.linename.toLowerCase().localeCompare(b.linename.toLowerCase()));

      const modifiedData = [];
      linesResult.rows.forEach(line => {
        dateRange.forEach(date => {
          let foundIndex = data.findIndex(p => p.linename === line.linename && date.time === p.date);
          modifiedData.push({
            linename: line.linename,
            value: foundIndex === -1 ? 0 : data[foundIndex].value,
            date: date.indicator
          })
        })
      })

      const uniqueTitles = [...new Set(modifiedData.map(p => p.linename))];
      const respJSON = {
        breakdownTrend:
          uniqueTitles.map(title => ({
            title,
            values: modifiedData.filter(p => p.linename === title).map(row => ({
              range: row.date,
              value: row.value
            })
            )
          })
          )
      };
      return respJSON
    }
    else {
      return { breakdownTrend : [] }
    }

  } catch (e) {
    return e
  }
};

const getBreakdownTrendByLine = async (lineId, timeQ, date, schemaName) => {

  let query = `select
      timewhen as date,
      machineid as machineid,
      machinename as machinename,
      ROUND(breakdown / 60) as value
     from getBreakdownTimes('${date}', 'Line', '${lineId}', '${timeQ}', 'A','${schemaName}')`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true);

    const dateRange = UtilityMethods.getTimeSeriesRanges(timeQ, new Date(date));
    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,lineid:string,linename:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = [];

      result.rows.reduce(function (res, item) {
        let key = item.machinename + '|' + item.date;
        if (!res[key]) {
          res[key] = { machinename: item.machinename, value: 0, machineid: item.machineid, date: item.date };
          data.push(res[key])
        }
        res[key].value += item.value;
        return res;
      }, {});

      const uniqueTitles = [...new Set(data.map(p => p.machinename))];
      const modifiedData = [];

      uniqueTitles.forEach(title => {
        dateRange.forEach(date => {
          let foundIndex = data.findIndex(p => p.machinename === title && date.time === p.date);
          modifiedData.push({
            machinename: title,
            value: foundIndex === -1 ? 0 : data[foundIndex].value,
            date: date.indicator
          })
        })
      })

      const respJSON = {
        breakdownTrend:
          uniqueTitles.map(title => ({
            title,
            values: modifiedData.filter(p => p.machinename === title).map(row => ({
              range: row.date,
              value: row.value
            })
            )
          })
          )
      };
      return respJSON
    }
    else {
      return { breakdownTrend : [] }
    }

  } catch (e) {
    return e
  }
};

const getBreakdownTrendByMachine = async (lineId, timeQ, date, schemaName, machineId) => {

  let query = `select
      timewhen as date,
      machineid as machineid,
      issue as issueid,
      issue as issuename,
      ROUND(breakdown / 60) as value
     from getBreakdownTimes('${date}', 'Line', '${lineId}', '${timeQ}', 'A','${schemaName}')`;

  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true);

    const dateRange = UtilityMethods.getTimeSeriesRanges(timeQ, new Date(date));
    if (result.rowCount > 0) {
      /**
       * @typedef {{date:string,lineid:string,linename:string,value:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = [];
      const machineFilteredData = result.rows.filter(p => p.machineid === machineId);
      machineFilteredData.reduce(function (res, item) {
        let key = item.issuename + '|' + item.date;
        if (!res[key]) {
          res[key] = { issuename: item.issuename, value: 0, issueid: item.issueid, date: item.date };
          data.push(res[key])
        }
        res[key].value += item.value;
        return res;
      }, {});

      const uniqueTitles = [...new Set(data.map(p => p.issuename))];
      const modifiedData = [];

      uniqueTitles.forEach(title => {
        dateRange.forEach(date => {
          let foundIndex = data.findIndex(p => p.issuename === title && date.time === p.date);
          modifiedData.push({
            issuename: title,
            value: foundIndex === -1 ? 0 : data[foundIndex].value,
            date: date.indicator
          })
        })
      })

      const respJSON = {
        breakdownTrend:
          uniqueTitles.map(title => ({
            title,
            values: modifiedData.filter(p => p.issuename === title).map(row => ({
              range: row.date,
              value: row.value
            })
            )
          })
          )
      };
      return respJSON
    }
    else {
      return { breakdownTrend : [] }
    }

  } catch (e) {
    return e
  }
};

const getBreakdownActionsByLine = async (lineId, timeQ, date, schemaName) => {
  let query = `select
      description as action,
      actiontime as actualtime,
      machinename as parentid,
      rootcause as rootcause,
      duration as duration
     from getBreakdownActionsForTimeRangeAndLineAggregation('${date}', 'Line', '${lineId}', '${timeQ}', 'A','${schemaName}')`;
  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true);

    if (result.rowCount > 0) {
      /**
       * @typedef {{action:string,actualtime:string,parentid:string,rootcause:string,duration:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = result.rows;
      const respJSON = {
        breakdownActionData: data.map(row => ({
          action: row["action"],
          actualTime: row["actualtime"],
          parentId: row["parentid"],
          rootCause: row["rootcause"],
          duration: row["duration"],
          status: UtilityMethods.getStatus(row["actualtime"]),
          markerMapper: UtilityMethods.getMarkerMapper(row["actualtime"], timeQ, new Date(date))
        }))
      }
      return respJSON
    }
    else {
      return {
        breakdownActionData: []
      }
    }

  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
};

const getBreakdownActionsByMachine = async (lineId, timeQ, date, schemaName, machineName) => {
  let query = `select
      description as action,
      actiontime as actualtime,
      machinename as machinename,
      issue as parentid,
      rootcause as rootcause,
      duration as duration
     from getBreakdownActionsForTimeRangeAndLineAggregation('${date}', 'Line', '${lineId}', '${timeQ}', 'A','${schemaName}')`;
  try {
    const pgPoolsInstance = await PgPools.getInstance();
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
    const result = await client.query(query)
    client.release(true);

    if (result.rowCount > 0) {
      /**
       * @typedef {{action:string,actualtime:string,machinename:string,parentid:string,rootcause:string,duration:number}} DataRow
       */

      /**
       * @type {[DataRow]}
       */
      const data = result.rows.filter(p => p.machinename === machineName);
      const respJSON = {
        breakdownActionData: data.map(row => ({
          action: row["action"],
          actualTime: row["actualtime"],
          parentId: row["parentid"],
          rootCause: row["rootcause"],
          duration: row["duration"],
          status: UtilityMethods.getStatus(row["actualtime"]),
          markerMapper: UtilityMethods.getMarkerMapper(row["actualtime"], timeQ, new Date(date))
        }))
      }
      return respJSON
    }
    else {
      return {
        breakdownActionData: []
      }
    }

  } catch (e) {
    res.status(500).send({
      error: e.message,
    })
  }
};

exports.getBreakdownDataByPlant = getBreakdownDataByPlant;
exports.getBreakdownDataByLine = getBreakdownDataByLine;
exports.getBreakdownDataByMachine = getBreakdownDataByMachine;
exports.getBreakdownActionsByLine = getBreakdownActionsByLine;
exports.getBreakdownTrendByPlant = getBreakdownTrendByPlant;
exports.getBreakdownTrendByLine = getBreakdownTrendByLine;
exports.getBreakdownTrendByMachine = getBreakdownTrendByMachine;
exports.getBreakdownActionsByMachine = getBreakdownActionsByMachine;

