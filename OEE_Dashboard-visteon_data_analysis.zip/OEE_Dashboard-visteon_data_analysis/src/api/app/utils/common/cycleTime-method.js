const { PgPools } = require('../../utils/pgPool');
const dbConfig = require('../../config/db.config');
const { getRealTimeJsonData, setRealTimeData } = require("../../../data-loader");
const UtilityMethods = require("../utility.methods").UtilityMethods;
const fs = require('fs');

const getCycleTimeDataByPlantMethodByDB = async (plantName, timeQ, date, schemaName) => {
    let linesGetterQuery = `
        SELECT
        l.lineId AS lineid
        FROM ${schemaName}."Lines" l
        JOIN ${schemaName}."Plants" p
        ON l."locId"=p.plantid
        WHERE plantname='${plantName}';
      `;

    let query = `SELECT 
    line_name as lineid,
    model as model,
    actualcycletime as actualcycletime,
    standardcycletime as standardcycletime
    FROM getModelCycleTimesFromProductionData('${date}', 'Plant', '${plantName}', '${timeQ}', 'A', 'Any', '${schemaName}');`;

    try {
        const pgPoolsInstance = await PgPools.getInstance();
        const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient();
        const result = await client.query(query);
        const linesResult = await client.query(linesGetterQuery);

        client.release(true);

        if (result.rowCount > 0) {
            /**
             * @typedef {{lineid:string,model:string,actualcycletime:number,standardcycletime:number}} DataRow
             */

            /**
             * @type {[DataRow]}
             */
            const data = [];
            let lines = [];
            if (linesResult.rowCount > 0)
                lines = linesResult.rows;

            result.rows.reduce(function (res, item) {
                if (!res[item.model]) {
                    let dataArray = [];
                    lines.forEach(line => dataArray.push({
                        lineId: line.lineid,
                        actualCycleTime: 0,
                        stdCycleTime: 0
                    }));
                    dataArray = dataArray.map(x => (x.lineId === item.lineid ? { ...x, actualCycleTime: Number(item.actualcycletime), stdCycleTime: Number(item.standardcycletime) } : x));
                    res[item.model] = { model: item.model, data: dataArray };
                    data.push(res[item.model])
                }
                else
                    res[item.model]["data"] = res[item.model]["data"].map(x => (x.lineId === item.lineid ? { ...x, actualCycleTime: Number(item.actualcycletime), stdCycleTime: Number(item.standardcycletime) } : x));
                return res;
            }, {});

            const respJSON = {
                cycleTimeData: data
            }
            return respJSON
        }

    } catch (e) {
        res.status(500).send({
            error: e.message,
        })
    }
}

const getRunDataAndStatsFromRealTimeData = async () => {
    try {
        let realTimeData = getRealTimeJsonData()["machineData"];
        let productIds = Object.keys(realTimeData);
        let realTimeDataAndStats = {
            "data": [], "stats": {
                "totalCount": 0,
                "totalGoodCount": 0,
                "totalBadCount": 0,
                "stdCycleTime": 0,
                "avgCycleTime": 0,
                "totalUnknown": 0
            }
        };
        let cycleTime = 0;
        productIds.forEach((pId, index) => {
            let pIdWiseData = realTimeData[pId];
            if (pIdWiseData.length > 0) {
                realTimeDataAndStats["data"].push({
                    "pId": pId,
                    "m1Id": pIdWiseData[0] !== undefined ? pIdWiseData[0]["machineId"] : "",
                    "m1EntryTime": pIdWiseData[0] !== undefined ? pIdWiseData[0]["timeStamp"] : "",
                    "m1ExitTime": pIdWiseData[1] !== undefined ? pIdWiseData[1]["timeStamp"] : "",
                    "m2Id": pIdWiseData[2] !== undefined ? pIdWiseData[2]["machineId"] : "",
                    "m2EntryTime": pIdWiseData[2] !== undefined ? pIdWiseData[2]["timeStamp"] : "",
                    "m2ExitTime": pIdWiseData[3] !== undefined ? pIdWiseData[3]["timeStamp"] : "",
                    "m3Id": pIdWiseData[4] !== undefined ? pIdWiseData[4]["machineId"] : "",
                    "m3EntryTime": pIdWiseData[4] !== undefined ? pIdWiseData[4]["timeStamp"] : "",
                    "m3ExitTime": pIdWiseData[5] !== undefined ? pIdWiseData[5]["timeStamp"] : "",
                    "isOk": getIsOkStatus(pIdWiseData),
                    // "isRunGoing": index === productIds.length - 1 && pIdWiseData[5] === undefined ? true : false,
                    "isRunGoing": getIsOkStatus(pIdWiseData) === 'N' ? false : pIdWiseData[5] === undefined ? true : false
                });
                // cycleTime += pIdWiseData[0] !== undefined && pIdWiseData[5] !== undefined ?
                //     new Date(pIdWiseData[5]["timeStamp"]).getMilliseconds() - new Date(pIdWiseData[0]["timeStamp"]).getMilliseconds() : 0;

            }
        })
        if (productIds.length > 0) {
            if (realTimeData[productIds[0]].length > 0 && realTimeData[productIds[productIds.length - 1]].length > 0) {
                let lastProductRuns = realTimeData[productIds[productIds.length - 1]];
                let firstProductRuns = realTimeData[productIds[0]];
                cycleTime = new Date(lastProductRuns[lastProductRuns.length - 1]["timeStamp"]).getTime() -
                    new Date(firstProductRuns[0]["timeStamp"]).getTime();
            }
        }
        realTimeDataAndStats["stats"]["totalCount"] = realTimeDataAndStats["data"].length;
        realTimeDataAndStats["stats"]["totalGoodCount"] = realTimeDataAndStats["data"].filter(p => p["isOk"] === "Y").length;
        realTimeDataAndStats["stats"]["totalBadCount"] = realTimeDataAndStats["data"].filter(p => p["isOk"] === "N").length;
        realTimeDataAndStats["stats"]["totalUnknown"] = realTimeDataAndStats["data"].filter(p => p["isOk"] === "").length;
        // realTimeDataAndStats["stats"]["avgCycleTime"] = cycleTime / realTimeDataAndStats["data"].filter(p => p["m3ExitTime"] !== '').length;
        realTimeDataAndStats["stats"]["avgCycleTime"] = parseFloat((cycleTime / productIds.length).toFixed(2));

        return {
            realTimeDataAndStat: realTimeDataAndStats
        };
    } catch (e) {
        console.log(e);
        return [];
    }

}

const getIsOkStatus = (productData) => {
    let status = '';
    if (productData[5] !== undefined) status = productData[5]["isGoodCount"];
    else if (productData[3] !== undefined) status = productData[3]["isGoodCount"];
    else if (productData[1] !== undefined) status = productData[1]["isGoodCount"];
    else status = ''
    return status;
}

const getStdCycleTimeData = async () => {
    try {
        return { stdCycleTime: getRealTimeJsonData()["stdCycleTime"] };
    } catch (e) {
        console.log(e);
        return { stdCycleTime: null }
    }
}

const updateStdCycleTime = async (newStdCycleTime) => {
    try {
        // Read the JSON file
        let filePath = 'data/real_time_machine_data.json';
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                throw err;
            }

            // Parse the JSON content
            let jsonData = JSON.parse(data);

            // Navigate to the specific field and update it
            let current = jsonData;
            let fieldPath = ['stdCycleTime'];
            for (let i = 0; i < fieldPath.length - 1; i++) {
                current = current[fieldPath[i]];
            }
            current[fieldPath[fieldPath.length - 1]] = newStdCycleTime;

            // Write the updated content back to the JSON file
            try {
                fs.writeFile(filePath, JSON.stringify(jsonData, null, 2), (err) => {
                    if (err) {
                        throw err;
                    } else {
                        setRealTimeData(JSON.parse(fs.readFileSync(filePath, "utf8")));
                    }
                });
            } catch (e) {
                return { "message": "Error updating Std Cycle Time" }
            }
        });
    } catch (e) {
        console.log(e);
        return { "message": "Error updating Std Cycle Time" }
    }

}

const insertRealTimeData = async (newRealTimeData) => {
    try {
        let realTimeData = getRealTimeJsonData()["machineData"];
        let productIds = Object.keys(realTimeData);
        let foundIndex = productIds.findIndex(p => p === newRealTimeData["poductId"]);
        if (foundIndex === -1) {
            realTimeData[newRealTimeData["poductId"]] = [
                {
                    "timeStamp": UtilityMethods.correctDateFormat(newRealTimeData["timeStamp"]),
                    "machineId": newRealTimeData["machineId"],
                    "eventType": newRealTimeData["eventType"],
                    "microStopTime": 0,
                    "isGoodCount": newRealTimeData["isGoodCount"]
                }
            ];
        }
        else {
            realTimeData[newRealTimeData["poductId"]].push({
                "timeStamp": UtilityMethods.correctDateFormat(newRealTimeData["timeStamp"]),
                "machineId": newRealTimeData["machineId"],
                "eventType": newRealTimeData["eventType"],
                "microStopTime": 0,
                "isGoodCount": newRealTimeData["isGoodCount"]
            })
        }
        // Convert new data to JSON format
        let filePath = 'data/real_time_machine_data.json';
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                throw err;
            }

            // Parse the JSON content
            let jsonData = JSON.parse(data);

            // Navigate to the specific field and update it
            let current = jsonData;
            let fieldPath = ['machineData'];
            for (let i = 0; i < fieldPath.length - 1; i++) {
                current = current[fieldPath[i]];
            }
            current[fieldPath[fieldPath.length - 1]] = realTimeData;
            // Take last 1000 entries from the realtime data
            let keys = Object.keys(realTimeData).slice(-1000);
            Object.keys(realTimeData).forEach(key => {
                if (!keys.includes(key))
                    delete realTimeData[key];
            })
            // Write the updated content back to the JSON file
            try {
                fs.writeFile(filePath, JSON.stringify(jsonData, null, 2), (err) => {
                    if (err) {
                        throw err;
                    } else {
                        setRealTimeData(JSON.parse(fs.readFileSync(filePath, "utf8")));
                    }
                });
            } catch (e) {
                return { "message": "Error updating real time data" }
            }
        });
    } catch (e) {
        console.log(e);
        return { "message": "Error updating real time data" }
    }
}

exports.getCycleTimeDataByPlantMethodByDB = getCycleTimeDataByPlantMethodByDB;
exports.getRunDataAndStatsFromRealTimeData = getRunDataAndStatsFromRealTimeData;
exports.updateStdCycleTime = updateStdCycleTime;
exports.insertRealTimeData = insertRealTimeData;
exports.getStdCycleTimeData = getStdCycleTimeData;