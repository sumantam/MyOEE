exports.getFilteredShiftIds = async (lineId, lineShiftTimes, timeQ) => {
  return lineShiftTimes
    .filter(
      (d) =>
        d.Line == lineId &&
        new Date(timeQ["start"]) <=
          new Date(d.Start) &&
        new Date(d.Start) <
          new Date(timeQ["end"])
    )
    .map((i) => i.Id);
};


exports.getFilteredMachines = async (lineId, pipelineMachines) => {
  return pipelineMachines.filter((d) => d.Line == lineId);
};


exports.getSyopagesByMachine = async (machineId, productionSummaries) => {
  productionSummaries.filter(d => {
    if(d.Data.Breakdowns > 0){
      const breakdowns = d.Data.Breakdowns.filter(i => i.Machines_In_Pipeline_Id == machineId);
      if(breakdowns.length > 0){

      }
    }
  });

}
