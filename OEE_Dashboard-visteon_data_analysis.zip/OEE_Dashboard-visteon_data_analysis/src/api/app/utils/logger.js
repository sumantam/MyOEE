const { createLogger, transports, format } = require("winston");

// logging function
exports.logger = createLogger({
  transports: [
    new transports.File({
      filename: "app-info.log",
      level: "info",
      format: format.combine(format.timestamp(), format.json()),
    })//,
    // new transports.File({
    //   filename: "app-error.log",
    //   level: "error",
    //   format: format.combine(format.timestamp(), format.json(), format.prettyPrint()),
    // }),
  ],
});

// // Create a Winston logger instance
// exports.logger = createLogger({
//   level: "info", // Set the logging level
//   format: format.combine(
//     format.timestamp(), // Add a timestamp to each log entry
//     format.json() // Format log entries as JSON
//   ),
//   transports: [
//     // Output logs to the console
//     new transports.Console(),
//     // Optionally, you can add more transports for logging to files, databases, etc.
//     // For example, to log to a file:
//     // new winston.transports.File({ filename: 'app.log' }),
//   ],
// });
