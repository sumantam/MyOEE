const Instance = require('./pgPool')
const { PgPools } = require('./pgPool')
const { Client } = require('pg')
const sequelize = require('./database')
const dbConfig = require('../config/db.config')

const sanitizeIdentifier = (identifier) => {
  return identifier.replace(/[^a-zA-Z0-9_]/g, '')
}

const checkRoleExists = async (client, roleName) => {
  const result = await client.query(
    'SELECT 1 FROM pg_roles WHERE rolname = $1',
    [roleName]
  )
  return result.rowCount > 0
}

const createUserDBMap = async (
  username,
  databaseName
) => {
  try {
    await (sequelize.query('SELECT user_db_map (:username, :database_name)',
      {
        replacements: {
          username,
          databaseName
        },
        type: sequelize.QueryTypes.SELECT
      }))
    return true
  } catch (error) {
    console.error(' Error in userDB map', error)
    return false
  }
}

const createFdwDb = async (remoteDb, user) => {
  const pgPoolsInstance = await PgPools.getInstance()
  const client = await pgPoolsInstance.getPool().getClient()
  const sanitizedUser = sanitizeIdentifier(user)
  const passuser = 'pass' + sanitizedUser

  try {
    const resultDb = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [remoteDb])

    if (resultDb.rowCount === 0) {
      console.log('Needs to create a new database')

      // Check if role exists
      const roleExists = await checkRoleExists(client, user)
      if (!roleExists) {
        console.log(' New role for the user being created ', user)
        await client.query(`CREATE ROLE "${sanitizedUser}" WITH LOGIN PASSWORD '${passuser}'`)
      }
      await client.query(`CREATE DATABASE "${remoteDb}" WITH OWNER "${sanitizedUser}"`)
      await client.query(`GRANT ALL PRIVILEGES ON DATABASE "${remoteDb}" TO "${sanitizedUser}"`)
      console.log('Successful in creating a new database')
    }

    // Calling with database and user
    await pgPoolsInstance.addPool(remoteDb, { database: remoteDb, user: sanitizedUser, password: passuser })
    await pgPoolsInstance.getPool(remoteDb).createTable('User')
    await pgPoolsInstance.getPool(remoteDb).createTable('Relation')
  } catch (error) {
    console.error(error.stack + ' createFDWDatabase')
  } finally {
    if (client) {
      await client.release(true)
    }
  }
}

const create_FDW_DB = async (remoteDb, user) => {
  let client
  try {
    const pgPool = new Instance()
    client = await pgPool.getClient()

    console.log('Before select')

    const databaseName = pgPool.getDatabase()
    const result = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [databaseName])

    console.log('After select')

    if (result.rowCount !== 0) {
      const resultDb = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [remoteDb])

      if (resultDb.rowCount === 0) {
        console.log('Needs to create a new database')
        const sanitizedUser = sanitizeIdentifier(user)
        const passuser = 'pass' + sanitizedUser

        // Check if role exists
        const roleExists = await checkRoleExists(client, user)
        if (!roleExists) {
          await client.query(`CREATE ROLE "${sanitizedUser}" WITH LOGIN PASSWORD '${passuser}'`)
        }
        await client.query(`CREATE DATABASE "${remoteDb}" WITH OWNER "${sanitizedUser}"`)
        await client.query(`GRANT ALL PRIVILEGES ON DATABASE "${remoteDb}" TO "${sanitizedUser}"`)
        console.log('Successful in creating a new database')
        await client.release(true)
      }
    }
  } catch (error) {
    console.error(error.stack + ' createFDWDatabase')
  } finally {
    if (client) {
      await client.release(true)
    }
  }
}

const createFDW = async (
  remoteUser,
  remoteHost,
  portNumber,
  remoteDb,
  remoteServer
) => {
  let client = null
  let fdwClient = null

  try {
    const sanitizedUser = sanitizeIdentifier(remoteUser)
    const passuser = 'pass' + sanitizedUser

    const config = {
      user: sanitizedUser,
      host: remoteHost,
      database: remoteDb,
      password: passuser,
      port: portNumber
    }

    // const client = await pgPool.getClient();
    client = new Client(config)

    console.log('Going inside the function createFDW ', config)

    await client.connect()
    const res = await client.query('SELECT 1 FROM pg_database WHERE datname = $1;', [remoteDb])
    await client.end()

    if (res.rows.length > 0) {
      console.log(`Database "${remoteDb}" exists.`)

      // create a client with a  new configuration incorporating
      // the database which should be used for foreign data wrapper

      const pgPool = new Instance()
      fdwClient = await pgPool.getClient()

      console.log('foreign data wrapper Client: ', fdwClient)

      const result = await fdwClient.query(
        'SELECT public.foreign_data_wrapper($1::varchar, $2::integer, $3::varchar, $4::varchar, $5::varchar, $6::varchar);',
        [remoteHost, portNumber, remoteDb, sanitizedUser, remoteServer, passuser]
      )

      fdwClient.release()

      console.log(' The result is : ', result)
    } else {
      console.log(`Database "${remoteDb}" does not exist.`)
    }

    // console.dir(client, { depth: null });

    return true
  } catch (error) {
    console.error(error.stack + 'createFDW')
    return false
  } finally {
    if (client) {
      await client.end()
    }

    if (fdwClient) {
      await fdwClient.release()
    }
  }
}

const createForeignDirectWrapper = async (
  remoteUser,
  remoteHost,
  portNumber,
  remoteDb,
  remoteServer
) => {
  const pgPoolsInstance = await PgPools.getInstance()
  let client = null

  try {
    const sanitizedUser = sanitizeIdentifier(remoteUser)
    const passuser = 'pass' + sanitizedUser

    client = await pgPoolsInstance.getPool().getClient()

    // Check if the remote database exists
    const dbCheckQuery = 'SELECT 1 FROM pg_database WHERE datname = $1;'
    const dbCheckValues = [remoteDb]
    const dbCheckResult = await client.query(dbCheckQuery, dbCheckValues)
    await client.release()
    client = null

    if (dbCheckResult.rows.length > 0) {
      console.log(`Database "${remoteDb}" exists.`)

      client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()

      // Call findFn to get details of foreign_data_wrapper function
      const findFnQuery = 'SELECT * FROM findFn($1);'
      const findFnValues = ['foreign_data_wrapper']
      const findFnResult = await client.query(findFnQuery, findFnValues)

      console.log('Result of findFn:', findFnResult.rows)

      // Release client after findFn query
      await client.release()
      client = null

      // Obtain a new client for foreign data wrapper operations
      client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()

      const fdwQuery = `
        SELECT public.foreign_data_wrapper($1::varchar, $2::integer, $3::varchar, $4::varchar, $5::varchar, $6::varchar);
      `
      const fdwValues = [remoteHost, portNumber, remoteDb, sanitizedUser, remoteServer, passuser]

      console.log(' The values are respectively ', fdwValues)
      const fdwResult = await client.query(fdwQuery, fdwValues)

      console.log('Result of foreign_data_wrapper:', fdwResult.rows)

      // Release fdwClient after foreign_data_wrapper call
      await client.release()
      client = null

      return true
    } else {
      console.log(`Database "${remoteDb}" does not exist.`)
      return false
    }
  } catch (error) {
    console.error('Error in createForeignDataWrapper:', error.stack)
    return false
  } finally {
    // Ensure clients are released in all cases
    if (client) {
      await client.release()
      client = null
    }
  }
}

// const createForeignDirectWrapper = async (
//   remoteUser,
//   remoteHost,
//   portNumber,
//   remoteDb,
//   remoteServer
// ) => {
//   const pgPoolsInstance = await PgPools.getInstance()
//   let client = null
//   let fdwClient = null

//   try {
//     const sanitizedUser = sanitizeIdentifier(remoteUser)
//     const passuser = 'pass' + sanitizedUser

//     console.log('Inside the function ', createForeignDirectWrapper.name)
//     client = await pgPoolsInstance.getPool().getClient()
//     const res = await client.query('SELECT 1 FROM pg_database WHERE datname = $1;', [remoteDb])

//     const queryText = 'SELECT * FROM findFn($1);' // Note the SELECT * to fetch all columns
//     const values = ['foreign_data_wrapper']
//     const myResult = await client.query(queryText, values)

//     console.log(' The result of the query is ', myResult.rows)
//     client.release(true)

//     if (res.rows.length > 0) {
//       console.log(`Database "${remoteDb}" exists.`)

//       // create a client with a  new configuration incorporating
//       // the database which should be used for foreign data wrapper

//       fdwClient = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
//       console.log('Foreign Direct Wrapper Client: ', fdwClient)

//       const queryText = `
//       SELECT public.foreign_data_wrapper($1::varchar, $2::integer, $3::varchar, $4::varchar, $5::varchar, $6::varchar);
//       `
//       const values = [remoteHost, portNumber, remoteDb, sanitizedUser, remoteServer, passuser]

//       const result = await fdwClient.query(queryText, values)
//       // const result = await fdwClient.query(
//       //   'SELECT public.foreign_data_wrapper($1::varchar, $2::integer, $3::varchar, $4::varchar, $5::varchar, $6::varchar);',
//       //   [remoteHost, portNumber, remoteDb, sanitizedUser, remoteServer, passuser]
//       // )

//       fdwClient.release(true)

//       console.log(' The result is : ', result)
//     } else {
//       console.log(`Database "${remoteDb}" does not exist.`)
//     }

//     return true
//   } catch (error) {
//     console.error(error.stack + 'createForeignDirectWrapper')
//     return false
//   } finally {
//     if (client) {
//       await client.release(true)
//     }

//     if (fdwClient) {
//       await fdwClient.release(true)
//     }
//   }
// }

module.exports = {
  createFDW: createForeignDirectWrapper,
  createFDWDatabase: createFdwDb
}
