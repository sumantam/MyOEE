const {
  dataPoint,
  commonChartModel,
} = require("../models/chartModel/common-chart-model");

const dummyData = [];
const UtilityMethods = require("./utility.methods").UtilityMethods;

exports.getMicrostopDataByLine = async (lines, timeQ) => {
  const msDataByLine = [];
  for (let i in lines) {
    console.log(i);

    const lineShiftIds = dummyData["Line_Shift_Times"]
      .filter(
        (d) =>
          d.Line == lines[i] &&
          new Date(UtilityMethods.getTimeStamp(timeQ["start"])) <=
            new Date(UtilityMethods.getTimeStamp(d.Start)) &&
          new Date(UtilityMethods.getTimeStamp(d.Start)) <
            new Date(UtilityMethods.getTimeStamp(timeQ["end"]))
      )
      .map((i) => i.Id);

    const stopTimesPerLine = [];

    lineShiftIds.forEach((shiftId, index) => {
      const filetredProductionSummaries =
        UtilityMethods.getFilteredProductionSummariesByShift(
          shiftId,
          dummyData["Production_Summaries"]
        );

      const msTime = UtilityMethods.getTotalMicrostopInstancesTime(
        filetredProductionSummaries
      );

      stopTimesPerLine.push(new dataPoint(`S${index + 1}`, msTime));
    });
    const lineName = dummyData["Lines"].filter((l) => l.Id == lines[i])[0].Name;
    msDataByLine.push(new commonChartModel(null, lineName, stopTimesPerLine));
  }

  return msDataByLine;
};

exports.getMicrostopDataByMachine = async (line, timeQ) => {
  const msDataByMchine = [];
  const msData = [];
  const lineShiftIds = dummyData["Line_Shift_Times"]
    .filter(
      (d) =>
        d.Line == line &&
        new Date(UtilityMethods.getTimeStamp(timeQ["start"])) <=
          new Date(UtilityMethods.getTimeStamp(d.Start)) &&
        new Date(UtilityMethods.getTimeStamp(d.Start)) <
          new Date(UtilityMethods.getTimeStamp(timeQ["end"]))
    )
    .map((i) => i.Id);

  const shifts = [];

  lineShiftIds.forEach((shiftId, index) => {
    const filetredProductionSummaries =
      UtilityMethods.getFilteredProductionSummariesByShift(
        shiftId,
        dummyData["Production_Summaries"]
      );

    const msInstances = UtilityMethods.getTotalMicrostopInstances(
      filetredProductionSummaries
    );

    shifts.push(`S${index + 1}`);

    msInstances.forEach((ms) => {
      msData.push({
        m: ms.machine,
        point: new dataPoint(`S${index + 1}`, ms.time),
      });
    });
  });

  const machines = msData.map((m) => m.m);
  const uniqueMachines = machines
    .filter((m, i) => machines.indexOf(m) == i)
    .sort();

  uniqueMachines.forEach((um) => {
    const msByMachine = msData.filter((i) => i.m == um);
    const stopTimesPerMachine = [];
    shifts.forEach((s) => {
      const msPerShift = msByMachine
        .filter((it) => it.point.marker == s)
        .map((i) => i.point);
      stopTimesPerMachine.push(
        new dataPoint(
          s,
          msPerShift.reduce((acc, i) => {
            return acc + i.value;
          }, 0)
        )
      );
    });
    msDataByMchine.push(new commonChartModel(null, um, stopTimesPerMachine));
  });

  return msDataByMchine;
};

exports.getTotalDelayByLine = async (lines, timeQ) => {
  const msDataByLine = [];
  for (let i in lines) {
    console.log(i);

    const lineShiftIds = dummyData["Line_Shift_Times"]
      .filter(
        (d) =>
          d.Line == lines[i] &&
          new Date(UtilityMethods.getTimeStamp(timeQ["start"])) <=
            new Date(UtilityMethods.getTimeStamp(d.Start)) &&
          new Date(UtilityMethods.getTimeStamp(d.Start)) <
            new Date(UtilityMethods.getTimeStamp(timeQ["end"]))
      )
      .map((i) => i.Id);

    const stopTimesPerLine = [];

    lineShiftIds.forEach((shiftId, index) => {
      const filetredProductionSummaries =
        UtilityMethods.getFilteredProductionSummariesByShift(
          shiftId,
          dummyData["Production_Summaries"]
        );

      const msTime = UtilityMethods.getTotalMicrostopInstancesTime(
        filetredProductionSummaries
      );

      stopTimesPerLine.push(new dataPoint(`S${index + 1}`, msTime));
    });
    const lineName = dummyData["Lines"].filter((l) => l.Id == lines[i])[0].Name;
    msDataByLine.push(new commonChartModel(null, lineName, stopTimesPerLine));
  }

  return msDataByLine;
};
