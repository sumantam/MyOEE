const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class LineShiftPlan {
  schema = 'public'

  constructor(schemaName = 'public') { this.schema = schemaName }

  async createLineShiftPlan(LineShiftPlan, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."LineShiftPlans" WHERE Id = $1
    ) AS lineshiftplan_exists;
    `

    const checkModelId = `
      SELECT ModelId FROM ${this.schema}."Models" WHERE ModelName= $1;
    `
    const insertQuery = `
      INSERT INTO ${this.schema}."LineShiftPlans" (
        Id,
        ShiftId,
        StartTime,
        ChangeoverTimeAfter,
        OtherTimes,
        ToProduce,
        ModelId
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7
      )
      RETURNING *;
    `

    const insertModelQuery = `
    SELECT FROM  InsertModel($1,$2, $3);
  `
    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client
      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery, [LineShiftPlan.Id])
      // console.log('The result is : => ', checkRes)
      let lineShiftPlanExists = checkRes.rows[0].lineshiftplan_exists

      if (!lineShiftPlanExists) {
        let retryCount = 5
        let ModelIdRes = (await tClient.query(checkModelId, [LineShiftPlan.ModelName]))

        while (ModelIdRes.rows.length === 0 && retryCount > 0) {
          // Insert the new model
          await tClient.query(insertModelQuery, [LineShiftPlan.ModelName, LineShiftPlan.barCodePrefix, this.schema])
          ModelIdRes = (await tClient.query(checkModelId, [LineShiftPlan.ModelName]))
          retryCount = retryCount - 1
        }

        if (ModelIdRes.rows.length === 0) {
          throw new Error('Failed to insert and retrieve the new model. retry_count = ', LineShiftPlan.ModelName, retryCount)
        }
        const ModelId = ModelIdRes.rows[0].modelid
        //
        const values = [
          LineShiftPlan.Id,
          LineShiftPlan.ShiftId,
          LineShiftPlan.StartTime,
          LineShiftPlan.ChangeoverTimeAfter,
          LineShiftPlan.OtherTimes,
          LineShiftPlan.ToProduce,
          ModelId
        ]

        // Insert the new shift owner
        const insertRes = await tClient.query(insertQuery, values)
        lineShiftPlanExists = insertRes.rows[0]
      }

      return lineShiftPlanExists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }
}

module.exports = {
  LineShiftPlan
}
