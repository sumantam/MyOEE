const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class ChangeOverTypeTimes {
  schema = 'public'

  constructor(schemaName = 'public') { this.schema = schemaName }

  async createChangeOverTypeTimes(changeoverType, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."ChangeOverTypeTimes" WHERE ChangeOverType = $1
    ) AS ChangeOverType_exists;
    `

    const insertQuery = `
      INSERT INTO ${this.schema}."ChangeOverTypeTimes" (
        ChangeOverType,
        ChangeOverTime
      ) VALUES (
        $1, $2
      )
      RETURNING *;
    `

    const values = [
      changeoverType.changeoverTypeTimesKey,
      changeoverType.changeoverTypeTimesVal
    ]

    // console.log('Inside the function createPlant')
    let tClient = null

    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery, [changeoverType.changeoverTypeTimesKey])
      // console.log('The result is : => ', checkRes)
      const ChangeOverTypeExists = checkRes.rows[0].changeovertype_exists

      if (!ChangeOverTypeExists) {
        // Insert the new plant
        const insertRes = await tClient.query(insertQuery, values)
        return insertRes.rows[0]
      }
      return null // Return null if the plant already exists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }

  async createChangeOverTypes (changeoverTypes, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."ChangeOverTypes"
          WHERE FromModel = $1
          AND ToModel = $2
          AND ChangeOverType = $3
    ) AS ChangeOverTypeExists;
    `
    const insertQuery = `
    INSERT INTO ${this.schema}."ChangeOverTypes" (
      FromModel,
      ToModel,
      changeoverType
    ) VALUES (
      $1, $2, $3
    )
    RETURNING *;
  `

    const ChangeOverValues = [
      changeoverTypes.fromTypes,
      changeoverTypes.toTypes,
      changeoverTypes.Val
    ]

    // console.log('Inside the function createPlant')
    let tClient = null

    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery,
        [changeoverTypes.fromTypes, changeoverTypes.toTypes, changeoverTypes.Val]
      )
      const ChangeOverTypeExists = checkRes.rows[0].changeovertypeexists

      if (!ChangeOverTypeExists) {
        const insertRes = await tClient.query(insertQuery, ChangeOverValues)
        return insertRes.rows[0]
      }
      return null // Return null if the plant already exists
    } catch (err) {
      console.error('Error inserting user',
        changeoverTypes.fromTypes,
        changeoverTypes.toTypes,
        changeoverTypes.Val,
        err.stack
      )
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }
}

module.exports = {
  ChangeOverTypeTimes
}
