exports.stopageByLine = function (lineId, lineName, stop) {
  this.lineId = lineId;
  this.lineName = lineName;
  this.stop = stop;
};

exports.stopageByMachine = function (machineId, machineTypeId, stop) {
  this.machineId = machineId;
  this.machineTypeId = machineTypeId;
  this.stop = stop;
};

exports.stopageByMachineType = function (machineTypeId, machineTypeName, stop) {
  this.machineTypeId = machineTypeId;
  this.machineTypeName = machineTypeName;
  this.stop = stop;
};

exports.stopageByIssueType = function (issueTypeId, isuueName, stop) {
  this.issueTypeId = issueTypeId;
  this.isuueName = isuueName;
  this.stop = stop;
};

exports.changeOverStopageByModelNew = function (modelName, stop, count) {
  this.modelName = modelName;
  this.stop = stop;
  this.count = count;
};

exports.changeOverStopageByModel = function (modelName, stop) {
  this.modelName = modelName;
  this.stop = stop;
};

exports.action = function (id, action, incidentTime, targetTime, actualTime, by, parentId, markerMapper, rootCause, status, auxText) {
  this.id = id;
  this.action = action;
  this.time = incidentTime;
  this.targetTime = targetTime;
  this.actualTime = actualTime;
  this.by = by;
  this.parentId = parentId;
  this.markerMapper = markerMapper;
  this.rootCause = rootCause;
  this.status = status;
  this.auxText = auxText;
};
