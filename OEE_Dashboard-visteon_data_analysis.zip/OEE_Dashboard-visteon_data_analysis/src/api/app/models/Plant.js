const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class Plant {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createPlant (plant, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."Plants" WHERE plantName = $1
    ) AS plant_exists;
    `

    const insertQuery = `
      INSERT INTO ${this.schema}."Plants" (
        plantName,
        ancillaryplantdatafile
      ) VALUES (
        $1, $2
      )
      RETURNING *;
    `

    const values = [
      plant.plantName,
      plant.plantDataFile
    ]

    // console.log('Inside the function createPlant')
    let tClient = null

    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery, [plant.plantName])
      // console.log('The result is : => ', checkRes)
      const plantExists = checkRes.rows[0].plant_exists

      if (!plantExists) {
        // Insert the new plant
        const insertRes = await tClient.query(insertQuery, values)
        return insertRes.rows[0]
      }
      return null // Return null if the plant already exists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }
}

module.exports = {
  Plant
}
