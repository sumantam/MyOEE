const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class MachineType {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createMachineType (MachineType, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."MachineTypes" WHERE MachineName = $1
    ) AS machinetype_exists;
    `

    const insertQuery = `
      INSERT INTO ${this.schema}."MachineTypes" (
        MachineName,
        ManufacturersCycleTime
      ) VALUES (
        $1, $2
      )
      RETURNING *;
    `

    const values = [
      MachineType.MachineName,
      MachineType.CycleTime
    ]

    // console.log('Inside the function createMachineType')
    let tClient = null

    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client
      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery, [MachineType.MachineName])
      // console.log('The result is : => ', checkRes)
      const machineTypeExists = checkRes.rows[0].machinetype_exists

      if (!machineTypeExists) {
        // Insert the new plant
        const insertRes = await tClient.query(insertQuery, values)
        return insertRes.rows[0]
      }
      return null // Return null if the machineType already exists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }
}

module.exports = {
  MachineType
}
