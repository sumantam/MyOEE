const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class StdCycleTimes {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createStdCycleTimes (stdcycleTimes, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."StdCycleTimes"
        WHERE Plant = $1
        AND LIne = $2
        AND Model = $3
    ) AS StdCycleTimes_exists;
    `

    const insertQuery = `
      INSERT INTO ${this.schema}."StdCycleTimes" (
        Plant,
        Line,
        Model,
        ModelId,
        LineId,
        CycleTime
      ) VALUES (
        $1,
        $2,
        $3,
        $4,
        $5,
        $6
      )
      RETURNING *;
    `

    // console.log('Inside the function createPlant')
    let tClient = null

    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      let ModelId = await tClient.query(`
        SELECT modelId from ${this.schema}."Models"
        WHERE ModelName= $1
      `, [stdcycleTimes.Model])

      ModelId = ModelId.rows[0].modelid

      let PlantId = await tClient.query(`
        SELECT plantId from ${this.schema}."Plants"
        WHERE PlantName= $1
      `, [stdcycleTimes.Plant])

      PlantId = PlantId.rows[0].plantid

      // console.log('The plantid is : ', PlantId)

      let LineId = await tClient.query(`
        SELECT lineId from ${this.schema}."Lines"
        WHERE LineName = $1
        AND "locId" = $2
      `, [stdcycleTimes.Line, PlantId])

      LineId = LineId.rows[0].lineid

      // console.log('The lineId is ', LineId)
      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery,
        [
          stdcycleTimes.Plant,
          stdcycleTimes.Line,
          stdcycleTimes.Model
        ]
      )

      const StdCycleTimesExists = checkRes.rows[0].stdcycletimes_exists

      if (!StdCycleTimesExists && ModelId && LineId) {
        // Insert the new plant

        // console.log('The values are', ModelId, 'and', LineId)
        const values = [
          stdcycleTimes.Plant,
          stdcycleTimes.Line,
          stdcycleTimes.Model,
          ModelId,
          LineId,
          stdcycleTimes.CycleTime
        ]

        const insertRes = await tClient.query(insertQuery, values)
        return insertRes.rows[0]
      }
      return null // Return null if the plant already exists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }

  // async createChangeOverTypes (changeoverTypes, client = null) {
  //   const checkQuery = `
  //   SELECT EXISTS (
  //       SELECT 1 FROM ${this.schema}."ChangeOverTypes"
  //         WHERE FromModel = $1
  //         AND ToModel = $2
  //         AND ChangeOverType = $3
  //   ) AS ChangeOverTypeExists;
  //   `
  //   const insertQuery = `
  //   INSERT INTO ${this.schema}."ChangeOverTypes" (
  //     FromModel,
  //     ToModel,
  //     changeoverType
  //   ) VALUES (
  //     $1, $2, $3
  //   )
  //   RETURNING *;
  // `

  //   const ChangeOverValues = [
  //     changeoverTypes.fromTypes,
  //     changeoverTypes.toTypes,
  //     changeoverTypes.Val
  //   ]

  //   // console.log('Inside the function createPlant')
  //   let tClient = null

  //   try {
  //     const pgPoolsInstance = await PgPools.getInstance()
  //     tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

  //     // Check if the plant already exists
  //     const checkRes = await tClient.query(checkQuery,
  //       [changeoverTypes.fromTypes, changeoverTypes.toTypes, changeoverTypes.Val]
  //     )
  //     const ChangeOverTypeExists = checkRes.rows[0].changeovertypeexists

  //     if (!ChangeOverTypeExists) {
  //       const insertRes = await tClient.query(insertQuery, ChangeOverValues)
  //       return insertRes.rows[0]
  //     }
  //     return null // Return null if the plant already exists
  //   } catch (err) {
  //     console.error('Error inserting user',
  //       changeoverTypes.fromTypes,
  //       changeoverTypes.toTypes,
  //       changeoverTypes.Val,
  //       err.stack
  //     )
  //     throw err
  //   } finally {
  //     if (client == null && tClient) {
  //       tClient.release()
  //     }
  //   }
  // }
}

module.exports = {
  StdCycleTimes
}
