const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class LineShiftTime {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createLineShiftTime (LineShiftTime, client = null) {
    const checkQuery = `
        SELECT OwnerId FROM ${this.schema}."ShiftOwners" WHERE OwnerName = $1;
    `
    const insertQuery = `
      SELECT FROM  InsertShiftOwner($1,$2);
    `

    const checkQueryLineShift = `
        SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."LineShiftTimes" WHERE Id = $1
    ) AS lineshiftowner_exists;
    `
    const insertQueryLineShift = `
      INSERT INTO ${this.schema}."LineShiftTimes" (
        Id,
        ShiftName,
        Start,
        Stop,
        ShiftOwnerId,
        Line,
        UTCOffset
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7
      )
      RETURNING *;
    `
    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      // Insert the new shift owner
      await tClient.query(insertQuery, [LineShiftTime.ShiftOwner, this.schema])

      const ShiftOwnerId = (await tClient.query(checkQuery, [LineShiftTime.ShiftOwner])).rows[0].ownerid
      //
      const values = [
        LineShiftTime.Id,
        LineShiftTime.ShiftName,
        LineShiftTime.Start,
        LineShiftTime.Stop,
        ShiftOwnerId,
        LineShiftTime.Line,
        LineShiftTime.UTCOffset
      ]

      const checkLineShiftTime = await tClient.query(checkQueryLineShift, [LineShiftTime.Id])
      // console.log('The result is : => ', checkRes)
      let LineShiftTimeExists = checkLineShiftTime.rows[0].lineshiftowner_exists

      if (!LineShiftTimeExists) {
        // Insert the new shift owner
        const insertRes = await tClient.query(insertQueryLineShift, values)
        LineShiftTimeExists = insertRes.rows[0]
        return LineShiftTimeExists
      }
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }

  // async createLineShiftTime (LineShiftTime, client = null) {
  //   const checkQuery = `
  //       SELECT OwnerId FROM ${this.schema}."ShiftOwners" WHERE OwnerName = $1;
  //   `
  //   const insertQuery = `
  //     INSERT INTO ${this.schema}."ShiftOwners" (
  //       OwnerId,
  //       OwnerName
  //     )
  //     SELECT
  //       nextval('${this.schema}.ShiftOwnerId_seq'),
  //       $1
  //     RETURNING OwnerId;
  //   `

  //   const checkQueryLineShift = `
  //       SELECT EXISTS (
  //       SELECT 1 FROM ${this.schema}."LineShiftTimes" WHERE Id = $1
  //   ) AS lineshiftowner_exists;
  //   `
  //   const insertQueryLineShift = `
  //     INSERT INTO ${this.schema}."LineShiftTimes" (
  //       Id,
  //       ShiftName,
  //       Start,
  //       Stop,
  //       ShiftOwnerId,
  //       Line,
  //       UTCOffset
  //     ) VALUES (
  //       $1, $2, $3, $4, $5, $6, $7
  //     )
  //     RETURNING *;
  //   `
  //   let tClient = null
  //   let retries = 3
  //   try {
  //     const pgPoolsInstance = await PgPools.getInstance()
  //     tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client
  //     // Check if the shiftowner already exists
  //     while (retries > 0) {
  //       try {
  //         const checkRes = await tClient.query(checkQuery, [LineShiftTime.ShiftOwner])
  //         // console.log('The result is : => ', checkRes)
  //         let ShiftOwnerId = checkRes.rows.length > 0 ? checkRes.rows[0].ownerid : null

  //         if (!ShiftOwnerId) {
  //           // Insert the new shift owner
  //           const insertRes = await tClient.query(insertQuery, [LineShiftTime.ShiftOwner])
  //           ShiftOwnerId = insertRes.rows.length > 0
  //             ? insertRes.rows[0].ownerid
  //             : (await tClient.query(checkQuery, [LineShiftTime.ShiftOwner])).rows[0].ownerid
  //         }

  //         const values = [
  //           LineShiftTime.Id,
  //           LineShiftTime.ShiftName,
  //           LineShiftTime.Start,
  //           LineShiftTime.Stop,
  //           ShiftOwnerId,
  //           LineShiftTime.Line,
  //           LineShiftTime.UTCOffset
  //         ]

  //         const checkLineShiftTime = await tClient.query(checkQueryLineShift, [LineShiftTime.Id])
  //         // console.log('The result is : => ', checkRes)
  //         let LineShiftTimeExists = checkLineShiftTime.rows[0].lineshiftowner_exists

  //         if (!LineShiftTimeExists) {
  //           // Insert the new shift owner
  //           const insertRes = await tClient.query(insertQueryLineShift, values)
  //           LineShiftTimeExists = insertRes.rows[0]
  //           return LineShiftTimeExists
  //         }

  //         return null
  //       } catch (err) {
  //         if (retries > 0) {
  //           retries -= 1
  //           console.log('Retrying due to OCC conflict:', err.message)
  //           continue
  //         } else {
  //           throw err
  //         }
  //       }
  //     }
  //   } catch (err) {
  //     console.error('Error inserting user', err.stack)
  //     throw err
  //   } finally {
  //     if (client == null && tClient) {
  //       tClient.release()
  //     }
  //   }
  // }
}

module.exports = {
  LineShiftTime
}
