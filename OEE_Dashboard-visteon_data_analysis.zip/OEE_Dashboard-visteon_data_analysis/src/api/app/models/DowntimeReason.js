const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class DowntimeReason {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createDowntimeReason (downtimeReason, client = null) {
    const checkQuery = `
        SELECT downtimeReasonId FROM ${this.schema}."DowntimeReasons" WHERE downtimeReasonId = $1 AND actionId = $2;
    `

    const insertQuery = `
      INSERT INTO ${this.schema}."DowntimeReasons" (
          downtimeReasonId,
          class,
          rootCause,
          context,
          actionId,
          description
      ) VALUES (
        $1, $2, $3, $4, $5, $6
      )
      RETURNING *;
    `

    const values = [
      downtimeReason.downtimeReasonId,
      downtimeReason.class,
      downtimeReason.rootCause,
      downtimeReason.context,
      downtimeReason.actionId,
      downtimeReason.desc
    ]

    // console.log('Inside the function createDowntimeReason and insert query', insertQuery)
    let tClient

    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      let downtimeReasonExists = null
      let retryCount = 3
      // Check if the downtime instance already exists
      while (!downtimeReasonExists && retryCount > 0) {
        const checkRes = await tClient.query(checkQuery, [downtimeReason.downtimeReasonId, downtimeReason.actionId])
        downtimeReasonExists = (checkRes.rowCount > 0) ? checkRes.rows[0].downtimereasonid : null
        retryCount = retryCount - 1
      }

      if (!downtimeReasonExists) {
        // Insert the new plant
        const insertRes = await tClient.query(insertQuery, values)
        downtimeReasonExists = insertRes.rowCount > 0
          ? insertRes.rows[0].downtimereasonid
          : (await tClient.query(checkQuery, [downtimeReason.downtimeReasonId, downtimeReason.actionId])).rows[0].downtimereasonid
        return insertRes.rows[0]
      }
      return null
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }

  getTimeStamp(dateString) {
    if (dateString.indexOf(':') === -1) {
      const firstPart = dateString.substring(0, dateString.indexOf('T') + 1)
      const secondPart = dateString.substring(dateString.indexOf('T') + 1)
      const modifiedSecondPart = secondPart.match(/.{1,2}/g).join(":")
      return Date.parse(new Date(firstPart + modifiedSecondPart)) / 1000
    }
    else
      return Date.parse(new Date(dateString)) / 1000
  }
}

module.exports = {
  DowntimeReason
}
