exports.commonChartModel = function (value, marker, yValues) {
  this.value = value;
  this.marker = marker;
  this.dataPoints = yValues; //yValues.map((i) => new dataPoint(i.value, i.marker));
};

exports.dataPoint = function (marker, value) {
  this.marker = marker;
  this.value = value;
};
