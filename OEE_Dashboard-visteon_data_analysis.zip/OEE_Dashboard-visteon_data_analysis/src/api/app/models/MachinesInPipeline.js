const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

function getSubstitutedQuery(query, params) {
  return query.replace(/\$(\d+)/g, (_, index) => {
    const param = params[index - 1]
    return param === null ? 'NULL' : `'${param}'`
  })
}

class MachinesInPipeline {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createMachineInPipeline (MachineInPipeline, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."MachinesInPipeline" WHERE Id = $1
    ) AS machineinpipeline_exists;
    `

    const checkPrevQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."MachinesInPipeline"
        WHERE ($1 IS NULL)
          OR  ($1 IS NOT NULL AND Id = $1)
    )
    OR NOT EXISTS (
    SELECT 1
    FROM ${this.schema}."MachinesInPipeline"
    ) AS prevmachineinpipeline_exists;
    `

    const insertQuery = `
      INSERT INTO ${this.schema}."MachinesInPipeline" (
        Id,
        LineId,
        MachineType,
        PreviousMachineId,
        MachineName,
        PrecedingConveyorSize,
        ExpectedCycleTime
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7
      )
      RETURNING *;
    `

    const values = [
      MachineInPipeline.Id,
      MachineInPipeline.Line,
      MachineInPipeline.MachineType,
      MachineInPipeline.PreviousMachineId !== 'NONE' ? MachineInPipeline.PreviousMachineId : null,
      MachineInPipeline.MachineName,
      MachineInPipeline.PrecedingConveyorSize,
      MachineInPipeline.ExpectedCycleTime
    ]

    // console.log('Inside the function createMachineInPipeline')
    let tClient = null

    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client
      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery, [MachineInPipeline.Id])
      // console.log('The result is : => ', checkRes)
      const machineInPipelineExists = checkRes.rows[0].machineinpipeline_exists

      if (!machineInPipelineExists) {
        // Insert the new plant
        // console.log('Values :', values)
        let loopCnt = 3

        while (loopCnt >= 0) {
          const vv = [
            MachineInPipeline.PreviousMachineId !== 'NONE' ? MachineInPipeline.PreviousMachineId : null
          ]

          const substitutedPrevQuery = getSubstitutedQuery(checkPrevQuery, vv)
          console.log('Substituted checkPrevQuery:', substitutedPrevQuery)

          const prevMachRes = await tClient.query(substitutedPrevQuery) // checkPrevQuery, vv
          const prevmachineInPipelineExists = prevMachRes.rows[0].prevmachineinpipeline_exists

          if (prevmachineInPipelineExists) {
            const insertRes = await tClient.query(insertQuery, values)
            return insertRes.rows[0]
          }

          --loopCnt
        }
      }
      return null // Return null if the machineType already exists
    } catch (err) {
      console.error('Error inserting user', err.stack, values)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }
}

module.exports = {
  MachinesInPipeline
}
