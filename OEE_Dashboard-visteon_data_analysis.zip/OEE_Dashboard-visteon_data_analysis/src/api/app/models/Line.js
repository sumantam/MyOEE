const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class Line {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createLine (Line, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."Lines" WHERE lineId = $1
    ) AS line_exists;
    `
    const insertQuery = `
      INSERT INTO ${this.schema}."Lines" (
        lineId,
        lineName,
        "locId"
      ) VALUES (
        $1, $2, $3
      )
      RETURNING *;
    `

    const values = [
      Line.lineId,
      Line.lineName,
      Line.locId
    ]

    // console.log('Inside the function createLine')

    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery, [Line.lineId])
      // console.log('The result is : => ', checkRes)
      const lineExists = checkRes.rows[0].line_exists

      if (!lineExists) {
      // Insert the new plant
        const insertRes = await tClient.query(insertQuery, values)
        return insertRes.rows[0]
      }
      return null // Return null if the line already exists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }
}

module.exports = {
  Line
}
