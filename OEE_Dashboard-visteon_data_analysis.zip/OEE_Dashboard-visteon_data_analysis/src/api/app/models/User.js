const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')
// const { DataTypes } = require("sequelize");
// const sequelize = require('../utils/database')

dotenv.config({ path: path.resolve(__dirname, '../../.env.sample') })

class User {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async create (user, transaction) {
    const query1 = `
      INSERT INTO "${this.schema}"."Users" (
      email,
      name,
      role,
      responsibility,
      designation,
      countryCode,
      mobileNumber,
      img,
      location)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *;`

    const query2 = `
      INSERT INTO "${this.schema}"."Authenticator" (
      "userEmail",
      password
      )
      VALUES ($1, $2)
      RETURNING *;`

    const img = JSON.stringify(user.img)
    const values = [
      user.email, user.name, user.role, user.responsibility,
      user.designation, user.countryCode, user.mobileNumber,
      img, user.location
    ]

    try {
      // console.log('Query : ', query, ' values: ', values)
      const res = await transaction.query(query1, values)
      await transaction.query(query2, [user.email, user.password])
      return res.rows[0]
    } catch (err) {
      console.error('Error creating user', err.stack)
      throw err
    }
  }

  async update (user, oldEmail, transaction) {
  //
  // The user should have the following
  // user = {
  //    email,
  //    name,
  //    role,
  //    responsibility,
  //    designation,
  //    countryCode,
  //    mobileNumber,
  //    img,
  //    location
  // }
  //

    const query = `
      SELECT * from public."updateUser" (
        $1::VARCHAR,
        $2::VARCHAR,
        $3::VARCHAR,
        $4::VARCHAR,
        $5::VARCHAR,
        $6::VARCHAR,
        $7::VARCHAR,
        $8::VARCHAR,
        $9::INTEGER,
        $10::INTEGER,
        $11::VARCHAR
      )
      RETURNING *;`

    const query2 = `
      UPDATE "${this.schema}"."Authenticator"
        SET "userEmail"   = $1::VARCHAR
        WHERE "userEmail" = $2::VARCHAR
    `

    const values = [
      'Users', this.schema, oldEmail,
      user.email, user.name, user.role, user.responsibility,
      user.designation, user.countryCode, user.mobileNumber,
      user.location
    ]

    try {
      await transaction.query(query2, [user.email, oldEmail])
      const res = await transaction.query(query, values)
      return res.rows[0]
    } catch (err) {
      console.error('Error creating user', err.stack)
      throw err
    }
  }

  async findByPrimaryKey (email) {
    console.log('Target Schema ', this.schema)
    console.log('User Email ', email)

    console.log('Entering the function findByPrimaryKey ')
    const query = `
        SELECT * from public."findByPrimaryKey"
        (
          $1::VARCHAR,
          $2::VARCHAR,
          $3::VARCHAR,
          $4::VARCHAR,
          $5::VARCHAR
        )
        AS (
          email VARCHAR,
          name VARCHAR
        );
        `

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const data = await client.query(query, ['Users', 'email', email, this.schema, 'email, name'])
    client.release()
    return data.rows
  }

  async findAll () {
    console.log('Entering the function findAll ')
    const query = `
        SELECT * from public."findAll"
        (
          $1::VARCHAR,
          $2::VARCHAR,
          $3::VARCHAR
        )
        AS (
          email VARCHAR,
          name VARCHAR
        );
        `

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const data = await client.query(query, ['Users', this.schema, 'email, name'])
    client.release()
    return data.rows
  }

  async findByResponsibility (responsibility) {
    console.log('Entering the function findByResponsibility ')
    const query = `
        SELECT * from public."findByResponsibility"
        (
          $1::VARCHAR,
          $2::VARCHAR,
          $3::VARCHAR,
          $4::VARCHAR
        )
        AS (
          email VARCHAR,
          name VARCHAR,
          role VARCHAR,
          responsibility VARCHAR
        );
        `

    const pgPoolsInstance = await PgPools.getInstance()
    const client = await pgPoolsInstance.getPool(dbConfig.DB).getClient()
    const data = await client.query(query,
      ['Users', responsibility, this.schema, 'email, name, role, responsibility'])
    client.release()
    return data.rows
  }
}

module.exports = {
  User
}
