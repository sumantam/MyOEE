const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class Production {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createProduction (ProductionData, client = null) {
    const insertQueryShift = `
      SELECT FROM insertShifts ( $1, $2, $3, $4, $5, $6, $7, $8);
    `
    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      const values = [
        ProductionData.ShiftId,
        ProductionData.LineShiftPlanId,
        ProductionData.ChangeoverTimeStart,
        ProductionData.ChangeoverTimeEnd,
        ProductionData.Planned,
        ProductionData.Total,
        ProductionData.TotalOK,
        this.schema
      ]

      const insertRes = await tClient.query(insertQueryShift, values)
      const ShiftExists = insertRes.rows[0]
      return ShiftExists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }

  async createRuns (RunData, client = null) {
    const insertQueryRun = `
      SELECT FROM insertRuns ( $1, $2, $3, $4, $5, $6, $7, $8, $9, $10);
    `
    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      const values = [
        RunData.ProdShiftId,
        RunData.Barcode,
        RunData.RunNumber,
        RunData.EntryMachineId,
        RunData.ExitMachineId,
        RunData.EntryMachineTimestamp,
        RunData.ExitMachineTimestamp,
        RunData.Status,
        RunData.OtherInfo,
        this.schema
      ]

      const insertRes = await tClient.query(insertQueryRun, values)
      const RunExists = insertRes.rows[0]
      return RunExists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }

  async createMicroStops (MicroStopData, client = null) {
    const chkQueryMicroStop = `
      SELECT RunId FROM ${this.schema}."Runs" WHERE Barcode = $1 AND RunNumber = $2;
    `

    const insertQueryMicroStop = `
      SELECT FROM insertMicroStops ( $1, $2, $3, $4, $5, $6, $7, $8, $9, $10);
    `
    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client
      const queryRes = await tClient.query(chkQueryMicroStop, [MicroStopData.Barcode, MicroStopData.RunNumber])

      const runId = queryRes.rows.length > 0 ? queryRes.rows[0].runid : null

      if (!runId) {
        throw new Error(`No Run found for Barcode: ${MicroStopData.Barcode} and RunNumber: ${MicroStopData.RunNumber}`)
      }

      const values = [
        runId,
        MicroStopData.DowntimeInstanceId,
        MicroStopData.MachinesInPipelineId,
        MicroStopData.DowntimeReasonId,
        MicroStopData.FromTime,
        MicroStopData.ToTime,
        MicroStopData.Issue,
        MicroStopData.Action,
        MicroStopData.ActionTime || null,
        this.schema
      ]

      const insertRes = await tClient.query(insertQueryMicroStop, values)
      const MicroStopExists = insertRes.rows[0]
      return MicroStopExists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }

  async createBreakdown (BreakdownData, client = null) {
    const insertQueryBreakdown = `
      SELECT FROM insertBreakdowns ( $1, $2, $3, $4, $5, $6, $7, $8, $9, $10);
    `
    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      const values = [
        BreakdownData.ShiftId,
        BreakdownData.DowntimeInstanceId,
        BreakdownData.MachinesInPipelineId,
        BreakdownData.DowntimeReasonId,
        BreakdownData.FromTime,
        BreakdownData.ToTime,
        BreakdownData.Issue,
        BreakdownData.ActionId,
        BreakdownData.ActionTime,
        this.schema
      ]

      const insertRes = await tClient.query(insertQueryBreakdown, values)
      const BreakdownExists = insertRes.rows[0]
      return BreakdownExists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }

  async createRunSummary (client = null) {
    const insertQueryRunSummary = `
      SELECT FROM insertRunSummary (
        $1
      );
    `

    // const lineQueryRunSummary = `
    //   SELECT * FROM  RunSummaryData ($1, $2);
    // `

    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client

      const insertRes = await tClient.query(insertQueryRunSummary, [this.schema])
      const RunSummaryExists = insertRes.rows[0]
      return RunSummaryExists

      // const runSummaryRes = await tClient.query(lineQueryRunSummary, [RunData.ProdShiftId, this.schema])
      // let retryCount = 3

      // while (retryCount > 0) {
      //   if (runSummaryRes.rows[0]) {
      //     const lineid = runSummaryRes.rows[0].lineid
      //     const line = runSummaryRes.rows[0].line
      //     const plantname = runSummaryRes.rows[0].plantname
      //     const toproduce = runSummaryRes.rows[0].toproduce

      //     const RunSummaryValues = [
      //       RunData.ProdShiftId,
      //       lineid,
      //       line,
      //       plantname,
      //       toproduce,
      //       RunData.EntryMachineTimestamp,
      //       RunData.ExitMachineTimestamp,
      //       RunData.Status,
      //       RunData.OtherInfo,
      //       this.schema
      //     ]

      //     const insertRes = await tClient.query(insertQueryRunSummary, RunSummaryValues)
      //     const RunSummaryExists = insertRes.rows[0]
      //     return RunSummaryExists
      //   }
      //   retryCount = retryCount - 1
      // }
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }
}

module.exports = {
  Production
}
