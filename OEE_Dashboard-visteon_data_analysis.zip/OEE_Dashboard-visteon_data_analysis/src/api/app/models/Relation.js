const dotenv = require('dotenv')
const path = require('path')
const format = require('pg-format')
const { DataTypes } = require('sequelize')
const sequelize = require('../utils/database')
// const StateTable = require("./stateTable.model");

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

class Relation {
  schema = 'public'

  constructor (schemaName = 'public') {
    this.schema = schemaName
  }

  async bulkCreate (relations, transaction) {
    if (relations.length === 0) {
      console.log('No relations to insert.')
      return []
    }

    const query = `
      INSERT INTO "${this.schema}"."Relation" (
      "userEmail",
      "managerEmail")
      VALUES %L
      RETURNING *;`

    const values = relations.map((relation) => [
      relation.userEmail,
      relation.managerEmail
    ])

    const formattedValues = values.map(
      innerArray => innerArray.map(
        element => format.literal(element) // Properly escape and quote each element
      ).join(', ')
    ).join('), (')

    // Wrap the result in the desired parentheses
    const Val = `(${formattedValues})`
    const formattedQuery = query.replace('%L', Val)

    // console.log(' formattedValues : ', formattedValues, 'formattedQuery', formattedQuery, ' values ', values, 'Val :', Val)

    try {
      const res = await transaction.query(formattedQuery)
      return res.rows
    } catch (err) {
      console.error('Error inserting relations', err.stack)
      throw err
    }
  }
}

// creating Relations table
const RelationModel = sequelize.define(
  'Relation',
  {
    userEmail: {
      type: DataTypes.STRING,
      allowNull: false,
      managerEmail: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: 'HR'
      }
    },

    // Composite Indexing
    indexes: [
      {
        unique: true,
        fields: ['managerEmail', 'userEmail']
      }
    ]
  }

)

module.exports = {
  Relation,
  RelationModel
}
