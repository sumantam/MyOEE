const dotenv = require('dotenv')
const path = require('path')
const { PgPools } = require('../utils/pgPool')
const dbConfig = require('../config/db.config')

dotenv.config({ path: path.resolve(__dirname, '../../.env') })

function convertToJSON (IssueTypeName, MachineName, Issues) {
  const result = []
  if (Issues == null) {
    return result
  }

  Issues.forEach(issue => {
    const res = {
      MachineName,
      IssueTypeName,
      IssueDescription: issue
    }
    result.push(res)
  })

  return result
}

class IssueType {
  schema = 'public'

  constructor (schemaName = 'public') { this.schema = schemaName }

  async createIssueType (IssueTypeName, MachineName, Issues, client = null) {
    const checkQuery = `
    SELECT EXISTS (
        SELECT 1 FROM ${this.schema}."Issues" WHERE MachineName = $1
        AND IssueTypeName = $2
    ) AS issuetype_exists;
    `

    const insertQuery = `
      SELECT insert_bulk_issues (
      $1::jsonb,
      $2
      );
    `
    let tClient = null
    try {
      const pgPoolsInstance = await PgPools.getInstance()
      tClient = (client == null) ? await pgPoolsInstance.getPool(dbConfig.DB).getClient() : client
      // Check if the plant already exists
      const checkRes = await tClient.query(checkQuery, [MachineName, IssueTypeName])
      // console.log('The result is : => ', checkRes)
      const issueTypeExists = checkRes.rows[0].issuetype_exists
      const issues = convertToJSON(IssueTypeName, MachineName, Issues)

      if ((!issueTypeExists) && (issues.length !== 0)) {
        // Insert the new plant

        const issuesJson = JSON.stringify(issues)
        const insertRes = await tClient.query(insertQuery, [issuesJson, this.schema])
        return insertRes.rows[0]
      }
      return null // Return null if the machineType already exists
    } catch (err) {
      console.error('Error inserting user', err.stack)
      throw err
    } finally {
      if (client == null && tClient) {
        tClient.release()
      }
    }
  }
}

module.exports = {
  IssueType
}
