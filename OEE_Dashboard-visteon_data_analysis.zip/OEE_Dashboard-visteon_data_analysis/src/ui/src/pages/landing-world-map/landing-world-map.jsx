import { Box } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { themeSelector, plantsSelector, setPlantFilter, setPlantNameFilter, dateSelector } from "../../reducers/filter-reducer";
import { fetchOeeDataForMap } from "../../reducers/oee-accelerator-reducer";
import oeeAcceleratorService from "../../services/oee-accelerator-service";
import WorldMap from "../../components/world-map/world-map";
import Loader from "../../components/loader/loader";
import UtilityMethods from "../../utilities";

const LandingWorldMap = () => {
    const dispatch = useDispatch();
    const theme = useSelector(themeSelector);
    const dateParam = useSelector(dateSelector);
    const plants = useSelector(plantsSelector);
    const [plantsWithOEEData, setPlantsWithOEEData] = useState([]);
    const [markerBackground, setMarkerBackground] = useState([]);
    const [allDataLoaded, setAllDataLoaded] = useState(false);
    const rangeForOee = [0, 70, 85, 100];
    const rangeForActual = [0, 94, 96, 100];

    const getColorForOee = (oee) => {
        let color = null;
        if (oee > 0) {
            if (oee < rangeForOee[1]) color = theme["colors"]["redGradientColor"][0]
            else if (oee >= rangeForOee[1] && oee < rangeForOee[2]) color = theme["colors"]["yellowGradientColor"][0]
            else color = theme["colors"]["greenGradientColor"][0];
        }
        else color = "black";
        return color;
    }

    const getColorForActual = (plan, actual) => {
        let color = null;
        if (plan > 0) {
            let adjustedAdherence = UtilityMethods.getAdjustedAdherence(plan, actual);
            if (adjustedAdherence < rangeForActual[1]) color = theme["colors"]["redGradientColor"][0];
            else if (adjustedAdherence >= rangeForActual[1] && adjustedAdherence < rangeForActual[2]) color = theme["colors"]["yellowGradientColor"][0];
            else color = theme["colors"]["greenGradientColor"][0];
        }
        else color = "black";
        return color;
    }

    useEffect(() => {
        setAllDataLoaded(false);
        dispatch(setPlantFilter(null));
        dispatch(setPlantNameFilter(null));
        let locPlantsWithOeeData = [];
        let locMarkerBackground = [];
        plants.forEach(async (plant, i) => {
           
            let dayObject = {
                "oee": 0,
                "planned": 0,
                "actual": 0,
                "bgColorForOee": "black",
                "bgColorForActual": "black"
            }

            let weekObject = {
                "oee": 0,
                "planned": 0,
                "actual": 0,
                "bgColorForOee": "black",
                "bgColorForActual": "black"
            }
            let plantObject = {
                "name": plant["Name"],
                "id": plant["Id"],
                "lat": plant["Lat"],
                "long": plant["Long"],
                "lastDayData": dayObject,
                "lastWeekData": weekObject,
                "tooltipBackground": theme["colors"]["colorShades"][5]
            }
            const parallelApiCallsResultForDay = await dispatch(
                fetchOeeDataForMap({ plant: plant["Name"], tq: "day", date: dateParam })
            ).unwrap();

            if (parallelApiCallsResultForDay.data !== undefined) {
                let allData = parallelApiCallsResultForDay.data;

                if (allData[0]?.data?.Lines !== undefined) {
                    dayObject["oee"] = allData[0].data.Lines.OEE;
                    dayObject["bgColorForOee"] = getColorForOee(allData[0].data.Lines.OEE)
                }
                if (allData[1]?.data?.viewByLineObjects?.length > 0) {
                    dayObject["actual"] = allData[1].data.viewByLineObjects[0].actual;
                    dayObject["planned"] = allData[1].data.viewByLineObjects[0].plan;
                    dayObject["bgColorForActual"] = getColorForActual(allData[1].data.viewByLineObjects[0].plan, allData[1].data.viewByLineObjects[0].actual);
                }
            }

            const parallelApiCallsResultForWeek = await dispatch(
                fetchOeeDataForMap({ plant: plant["Name"], tq: "week", date: dateParam })
            ).unwrap();

            if (parallelApiCallsResultForWeek.data !== undefined) {
                let allData = parallelApiCallsResultForWeek.data;
                if (allData[0]?.data?.Lines !== undefined) {
                    weekObject["oee"] = allData[0].data.Lines.OEE;
                    weekObject["bgColorForOee"] = getColorForOee(allData[0].data.Lines.OEE)
                }
                if (allData[1]?.data?.viewByLineObjects?.length > 0) {
                    weekObject["actual"] = allData[1].data.viewByLineObjects[0].actual;
                    weekObject["planned"] = allData[1].data.viewByLineObjects[0].plan;
                    weekObject["bgColorForActual"] = getColorForActual(allData[1].data.viewByLineObjects[0].plan, allData[1].data.viewByLineObjects[0].actual);
                }
            }

            locPlantsWithOeeData.push(plantObject)
            if (locPlantsWithOeeData.length === plants.length) {
                locMarkerBackground = locPlantsWithOeeData.map(p => p["lastDayData"]["bgColorForOee"])
                setPlantsWithOEEData(locPlantsWithOeeData);
                setMarkerBackground(locMarkerBackground);
                setAllDataLoaded(true);
            }

        })
    }, [dispatch])

    return (
        !allDataLoaded ? <Loader /> :
            <Box flexGrow={1}>
                <WorldMap
                    data={plantsWithOEEData}
                    markerBackground={markerBackground}
                    fontFamily={theme["fontFamily"]} />
            </Box>
    )
}

export default LandingWorldMap;