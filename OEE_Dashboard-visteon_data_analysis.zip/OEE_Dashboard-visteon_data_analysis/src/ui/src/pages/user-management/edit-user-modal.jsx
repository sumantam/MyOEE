import {
  Button,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControl,
  Chip,
  IconButton,
  InputLabel,
  MenuItem,
  Modal,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import { toast } from "react-toastify";
import userService from "../../services/user-service";
import CloseIcon from "@mui/icons-material/Close";
import { styled } from "@mui/system";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { updateUser } from "../../reducers/users-reducer";

const CustomModal = styled(Modal)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));
const ModalContent = styled("div")(({ theme }) => ({
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "400px",
  backgroundColor: "#F0F0FF",
  boxShadow: "0 2px 10px rgba(0, 0, 0, 0.2)",
  outline: "none",
  borderRadius: theme.shape.borderRadius,
  padding: theme.spacing(4),
}));

export const EditedUserModal = ({
  user,
  open,
  onClose,
  setIsEditModalOpen,
  isEditModalOpen,
}) => {
  console.log(onClose);
  console.log(setIsEditModalOpen);
  const dispatch = useDispatch();
  console.log(user);
  const [name, setName] = useState(user ? user.name : "test");
  console.log(name);
  const [email, setEmail] = useState(user ? user.email : "test");
  console.log(email);
  const [password, setPassword] = useState(user ? user.password : "");
  console.log(password);
  const [role, setRole] = useState(null);
  const [responsibility, setResponsibility] = useState(null);
  const [mobileNumber, setMobileNumber] = useState(null);
  const [selectedManager, setSelectedManager] = useState([]);
  const [selectedReportees, setSelectedReportees] = useState([]);
  const [location, setLocation] = useState(null);
  const [next, setNext] = useState(false);
  const [operatorReportees, setOperatorReportees] = useState([]);
  const [executiveReportees, setExecutiveReportees] = useState([]);
  const [supervisorReportees, setSupervisorReportees] = useState([]);
  const [mobileNumberError, setMobileNumberError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const operatorResponse = await userService.getResponsibilities(`Operator`);
        const executiveResponse = await userService.getResponsibilities('Executive');
        const supervisorResponse = await userService.getResponsibilities('Supervisor');
        console.log(operatorResponse.data);
        console.log(executiveResponse.data);
        console.log(supervisorResponse.data);

        // Update the corresponding state with the reportees from each API response
        setOperatorReportees(operatorResponse.data);
        setExecutiveReportees(executiveResponse.data);
        setSupervisorReportees(supervisorResponse.data);

        console.log(operatorReportees);
      } catch (error) {
        // Handle error if necessary
        console.log(error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    setEmail(user ? user.email : null);
    setName(user ? user.name : null);
    setMobileNumber(user ? user.mobileNumber : null);
    // setRole(user?user.role:null)
    // setResponsibility(user?user.responsibility:null)
    setLocation(user ? user.location : null);
    setPassword(user ? user.password : null);
  }, [isEditModalOpen]);

  const isEmailValid = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const isMobileNumberValid = (mobileNumber) => {
    return /^\d{10}$/.test(mobileNumber);
  };

  const handleEmailChange = (event) => {
    console.log(event);

    setEmail(event.target.value);
  };

  const handleMobileChange = (event) => {
    console.log(event);

    setMobileNumber(event.target.value);

    const isValidMobileNumber = /^\d{10}$/.test(event.target.value);
    if (isValidMobileNumber) {
      setMobileNumberError("");
    } else {
      setMobileNumberError("Please enter a valid 10-digit phone number.");
    }
  };

  const validateEmail = (email) => {
    // Basic email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleRoleChange = (event) => {
    console.log(event);

    setRole(event.target.value);
  };
  const handleResponsibilityChange = (event) => {
    console.log(event);

    setResponsibility(event.target.value);
  };

  const handleNext = () => {
    setNext(!next);
  };

  const handleReporteeSelection = (event) => {
    const selectedValue = event.target.value;
    const selectedValues = Array.isArray(selectedValue)
      ? selectedValue
      : [selectedValue];
    setSelectedReportees((prevSelected) => [
      ...prevSelected,
      ...selectedValues,
    ]);
  };

  const handleClose = () => {
    console.log("clicked");
    setNext(false);
    setIsEditModalOpen(!isEditModalOpen);
    setSelectedManager([]);
    setSelectedReportees([]);
  };

  const handleSave = async () => {
    setNext(false);
    const updatedUser = {
      data: {
        basic: {
          ...user.basic,
          name: name,
          role: role,
          password: password,
          responsibility: responsibility,
          countryCode: "91",
          mobileNumber: mobileNumber,
          email: email,
          designation: "Default",
          location: location,
        },
        img: null, // Keep the existing img value
        relation: {
          ...user.relation,
          mgrList: Array.isArray(selectedManager)
            ? selectedManager.map((manager) => ({
                email: manager.email,
              }))
            : [],
          reporteeList: selectedReportees.map((reportee) => ({
            email: reportee.email,
          })), // Add the selected reportees here
        },
      },
    };

    console.log("this is updated user ", updatedUser);
    try {
      const response = await userService.updateUser(user.email, updateUser);
      console.log(response);

      if (response.status === 200) {
        // User updated successfully
        dispatch(updateUser(updatedUser.data.basic));
        toast.success("Update successful ", {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        console.log("Update Successful");
        setIsEditModalOpen(false);
      } else {
        toast.error("Error ", {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        // Handle error response
        console.error("Error updating user:", response.statusText);
      }
    } catch (error) {
      // Handle network or other errors
      toast.error("Error ", {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      console.error("Error updating user:", error.message);
    }
  };

  return (
    <CustomModal open={open}>
      <ModalContent>
        <Typography variant="h5" gutterBottom>
          Edit User Details
        </Typography>
        <IconButton
          sx={{
            position: "absolute",
            top: "25px",
            right: "20px",
          }}
          edge="end"
          color="inherit"
          aria-label="close"
          onClick={handleClose}
        >
          <CloseIcon />
        </IconButton>
        <>
          {next === true && responsibility === "Supervisor" && (
            <>
              <FormControl fullWidth>
                <DialogTitle
                  sx={{
                    color: "#063c6f",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "flex-start",
                    alignItems: "center",
                  }}
                >
                  Supervisor
                </DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Fill in the following details
                  </DialogContentText>
                  <TextField
                    select
                    fullWidth
                    margin="normal"
                    size="small"
                    label="Manager"
                    onChange={(e) => setSelectedManager(e.target.value)}
                    sx={{ marginBottom: "1rem" }} // Add bottom margin for spacing
                  >
                    {executiveReportees
                      .filter((operator) => {
                        const isMatch = !operator.email
                          .toLowerCase()
                          .includes(user.email.toLowerCase());

                        console.log("Exec:", operator, "Match:", isMatch);

                        return isMatch;
                      })
                      .map((operator) => (
                        <MenuItem key={operator.name} value={operator}>
                          {`${operator.name} - ${operator.email}`}
                        </MenuItem>
                      ))}
                  </TextField>
                  <TextField
                    fullWidth
                    margin="normal"
                    id="reportees-select"
                    label="Reportees"
                    select
                    multiple
                    value={selectedReportees}
                    onChange={(e) => handleReporteeSelection(e)}
                    SelectProps={{
                      renderValue: (selected) => (
                        <div>
                          {Array.isArray(selected) ? (
                            selected.map((reportee) => (
                              <Chip key={reportee.name} label={reportee.name} />
                            ))
                          ) : (
                            <Chip key={selected.name} label={selected.name} />
                          )}
                        </div>
                      ),
                    }}
                  >
                    {operatorReportees
                      .filter((operator) => {
                        const isMatch = !operator.email
                          .toLowerCase()
                          .includes(user.email.toLowerCase());

                        console.log("Operator:", operator, "Match:", isMatch);

                        return isMatch;
                      })
                      .map((operator) => {
                        console.log("Filtered Operator:", operator);
                        return (
                          <MenuItem key={operator.name} value={operator}>
                            {`${operator.name} - ${operator.email}`}
                          </MenuItem>
                        );
                      })}
                  </TextField>
                </DialogContent>
                <DialogActions>
                  <Button
                    onClick={handleSave}
                    sx={{
                      background: "#063c6f",
                      color: "white",
                      "&:hover": {
                        background: "#06009a",
                      },
                    }}
                  >
                    Submit
                  </Button>
                </DialogActions>
              </FormControl>
            </>
          )}

          {next === true && responsibility === "Executive" && (
            <>
              <FormControl fullWidth>
                <DialogTitle
                  sx={{
                    color: "#063c6f",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "flex-start",
                    alignItems: "center",
                  }}
                >
                  Executive
                </DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Fill in the following details
                  </DialogContentText>
                  <TextField
                    fullWidth
                    margin="normal"
                    id="reportees-select"
                    label="Reportees"
                    select
                    multiple
                    value={selectedReportees}
                    onChange={(e) => handleReporteeSelection(e)}
                    SelectProps={{
                      renderValue: (selected) => (
                        <div>
                          {selected.map((reportee) => (
                            <Chip key={reportee.name} label={reportee.name} />
                          ))}
                        </div>
                      ),
                    }}
                    sx={{ marginBottom: "1rem" }} // Add bottom margin for spacing
                  >
                    {supervisorReportees
                      .filter(
                        (operator) =>
                          !operator.email
                            .toLowerCase()
                            .includes(user.email.toLowerCase())
                      )
                      .map((operator) => (
                        <MenuItem key={operator.email} value={operator}>
                          {`${operator.name} - ${operator.email}`}
                        </MenuItem>
                      ))}
                  </TextField>
                </DialogContent>
                <DialogActions>
                  <Button
                    onClick={handleSave}
                    sx={{
                      background: "#063c6f",
                      color: "white",
                      "&:hover": {
                        background: "#06009a",
                      },
                    }}
                  >
                    Submit
                  </Button>
                </DialogActions>
              </FormControl>
            </>
          )}

          {next === true && responsibility === "Operator" && (
            <>
              <FormControl fullWidth>
                <DialogTitle
                  sx={{
                    color: "#063c6f",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "flex-start",
                    alignItems: "center",
                  }}
                >
                  Operator
                </DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Fill in the following details
                  </DialogContentText>
                  <TextField
                    select
                    fullWidth
                    margin="normal"
                    size="small"
                    label="Role"
                    onChange={(e) => setSelectedManager(e.target.value)}
                    sx={{ marginBottom: "1rem" }} // Add bottom margin for spacing
                  >
                    {supervisorReportees
                      .filter(
                        (operator) =>
                          !operator.email
                            .toLowerCase()
                            .includes(user.email.toLowerCase())
                      )
                      .map((operator) => (
                        <MenuItem key={operator.name} value={operator}>
                          {`${operator.name} - ${operator.email}`}
                        </MenuItem>
                      ))}
                  </TextField>
                </DialogContent>
                <DialogActions>
                  <Button
                    onClick={handleSave}
                    sx={{
                      background: "#063c6f",
                      color: "white",
                      "&:hover": {
                        background: "#06009a",
                      },
                    }}
                  >
                    Submit
                  </Button>
                </DialogActions>
              </FormControl>
            </>
          )}

          {next === false && (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <FormControl fullWidth>
                <TextField
                  key="email"
                  label="Email"
                  value={email}
                  onChange={handleEmailChange}
                  error={email && !validateEmail(email)}
                  helperText={
                    email && !validateEmail(email) ? "Invalid email format" : ""
                  }
                  margin="normal"
                />
                <TextField
                  key="mobileNumber"
                  label="Mobile Number"
                  value={mobileNumber}
                  onChange={handleMobileChange}
                  margin="normal"
                  error={!!mobileNumberError}
                  helperText={mobileNumberError}
                />
                <TextField
                  select
                  fullWidth
                  margin="normal"
                  size="small"
                  label="Role"
                  onChange={(e) => handleRoleChange(e)}
                >
                  <MenuItem value="Admin">Admin</MenuItem>
                  <MenuItem value="User">User</MenuItem>
                </TextField>
                <TextField
                  select
                  fullWidth
                  value={responsibility}
                  margin="normal"
                  size="small"
                  label="Responsibility"
                  onChange={(e) => handleResponsibilityChange(e)}
                >
                  <MenuItem value="Executive">Executive</MenuItem>
                  <MenuItem value="Supervisor">Supervisor</MenuItem>
                  <MenuItem value="Operator">Operator</MenuItem>
                </TextField>
                {/* Add more user details as needed */}
              </FormControl>
              <Button
                variant="contained"
                onClick={handleNext}
                sx={{
                  background: "#063c6f",
                  color: "white",
                  maxWidth: "20vw",
                  alignSelf: "flex-end", // Shift button to the right end
                  marginTop: "1rem",
                  "&:hover": {
                    background: "#06009a",
                  }, // Add top margin for spacing
                }}
              >
                Next
              </Button>
            </div>
          )}
        </>
      </ModalContent>
    </CustomModal>
  );
};
