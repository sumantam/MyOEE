import { Box, CardContent, Grid, Card, Button, Stack, FormControl, InputLabel, Select, MenuItem, Tooltip } from "@mui/material";
import dayjs from 'dayjs';
import { useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import GanttChart from "../../../components/gantt-chart/gantt-chart";
import TimePickerValue from "../../../components/time-picker/time-picker";
import FileUpload from "../../../components/file-upload/file-upload";
import FileDownload from "../../../components/file-download/file-download";
import Loader from "../../../components/loader/loader";
import timeseriesService from "../../../services/timeseries-service";
import { Info } from '@mui/icons-material';
import { setRefreshButtonVisibility } from "../../../reducers/filter-reducer";
import "./prod-line-state-time-dashboard.css";

const ProdLineStateTimeDashboard = () => {

    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [events, setEvents] = useState([]);
    const [selectedEvent, setSelectedEvent] = useState('');
    const [date, setDate] = useState('');
    const [fromTime, setFromTime] = useState(null);
    const [toTime, setToTime] = useState(null);
    const [isUploading, setIsUploading] = useState(false);
    const [firstTimeLoad, setFirstTimeLoad] = useState(true);
    const [timeSeriesData, setTimeSeriesData] = useState([]);
    const [timeSeriesChartYAxisVal, setTimeSeriesChartYAxisVal] = useState([]);
    const [idForTimeSeriesChart, setIdForTimeSeriesChart] = useState('');
    const [selectedPcbIds, setSelectedPcbIds] = useState([]);
    const [idForPcbSpecificChart, setIdForPcbSpecificChart] = useState('');
    const [pcbIdSpecificYaxisKeyVal, setPcbIdSpecificYaxisKeyVal] = useState([]);

    useEffect(() => {
        dispatch(setRefreshButtonVisibility(false));
        return () => {
            dispatch(setRefreshButtonVisibility(true));
        }
    }, [dispatch])

    const populatePcbIds = useCallback((pcbId) => {
        if (pcbId === '') return;
        setSelectedPcbIds((prevItems) => {
            if (prevItems.length > 4)
                return [...prevItems.slice(1), ...timeSeriesData.filter(p => p["pcbId"] === pcbId)];
            return [...prevItems, ...timeSeriesData.filter(p => p["pcbId"] === pcbId)];
        });
        setPcbIdSpecificYaxisKeyVal((prevItems) => {
            if (prevItems.length > 4)
                return [...prevItems.slice(1), { "pcbId": pcbId }];
            return [...prevItems, { "pcbId": pcbId }];
        });
        setIdForPcbSpecificChart(pcbId);
    }, [timeSeriesData])

    const clearPcbIds = () => {
        setSelectedPcbIds([]);
        setPcbIdSpecificYaxisKeyVal([]);
    }

    const setFromTimeValue = async (val) => {
        let locFromTime = new Date(val["$d"]).getTime();
        let locToTime = new Date(toTime["$d"]).getTime();
        if (locFromTime <= locToTime) {
            setTimeSeriesChartYAxisVal([]);
            setTimeSeriesData([]);
            await eventSpecificTimeSeriesData(selectedEvent, dayjs(val), toTime);
            setFromTime(dayjs(val));
        }
        else
            setFromTime(dayjs(fromTime));
    }

    const setToTimeValue = async (val) => {
        let locFromTime = new Date(fromTime["$d"]).getTime();
        let locToTime = new Date(val["$d"]).getTime();
        if (locToTime >= locFromTime) {
            setTimeSeriesChartYAxisVal([]);
            setTimeSeriesData([]);
            await eventSpecificTimeSeriesData(selectedEvent, fromTime, dayjs(val));
            setToTime(dayjs(val));
        }
        else
            setToTime(dayjs(toTime));

    }

    const csvFileUpload = async (file) => {
        setIsUploading(true);
        try {
            setFirstTimeLoad(false);
            setTimeSeriesChartYAxisVal([]);
            setTimeSeriesData([]);
            const fileUploaded = await timeseriesService.createJsonFromCsv(file);
            if (fileUploaded.data === "Data written to JSON file successfully") {
                await getEvents();
            }
        } catch (error) {
            console.error("Error uploading file:", error);
        } finally {
            setIsUploading(false);
        }
    }

    const sampleFileDownload = async () => {
        const fileDownload = await timeseriesService.getSampleCsv();
        const url = window.URL.createObjectURL(new Blob([fileDownload.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "sample.csv"); // Filename for download
        document.body.appendChild(link);
        link.click();
        link.remove(); // Clean up
    }

    const getEvents = async () => {
        const events = await timeseriesService.getEvents();
        if (events["data"]["events"].length > 0) {
            setEvents(events["data"]["events"]);
            setSelectedEvent(events["data"]["events"][0]);
            setFromTime(dayjs('2024-11-10T00:00:00.000'));
            setToTime(dayjs('2024-11-10T00:59:59.999'));
            await eventSpecificTimeSeriesData(events["data"]["events"][0], dayjs('2024-11-10T00:00:00.000'), dayjs('2024-11-10T00:59:59.999'));
        }
    }

    const eventSpecificTimeSeriesData = async (event, fromTimeParam, toTimeParam) => {
        setFirstTimeLoad(false);
        let ft = new Date(fromTimeParam["$d"]);
        let tt = new Date(toTimeParam["$d"]);
        let utcFt = new Date(Date.UTC(ft.getFullYear(), ft.getMonth(), ft.getDate(), ft.getHours(), ft.getMinutes(), ft.getSeconds(), ft.getMilliseconds())).getTime();
        let utcTt = new Date(Date.UTC(tt.getFullYear(), tt.getMonth(), tt.getDate(), tt.getHours(), tt.getMinutes(), tt.getSeconds(), tt.getMilliseconds())).getTime();
        const timeSeriesData = await timeseriesService.getEventSpecificTimeSeriesData(event, utcFt, utcTt);
        if (timeSeriesData["data"]["timeSeriesData"].length > 0) {
            setDate(new Date(timeSeriesData["data"]["timeSeriesData"][0]["fromDate"]).toDateString())
            let locYAxisVal = [];
            timeSeriesData["data"]["timeSeriesData"].forEach((p, i) => {
                let foundIndex = locYAxisVal.findIndex(x => x["machine"] === p["machine"]);
                if (foundIndex === -1)
                    locYAxisVal.push({ "machine": p["machine"] })
                if (i < timeSeriesData["data"]["timeSeriesData"].length)
                    setTimeSeriesChartYAxisVal(locYAxisVal);
            })
            setTimeSeriesData(timeSeriesData["data"]["timeSeriesData"]);
            setIdForTimeSeriesChart(event);
        }
    }
    const hnadleEventChange = async (event) => {
        setTimeSeriesChartYAxisVal([]);
        setTimeSeriesData([]);
        await eventSpecificTimeSeriesData(event.target.value, fromTime, toTime);
        setSelectedEvent(event.target.value);
    }

    const goToGlobalView = () => {
        navigate("/oee");
    }

    return (
        <Box flexGrow={1} p={2}>
            <Grid container spacing={1} justifyContent="center">
                <Grid item xs={12} sm={12} md={12} lg={12} style={{ textAlign: "end" }}>
                    <Button variant="outlined" onClick={goToGlobalView}>Global View</Button>
                </Grid>
                <Grid item xs={12} sm={12} md={5} lg={5} style={{ textAlign: "start" }}>
                    <Stack direction="row" spacing={2} sx={{
                        justifyContent: "flex-start",
                        alignItems: "center",
                    }}>
                        <FileUpload uploadFile={csvFileUpload} isUploading={isUploading} />
                        <FileDownload download={async () => await sampleFileDownload()} />
                        <Tooltip title="Please download the sample csv file for reference" placement="right-start">
                            <Info />
                        </Tooltip>
                    </Stack>
                </Grid>
                <Grid item xs={12} sm={12} md={7} lg={7} style={{ textAlign: "end" }}>
                    {events.length > 0 ?
                        <Stack direction="row" spacing={2} sx={{
                            justifyContent: "flex-end",
                            alignItems: "center",
                        }}>
                            <FormControl>
                                <InputLabel id="event-lbl">Events</InputLabel>
                                <Select
                                    labelId="event-lbl"
                                    id="ddlEvent"
                                    className="custom-filter-select"
                                    value={selectedEvent}
                                    label="Event"
                                    onChange={hnadleEventChange}
                                >
                                    {events.map(item => (
                                        <MenuItem key={item} value={item}>
                                            {item}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            <TimePickerValue label="From Time" value={fromTime} setTime={setFromTimeValue} />
                            <TimePickerValue label="To Time" value={toTime} setTime={setToTimeValue} />
                        </Stack> : <></>}
                </Grid>
                {selectedPcbIds.length > 0 ?
                    <>
                        <Grid item xs={12} sm={12} md={12} lg={12} style={{ textAlign: "end" }}>
                            <Button variant="outlined" onClick={() => clearPcbIds()}>Clear</Button>
                        </Grid>
                        <Grid item xs={12} sm={12} md={12} lg={12} style={{ marginTop: '1rem' }}>
                            <Card style={{ minHeight: '400px' }}>
                                <CardContent>
                                    <GanttChart
                                        title={`PCB Specific ${selectedEvent} Time Series (Forvia) (${date}) (Last 5 entries)`}
                                        id={idForPcbSpecificChart}
                                        height="400px"
                                        data={selectedPcbIds}
                                        yaxisKeyVal={pcbIdSpecificYaxisKeyVal}
                                        categoryField="pcbId"
                                        isTooltipTextPrefixMachine={false}
                                        fromTime={fromTime["$d"]}
                                        toTime={toTime["$d"]}
                                    />
                                </CardContent>
                            </Card>
                        </Grid>
                    </> : <></>}
                {timeSeriesData.length > 0 && timeSeriesChartYAxisVal.length > 0 ?
                    <Grid item xs={12} sm={12} md={12} lg={12} style={{ marginTop: '1rem' }}>
                        <Card style={{ minHeight: '400px' }}>
                            <CardContent>
                                <GanttChart
                                    title={`${selectedEvent} Time Series (Forvia) (${date})`}
                                    id={idForTimeSeriesChart}
                                    height="400px"
                                    data={timeSeriesData}
                                    yaxisKeyVal={timeSeriesChartYAxisVal}
                                    categoryField="machine"
                                    clickToPopulatePcbSpecficGantt={populatePcbIds}
                                    isTooltipTextPrefixMachine={true}
                                    fromTime={fromTime["$d"]}
                                    toTime={toTime["$d"]}
                                />
                            </CardContent>
                        </Card>
                    </Grid> : firstTimeLoad ? <></> : <Loader />}
            </Grid>
        </Box>
    )
}

export default ProdLineStateTimeDashboard;