import {
  Box,
  Grid,
  Typography,
  Stack,
  Button,
  Card,
  CardContent
} from "@mui/material";
import "../../../App.css";
import CardBox from "../../../components/cardbox-container/cardbox-container";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchMicrostopData,
  fetchMicrostopDataByMachine,
} from "../../../reducers/microstop-data-reducer";
import {
  lineNameSelector,
  lineSelector,
  tqSelector,
  themeSelector,
  dateSelector
} from "../../../reducers/filter-reducer";
import { useEffect, useState } from "react";
import RenderType from "../../../models/render-type";
import {
  AdditionalMarkerData,
  ParetoModel,
  TrendModel,
} from "../../../models/microstop-chart";
import DasboardLayout from "../../../models/dashboard-content-layout";
import UtilityMethods from "../../../utilities";
import { useNavigate } from "react-router-dom";
import { addPath, removePath } from "../../../reducers/bread-crumb-reducer";
import BreadCrumb from "../../../components/bread-crumb/bread-crumb";
import Loader from "../../../components/loader/loader";

const MicrostopDashboard = () => {
  const dispatch = useDispatch();
  const tq = useSelector(tqSelector);
  const theme = useSelector(themeSelector);
  const dateParam = useSelector(dateSelector);
  const [timeRange, setTimeRange] = useState(
    UtilityMethods.createTimeQuantumRange(tq)
  );
  const [timeRangeForTrend, setTimeRangeForTrend] = useState(
    UtilityMethods.createTimeQuantumRangeForTrend(tq)
  );
  const [chartActualData, setChartActualData] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [trendData, setTrendData] = useState([]);
  const [paynterMarkerData, setPaynterMarkerData] = useState([]);
  const [actionsData, setActionsData] = useState([]);
  const [topSectionLayout, setTopSectionLayout] = useState(
    new DasboardLayout()
  );
  const [bottomSectionLayout, setBottomSectionLayout] = useState(
    new DasboardLayout()
  );
  const [trendType, setTrendType] = useState(0);
  const [paretoType, setParetoType] = useState(0);
  const [
    lineNameMAchineNameConcatenatedStr,
    setLineNameMAchineNameConcatenatedStr,
  ] = useState(useSelector(lineNameSelector));
  const [actionTableFirstColName, setActionTableFirstColName] =
    useState("Machine");
  const [allDataLoaded, setAllDataLoaded] = useState(false);

  const line = useSelector(lineSelector);
  const navigate = useNavigate();

  useEffect(() => {
    let fetchedDate = new Date(dateParam);
    setTimeRange(UtilityMethods.createTimeQuantumRange(tq, fetchedDate.getFullYear(), fetchedDate.getDate(), fetchedDate.getMonth()))
    setTimeRangeForTrend(UtilityMethods.createTimeQuantumRangeForTrend(tq, fetchedDate.getFullYear(), fetchedDate.getDate(), fetchedDate.getMonth()))
    setAllDataLoaded(false);
    getMicroStopData();
  }, [tq, dateParam, theme, dispatch]);

  const getMicroStopData = async () => {
    const ms = await dispatch(
      fetchMicrostopData({ line: line, timeQ: tq, date: dateParam })
    ).unwrap();
    if (ms.data && ms.data.data?.microstopData?.length > 0) {
      let msDataInOrder = ms.data.data?.microstopData?.sort((a, b) => b.value - a.value)
      msDataInOrder = msDataInOrder.slice(0, 7);
      setChartActualData([...msDataInOrder]);
      setChartData([
        ...msDataInOrder.map(
          (item) => new ParetoModel(item)
        ),
      ]);
    }

    if (ms.trend && ms.trend?.data?.microstopTrend?.length > 0 && ms.data && ms.data.data?.microstopData?.length > 0) {
      let filteredData = [];
      let msData = ms.data.data?.microstopData?.sort((a, b) => b.value - a.value)
      msData = msData.slice(0, 7);

      let keys = msData?.map(p => p["name"]);
      keys.forEach(key => {
        let dataObj = ms.trend?.data.microstopTrend.find(x => x["title"] === key);
        if (dataObj !== null || dataObj !== undefined) filteredData.push(dataObj);
      })
      if (filteredData.length > 0)
        setTrendData([
          ...filteredData?.map(
            (item) => new TrendModel({ "title": item?.title, "data": item?.values })
          ),
        ]);
      setAllDataLoaded(true);
    }

    else {
      setChartData([]);
      setTrendData([]);
      setAllDataLoaded(true);
    }

    if (ms.data && ms.data.data?.microstopData?.length > 0 && ms.actions?.data?.microstopActionData?.length > 0) {
      // let filteredActionData = [];
      let filteredActionData = ms.actions?.data?.microstopActionData;
      // let msData = ms.data.data?.microstopData?.sort((a, b) => b.value - a.value)
      // msData = msData.slice(0, 5);

      // let keys = msData?.map(p => p["name"]);
      // keys.forEach(key => {
      //   let dataObjs = ms.actions?.data.microstopActionData.filter(x => x["parentId"] === key);
      //   if (dataObjs !== null || dataObjs !== undefined || dataObjs.length > 0)
      //     dataObjs.forEach(item => filteredActionData.push(item));
      // })
      if (filteredActionData.length > 0) {
        setActionsData([...filteredActionData]);
        setPaynterMarkerData([
          ...filteredActionData?.map(
            (item) =>
              new AdditionalMarkerData(
                item.parentId,
                item.markerMapper,
                item.action,
                item.status === "G" ? theme["colors"]["greenGradientColor"][0] : item.status === "Y" ? theme["colors"]["yellowGradientColor"][0] :
                  theme["colors"]["redGradientColor"][0]
              )
          ),
        ]);
        setActionTableFirstColName("Machine");
      }

    }
  };

  const handleToSectionExpansion = (isExpanded) => {
    const layout = { ...topSectionLayout };
    layout.expanded = isExpanded;
    layout.md = isExpanded ? 12 : 6;
    layout.lg = isExpanded ? 12 : 6;
    setTopSectionLayout(layout);
  };

  const handleBottomSectionExpansion = (isExpanded) => {
    const layout = { ...bottomSectionLayout };
    layout.expanded = isExpanded;
    layout.md = isExpanded ? 12 : 6;
    layout.lg = isExpanded ? 12 : 6;
    setBottomSectionLayout(layout);
  };

  const handleChange = (event, isTrend) => {
    isTrend ? setTrendType(parseInt(event.target.value)) : setParetoType(parseInt(event.target.value));
  };

  const switchChart = (flag, isTrend = true) => {
    handleChange({
      target: {
        value: flag ? 1 : 0,
      },
    }, isTrend);
  };

  const handleClick = async (event) => {
    const mName = event.points[0].x;
    const m = chartActualData.find((i) => i.name === mName);
    if (m !== undefined) {
      setTrendType(0);
      setParetoType(0);
      setAllDataLoaded(false);
      dispatch(
        addPath({
          path: "/oee/dashboard/microstop/byMachine",
          name: "Microstop By Machine",
          icon: "bug",
        })
      );
      getMicrostopDataByMachineId(m.id, mName);
      navigate(`/oee/dashboard/microstop/byMachine`);
    }
  };

  const getMicrostopDataByMachineId = async (id, name) => {
    setLineNameMAchineNameConcatenatedStr(
      lineNameMAchineNameConcatenatedStr + ") (" + name
    );
    const ms = await dispatch(
      fetchMicrostopDataByMachine({ line: line, timeQ: tq, mid: id, mName: name, date: dateParam })
    ).unwrap();
    if (ms.data && ms.data.data?.microstopData?.length > 0) {
      let msDataInOrder = ms.data?.data?.microstopData?.sort((a, b) => b.value - a.value)
      msDataInOrder = msDataInOrder.slice(0, 7);

      setChartActualData([...msDataInOrder]);
      setChartData([
        ...msDataInOrder.map(
          (item) => new ParetoModel(item)
        ),
      ]);
    }

    if (ms.trend && ms.trend?.data?.microstopTrend?.length > 0 && ms.data && ms.data.data?.microstopData?.length > 0) {
      let filteredData = [];
      let msDataInOrder = ms.data.data?.microstopData?.sort((a, b) => b.value - a.value)
      msDataInOrder = msDataInOrder.slice(0, 7);
      let keys = msDataInOrder?.map(p => p["name"]);
      keys.forEach(key => {
        let dataObj = ms.trend?.data.microstopTrend?.find(x => x["title"] === key);
        if (dataObj !== null || dataObj !== undefined) filteredData.push(dataObj);
      })
      if (filteredData.length > 0)
        setTrendData([
          ...filteredData?.map(
            (item) => new TrendModel({ "title": item?.title, "data": item?.values })
          ),
        ]);
      setAllDataLoaded(true);
    }

    else {
      setChartData([]);
      setTrendData([]);
      setAllDataLoaded(true);
    }

    if (ms.data && ms.data.data?.microstopData?.length > 0 && ms.actions?.data?.microstopActionData?.length > 0) {
      // let filteredActionData = [];
      let filteredActionData = ms.actions?.data?.microstopActionData;
      // let msData = ms.data.data?.microstopData?.sort((a, b) => b.value - a.value)
      // msData = msData.slice(0, 5);

      // let keys = msData?.map(p => p["name"]);
      // keys.forEach(key => {
      //   let dataObjs = ms.actions?.data.microstopActionData.filter(x => key.includes(x["rootCause"].substring(0, x["rootCause"].indexOf(' '))));
      //   if (dataObjs !== null || dataObjs !== undefined || dataObjs.length > 0)
      //     dataObjs.forEach(item => filteredActionData.push(item));
      // })

      if (filteredActionData.length > 0) {
        setActionsData([...filteredActionData]);
        setPaynterMarkerData([
          ...filteredActionData?.map(
            (item) =>
              new AdditionalMarkerData(
                // item.rootCause.substring(0, item.rootCause.indexOf(' ')),
                item.parentId,
                item.markerMapper,
                item.action,
                item.status === "G" ? theme["colors"]["greenGradientColor"][0] : item.status === "Y" ? theme["colors"]["yellowGradientColor"][0] :
                  theme["colors"]["redGradientColor"][0]
              )
          ),
        ]);
        setActionTableFirstColName("Issue");
      }
    }
  };

  const goToBreakdown = () => {
    dispatch(removePath(1));
    dispatch(addPath({ path: '/oee/dashboard/breakdown2', name: 'Breakdown By Line', icon: 'machine' }))
    navigate("/oee/dashboard/breakdown2");
  }

  const goToOEEAccelerator = () => {
    dispatch(removePath(1));
    dispatch(addPath({ path: '/oee/dashboard/oee-accelerator', name: 'OEE By Line', icon: 'balance' }))
    navigate("/oee/dashboard/oee-accelerator");
  }

  return !allDataLoaded ? (
    <Loader />
  ) : (
    <Box flexGrow={1}>
      <Grid container spacing={1} justifyContent="center">
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <BreadCrumb />
        </Grid>
      </Grid>
      <Grid container spacing={1} justifyContent="center">
        <Grid item xs={12} sm={12} md={6} lg={6}>
          <Typography
            style={{
              fontSize: "1.5rem",
              fontWeight: "bold",
              fontFamily: theme["fontFamily"],
            }}
          >
            Micro-Stop Analysis ({lineNameMAchineNameConcatenatedStr})
          </Typography>
        </Grid>
        <Grid item xs={12} sm={12} md={6} lg={6}>
          <Stack direction="row" spacing={2} sx={{
            justifyContent: "flex-end",
            alignItems: "center",
          }}>
            <Button variant="outlined" onClick={goToBreakdown}>Breakdown</Button>
            <Button variant="outlined" onClick={goToOEEAccelerator}>OEE Accelerator</Button>
          </Stack>
        </Grid>
        <Grid
          item
          xs={topSectionLayout.xs}
          sm={topSectionLayout.sm}
          md={topSectionLayout.md}
          lg={topSectionLayout.lg}
        >
          {trendData.length > 0 ? (
            <CardBox
              type={trendType === 0 ? RenderType.TREND : RenderType.TRENDBAR}
              isSwitchRequired={true}
              switchChart={(flag) => switchChart(flag)}
              data={trendData}
              actions={[]}
              handleExpansion={handleToSectionExpansion}
              expanded={topSectionLayout.expanded}
              colors={theme["colors"]["colorShades"]}
              timeRange={timeRangeForTrend}
              lineOrMachine={lineNameMAchineNameConcatenatedStr}
              fontFamily={theme["fontFamily"]}
              IsLossOrGainIndicatorRequired={true}
            />
          ) : (
            <Card>
                <CardContent>
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                    No data available for {new Date(dateParam).toDateString()}
                  </Typography>
                </CardContent>
              </Card>
          )}
        </Grid>
        <Grid
          item
          xs={topSectionLayout.xs}
          sm={topSectionLayout.sm}
          md={topSectionLayout.md}
          lg={topSectionLayout.lg}
        >
          {chartData?.length > 0 ? (
            <CardBox
              type={paretoType === 0 ? RenderType.PARETO : RenderType.PARETOPIE}
              isSwitchRequired={true}
              switchChart={(flag) => switchChart(flag, false)}
              id="microstopPieByLine"
              data={chartData}
              actions={[]}
              handleExpansion={handleToSectionExpansion}
              expanded={topSectionLayout.expanded}
              colors={theme["colors"]["colorShades"]}
              handleClick={handleClick}
              timeRange={timeRange}
              lineOrMachine={lineNameMAchineNameConcatenatedStr}
              fontFamily={theme["fontFamily"]}
            />
          ) : (
            <Card>
              <CardContent>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                  No data available for {new Date(dateParam).toDateString()}
                </Typography>
              </CardContent>
            </Card>
          )}
        </Grid>
        <Grid
          item
          xs={bottomSectionLayout.xs}
          sm={bottomSectionLayout.sm}
          md={bottomSectionLayout.md}
          lg={bottomSectionLayout.lg}
        >
          {trendData.length > 0 ? (
            <CardBox
              type={RenderType.PAYNTER}
              data={trendData}
              markerData={paynterMarkerData}
              handleExpansion={handleBottomSectionExpansion}
              expanded={bottomSectionLayout.expanded}
              firstColumnName={actionTableFirstColName}
              colors={theme["colors"]["colorShades"]}
              timeRange={timeRangeForTrend}
              lineOrMachine={lineNameMAchineNameConcatenatedStr}
              fontFamily={theme["fontFamily"]}
              IsMs={true}
            />
          ) : (
            <Card>
              <CardContent>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                  No data available for {new Date(dateParam).toDateString()}
                </Typography>
              </CardContent>
            </Card>
          )}
        </Grid>
        <Grid
          item
          xs={bottomSectionLayout.xs}
          sm={bottomSectionLayout.sm}
          md={bottomSectionLayout.md}
          lg={bottomSectionLayout.lg}
        >
          {actionsData?.length > 0 ? (
            <CardBox
              type={RenderType.ACTIONS}
              data={[]}
              actions={actionsData}
              handleExpansion={handleBottomSectionExpansion}
              expanded={bottomSectionLayout.expanded}
              firstColumnName={actionTableFirstColName}
              colors={theme["colors"]["colorShades"]}
              timeRange={timeRange}
              lineOrMachine={lineNameMAchineNameConcatenatedStr}
              fontFamily={theme["fontFamily"]}
              redGradientColor={theme["colors"]["redGradientColor"]}
              yellowGradientColor={theme["colors"]["yellowGradientColor"]}
              greenGradientColor={theme["colors"]["greenGradientColor"]}
              IsMs={true}
            />
          ) : (
            <Card>
              <CardContent>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                  No data available for {new Date(dateParam).toDateString()}
                </Typography>
              </CardContent>
            </Card>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default MicrostopDashboard;
