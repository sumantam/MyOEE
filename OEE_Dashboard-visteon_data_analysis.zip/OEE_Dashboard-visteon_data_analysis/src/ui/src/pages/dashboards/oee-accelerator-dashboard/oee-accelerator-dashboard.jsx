import {
  Box,
  CardContent,
  CardHeader,
  IconButton,
  Grid,
  Card,
  Typography,
  Stack,
  Button
} from "@mui/material";
import { useLayoutEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import CardBox from "../../../components/cardbox-container/cardbox-container";
import DasboardLayout from "../../../models/dashboard-content-layout";
import LineChart from "../../../components/line-chart/line-chart";
import BarChart from "../../../components/bar-chart/bar-chart";
import TwoLevelPieChart from "../../../components/two-level-pie-chart/two-level-pie-chart";
import ColumnLineChart from "../../../components/column-line-chart/column-line-chart";
import ChartSwitch from "../../../components/chart-switch/chart-switch";
import ChartSwitch2 from "../../../components/chart-switch-2/chart-switch-2";
import StackedColumnChart from "../../../components/stacked-column-chart/stacked-column-chart";
import { fetchAllData, fetchOeeData } from "../../../reducers/oee-accelerator-reducer";
import { CloseFullscreen, OpenInFull } from "@mui/icons-material";
import {
  lineSelector,
  plantSelector,
  plantNameSelector,
  tqSelector,
  lineNameSelector,
  themeSelector,
  dateSelector
} from "../../../reducers/filter-reducer";
import { removePath, addPath } from "../../../reducers/bread-crumb-reducer";
import UtilityMethods from "../../../utilities";
import Loader from "../../../components/loader/loader";
import BreadCrumb from "../../../components/bread-crumb/bread-crumb";
import RenderType from "../../../models/render-type";

const OeeAcceleratorDashboard = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const plant = useSelector(plantSelector);
  const plantName = useSelector(plantNameSelector)
  const tq = useSelector(tqSelector);
  const theme = useSelector(themeSelector);
  const line = useSelector(lineSelector);
  const lineName = useSelector(lineNameSelector);
  const [topSectionLayout, setTopSectionLayout] = useState(
    new DasboardLayout()
  );
  const [productionChartCategoryAxis, setProductionChartCategoryAxis] =
    useState("model");

  const [isViewByLine, setIsViewByLine] = useState(true);

  const [oeeParams, setOeeParams] = useState(null);
  const [oeeTrend, setOeeTrend] = useState(null);
  const [oeeTrendBar, setOeeTrendBar] = useState(null);
  const [isOeeTrendBar, setIsOeeTrendBar] = useState(false);
  const [isDownTimeTrendBar, setIsDownTimeTrendBar] = useState(false);
  const [isDownTimeParetoBar, setIsDownTimeParetoBar] = useState(false);
  const [productionChartData, setProductionChartData] = useState(null);
  const [downTimeTrend, setDownTimeTrend] = useState(null);
  const [downTimeParetoByCause, setDownTimeParetoByCause] = useState(null);
  const dateParam = useSelector(dateSelector);
  const [timeRange, setTimeRange] = useState(
    UtilityMethods.createTimeQuantumRange(tq)
  );
  const [timeRangeForTrend, setTimeRangeForTrend] = useState(
    UtilityMethods.createTimeQuantumRangeForTrend(tq)
  );
  const [allDataLoaded, setAllDataLoaded] = useState(false);

  const handleToSectionExpansion = (isExpanded) => {
    const layout = { ...topSectionLayout };
    layout.expanded = isExpanded;
    layout.md = isExpanded ? 12 : 6;
    layout.lg = isExpanded ? 12 : 6;
    setTopSectionLayout(layout);
  };

  const renderTitle = (chartTitle) => {
    return (
      chartTitle +
      " (" +
      lineName +
      ") (" +
      timeRange["start"].toDateString() +
      " - " +
      timeRange["end"].toDateString() +
      ")"
    );
  };

  const renderTitleForTrend = (chartTitle) => {
    return (
      chartTitle +
      " (" +
      lineName +
      ") (" +
      timeRangeForTrend["start"].toDateString() +
      " - " +
      timeRangeForTrend["end"].toDateString() +
      ")"
    );
  };

  useLayoutEffect(() => {
    let fetchedDate = new Date(dateParam);
    setTimeRange(UtilityMethods.createTimeQuantumRange(tq, fetchedDate.getFullYear(), fetchedDate.getDate(), fetchedDate.getMonth()));
    setTimeRangeForTrend(UtilityMethods.createTimeQuantumRangeForTrend(tq, fetchedDate.getFullYear(), fetchedDate.getDate(), fetchedDate.getMonth()));
    setAllDataLoaded(false);
    getOeeData();
  }, [dispatch, plantName, tq, dateParam, theme]);

  const getOeeData = async () => {

    const parallelApiCallsResultForOee = await dispatch(
      fetchOeeData({ plant: plantName, line: line, tq: tq, date: dateParam })
    ).unwrap();

    if (parallelApiCallsResultForOee.data !== undefined) {
      let allData = parallelApiCallsResultForOee.data;
      if (allData[0]?.data?.Lines !== null || allData[0]?.data?.Lines !== undefined)
        setOeeParams(allData[0].data.Lines)
      if (allData[1]?.data?.viewByModelObjcts?.length > 0) {
        setProductionChartData(allData[1].data.viewByModelObjcts);
        setAllDataLoaded(true);
      }
    }

    const parallelApiCallsResult = await dispatch(
      fetchAllData({ plant: plantName, line: line, tq: tq, date: dateParam })
    ).unwrap();

    if (parallelApiCallsResult.data !== undefined) {
      let allData = parallelApiCallsResult.data;
      if (allData[0]?.data?.oeeTrend?.length > 0)
        setOeeTrend(allData[0].data.oeeTrend)
      if (allData[1]?.data?.downtimeTrend?.length > 0)
        setDownTimeTrend(allData[1].data.downtimeTrend)
      if (allData[2]?.data?.downtimePareto?.length > 0)
        setDownTimeParetoByCause(allData[2].data.downtimePareto)
      if (allData[3]?.data?.oeeTrendBar?.length > 0)
        setOeeTrendBar(allData[3].data.oeeTrendBar)
    }

  }

  const goToMicrostop = () => {
    dispatch(removePath(1));
    dispatch(addPath({ path: '/oee/dashboard/microstop', name: 'Microstop By Line', icon: 'machine' }))
    navigate("/oee/dashboard/microstop");
  }

  const goToBreakdown = () => {
    dispatch(removePath(1));
    dispatch(addPath({ path: '/oee/dashboard/breakdown2', name: 'Breakdown By Line', icon: 'machine' }))
    navigate("/oee/dashboard/breakdown2");
  }

  const switchChart = (flag) => {
    setIsOeeTrendBar(flag);
  }

  const switchChartForDownTimeTrend = (flag) => {
    setIsDownTimeTrendBar(flag);
  }

  const switchChartForPie = (flag) => {
    setIsDownTimeParetoBar(flag);
  }

  return !allDataLoaded ? (
    <Loader />
  ) : (
    <Box flexGrow={1}>
      <Grid container spacing={1} justifyContent="center">
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <BreadCrumb />
        </Grid>
      </Grid>
      <Grid container spacing={1} justifyContent="center">
        <Grid item xs={12} sm={12} md={6} lg={6}>
          <Typography
            style={{
              fontSize: "1.5rem",
              fontWeight: "bold",
              fontFamily: theme["fontFamily"],
            }}
          >
            OEE Accelerator ({lineName})
          </Typography>
        </Grid>
        <Grid item xs={12} sm={12} md={6} lg={6}>
          <Stack direction="row" spacing={2} sx={{
            justifyContent: "flex-end",
            alignItems: "center",
          }}>
            <Button variant="outlined" onClick={goToBreakdown}>Breakdown</Button>
            <Button variant="outlined" onClick={goToMicrostop}>Microstop</Button>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <Typography
            style={{
              fontSize: "1rem",
              fontWeight: "bold",
              fontFamily: theme["fontFamily"],
            }}
          >
            ({timeRange["start"].toDateString()} -{" "}
            {timeRange["end"].toDateString()})
          </Typography>
        </Grid>
        {oeeParams !== null ? <>
          <Grid item xs={12} sm={12} md={6} lg={6}>
            <CardBox
              type={RenderType.Gauge}
              data={oeeParams["OEE"]}
              id="OEE"
              gaugeRange={[0, 70, 85, 100]}
              redGradientColor={theme["colors"]["redGradientColor"]}
              yellowGradientColor={theme["colors"]["yellowGradientColor"]}
              greenGradientColor={theme["colors"]["greenGradientColor"]}
              fontFamily={theme["fontFamily"]}
              chartHeight="300px"
            />
          </Grid>
          <Grid item xs={12} sm={12} md={6} lg={6}>
            <Card style={{ minHeight: "400px" }}>
              <CardHeader
                title={renderTitle("Production: Actual vs Plan")}
                titleTypographyProps={{
                  fontSize: 16,
                  fontWeight: 600,
                  fontFamily: theme["fontFamily"],
                }}
                style={{ paddingBottom: 0 }}
                action={
                  <IconButton
                    onClick={() =>
                      handleToSectionExpansion(!topSectionLayout.expanded)
                    }
                  >
                    {topSectionLayout.expanded ? (
                      <CloseFullscreen />
                    ) : (
                      <OpenInFull />
                    )}
                  </IconButton>
                }
              />
              <CardContent>
                <Grid container spacing={2} justifyContent="center">
                  <Grid item xs={12} sm={12} md={12} lg={12}>
                    <BarChart
                      data={productionChartData}
                      categoryField={productionChartCategoryAxis}
                      redGradientColor={theme["colors"]["redGradientColor"]}
                      yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                      greenGradientColor={theme["colors"]["greenGradientColor"]}
                      range={[0, 94, 96, 100]}
                      dataSeriesKeyTitle={[
                        {
                          key: "plan",
                          title: "Plan",
                          isColorModificationRequired: false,
                        },
                        {
                          key: "actual",
                          title: "Actual",
                          isColorModificationRequired: true,
                        },
                      ]}
                      id="production"
                      title="Production: Actual vs Plan"
                      fontFamily={theme["fontFamily"]}
                      width="600px"
                      height="300px"
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={12} md={2} lg={2}>
            <CardBox
              type={RenderType.Gauge}
              data={oeeParams["Availability"]}
              id="Availability"
              gaugeRange={[0, 90, 95, 100]}
              redGradientColor={theme["colors"]["redGradientColor"]}
              yellowGradientColor={theme["colors"]["yellowGradientColor"]}
              greenGradientColor={theme["colors"]["greenGradientColor"]}
              fontFamily={theme["fontFamily"]}
              chartHeight="150px"
              fontSize="smaller"
            />
          </Grid>
          <Grid item xs={12} sm={12} md={2} lg={2}>
            <CardBox
              type={RenderType.Gauge}
              data={oeeParams["Performance_Percentage"]}
              id="Performance"
              gaugeRange={[0, 85, 90, 120]}
              redGradientColor={theme["colors"]["redGradientColor"]}
              yellowGradientColor={theme["colors"]["yellowGradientColor"]}
              greenGradientColor={theme["colors"]["greenGradientColor"]}
              fontFamily={theme["fontFamily"]}
              chartHeight="150px"
              fontSize="smaller"
            />
          </Grid>
          <Grid item xs={12} sm={12} md={2} lg={2}>
            <CardBox
              type={RenderType.Gauge}
              data={oeeParams["Quality_Percentage"]}
              id="Quality"
              gaugeRange={[0, 93, 97, 100]}
              redGradientColor={theme["colors"]["redGradientColor"]}
              yellowGradientColor={theme["colors"]["yellowGradientColor"]}
              greenGradientColor={theme["colors"]["greenGradientColor"]}
              fontFamily={theme["fontFamily"]}
              chartHeight="150px"
              fontSize="smaller"
            />
          </Grid>
          <Grid item xs={12} sm={12} md={2} lg={2}>
            <CardBox
              type={RenderType.Gauge}
              data={oeeParams["BTS"]}
              id="BTS"
              gaugeRange={[0, 90, 95, 100]}
              redGradientColor={theme["colors"]["redGradientColor"]}
              yellowGradientColor={theme["colors"]["yellowGradientColor"]}
              greenGradientColor={theme["colors"]["greenGradientColor"]}
              fontFamily={theme["fontFamily"]}
              chartHeight="150px"
              fontSize="smaller"
            />
          </Grid>
          <Grid item xs={12} sm={12} md={2} lg={2}>
            <CardBox
              type={RenderType.Gauge}
              data={parseFloat((oeeParams["Total_FTT"] / oeeParams["Total"] * 100).toFixed(2))}
              id="FTT"
              gaugeRange={[0, 90, 95, 100]}
              redGradientColor={theme["colors"]["redGradientColor"]}
              yellowGradientColor={theme["colors"]["yellowGradientColor"]}
              greenGradientColor={theme["colors"]["greenGradientColor"]}
              fontFamily={theme["fontFamily"]}
              chartHeight="150px"
              fontSize="smaller"
            />
          </Grid>
          <Grid item xs={12} sm={12} md={2} lg={2}>
            <CardBox
              type={RenderType.Gauge}
              data={parseFloat((oeeParams["Total_NG"] / oeeParams["Total"] * 100).toFixed(2))}
              id="Scrap"
              gaugeRange={[0, 3, 7, 10]}
              redGradientColor={theme["colors"]["redGradientColor"]}
              yellowGradientColor={theme["colors"]["yellowGradientColor"]}
              greenGradientColor={theme["colors"]["greenGradientColor"]}
              fontFamily={theme["fontFamily"]}
              chartHeight="150px"
              fontSize="smaller"
            />
          </Grid>
        </> :
          <Card>
            <CardContent>
              <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                No data available for {new Date(dateParam).toDateString()}
              </Typography>
            </CardContent>
          </Card>}
        <Grid
          item
          xs={12}
          sm={12}
          md={12}
          lg={12}
        >
          <Card>
            <CardHeader
              title={renderTitleForTrend("OEE Trend")}
              titleTypographyProps={{
                fontSize: 16,
                fontWeight: 600,
                fontFamily: theme["fontFamily"],
              }}
              style={{ paddingBottom: 0 }}
              action={
                <>
                  <ChartSwitch switchChart={(flag) => switchChart(flag)} />
                  {/* <IconButton
                    onClick={() =>
                      handleToSectionExpansion(!topSectionLayout.expanded)
                    }
                  >
                    {topSectionLayout.expanded ? (
                      <CloseFullscreen />
                    ) : (
                      <OpenInFull />
                    )}
                  </IconButton> */}
                </>

              }
            />
            <CardContent>
              <Grid container spacing={2} justifyContent="center">
                <Grid item xs={12} sm={12} md={12} lg={12}>
                  {!isOeeTrendBar ? <LineChart
                    data={oeeTrend}
                    unit="%"
                    yAxisTitle="Percentage"
                    labelRotation={{ required: true, angle: -45 }}
                    categoryField="range"
                    valueField="value"
                    id="oeeTrend"
                    title="OEE Trend"
                    fontFamily={theme["fontFamily"]}
                    colors={theme["colors"]["colorShades"]}
                    width="600px"
                    height="400px"
                  /> :
                    <StackedColumnChart
                      data={oeeTrendBar}
                      categoryField="range"
                      dataSeriesKeyTitle={[
                        { key: "percentage", title: "Percentage" }
                      ]}
                      barKeysAndTitles={[
                        { "key": "availability", "title": "Availability" },
                        { "key": "performance", "title": "Performance" },
                        { "key": "quality", "title": "Quality" },
                        { "key": "oee", "title": "OEE" }
                      ]}
                      labelRotationRequired={true}
                      id="oeeTrendBar"
                      title="By Cause"
                      fontFamily={theme["fontFamily"]}
                      colors={theme["colors"]["colorShades"]}
                      width="600px"
                      height="400px"
                    />
                  }
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        <Grid
          item
          xs={12}
          sm={12}
          md={12}
          lg={12}
        >
          <Grid container spacing={1} justifyContent="center">
            <Grid
              item
              xs={topSectionLayout.xs}
              sm={topSectionLayout.sm}
              md={topSectionLayout.md}
              lg={topSectionLayout.lg}
            >
              <Card>
                <CardHeader
                  title={renderTitleForTrend("Delay Analysis")}
                  titleTypographyProps={{
                    fontSize: 16,
                    fontWeight: 600,
                    fontFamily: theme["fontFamily"],
                  }}
                  style={{ paddingBottom: 0 }}
                  action={
                    <>
                      {/* <ChartSwitch switchChart={(flag) => switchChartForDownTimeTrend(flag)} /> */}
                      <IconButton
                        onClick={() =>
                          handleToSectionExpansion(!topSectionLayout.expanded)
                        }
                      >
                        {topSectionLayout.expanded ? (
                          <CloseFullscreen />
                        ) : (
                          <OpenInFull />
                        )}
                      </IconButton>
                    </>

                  }
                />
                <CardContent>
                  <Grid container spacing={2} justifyContent="center">
                    <Grid item xs={12} sm={12} md={12} lg={12}>
                      {!isDownTimeTrendBar ? <LineChart
                        data={downTimeTrend}
                        unit="min(s)"
                        yAxisTitle="Stop time (mins)"
                        labelRotation={{ required: true, angle: -45 }}
                        categoryField="range"
                        valueField="value"
                        id="downtimeTrend"
                        title="Delay Analysis"
                        fontFamily={theme["fontFamily"]}
                        colors={theme["colors"]["colorShades"]}
                        width="600px"
                        height="400px"
                      /> :
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      }
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
            <Grid
              item
              xs={topSectionLayout.xs}
              sm={topSectionLayout.sm}
              md={topSectionLayout.md}
              lg={topSectionLayout.lg}
            >
              <Card>
                <CardHeader
                  title={renderTitle("Delay Analysis By Cause")}
                  titleTypographyProps={{
                    fontSize: 16,
                    fontWeight: 600,
                    fontFamily: theme["fontFamily"],
                  }}
                  style={{ paddingBottom: 0 }}
                  action={
                    <>
                      <ChartSwitch2 switchChart={(flag) => switchChartForPie(flag)} />
                      <IconButton
                        onClick={() =>
                          handleToSectionExpansion(!topSectionLayout.expanded)
                        }
                      >
                        {topSectionLayout.expanded ? (
                          <CloseFullscreen />
                        ) : (
                          <OpenInFull />
                        )}
                      </IconButton>
                    </>

                  }
                />
                <CardContent>
                  <Grid container spacing={2} justifyContent="center">
                    <Grid item xs={12} sm={12} md={12} lg={12}>
                      {!isDownTimeParetoBar ? <ColumnLineChart
                        data={downTimeParetoByCause}
                        categoryField="name"
                        dataSeriesKeyTitle={[
                          { key: "value", title: "Stop time (mins)" },
                          { key: "percentage", title: "Percentage" },
                        ]}
                        // categoryField="line"
                        // dataSeriesKeyTitle={[
                        //   { key: "stopTime", title: "Stop time (mins)" },
                        //   { key: "percentage", title: "Percentage" },
                        // ]}
                        labelRotationRequired={true}
                        id="cause"
                        title="By Cause"
                        fontFamily={theme["fontFamily"]}
                        colors={theme["colors"]["colorShades"]}
                        width="600px"
                        height="367px"
                      /> :
                        <TwoLevelPieChart id="twoLevelPieChart"
                          data={downTimeParetoByCause}
                          // categoryField="line"
                          // dataSeriesKeyTitle={[
                          //   { key: "stopTime", title: "(mins)" },
                          //   { key: "percentage", title: "Percentage" },
                          // ]}
                          categoryField="name"
                          dataSeriesKeyTitle={[
                            { key: "value", title: "(mins)" },
                            { key: "percentage", title: "Percentage" },
                          ]}
                          fontFamily={theme["fontFamily"]}
                          colors={theme["colors"]["colorShades"]}
                          height="399px" />
                      }
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
};

export default OeeAcceleratorDashboard;
