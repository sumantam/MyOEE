import {
  Box,
  Grid,
  Typography,
  CardContent,
  Card,
  CardHeader,
  Chip,
  Stack,
  IconButton,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  SpeedDial,
  SpeedDialIcon,
  SpeedDialAction,
  Button,
  FormControl, InputLabel, MenuItem, Select,
} from "@mui/material";
import { styled } from '@mui/material/styles';
import {
  CloseFullscreen,
  OpenInFull,
  ExpandMore
} from "@mui/icons-material";
import "../../../App.css";
import CardBox from "../../../components/cardbox-container/cardbox-container";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchOeeData,
  fetchAllData,
  fetchLineWiseProductionData,
  fetchModelWiseProductionData
} from "../../../reducers/delayed-dashboard-reducer";
import BarChart from "../../../components/bar-chart/bar-chart";
import LineChart from "../../../components/line-chart/line-chart";
import StackedColumnChart from "../../../components/stacked-column-chart/stacked-column-chart";
import ColumnLineChart from "../../../components/column-line-chart/column-line-chart";
import TwoLevelPieChart from "../../../components/two-level-pie-chart/two-level-pie-chart";
import ChartSwitch from "../../../components/chart-switch/chart-switch";
import ChartSwitch2 from "../../../components/chart-switch-2/chart-switch-2";
import BreadCrumb from "../../../components/bread-crumb/bread-crumb";
import { useEffect, useState, useRef } from "react";
import RenderType from "../../../models/render-type";
import {
  ParetoModel,
  TrendModelWithSum,
  TrendModel
} from "../../../models/microstop-chart";
import DasboardLayout from "../../../models/dashboard-content-layout";
import {
  setLineFilter,
  tqSelector,
  themeSelector,
  plantNameSelector,
  linesSelector,
  dateSelector
} from "../../../reducers/filter-reducer";
import { useNavigate } from "react-router-dom";
import UtilityMethods from "../../../utilities";
import SmtChangeOver from "./smt-change-over";
import SmtCycleTime from "./smt-cycle-time";
import { addPath } from "../../../reducers/bread-crumb-reducer";
import Loader from "../../../components/loader/loader";

const SMTDashboard = () => {
  const oeeAnalysisRef = useRef(null);
  const oeeByLineRef = useRef(null);
  const delayRef = useRef(null);
  const delayByLineRef = useRef(null);
  const cycleTimeRef = useRef(null);
  const delayByPerformanceRef = useRef(null);
  const delayByChangeoverRef = useRef(null);
  const delayByBreakdownRef = useRef(null);
  const delayByQualityRef = useRef(null);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const plantName = useSelector(plantNameSelector);
  const lines = useSelector(linesSelector);
  const tq = useSelector(tqSelector);
  const theme = useSelector(themeSelector);
  const [smtDashboardState, setSmtDashboardState] = useState({
    timeRange: UtilityMethods.createTimeQuantumRange(tq),
    timeRangeForTrend: UtilityMethods.createTimeQuantumRangeForTrend(tq),
    paretoData: [],
    trendData: [],
    qParetoData: [],
    qTrendData: [],
    brParetoData: [],
    brTrendData: [],
    chParetoData: [],
    chTrendData: [],
    oeeParams: {},
    oeeTrend: [],
    oeeTrendSelectedParam: { "key": "oeeVal", "name": "OEE" },
    oeeParetoSelectedParam: { "key": "oeeVal", "name": "OEE", "percentageKey": "oeePer" },
    oeeTrendBar: [],
    oeePareto: [],
    isViewByLine: true,
    productionChartCategoryAxis: "line",
    productionChartData: [],
    topSectionLayout: new DasboardLayout(),
    bottomSectionLayout: new DasboardLayout(),
    trendType: {
      "delay": 0, "delayByLine": 0, "oeeByLine": 0, "performanceByLine": 0, "qualityByLine": 0, "changeoverByLine": 0, "breakdownByLine": 0, "microstopByLine": 0
    },
    paretoType: {
      "delay": 0, "delayByLine": 0, "oeeByLine": 0, "performanceByLine": 0, "qualityByLine": 0, "changeoverByLine": 0, "breakdownByLine": 0, "microstopByLine": 0
    },
    totalDelayData: [],
    totalDelayTrendData: [],
    totalDelayDataByLine: [],
    totalDelayTrendDataByLine: [],
    isFirstChunkDataLoaded: false,
    isAllDataLoaded: false,
    hidden: false
  });
  const dateParam = useSelector(dateSelector);


  useEffect(() => {
    let fetchedDate = new Date(dateParam);
    setSmtDashboardState((prevState) => ({
      ...prevState,
      timeRange: UtilityMethods.createTimeQuantumRange(tq, fetchedDate.getFullYear(), fetchedDate.getDate(), fetchedDate.getMonth()),
      timeRangeForTrend: UtilityMethods.createTimeQuantumRangeForTrend(tq, fetchedDate.getFullYear(), fetchedDate.getDate(), fetchedDate.getMonth()),
      isFirstChunkDataLoaded: false,
      isAllDataLoaded: false
    }));
    getTotalDelayData();

  }, [tq, dateParam, plantName, theme, dispatch]);

  const viewProductionByLineOrModel = async (isLine) => {
    setSmtDashboardState((prevState) => ({
      ...prevState,
      isViewByLine: isLine
    }));

    const productionData = isLine ? await dispatch(
      fetchLineWiseProductionData({ plant: plantName, tq: tq, date: dateParam })
    ).unwrap() :
      await dispatch(
        fetchModelWiseProductionData({ plant: plantName, tq: tq, date: dateParam })
      ).unwrap();
    if (isLine) {
      if (productionData.data?.viewByLineObjects?.length > 0) {
        setSmtDashboardState((prevState) => ({
          ...prevState,
          productionChartData: productionData.data?.viewByLineObjects,
          productionChartCategoryAxis: "line"
        }));
      }
    }
    else {
      if (productionData.data?.viewByModelObjcts?.length > 0) {
        setSmtDashboardState((prevState) => ({
          ...prevState,
          productionChartData: productionData.data?.viewByModelObjcts,
          productionChartCategoryAxis: "model"
        }));
      }
    }
  };

  const calCulatePercenatgeAndSort = (valFieldName, percenatgeFieldName, data) => {
    data = data.sort((a, b) => b[valFieldName] - a[valFieldName]);
    let percentage = 0;
    data.forEach(
      item => {
        percentage += (item[valFieldName] /
          UtilityMethods.getSumOfStopTimes(
            data,
            valFieldName
          )) *
          100;
        item[percenatgeFieldName] = percentage;
      }
    );
    return data;
  }

  const getTotalDelayData = async () => {

    const parallelApiCallsResultForOee = await dispatch(
      fetchOeeData({ plant: plantName, tq: tq, date: dateParam })
    ).unwrap();
    if (parallelApiCallsResultForOee.data !== undefined) {
      let oeeData = parallelApiCallsResultForOee.data;
      if (oeeData[0]?.data?.Lines !== null && oeeData[0]?.data?.Lines !== undefined)
        setSmtDashboardState((prevState) => ({
          ...prevState,
          oeeParams: oeeData[0].data.Lines
        }));
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          oeeParams: undefined,
          isFirstChunkDataLoaded: true
        }));
      if (oeeData[1]?.data?.viewByLineObjects?.length > 0)
        setSmtDashboardState((prevState) => ({
          ...prevState,
          productionChartData: oeeData[1].data.viewByLineObjects,
          isFirstChunkDataLoaded: true
        }));
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          productionChartData: [],
          isFirstChunkDataLoaded: true
        }));

    }
    let res = {};
    let qres = {};
    let breakdown = {};
    let breakdownTrend = {};
    let cho = {};
    let choTrend = {};
    let trend = {};
    let qtrend = {};
    const parallelApiCallsResult = await dispatch(
      fetchAllData({ plant: plantName, tq: tq, date: dateParam })
    ).unwrap();
    if (parallelApiCallsResult.data !== undefined) {
      let allData = parallelApiCallsResult.data;
      if (allData[0]?.data?.oeePareto?.length > 0) {
        let oeeParetoData = allData[0].data.oeePareto.map(p => ({ ...p }));
        setSmtDashboardState((prevState) => ({
          ...prevState,
          oeePareto: calCulatePercenatgeAndSort("oeeVal", "oeePer", oeeParetoData)
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          oeePareto: []
        }));
      if (allData[1]?.data?.lossData?.length > 0) {
        res = allData[1];
        setSmtDashboardState((prevState) => ({
          ...prevState,
          paretoData: [...res.data.lossData.map((item) => new ParetoModel(item))]
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          paretoData: []
        }));
      if (allData[2]?.data?.lossData?.length > 0) {
        qres = allData[2];
        setSmtDashboardState((prevState) => ({
          ...prevState,
          qParetoData: [...qres.data.lossData.map((item) => new ParetoModel(item))]
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          qParetoData: []
        }));
      if (allData[3]?.data?.breakdownData?.length > 0) {
        breakdown = allData[3];
        setSmtDashboardState((prevState) => ({
          ...prevState,
          brParetoData: [
            ...breakdown.data.breakdownData.map(
              (item) => new ParetoModel(item)
            ),
          ]
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          brParetoData: []
        }));
      if (allData[4]?.data?.breakdownTrend?.length > 0) {
        breakdownTrend = allData[4];
        const brTemp = breakdownTrend.data.breakdownTrend.map(
          (p) => new TrendModelWithSum(p.title, p.values)
        );
        setSmtDashboardState((prevState) => ({
          ...prevState,
          brTrendData: brTemp
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          brTrendData: []
        }));
      if (allData[5]?.data?.oeeTrendBar?.length > 0)
        setSmtDashboardState((prevState) => ({
          ...prevState,
          oeeTrendBar: allData[5].data.oeeTrendBar
        }));
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          oeeTrendBar: []
        }));
      if (allData[6]?.data?.length > 0) {
        cho = allData[6];
        setSmtDashboardState((prevState) => ({
          ...prevState,
          chParetoData: [
            ...cho.data.map((item) => new ParetoModel(item)),
          ]
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          chParetoData: []
        }));
      if (allData[7]?.data?.length > 0) {
        choTrend = allData[7];
        const chTemp = choTrend.data.map(
          (p) => new TrendModelWithSum(p.title, p.data)
        );
        setSmtDashboardState((prevState) => ({
          ...prevState,
          chTrendData: chTemp
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          chTrendData: []
        }));
      if (allData[8]?.data?.oeeTrend?.length > 0)
        setSmtDashboardState((prevState) => ({
          ...prevState,
          oeeTrend: allData[8].data.oeeTrend
        }));
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          oeeTrend: []
        }));
      if (allData[9]?.data?.lossTrendData?.length > 0) {
        trend = allData[9];
        const temp = trend.data.lossTrendData.map((p) => new TrendModel(p));
        setSmtDashboardState((prevState) => ({
          ...prevState,
          trendData: temp
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          trendData: []
        }));
      if (allData[10]?.data?.lossTrendData?.length > 0) {
        qtrend = allData[10];
        const qtemp = qtrend.data.lossTrendData.map((p) => new TrendModel(p));
        setSmtDashboardState((prevState) => ({
          ...prevState,
          qTrendData: qtemp
        }));
      }
      else
        setSmtDashboardState((prevState) => ({
          ...prevState,
          qTrendData: []
        }));
    }

    const totalDelay = [];
    const perfDelay = res.data?.lossData?.reduce((acc, curr) => {
      return acc + curr.value;
    }, 0);
    const qualityDelay = qres.data?.lossData?.reduce((acc, curr) => {
      return acc + curr.value;
    }, 0);
    const brDelay = breakdown.data?.breakdownData?.reduce((acc, curr) => {
      return acc + curr.value;
    }, 0);
    const chDelay = cho.data?.reduce((acc, curr) => {
      return acc + curr.value;
    }, 0);

    if (perfDelay > 0 || qualityDelay > 0 || brDelay > 0 || chDelay > 0) {
      totalDelay.push(new ParetoModel({ "name": "Performance", "value": perfDelay }));
      totalDelay.push(new ParetoModel({ "name": "Quality", "value": qualityDelay }));
      totalDelay.push(new ParetoModel({ "name": "Breakdown", "value": brDelay }));
      totalDelay.push(new ParetoModel({ "name": "ChangeOver", "value": chDelay }));
    }

    const totalDelayTrend = [];
    let timeQuantums = breakdownTrend?.data?.breakdownTrend[0]?.["values"].map((p) => p["range"]);
    let allDelays = ["Breakdown", "Performance", "ChangeOver", "Quality"];
    if (timeQuantums?.length > 0) {
      for (let i = 0; i < allDelays.length; i++) {
        const data = {
          reference: allDelays[i],
          data: [],
        };
        switch (allDelays[i]) {
          case "Breakdown":
            for (let j = 0; j < timeQuantums.length; j++) {
              let value = 0;
              for (let l = 0; l < breakdownTrend.data?.breakdownTrend?.length; l++) {
                value += breakdownTrend.data.breakdownTrend[l]["values"][j] !== undefined ? breakdownTrend.data.breakdownTrend[l]["values"][j]["value"] : 0;
              }
              data["data"].push({ range: timeQuantums[j], value: value });
            }
            break;
          case "Performance":
            for (let j = 0; j < timeQuantums.length; j++) {
              let value = 0;
              for (let l = 0; l < trend.data?.lossTrendData?.length; l++) {
                value += trend.data.lossTrendData[l]["data"][j]["value"];
              }
              data["data"].push({ range: timeQuantums[j], value: value });
            }
            break;
          case "ChangeOver":
            for (let j = 0; j < timeQuantums.length; j++) {
              let value = 0;
              for (let l = 0; l < choTrend.data?.length; l++) {
                value += choTrend.data[l]["data"][j]["value"];
              }
              data["data"].push({ range: timeQuantums[j], value: value });
            }
            break;
          case "Quality":
            for (let j = 0; j < timeQuantums.length; j++) {
              let value = 0;
              for (let l = 0; l < qtrend.data?.lossTrendData?.length; l++) {
                value += qtrend.data.lossTrendData[l]["data"][j]["value"];
              }
              data["data"].push({ range: timeQuantums[j], value: value });
            }
            break;
          default:
            break;
        }
        totalDelayTrend.push(new TrendModel({ "title": data.reference, "data": data.data }));
      }
    }
    setSmtDashboardState((prevState) => ({
      ...prevState,
      totalDelayData: totalDelay,
      totalDelayTrendData: totalDelayTrend
    }));
    const totalDelayByLine = [];
    for (let i = 0; i < res.data?.lossData?.length; i++) {
      let bdVal = breakdown.data?.breakdownData[i] !== undefined ? breakdown.data?.breakdownData[i].value : 0;
      let object = {
        "name": res.data.lossData[i].name,
        "value": res.data.lossData[i].value + qres.data.lossData[i].value + bdVal + cho.data[i].value
      }
      var temp = new ParetoModel(object);
      totalDelayByLine.push(temp);
    }
    const totalDelayTrendByLine = [];
    for (let i = 0; i < breakdownTrend.data?.breakdownTrend?.length; i++) {
      const data = {
        reference: breakdownTrend.data.breakdownTrend[i].title,
        data: breakdownTrend.data.breakdownTrend[i].values.map((p, j) => ({
          range: p.range,
          value:
            p.value +
            trend.data.lossTrendData[i].data[j].value +
            qtrend.data.lossTrendData[i].data[j].value +
            choTrend.data[i].data[j].value,
        })),
      };
      totalDelayTrendByLine.push(new TrendModel({ "title": data.reference, "data": data.data }));
    }
    setSmtDashboardState((prevState) => ({
      ...prevState,
      totalDelayTrendDataByLine: totalDelayTrendByLine,
      totalDelayDataByLine: totalDelayByLine,
      isAllDataLoaded: true
    }));
  };

  const handleToSectionExpansion = (isExpanded) => {
    const layout = { ...smtDashboardState.topSectionLayout };
    layout.expanded = isExpanded;
    layout.md = isExpanded ? 12 : 6;
    layout.lg = isExpanded ? 12 : 6;
    setSmtDashboardState((prevState) => ({
      ...prevState,
      topSectionLayout: layout
    }));
  };

  const handleBottomSectionExpansion = (isExpanded) => {
    const layout = { ...smtDashboardState.bottomSectionLayout };
    layout.expanded = isExpanded;
    layout.md = isExpanded ? 12 : 6;
    layout.lg = isExpanded ? 12 : 6;
    setSmtDashboardState((prevState) => ({
      ...prevState,
      bottomSectionLayout: layout
    }));
    // setBottomSectionLayout(layout);
  };

  const handleChange = (event, module, isTrend) => {
    isTrend ? setSmtDashboardState((prevState) => ({
      ...prevState,
      trendType: {
        ...prevState.trendType,
        [module]: event.target.value
      }
    })) : setSmtDashboardState((prevState) => ({
      ...prevState,
      paretoType: {
        ...prevState.paretoType,
        [module]: event.target.value
      }
    }));
  };

  const switchChart = (flag, module, isTrend = true) => {
    handleChange({
      "target": {
        "value": flag ? 1 : 0
      }
    }, module, isTrend)
  }

  const navigateToOee = (event) => {
    dispatch(addPath({ path: '/oee/dashboard/oee-accelerator', name: 'OEE By Line', icon: 'balance' }))
    const lineName = event.points[0].x;
    const lineData = lines.find((i) => i.Name === lineName);
    dispatch(setLineFilter(lineData));
    navigate("/oee/dashboard/oee-accelerator");
  };

  const navigateToBreakdown = (event) => {
    dispatch(addPath({ path: '/oee/dashboard/breakdown2', name: 'Breakdown By Line', icon: 'machine' }))
    const lineName = event.points[0].x;
    const lineData = lines.find((i) => i.Name === lineName);
    dispatch(setLineFilter(lineData));
    navigate("/oee/dashboard/breakdown2");
  };

  const navigateToMicrostop = (event) => {
    dispatch(addPath({ path: '/oee/dashboard/microstop', name: 'Microstop By Line', icon: 'machine' }))
    const lineName = event.points[0].x;
    const lineData = lines.find((i) => i.Name === lineName);
    dispatch(setLineFilter(lineData));
    navigate("/oee/dashboard/microstop");
  };

  const StyledSpeedDial = styled(SpeedDial)(({ theme }) => ({
    position: 'absolute',
    '&.MuiSpeedDial-directionUp, &.MuiSpeedDial-directionLeft': {
      bottom: theme.spacing(2),
      right: theme.spacing(2),
    },
    '&.MuiSpeedDial-directionDown, &.MuiSpeedDial-directionRight': {
      top: theme.spacing(2),
      left: theme.spacing(2),
    },
  }));

  const actions = [
    { name: 'Delay Analysis (Quality By Line)' },
    { name: 'Delay Analysis (Breakdown By Line)' },
    { name: 'Delay Analysis (Changeover By Line)' },
    { name: 'Delay Analysis (Performance By Line)' },
    { name: 'Cycle Time' },
    { name: 'Delay Analysis (By Line)' },
    { name: 'Delay Analysis' },
    { name: 'OEE By Line' },
    { name: 'OEE Analysis' }
  ];

  const oeeTrendParams = [
    { "key": "availabilityVal", "name": "Availability", "percentageKey": "availabilityPer" },
    { "key": "qualityVal", "name": "Quality", "percentageKey": "qualityPer" },
    { "key": "performanceVal", "name": "Performance", "percentageKey": "performancePer" },
    { "key": "oeeVal", "name": "OEE", "percentageKey": "oeePer" },
  ]

  const handleOeeTrendParamChange = async (event) => {
    let selected = oeeTrendParams.find(p => p["name"] === event.target.value);
    setSmtDashboardState((prevState) => ({
      ...prevState,
      oeeTrendSelectedParam: selected
    }));
  }

  const handleOeeParetoParamChange = async (event) => {
    let selected = oeeTrendParams.find(p => p["name"] === event.target.value);
    setSmtDashboardState((prevState) => ({
      ...prevState,
      oeePareto: calCulatePercenatgeAndSort(selected["key"], selected["percentageKey"], smtDashboardState.oeePareto),
      oeeParetoSelectedParam: selected
    }));
  }

  const focusToSection = (sectionName) => {
    let yOffset = -60;
    let ref = null;
    let behavior = 'smooth';
    switch (sectionName) {
      case 'OEE Analysis':
        ref = oeeAnalysisRef?.current?.getBoundingClientRect().top + window.scrollY + yOffset;
        break;
      case 'OEE By Line':
        ref = oeeByLineRef?.current?.getBoundingClientRect().top + window.scrollY + yOffset;
        break;
      case 'Delay Analysis':
        ref = delayRef?.current?.getBoundingClientRect().top + window.scrollY + yOffset;
        break;
      case 'Delay Analysis (By Line)':
        ref = delayByLineRef?.current?.getBoundingClientRect().top + window.scrollY + yOffset;
        break;
      case 'Cycle Time':
        ref = cycleTimeRef?.current?.getBoundingClientRect().top + + window.scrollY + yOffset;
        break;
      case 'Delay Analysis (Performance By Line)':
        ref = delayByPerformanceRef?.current?.getBoundingClientRect().top + window.scrollY + yOffset;
        break;
      case 'Delay Analysis (Changeover By Line)':
        ref = delayByChangeoverRef?.current?.getBoundingClientRect().top + window.scrollY + yOffset;
        break;
      case 'Delay Analysis (Breakdown By Line)':
        ref = delayByBreakdownRef?.current?.getBoundingClientRect().top + window.scrollY + yOffset;
        break;
      case 'Delay Analysis (Quality By Line)':
        ref = delayByQualityRef?.current?.getBoundingClientRect().top + window.scrollY + yOffset;
        break;
      default:
        break;
    }
    window.scrollTo({ top: ref, behavior: behavior });

  }

  const getOeeVal = (a, p, q) => {
    return parseFloat(((a / 100) * (p / 100) * (q / 100) * 100).toFixed(2));
  }

  return (
    !smtDashboardState.isFirstChunkDataLoaded ? <Loader /> :
      <div>
        {smtDashboardState.oeeParams !== undefined ?
          <Box flexGrow={1}>
            <Grid container spacing={1} justifyContent="center">
              <Grid item xs={12} sm={12} md={12} lg={12}>
                <BreadCrumb />
              </Grid>
              <Grid item xs={10} sm={10} md={6} lg={6}>
                <Typography style={{ fontSize: "1.5rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                  OEE Accelerator for ({plantName})
                </Typography>
              </Grid>
              <Grid item xs={2} sm={2} md={6} lg={6}>

              </Grid>
              {smtDashboardState.isAllDataLoaded ?
                <StyledSpeedDial
                  ariaLabel="SpeedDial playground example"
                  hidden={smtDashboardState.hidden}
                  sx={{ left: '90vw', position: 'fixed', marginBottom: '-0.5rem' }}
                  icon={<SpeedDialIcon />}>
                  {actions.map((action, i) => (
                    <SpeedDialAction
                      sx={{ width: '25rem', height: '2rem', marginRight: '20vw', borderRadius: '1rem', backgroundColor: theme["colors"]["colorShades"][i] }}
                      key={action.name}
                      tooltipTitle={"Please click to go to " + action.name + " section"}
                      icon={
                        <div style={{ color: 'black', fontFamily: theme["fontFamily"] }}>{action.name}</div>
                      }
                      onClick={() => focusToSection(action.name)}
                    />
                  ))}
                </StyledSpeedDial> : <></>}
            </Grid>
            {smtDashboardState.oeeParams?.OEE !== undefined ?
              <Accordion ref={oeeAnalysisRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    OEE Analysis ({smtDashboardState.timeRange["start"].toDateString()} - {smtDashboardState.timeRange["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <Grid container spacing={1} justifyContent="center">
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      <CardBox
                        type={RenderType.Gauge}
                        data={getOeeVal(smtDashboardState.oeeParams?.Availability, smtDashboardState.oeeParams?.Performance_Percentage, smtDashboardState.oeeParams?.Quality_Percentage)}
                        id="OEE"
                        gaugeRange={[0, 70, 85, 100]}
                        redGradientColor={theme["colors"]["redGradientColor"]}
                        yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                        greenGradientColor={theme["colors"]["greenGradientColor"]}
                        fontFamily={theme["fontFamily"]}
                        chartHeight="300px"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      <Card>
                        <CardHeader
                          style={{ paddingBottom: 0, marginBottom: "-0.5rem" }}
                          action={
                            <Stack
                              direction="row"
                              spacing={1}
                              justifyContent="flex-end"
                              alignItems="flex-start"
                            >
                              <Chip
                                label="View By Line"
                                style={{ fontFamily: theme["fontFamily"], fontWeight: "700" }}
                                color="primary"
                                variant={!smtDashboardState.isViewByLine ? "outlined" : ""}
                                onClick={async () =>
                                  await viewProductionByLineOrModel(true)
                                }
                              />
                              <Chip
                                label="View By Model"
                                style={{ fontFamily: theme["fontFamily"], fontWeight: "700" }}
                                color="primary"
                                variant={smtDashboardState.isViewByLine ? "outlined" : ""}
                                onClick={async () =>
                                  await viewProductionByLineOrModel(false)
                                }
                              />
                              <IconButton
                                onClick={() =>
                                  handleToSectionExpansion(!smtDashboardState.topSectionLayout.expanded)
                                }
                              >
                                {smtDashboardState.topSectionLayout.expanded ? (
                                  <CloseFullscreen />
                                ) : (
                                  <OpenInFull />
                                )}
                              </IconButton>
                            </Stack>
                          }
                        />
                        <CardContent style={{ paddingTop: "0rem" }}>
                          <Grid container spacing={2} justifyContent="center">
                            <Grid item xs={12} sm={12} md={12} lg={12}>
                              <BarChart
                                data={smtDashboardState.productionChartData}
                                categoryField={smtDashboardState.productionChartCategoryAxis}
                                redGradientColor={theme["colors"]["redGradientColor"]}
                                yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                                greenGradientColor={theme["colors"]["greenGradientColor"]}
                                range={[0, 94, 96, 100]}
                                dataSeriesKeyTitle={[
                                  {
                                    key: "plan",
                                    title: "Plan",
                                    isColorModificationRequired: false,
                                  },
                                  {
                                    key: "actual",
                                    title: "Actual",
                                    isColorModificationRequired: true,
                                  },
                                ]}
                                id="production"
                                title="Production: Actual vs Plan"
                                fontFamily={theme["fontFamily"]}
                                width="600px"
                                height="290px"
                              />
                            </Grid>
                          </Grid>
                        </CardContent>
                      </Card>
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={2}
                      lg={2}
                    >
                      <CardBox
                        type={RenderType.Gauge}
                        data={smtDashboardState.oeeParams?.Availability}
                        id="Availability"
                        gaugeRange={[0, 90, 95, 100]}
                        redGradientColor={theme["colors"]["redGradientColor"]}
                        yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                        greenGradientColor={theme["colors"]["greenGradientColor"]}
                        fontFamily={theme["fontFamily"]}
                        chartHeight="150px"
                        fontSize="smaller"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={2}
                      lg={2}
                    >
                      <CardBox
                        type={RenderType.Gauge}
                        data={smtDashboardState.oeeParams?.Performance_Percentage}
                        id="Performance"
                        gaugeRange={[0, 85, 90, 120]}
                        redGradientColor={theme["colors"]["redGradientColor"]}
                        yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                        greenGradientColor={theme["colors"]["greenGradientColor"]}
                        fontFamily={theme["fontFamily"]}
                        chartHeight="150px"
                        fontSize="smaller"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={2}
                      lg={2}
                    >
                      <CardBox
                        type={RenderType.Gauge}
                        data={smtDashboardState.oeeParams?.Quality_Percentage}
                        id="Quality"
                        gaugeRange={[0, 93, 97, 100]}
                        redGradientColor={theme["colors"]["redGradientColor"]}
                        yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                        greenGradientColor={theme["colors"]["greenGradientColor"]}
                        fontFamily={theme["fontFamily"]}
                        chartHeight="150px"
                        fontSize="smaller"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={2}
                      lg={2}
                    >
                      <CardBox
                        type={RenderType.Gauge}
                        data={smtDashboardState.oeeParams?.BTS}
                        id="BTS"
                        gaugeRange={[0, 90, 95, 100]}
                        redGradientColor={theme["colors"]["redGradientColor"]}
                        yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                        greenGradientColor={theme["colors"]["greenGradientColor"]}
                        fontFamily={theme["fontFamily"]}
                        chartHeight="150px"
                        fontSize="smaller"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={2}
                      lg={2}
                    >
                      <CardBox
                        type={RenderType.Gauge}
                        data={parseFloat((smtDashboardState.oeeParams?.Total_FTT / smtDashboardState.oeeParams?.Total * 100).toFixed(2))}
                        id="FTT"
                        gaugeRange={[0, 90, 95, 100]}
                        redGradientColor={theme["colors"]["redGradientColor"]}
                        yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                        greenGradientColor={theme["colors"]["greenGradientColor"]}
                        fontFamily={theme["fontFamily"]}
                        chartHeight="150px"
                        fontSize="smaller"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={2}
                      lg={2}
                    >
                      <CardBox
                        type={RenderType.Gauge}
                        data={parseFloat((smtDashboardState.oeeParams?.Total_NG / smtDashboardState.oeeParams?.Total * 100).toFixed(2))}
                        id="Scrap"
                        gaugeRange={[0, 3, 7, 10]}
                        redGradientColor={theme["colors"]["redGradientColor"]}
                        yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                        greenGradientColor={theme["colors"]["greenGradientColor"]}
                        fontFamily={theme["fontFamily"]}
                        chartHeight="150px"
                        fontSize="smaller"
                      />
                    </Grid>
                  </Grid>
                </AccordionDetails>
              </Accordion> :
              <Card>
                <CardContent>
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                    No data available for {new Date(dateParam).toDateString()}
                  </Typography>
                </CardContent>
              </Card>}
            {smtDashboardState.oeeTrend?.length > 0 ?
              <Accordion ref={oeeByLineRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    OEE (By Line) ({smtDashboardState.timeRangeForTrend["start"].toDateString()} - {smtDashboardState.timeRangeForTrend["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <Grid container spacing={1} justifyContent="center">
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.oeeTrend?.length > 0 ? (
                        <Card>
                          <CardHeader
                            style={{ paddingBottom: 0 }}
                            action={
                              <Stack direction="row" spacing={2} sx={{
                                justifyContent: "flex-end",
                                alignItems: "center",
                              }}>
                                <ChartSwitch switchChart={(flag) => switchChart(flag, "oeeByLine")} />
                                <FormControl>
                                  <InputLabel id="theme-lbl">OEE Parameters</InputLabel>
                                  <Select
                                    labelId="trend-lbl"
                                    id="ddlTrend"
                                    style={{ width: '10rem' }}
                                    value={smtDashboardState.oeeTrendSelectedParam["name"]}
                                    label="OEE Params"
                                    onChange={handleOeeTrendParamChange}
                                  >
                                    {oeeTrendParams.map(item => (
                                      <MenuItem key={item["key"]} value={item["name"]}>
                                        <Stack direction="row" spacing={1}>
                                          <div>{item["name"]}</div>
                                        </Stack>
                                      </MenuItem>
                                    ))}
                                  </Select>
                                </FormControl>
                                <IconButton
                                  onClick={() =>
                                    handleToSectionExpansion(!smtDashboardState.topSectionLayout.expanded)
                                  }
                                >
                                  {smtDashboardState.topSectionLayout.expanded ? (
                                    <CloseFullscreen />
                                  ) : (
                                    <OpenInFull />
                                  )}
                                </IconButton>
                              </Stack>
                            }
                          />
                          <CardContent>
                            {smtDashboardState.trendType["oeeByLine"] === 0 ? <LineChart
                              data={smtDashboardState.oeeTrend}
                              unit="%"
                              yAxisTitle="Percentage"
                              labelRotation={{ required: true, angle: -45 }}
                              categoryField="range"
                              valueField={smtDashboardState.oeeTrendSelectedParam["key"]}
                              id="oeeTrend"
                              title="OEE Trend"
                              fontFamily={theme["fontFamily"]}
                              colors={theme["colors"]["colorShades"]}
                              width="600px"
                              height="450px"
                            /> : <StackedColumnChart
                              data={smtDashboardState.oeeTrendBar}
                              // categoryField="time"
                              categoryField="date"
                              dataSeriesKeyTitle={[
                                { key: "percentage", title: "Percentage" }
                              ]}
                              barKeysAndTitles={lines.map(p => ({ "key": p["Name"] + "_" + smtDashboardState.oeeTrendSelectedParam["key"], "title": p["Name"] }))}
                              labelRotationRequired={true}
                              id="oeeTrendBar"
                              title="By Cause"
                              fontFamily={theme["fontFamily"]}
                              colors={theme["colors"]["colorShades"]}
                              width="600px"
                              height="400px"
                            />}
                          </CardContent>
                        </Card>
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.oeePareto?.length > 0 ?
                        <Card>
                          <CardHeader
                            style={{ paddingBottom: 0 }}
                            action={
                              <Stack direction="row" spacing={2} sx={{
                                justifyContent: "flex-end",
                                alignItems: "center",
                              }}>
                                <ChartSwitch2 switchChart={(flag) => switchChart(flag, "oeeByLine", false)} />
                                <FormControl>
                                  <InputLabel id="theme-lbl">OEE Parameters</InputLabel>
                                  <Select
                                    labelId="trend-lbl"
                                    id="ddlTrend"
                                    style={{ width: '10rem' }}
                                    value={smtDashboardState.oeeParetoSelectedParam["name"]}
                                    label="OEE Params"
                                    onChange={handleOeeParetoParamChange}
                                  >
                                    {oeeTrendParams.map(item => (
                                      <MenuItem key={item["key"]} value={item["name"]}>
                                        <Stack direction="row" spacing={1}>
                                          <div>{item["name"]}</div>
                                        </Stack>
                                      </MenuItem>
                                    ))}
                                  </Select>
                                </FormControl>
                                <IconButton
                                  onClick={() =>
                                    handleToSectionExpansion(!smtDashboardState.topSectionLayout.expanded)
                                  }
                                >
                                  {smtDashboardState.topSectionLayout.expanded ? (
                                    <CloseFullscreen />
                                  ) : (
                                    <OpenInFull />
                                  )}
                                </IconButton>
                              </Stack>
                            }
                          />
                          <CardContent>
                            {smtDashboardState.paretoType["oeeByLine"] === 0 ? <ColumnLineChart
                              data={smtDashboardState.oeePareto}
                              categoryField="line"
                              dataSeriesKeyTitle={[
                                { key: smtDashboardState.oeeParetoSelectedParam["key"], title: smtDashboardState.oeeParetoSelectedParam["name"] },
                                { key: smtDashboardState.oeeParetoSelectedParam["percentageKey"], title: "Percentage" },
                              ]}
                              labelRotationRequired={true}
                              id="cause"
                              title="By Cause"
                              fontFamily={theme["fontFamily"]}
                              colors={theme["colors"]["colorShades"]}
                              width="600px"
                              height="418px"
                            /> : <TwoLevelPieChart id="twoLevelPieChart"
                              data={smtDashboardState.oeePareto}
                              categoryField="line"
                              dataSeriesKeyTitle={[
                                { key: smtDashboardState.oeeParetoSelectedParam["key"], title: smtDashboardState.oeeParetoSelectedParam["name"] },
                                { key: smtDashboardState.oeeParetoSelectedParam["percentageKey"], title: "Percentage" },
                              ]}
                              fontFamily={theme["fontFamily"]}
                              colors={theme["colors"]["colorShades"]}
                              height="418px" />}
                          </CardContent>
                        </Card> : <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>}
                    </Grid>
                  </Grid>
                </AccordionDetails>
              </Accordion> :
              <Card>
                <CardContent>
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                    No data available for {new Date(dateParam).toDateString()}
                  </Typography>
                </CardContent>
              </Card>}
            {smtDashboardState.totalDelayData.length > 0 ?
              <Accordion ref={delayRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    Delay Analysis ({smtDashboardState.timeRangeForTrend["start"].toDateString()} - {smtDashboardState.timeRangeForTrend["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <Grid container spacing={1} justifyContent="center">
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.totalDelayTrendData.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.trendType["delay"] === 0 ? RenderType.TREND : RenderType.TRENDBAR
                          }
                          switchChart={(flag) => switchChart(flag, "delay")}
                          data={smtDashboardState.totalDelayTrendData}
                          isSwitchRequired={true}
                          actions={[]}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                          IsLossOrGainIndicatorRequired={true}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.totalDelayData?.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.paretoType["delay"] === 0 ? RenderType.PARETO : RenderType.PARETOPIE
                          }
                          switchChart={(flag) => switchChart(flag, "delay", false)}
                          id="delayPie"
                          data={smtDashboardState.totalDelayData}
                          actions={[]}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                          isLegendToBeAdjusted={true}
                          IsLossOrGainIndicatorRequired={true}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                  </Grid>
                </AccordionDetails>
              </Accordion> :
              <Card>
                <CardContent>
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                    No data available for {new Date(dateParam).toDateString()}
                  </Typography>
                </CardContent>
              </Card>}
            {smtDashboardState.totalDelayDataByLine.length > 0 ?
              <Accordion ref={delayByLineRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    Delay Analysis (By Line) ({smtDashboardState.timeRangeForTrend["start"].toDateString()} - {smtDashboardState.timeRangeForTrend["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <Grid container spacing={1} justifyContent="center">
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.totalDelayTrendDataByLine.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.trendType["delayByLine"] === 0 ? RenderType.TREND : RenderType.TRENDBAR
                          }
                          data={smtDashboardState.totalDelayTrendDataByLine}
                          switchChart={(flag) => switchChart(flag, "delayByLine")}
                          isSwitchRequired={true}
                          actions={[]}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                          IsLossOrGainIndicatorRequired={true}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.totalDelayDataByLine?.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.paretoType["delayByLine"] === 0 ? RenderType.PARETO : RenderType.PARETOPIE
                          }
                          switchChart={(flag) => switchChart(flag, "delayByLine", false)}
                          id="delayPieByLine"
                          data={smtDashboardState.totalDelayDataByLine}
                          actions={[]}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          handleClick={navigateToOee}
                          fontFamily={theme["fontFamily"]}
                          IsLossOrGainIndicatorRequired={true}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                  </Grid>
                </AccordionDetails>
              </Accordion> :
              <Card>
                <CardContent>
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                    No data available for {new Date(dateParam).toDateString()}
                  </Typography>
                </CardContent>
              </Card>}
            {smtDashboardState.chTrendData.length > 0 ?
              <Accordion ref={cycleTimeRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    Cycle Time ({smtDashboardState.timeRange["start"].toDateString()} - {smtDashboardState.timeRange["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <SmtCycleTime />
                </AccordionDetails>
              </Accordion> : <Card>
                <CardContent>
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                    No data available for {new Date(dateParam).toDateString()}
                  </Typography>
                </CardContent>
              </Card>}
            {smtDashboardState.paretoData.length > 0 ? (
              <Accordion ref={delayByPerformanceRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    Delay Analysis (Performance By Line) ({smtDashboardState.timeRangeForTrend["start"].toDateString()} - {smtDashboardState.timeRangeForTrend["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <Grid container spacing={1} justifyContent="center">
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.trendData.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.trendType["performanceByLine"] === 0 ? RenderType.TREND : RenderType.TRENDBAR
                          }
                          data={smtDashboardState.trendData}
                          actions={[]}
                          switchChart={(flag) => switchChart(flag, "performanceByLine")}
                          isSwitchRequired={true}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                          IsLossOrGainIndicatorRequired={true}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.paretoData?.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.paretoType["performanceByLine"] === 0 ? RenderType.PARETO : RenderType.PARETOPIE
                          }
                          switchChart={(flag) => switchChart(flag, "performanceByLine", false)}
                          id="performancePieByLine"
                          data={smtDashboardState.paretoData}
                          actions={[]}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          handleClick={navigateToMicrostop}
                          fontFamily={theme["fontFamily"]}
                          IsLossOrGainIndicatorRequired={true}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                  </Grid>
                </AccordionDetails>
              </Accordion>
            ) : (
              <Card>
                <CardContent>
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                    No data available for {new Date(dateParam).toDateString()}
                  </Typography>
                </CardContent>
              </Card>
            )}
            {smtDashboardState.chTrendData.length > 0 ? (
              <Accordion ref={delayByChangeoverRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    Delay Analysis (Changeover By Line) ({smtDashboardState.timeRangeForTrend["start"].toDateString()} - {smtDashboardState.timeRangeForTrend["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <Grid container spacing={1} justifyContent="center">
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.chTrendData.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.trendType["changeoverByLine"] === 0 ? RenderType.TREND : RenderType.TRENDBAR
                          }
                          data={smtDashboardState.chTrendData}
                          actions={[]}
                          switchChart={(flag) => switchChart(flag, "changeoverByLine")}
                          isSwitchRequired={true}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.chParetoData?.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.paretoType["changeoverByLine"] === 0 ? RenderType.PARETO : RenderType.PARETOPIE
                          }
                          switchChart={(flag) => switchChart(flag, "changeoverByLine", false)}
                          id="changeoverPieByLine"
                          data={smtDashboardState.chParetoData}
                          actions={[]}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                  </Grid>
                  <SmtChangeOver />
                </AccordionDetails>
              </Accordion>
            ) : (<Card>
              <CardContent>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                  No data available for {new Date(dateParam).toDateString()}
                </Typography>
              </CardContent>
            </Card>)}
            {smtDashboardState.brTrendData.length > 0 ? (
              <Accordion ref={delayByBreakdownRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    Delay Analysis (Breakdown By Line) ({smtDashboardState.timeRangeForTrend["start"].toDateString()} - {smtDashboardState.timeRangeForTrend["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <Grid container spacing={1} justifyContent="center">
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.brTrendData.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.trendType["breakdownByLine"] === 0 ? RenderType.TREND : RenderType.TRENDBAR
                          }
                          data={smtDashboardState.brTrendData}
                          actions={[]}
                          switchChart={(flag) => switchChart(flag, "breakdownByLine")}
                          isSwitchRequired={true}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.brParetoData?.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.paretoType["breakdownByLine"] === 0 ? RenderType.PARETO : RenderType.PARETOPIE
                          }
                          switchChart={(flag) => switchChart(flag, "breakdownByLine", false)}
                          id="breakdownPieByLine"
                          data={smtDashboardState.brParetoData}
                          actions={[]}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          handleClick={navigateToBreakdown}
                          fontFamily={theme["fontFamily"]}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                  </Grid>
                </AccordionDetails>
              </Accordion>
            ) : (<Card>
              <CardContent>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                  No data available for {new Date(dateParam).toDateString()}
                </Typography>
              </CardContent>
            </Card>)}
            {smtDashboardState.qParetoData.length > 0 ? (
              <Accordion ref={delayByQualityRef} defaultExpanded style={{ margin: 'auto' }}>
                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel1-content"
                  id="panel1-header"
                >
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"], marginTop: "-1rem" }}>
                    Delay Analysis (Quality By Line) ({smtDashboardState.timeRangeForTrend["start"].toDateString()} - {smtDashboardState.timeRangeForTrend["end"].toDateString()})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails style={{ marginTop: "-1.5rem" }}>
                  <Grid container spacing={1} justifyContent="center">
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.qTrendData.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.trendType["qualityByLine"] === 0 ? RenderType.TREND : RenderType.TRENDBAR
                          }
                          data={smtDashboardState.qTrendData}
                          actions={[]}
                          switchChart={(flag) => switchChart(flag, "qualityByLine")}
                          isSwitchRequired={true}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                    <Grid
                      item
                      xs={smtDashboardState.topSectionLayout.xs}
                      sm={smtDashboardState.topSectionLayout.sm}
                      md={smtDashboardState.topSectionLayout.md}
                      lg={smtDashboardState.topSectionLayout.lg}
                    >
                      {smtDashboardState.qParetoData?.length > 0 ? (
                        <CardBox
                          type={
                            smtDashboardState.paretoType["qualityByLine"] === 0 ? RenderType.PARETO : RenderType.PARETOPIE
                          }
                          switchChart={(flag) => switchChart(flag, "qualityByLine", false)}
                          id="qualityPieByLine"
                          data={smtDashboardState.qParetoData}
                          actions={[]}
                          handleExpansion={handleToSectionExpansion}
                          expanded={smtDashboardState.topSectionLayout.expanded}
                          colors={theme["colors"]["colorShades"]}
                          fontFamily={theme["fontFamily"]}
                        />
                      ) : (
                        <Card>
                          <CardContent>
                            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                              No data available for {new Date(dateParam).toDateString()}
                            </Typography>
                          </CardContent>
                        </Card>
                      )}
                    </Grid>
                  </Grid>
                </AccordionDetails>
              </Accordion>
            ) : (<Card>
              <CardContent>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                  No data available for {new Date(dateParam).toDateString()}
                </Typography>
              </CardContent>
            </Card>)}
          </Box> :
          <Box flexGrow={1}>
            <Card>
              <CardContent>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                  No data available for {new Date(dateParam).toDateString()}
                </Typography>
              </CardContent>
            </Card>
          </Box>
        }
      </div >
  );
};

export default SMTDashboard;
