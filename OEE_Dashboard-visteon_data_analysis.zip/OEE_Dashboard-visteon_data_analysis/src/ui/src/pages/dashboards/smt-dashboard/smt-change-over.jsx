import { Grid, Typography, Card, CardContent } from "@mui/material";
import { useEffect, useState } from "react";
import CardBox from "../../../components/cardbox-container/cardbox-container";
import RenderType from "../../../models/render-type";
import DasboardLayout from "../../../models/dashboard-content-layout";
import { useDispatch, useSelector } from "react-redux";
import { tqSelector, themeSelector, plantNameSelector, dateSelector } from "../../../reducers/filter-reducer";
import {
  fetchAllData,
  fetchChangeOverGridTrendData,
} from "../../../reducers/changeover-data-reducer";
import UtilityMethods from "../../../utilities";

function SmtChangeOver() {
  const dispatch = useDispatch();
  const plantName = useSelector(plantNameSelector);
  const dateParam = useSelector(dateSelector);
  const tq = useSelector(tqSelector);
  const theme = useSelector(themeSelector);
  const [timeRangeForTrend, setTimeRangeForTrend] = useState(
    UtilityMethods.createTimeQuantumRangeForTrend(tq)
  );
  const [changeOverGridData, setChangeOverGridData] = useState([]);
  const [changeOverGridTrendDataByLine, setChangeOverGridTrendDataByLine] =
    useState([]);

  const [
    changeOverGridTrendChartDataByLine,
    setChangeOverGridTrendChartDataByLine,
  ] = useState([]);
  const [switchValue, setSwitchValue] = useState(true);
  const [isLineClicked, setIsLineClicked] = useState(false);
  const [topSectionLayout, setTopSectionLayout] = useState(
    new DasboardLayout()
  );
  const [
    lineNameMAchineNameConcatenatedStr,
    setLineNameMAchineNameConcatenatedStr,
  ] = useState("");

  const [totalParams, setTotalParams] = useState(null);

  const handleTopSectionExpansion = (isExpanded) => {
    const layout = { ...topSectionLayout };
    layout.expanded = isExpanded;
    layout.md = isExpanded ? 12 : 6;
    layout.lg = isExpanded ? 12 : 6;
    setTopSectionLayout(layout);
  };

  const closeCard = () => {
    handleTopSectionExpansion(true);
    setChangeOverGridTrendChartDataByLine([]);
  }


  useEffect(() => {
    let fetchedDate = new Date(dateParam);
    setTimeRangeForTrend(UtilityMethods.createTimeQuantumRangeForTrend(tq, fetchedDate.getFullYear(), fetchedDate.getDate(), fetchedDate.getMonth()))
    getChangeOverData();
  }, [dispatch]);

  const getChangeOverData = async () => {

    const parallelApiCallsResult = await dispatch(
      fetchAllData({ plant: plantName, tq: tq, date: dateParam })
    ).unwrap();

    if (parallelApiCallsResult.data !== undefined) {
      let allData = parallelApiCallsResult.data;
      if (allData[0]?.data?.length > 0)
        setChangeOverGridData(allData[0].data);
      if (allData[1]?.data?.length > 0)
        await getGridTotalTrendData(allData[1]);
    }
  };

  const getGridTotalTrendData = async (choGridTrendData) => {
    if (!switchValue)
      setSwitchValue(true);
    setLineNameMAchineNameConcatenatedStr('Total');
    const choGridTrendModelData = [];
    if (choGridTrendData.data.length > 0) {
      choGridTrendModelData.push({
        title: "Plan",
        values: getPlanTimeValues(choGridTrendData.data),
      });
      choGridTrendModelData.push({
        title: "Actual",
        values: getActualTimeValues(choGridTrendData.data),
      });
      const totalPlanCount = getTotalPlanOrActualCountOrValue(choGridTrendData, true, "count");
      const totalPlanStop = getTotalPlanOrActualCountOrValue(choGridTrendData, true, "value");
      const totalActCount = getTotalPlanOrActualCountOrValue(choGridTrendData, false, "count");
      const totalActStop = getTotalPlanOrActualCountOrValue(choGridTrendData, false, "value");

      setTotalParams({ plan: { count: totalPlanCount, stop: ((totalPlanStop / totalPlanCount)).toFixed(2) }, actual: { count: totalActCount, stop: ((totalActStop / totalActCount)).toFixed(2) } });

      setChangeOverGridTrendDataByLine(choGridTrendData.data);
      setChangeOverGridTrendChartDataByLine(choGridTrendModelData);
      setIsLineClicked(false);
    }
  }

  const handleSwitchClicked = (event) => {
    setSwitchValue(event.target.checked);
    const choGridTrendData = changeOverGridTrendDataByLine;
    if (!switchValue) {
      const choGridTrendModelData = [];
      choGridTrendModelData.push({
        title: "Plan",
        values: getPlanTimeValues(choGridTrendData),
      });
      choGridTrendModelData.push({
        title: "Actual",
        values: getActualTimeValues(choGridTrendData),
      });
      setChangeOverGridTrendChartDataByLine(choGridTrendModelData);
      handleTopSectionExpansion(false);
    } else {
      const choGridTrendModelData = [];
      choGridTrendModelData.push({
        title: "Plan",
        values: getPlanCountValues(choGridTrendData),
      });
      choGridTrendModelData.push({
        title: "Actual",
        values: getActualCountValues(choGridTrendData),
      });
      setChangeOverGridTrendChartDataByLine(choGridTrendModelData);
      handleTopSectionExpansion(false);
    }
  };
  const handleLineClick = async (lineNameAndId) => {
    setIsLineClicked(false);
    setLineNameMAchineNameConcatenatedStr(lineNameAndId["lineName"]);
    const choGridTrendModelData = [];
    const choGridTrendData = await dispatch(
      fetchChangeOverGridTrendData({ plant: plantName, line: lineNameAndId["lineId"], tq: tq, date: dateParam })
    ).unwrap();
    if (choGridTrendData?.data?.length > 0) {
      choGridTrendModelData.push({
        title: "Plan",
        values: getPlanTimeValues(choGridTrendData.data),
      });
      choGridTrendModelData.push({
        title: "Actual",
        values: getActualTimeValues(choGridTrendData.data),
      });
      setChangeOverGridTrendDataByLine(choGridTrendData.data);
      setChangeOverGridTrendChartDataByLine(choGridTrendModelData);
      setSwitchValue(true);
      setIsLineClicked(true);
    }
  };

  const getTotalPlanOrActualCountOrValue = (choGridTrendData, isPlan, fieldName) => {
    let sum = 0;
    choGridTrendData.data.forEach((d) => {
      if (d.data.data !== undefined)
        sum += isPlan ? d.data?.data?.plan[fieldName] : d.data?.data?.actual[fieldName];
    })
    return sum;
  }

  const getPlanCountValues = (choGridTrendData) => {
    const values = [];
    choGridTrendData.forEach((d) =>
      values.push({ range: d.range, value: d.data?.data?.plan?.count })
    );
    return values;
  };

  const getActualCountValues = (choGridTrendData) => {
    const values = [];
    choGridTrendData.forEach((d) =>
      values.push({ range: d.range, value: d.data?.data?.actual?.count })
    );
    return values;
  };

  const getPlanTimeValues = (choGridTrendData) => {
    const values = [];
    choGridTrendData.forEach((d) => {
      let val = d.data?.data?.plan?.value / d.data?.data?.plan?.count;
      values.push({
        range: d.range,
        value: isNaN(val) ? 0 : val,
      })
    }
    );
    return values;
  };

  const getActualTimeValues = (choGridTrendData) => {
    const values = [];
    choGridTrendData.forEach((d) => {
      let val = d.data?.data?.actual?.value / d.data?.data?.actual?.count;
      values.push({
        range: d.range,
        value: isNaN(val) ? 0 : val,
      })
    }
    );
    return values;
  };

  return (
    <>
      {changeOverGridData.length > 0 && totalParams ? (
        <>
          <Grid container spacing={1} justifyContent="center">
            <Grid item xs={12} sm={12} md={12} lg={12}>
              <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                Delay Analysis (Changeover By Line) (
                {timeRangeForTrend["start"].toDateString()} -{" "}
                {timeRangeForTrend["end"].toDateString()})
              </Typography>
            </Grid>
            {changeOverGridTrendChartDataByLine?.length > 0 ? (
              <Grid
                item
                xs={topSectionLayout.xs}
                sm={topSectionLayout.sm}
                md={topSectionLayout.md}
                lg={topSectionLayout.lg}
              >

                <CardBox
                  type={RenderType.LineChartTrend}
                  data={changeOverGridTrendChartDataByLine}
                  handleExpansion={handleTopSectionExpansion}
                  expanded={topSectionLayout.expanded}
                  timeRange={timeRangeForTrend}
                  lineOrMachine={lineNameMAchineNameConcatenatedStr}
                  handleLineSwitchClick={handleSwitchClicked}
                  switchValue={switchValue}
                  trueValue={"Avg."}
                  falseValue={"Count"}
                  lineChartYLabel={switchValue ? "Average Changeover Time" : "Changeover Count"}
                  fontFamily={theme["fontFamily"]}
                  colorShades={theme["colors"]["colorShades"]}
                  closeCard={closeCard}
                  totalTrendGetter={getGridTotalTrendData}
                  totalParams={totalParams}
                  isLineClicked={isLineClicked}
                />
              </Grid>
            ) : (
              <Card>
                <CardContent>
                  <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                    No data available for {new Date(dateParam).toDateString()}
                  </Typography>
                </CardContent>
              </Card>
            )}
            <Grid
              item
              xs={topSectionLayout.xs}
              sm={topSectionLayout.sm}
              md={topSectionLayout.md}
              lg={topSectionLayout.lg}
            >
              {changeOverGridData.length > 0 ? (
                <CardBox
                  type={RenderType.CustomTable}
                  data={changeOverGridData}
                  actions={[]}
                  handleExpansion={handleTopSectionExpansion}
                  expanded={topSectionLayout.expanded}
                  colors={theme["colors"]["colorShades"]}
                  handleClick={handleLineClick}
                  fontFamily={theme["fontFamily"]}
                  redGradientColor={theme["colors"]["redGradientColor"]}
                  yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                  greenGradientColor={theme["colors"]["greenGradientColor"]}
                />
              ) : (
                <Card>
                  <CardContent>
                    <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
                      No data available for {new Date(dateParam).toDateString()}
                    </Typography>
                  </CardContent>
                </Card>
              )}
            </Grid>
          </Grid>
        </>
      ) : (
        <Card>
          <CardContent>
            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
              No data available for {new Date(dateParam).toDateString()}
            </Typography>
          </CardContent>
        </Card>
      )}
    </>
  );
}

export default SmtChangeOver;
