import { Grid, Card, CardContent, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import CardBox from "../../../components/cardbox-container/cardbox-container";
import RenderType from "../../../models/render-type";
import DasboardLayout from "../../../models/dashboard-content-layout";
import { useDispatch, useSelector } from "react-redux";
import { tqSelector, themeSelector, plantNameSelector, dateSelector } from "../../../reducers/filter-reducer";

import {
  fetchCycleTimeData
} from "../../../reducers/delayed-dashboard-reducer";

function SmtCycleTime() {
  const dispatch = useDispatch();
  const plantName = useSelector(plantNameSelector);
  const tq = useSelector(tqSelector);
  const dateParam = useSelector(dateSelector);
  const theme = useSelector(themeSelector);
  const [cycleTimeData, setCycleTimeData] = useState([]);

  const [topSectionLayout, setTopSectionLayout] = useState(
    new DasboardLayout()
  );

  const handleTopSectionExpansion = (isExpanded) => {
    const layout = { ...topSectionLayout };
    layout.expanded = isExpanded;
    layout.md = isExpanded ? 12 : 6;
    layout.lg = isExpanded ? 12 : 6;
    setTopSectionLayout(layout);
  };

  useEffect(() => {
    getChangeOverData();
  }, [dispatch]);

  const getChangeOverData = async () => {
    const cycleTimeData = await dispatch(
      fetchCycleTimeData({ plant: plantName, tq: tq, date: dateParam })
    ).unwrap();
    if (cycleTimeData.data.cycleTimeData?.length > 0) {
      setCycleTimeData(cycleTimeData.data.cycleTimeData);
    }
  };

  return (
    <>
      {cycleTimeData.length > 0 ? (
        <>
          <Grid container spacing={1} justifyContent="center">
            <Grid
              item
              xs={12}
              sm={12}
              md={12}
              lg={12}
            >
              <CardBox
                type={RenderType.CycleTimeTable}
                data={cycleTimeData}
                actions={[]}
                handleExpansion={handleTopSectionExpansion}
                expanded={true}
                colors={theme["colors"]["colorShades"]}
                fontFamily={theme["fontFamily"]}
                redGradientColor={theme["colors"]["redGradientColor"]}
                yellowGradientColor={theme["colors"]["yellowGradientColor"]}
                greenGradientColor={theme["colors"]["greenGradientColor"]}
              />
            </Grid>
          </Grid>
        </>
      ) : (
        <Card>
          <CardContent>
            <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>
              No data available for {new Date(dateParam).toDateString()}
            </Typography>
          </CardContent>
        </Card>
      )}
    </>
  );
}

export default SmtCycleTime;
