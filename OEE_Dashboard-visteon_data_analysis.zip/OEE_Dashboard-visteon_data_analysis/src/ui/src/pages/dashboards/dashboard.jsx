import { Outlet } from "react-router-dom";

const Dashboard = () => {
    return (
        <Outlet />
    );
}

export default Dashboard;