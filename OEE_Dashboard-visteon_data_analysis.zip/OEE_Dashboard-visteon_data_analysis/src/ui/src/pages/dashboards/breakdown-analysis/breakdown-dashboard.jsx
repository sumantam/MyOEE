import { Box, Grid } from "@mui/material";
import { BarChart } from '@mui/x-charts/BarChart';
import { LineChart } from '@mui/x-charts/LineChart';
import { ResponsiveChartContainer } from '@mui/x-charts/ResponsiveChartContainer';
import { LinePlot } from '@mui/x-charts/LineChart';
import { BarPlot } from '@mui/x-charts/BarChart';
import { ChartsXAxis } from '@mui/x-charts/ChartsXAxis';
import { ChartsYAxis } from '@mui/x-charts/ChartsYAxis';
import { DataGrid } from '@mui/x-data-grid';
import Paper from '@mui/material/Paper';
import '../../../App.css';
import { 
    lineChartXAxisData, 
    monthShortNames, 
    pickAndPlace4, 
    pickAndPlace2, 
    printer, 
    oven, 
    spi, 
    dualChartXaisData, 
    stopTimeData, 
    percentageData, 
    columns, 
    rows, 
    paynterData,
    colorPalette,
    paynterDataXAxisLabels
 } from './data';

const BreakdownDashboard = () => {
    return (
        <Box flexGrow={1} p={2}>
            <h3>Breakdown Analysis</h3>
            <Grid container spacing={1} justifyContent="center">
                <Grid item xs={12} sm={12} md={6} lg={6}>
                    <Paper elevation={3} style={{ padding: "1rem" }}>
                        <h5>Trend</h5>
                        <LineChart
                            xAxis={[
                                {
                                    id: 'Months',
                                    data: lineChartXAxisData,
                                    scaleType: 'time',
                                    valueFormatter: (date) => monthShortNames[date.getMonth()],
                                }
                            ]}
                            series={[
                                {
                                    id: 'PickAndPlace4',
                                    data: pickAndPlace4,
                                    stack: 'total',
                                    area: true,
                                    showMark: true,
                                    label: 'Pick And Place 4',
                                    color: colorPalette[3]
                                },
                                {
                                    id: 'PickAndPlace2',
                                    data: pickAndPlace2,
                                    stack: 'total',
                                    area: true,
                                    showMark: true,
                                    label: 'Pick And Place 2',
                                    color: colorPalette[4]
                                },
                                {
                                    id: 'Printer',
                                    data: printer,
                                    stack: 'total',
                                    area: true,
                                    showMark: true,
                                    label: 'Printer',
                                    color: colorPalette[5]
                                },
                                {
                                    id: 'Oven',
                                    data: oven,
                                    stack: 'total',
                                    area: true,
                                    showMark: true,
                                    label: 'Oven',
                                    color: colorPalette[6]
                                },
                                {
                                    id: 'SPI',
                                    data: spi,
                                    stack: 'total',
                                    area: true,
                                    showMark: true,
                                    label: 'SPI',
                                    color: colorPalette[7]
                                },
                            ]}
                            height={300}
                            margin={{ left: 30, right: 30, bottom: 30 }}
                            grid={{ vertical: true, horizontal: true }}
                        />
                    </Paper>
                </Grid>
                <Grid item xs={12} sm={12} md={6} lg={6}>
                    <Paper elevation={3} style={{ padding: "1rem" }}>
                        <h5>Pareto</h5>
                        <ResponsiveChartContainer
                            xAxis={[
                                {
                                    scaleType: 'band',
                                    data: dualChartXaisData,
                                    id: 'machines',
                                    tickLabelStyle: { fontSize: '0.7rem' }
                                },
                            ]}
                            yAxis={[
                                {
                                    id: 'stopTime'
                                },
                                {
                                    id: 'percentage'
                                }]}
                            series={[
                                {
                                    type: 'bar',
                                    id: 'stopTime',
                                    yAxisKey: 'stopTime',
                                    data: stopTimeData,
                                    color: colorPalette[6],
                                },
                                {
                                    type: 'line',
                                    id: 'percentage',
                                    yAxisKey: 'percentage',
                                    data: percentageData,
                                    showMark: true,
                                    stack: 'total',
                                    color: colorPalette[4],
                                }
                            ]}
                            height={300}
                        >
                            <BarPlot />
                            <LinePlot />
                            <ChartsXAxis axisId="machines" labelFontSize={18} />
                            <ChartsYAxis axisId="stopTime" label="Stop Time" />
                            <ChartsYAxis axisId="percentage" position="right" label="Percentage" />
                        </ResponsiveChartContainer>
                    </Paper>
                </Grid>
                <Grid item xs={12} sm={12} md={6} lg={6}>
                    <Paper elevation={3} style={{ padding: "1rem" }}>
                        <h5>Paynter</h5>
                        <table>
                            <tbody>
                                <tr>
                                    <th style={{ textAlign: 'left' }}>Pick & Place 4</th>
                                    <td style={{ width: '100%' }}>
                                        <BarChart
                                            xAxis={[{
                                                scaleType: 'band',
                                                data: paynterDataXAxisLabels,
                                                colorMap: {
                                                    type: 'ordinal',
                                                    colors: colorPalette
                                                },
                                                tickLabelStyle: { fontSize: '0.7rem' }
                                            }]}
                                            series={[{ data: paynterData }]}
                                            height={150}
                                        />
                                    </td>
                                </tr>
                                <tr>
                                    <th style={{ textAlign: 'left' }}>Pick & Place 2</th>
                                    <td style={{ width: '100%' }}>
                                        <BarChart
                                            xAxis={[{
                                                scaleType: 'band',
                                                data: paynterDataXAxisLabels,
                                                colorMap: {
                                                    type: 'ordinal',
                                                    colors: colorPalette
                                                },
                                                tickLabelStyle: { fontSize: '0.7rem' }
                                            }]}
                                            series={[{ data: paynterData }]}

                                            height={150}
                                        />
                                    </td>
                                </tr>
                                <tr>
                                    <th style={{ textAlign: 'left' }}>Printer</th>
                                    <td style={{ width: '100%' }}>
                                        <BarChart
                                            xAxis={[{
                                                scaleType: 'band',
                                                data: paynterDataXAxisLabels,
                                                colorMap: {
                                                    type: 'ordinal',
                                                    colors: colorPalette
                                                },
                                                tickLabelStyle: { fontSize: '0.7rem' }
                                            }]}
                                            series={[{ data: paynterData }]}

                                            height={150}
                                        />
                                    </td>
                                </tr>
                                <tr>
                                    <th style={{ textAlign: 'left' }}>Oven</th>
                                    <td style={{ width: '100%' }}>
                                        <BarChart
                                            xAxis={[{
                                                scaleType: 'band',
                                                data: paynterDataXAxisLabels,
                                                colorMap: {
                                                    type: 'ordinal',
                                                    colors: colorPalette
                                                },
                                                tickLabelStyle: { fontSize: '0.7rem' }
                                            }]}
                                            series={[{ data: paynterData }]}

                                            height={150}
                                        />
                                    </td>
                                </tr>
                                <tr>
                                    <th style={{ textAlign: 'left' }}>SPI</th>
                                    <td style={{ width: '100%' }}>
                                        <BarChart
                                            xAxis={[{
                                                scaleType: 'band',
                                                data: paynterDataXAxisLabels,
                                                colorMap: {
                                                    type: 'ordinal',
                                                    colors: colorPalette
                                                },
                                                tickLabelStyle: { fontSize: '0.7rem' }
                                            }]}
                                            series={[{ data: paynterData }]}

                                            height={150}
                                        />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </Paper>
                </Grid>
                <Grid item xs={12} sm={12} md={6} lg={6}>
                    <Paper elevation={3} style={{ padding: "1rem" }}>
                        <h5>Actions</h5>
                        <DataGrid
                            rows={rows}
                            columns={columns}
                        />
                    </Paper>
                </Grid>
            </Grid>
        </Box>
    );
}

export default BreakdownDashboard