export const lineChartXAxisData = [
    new Date(2024, 0, 1),
    new Date(2024, 1, 1),
    new Date(2024, 2, 1),
    new Date(2024, 3, 1),
    new Date(2024, 4, 1),
    new Date(2024, 5, 1),
    new Date(2024, 6, 1),
    new Date(2024, 7, 1)
];

export const monthShortNames = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'
]

export const pickAndPlace4 = [35, 30, 45, 40, 55, 50, 68, 65];
export const pickAndPlace2 = [30, 25, 45, 40, 55, 36, 65, 70];
export const printer = [40, 35, 50, 15, 60, 65, 27, 45];
export const oven = [45, 50, 35, 60, 75, 20, 75, 80];
export const spi = [50, 15, 60, 65, 30, 75, 80, 85];
export const dualChartXaisData = ['Pick And Place 4', 'Pick And Place 2', 'Printer', 'Oven', 'SPI']
export const stopTimeData = [60, 20, 10, 7, 3];
export const percentageData = [60, 80, 90, 97, 100];
export const paynterData = [4, 3, 5, 4, 3, 5, 7, 8];

export const columns = [
    { field: 'id', headerName: 'SI No', width: 50 },
    {
        field: 'issue',
        headerName: 'Issue',
        width: 50,
    },
    {
        field: 'rootCause',
        headerName: 'Root Casue',
        width: 120,
    },
    {
        field: 'action',
        headerName: 'Action',
        width: 100,
    },
    {
        field: 'resp',
        headerName: 'Resp',
        width: 100,
    },
    {
        field: 'target',
        headerName: 'Target',
        width: 100,
    },
    {
        field: 'gyr',
        headerName: 'GYR',
        width: 100,
    },
];

export const rows = [
    { "id": 1, "issue": '1', "rootCause": 'Sample', "action": "Sample", "resp": "Sample", "target": "Sample", "gyr": "Sample" },
    { "id": 2, "issue": '2', "rootCause": 'Sample', "action": "Sample", "resp": "Sample", "target": "Sample", "gyr": "Sample" },
    { "id": 3, "issue": '1', "rootCause": 'Sample', "action": "Sample", "resp": "Sample", "target": "Sample", "gyr": "Sample" },
    { "id": 4, "issue": '2', "rootCause": 'Sample', "action": "Sample", "resp": "Sample", "target": "Sample", "gyr": "Sample" },
    { "id": 5, "issue": '3', "rootCause": 'Sample', "action": null, "resp": "Sample", "target": "Sample", "gyr": "Sample" },
];

export const colorPalette = ['#5A089E', '#08239E', '#08589e', '#2b8cbe', '#4eb3d3', '#7bccc4', '#a8ddb5', '#ccebc5'];

export const paynterDataXAxisLabels = ['group A', 'group B', 'group C', 'group D', 'group E', 'group F', 'group G', 'group H'];



