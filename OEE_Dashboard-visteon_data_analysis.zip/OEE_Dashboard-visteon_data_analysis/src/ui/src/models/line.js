const Line = function (id, name, plant) {
    this.id = id;
    this.name = name;
    this.plant = plant;
};

export default Line;