const Shift = function (id, name, start, end, owner, line) {
    this.id = id;
    this.name = name;
    this.start = start;
    this.end = end;
    this.owner = owner;
    this.line = line;
};

export default Shift;