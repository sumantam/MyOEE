const Plant = function (name) {
    this.name = name;
};

export default Plant;