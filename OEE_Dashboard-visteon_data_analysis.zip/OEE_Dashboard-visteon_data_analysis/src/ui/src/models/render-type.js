const RenderType = Object.freeze({
    PARETO: 0,
    TREND: 1,
    PAYNTER: 2,
    ACTIONS: 3,
    TRENDBAR: 4,
    CustomTable: 5,
    LineChartTrend:6,
    CycleTimeTable: 7,
    PARETOPIE: 8,
    Gauge: 9
});

export default RenderType;