import { getWithMainThread, handleParallelApiCalls } from "./service-base";

const createListOfUrlsAndGetOeeDataForWorldMap = async (plant = "Chennai", timeq = "day", date = "2024-08-15", schemaName = "company5") => {
    let apiUrls = [
        `access/oeeParameters/${plant}/All/${timeq}`,
        `access/productionByLine/${plant}/all/${timeq}/true`,
    ];

    return await handleParallelApiCalls(apiUrls, { schemaName: schemaName, date: date });
}

const createListOfUrlsAndGetOeeData = async (plant = "Chennai", line = "Ch001", timeq = "day", date = "2024-08-15", schemaName = "company5") => {
    let apiUrls = [
        `access/oeeParameters/${plant}/${line}/${timeq}`,
        `oee/productionByModel/${plant}/${line}/${timeq}/true`,
    ];

    return await handleParallelApiCalls(apiUrls, { schemaName: schemaName, date: date });
}

const createListOfUrlsAndGetData = async (plant = "Chennai", line = "Ch001", timeq = "day", date = "2024-08-15", schemaName = "company5") => {
    let apiUrls = [

        `oee/oeeTrend/${plant}/${line}/${timeq}`,
        `oee/downTimeTrend/${plant}/${line}/${timeq}`,
        `oee/downTimeParetoByCause/${plant}/${line}/${timeq}`,
        `oee/oeeTrendBar/${line}/${timeq}`
    ];

    return await handleParallelApiCalls(apiUrls, { schemaName: schemaName, date: date });
}

const getOeeParameters = async (plant, line, timeq, date = "2024-08-15", schemaName = "company5") => {
    return await getWithMainThread(`access/oeeParameters/${plant}/${line}/${timeq}`, { schemaName: schemaName, date: date });
}

const getProductionByLine = async (plant, line, timeq, isTotalRequired = false, date = "2024-08-15", schemaName = "company5") => {
    return await getWithMainThread(`access/productionByLine/${plant}/${line}/${timeq}/${isTotalRequired}`, { schemaName: schemaName, date: date });
}

const oeeAcceleratorService = {
    getProductionByLine,
    getOeeParameters,
    createListOfUrlsAndGetData,
    createListOfUrlsAndGetOeeData,
    createListOfUrlsAndGetOeeDataForWorldMap
}

export default oeeAcceleratorService;
