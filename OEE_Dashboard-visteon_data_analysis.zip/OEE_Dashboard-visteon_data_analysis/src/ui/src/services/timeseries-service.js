import { getWithMainThread, postForFileUpload } from "./service-base";

const createJsonFromCsv = async (file) => {
    const data = new FormData();
    data.append('file', file);
    return await postForFileUpload("files/readForbiaCsvAndPrepareJson", data);
}

const getEvents = async () => {
    return await getWithMainThread("files/getUniqueEventPairs");
}

const getEventSpecificTimeSeriesData = async (event, fromTime, toTime) => {
    return await getWithMainThread(`files/getEventSpecificTimeSeriesData/${fromTime}/${toTime}`, { event: event })
}

const getSampleCsv = async () => {
    return await getWithMainThread("files/downloadSampleFile", {
        responseType: "blob", // Ensures the response is a Blob
    });
}

const timeseriesService = {
    createJsonFromCsv,
    getEvents,
    getEventSpecificTimeSeriesData,
    getSampleCsv
}

export default timeseriesService;