import { getWithMainThread, handleParallelApiCalls } from "./service-base";

const createListOfUrlsAndGetOeeData = async (plant = "Chennai", timeq = "day", date = "2024-08-15", schemaName = "company5") => {
  let apiUrls = [
    `access/oeeParameters/${plant}/All/${timeq}`,
    `access/productionByLine/${plant}/all/${timeq}/true`,
  ];
  
  return await handleParallelApiCalls(apiUrls, { schemaName: schemaName, date: date });
}

const createListOfUrlsAndGetData = async (plant = "Chennai", timeq = "day", date = "2024-08-15", schemaName = "company5") => {
  let apiUrls = [
    `oee/oeeParetoForPlant/${plant}/${timeq}`,
    `oee/performanceOrQualityLoss/${plant}/${timeq}/Performance`,
    `oee/performanceOrQualityLoss/${plant}/${timeq}/Quality`,
    `breakdown/byPlant/${plant}/${timeq}`,
    `breakdown/trend/byPlant/${plant}/${timeq}`,
    `oee/oeeTrendBarForPlant/${plant}/${timeq}`,
    `access/changeOver/${plant}/all/${timeq}`,
    `access/changeoverTrend/${plant}/all/${timeq}`,
    `oee/oeeTrendForPlant/${plant}/${timeq}`,
    `oee/performanceOrQualityLossTrend/${plant}/${timeq}/Performance`,
    `oee/performanceOrQualityLossTrend/${plant}/${timeq}/Quality`
  ];
  
  return await handleParallelApiCalls(apiUrls, { schemaName: schemaName, date: date });
}


const getLineWiseProductionByPlant = async (plant = "Chennai", timeq = "day", date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`access/productionByLine/${plant}/all/${timeq}/true`, { schemaName: schemaName, date: date });
}

const getModelWiseProductionByPlant = async (plant = "Chennai", timeq = "day", date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`oee/productionByModel/${plant}/all/${timeq}/true`, { schemaName: schemaName, date: date });
}

const getCycleTimeDataByPlant = async (plant = "P002", timeQ = "day", date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`cycleTime/cycleTimeDataByPlant/${plant}/${timeQ}`, { schemaName: schemaName, date: date });
};

const DelayDashboardService = {
  getCycleTimeDataByPlant,
  getLineWiseProductionByPlant,
  getModelWiseProductionByPlant,
  createListOfUrlsAndGetData,
  createListOfUrlsAndGetOeeData
};

export default DelayDashboardService;
