import { getWithMainThread } from "./service-base";

const getBreakdownData = async (lineId, timeQ, date = "2024-08-15", schemaName = "company5") => {
    return await getWithMainThread(`breakdown/byLine/${lineId}/${timeQ}`, { schemaName: schemaName, date: date });
};

const getBreakdownTrendData = async (lineId, timeQ, date = "2024-08-15", schemaName = "company5") => {
    return await getWithMainThread(`breakdown/trend/byLine/${lineId}/${timeQ}`, { schemaName: schemaName, date: date });
}

const getBreakdownActions = async (lineId, timeQ, date = "2024-08-15", schemaName = "company5") => {
    return await getWithMainThread(`breakdown/actions/byLine/${lineId}/${timeQ}`, { schemaName: schemaName, date: date });
};

const getBreakdownDataByMachine = async (lineId, timeQ, mId, date = "2024-08-15", schemaName = "company5") => {
    return await getWithMainThread(`breakdown/byMachine/${lineId}/${timeQ}/${mId}`, { schemaName: schemaName, date: date });
};

const getBreakdownTrendDataByMachine = async (lineId, timeQ, mId, date = "2024-08-15", schemaName = "company5") => {
    return await getWithMainThread(`breakdown/trend/byMachine/${lineId}/${timeQ}/${mId}`, { schemaName: schemaName, date: date });
}

const getBreakdownActionsByMachine = async (lineId, timeQ, mId, date = "2024-08-15", schemaName = "company5") => {
    return await getWithMainThread(`breakdown/actions/byMachine/${lineId}/${timeQ}/${mId}`, { schemaName: schemaName, date: date });
};

const BreakdownService = {
    getBreakdownData,
    getBreakdownTrendData,
    getBreakdownActions,
    getBreakdownDataByMachine,
    getBreakdownTrendDataByMachine,
    getBreakdownActionsByMachine
};

export default BreakdownService;