import { getWithMainThread, update } from "./service-base";

const getRealTimeDataAndStat = async () => {
    return await getWithMainThread(`cycleTime/realTimeDataAndStats`);
};

const getStdCycleTime = async () => {
    return await getWithMainThread(`cycleTime/stdCycleTime`);
};

const updateStdCycleTime = async (newStdCycleTime) => {
    return await update(`cycleTime/updateStdCycleTime`, { "newStdCycleTime": newStdCycleTime });
};

const RealTimeService = {
    getRealTimeDataAndStat,
    updateStdCycleTime,
    getStdCycleTime
}

export default RealTimeService;