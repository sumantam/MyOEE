import { toast } from "react-toastify";

const warning = (message) => {
    toast.warning(message, { position: 'top-right', autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: true, draggable: true, progress: undefined });
}

const info = (message) => {
    toast.warning(message, { position: 'top-right', autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: true, draggable: true, progress: undefined });
}

const error = (message) => {
    toast.warning(message, { position: 'top-right', autoClose: 3000, hideProgressBar: false, closeOnClick: true, pauseOnHover: true, draggable: true, progress: undefined });
}

const ToasterService = {
    info,
    warning,
    error
};

export default ToasterService;