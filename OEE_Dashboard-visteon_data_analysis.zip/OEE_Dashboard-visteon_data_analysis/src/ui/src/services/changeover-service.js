import { handleParallelApiCalls, getWithMainThread } from "./service-base";

const createListOfUrlsAndGetData = async (plant = "Chennai", timeq = "day", date = "2024-08-15", schemaName = "company5") => {
  let apiUrls = [
    `access/changeoverPlannedvsActual/${plant}/all/${timeq}/true`,
    `access/changeoverPlannedvsActualTrend/${plant}/all/${timeq}/true`,
  ];
  
  return await handleParallelApiCalls(apiUrls, { schemaName: schemaName, date: date });
}

const getChangeOverGridTrendDataByLine = async (plant = "Chennai", line = "Ch003", timeQ = "day", date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`access/changeoverPlannedvsActualTrend/${plant}/${line}/${timeQ}/true`, { schemaName: schemaName, date: date });
};

const ChangeOverService = {
  getChangeOverGridTrendDataByLine,
  createListOfUrlsAndGetData
};

export default ChangeOverService;