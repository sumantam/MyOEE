
import { getWithMainThread } from "./service-base";

const getMicrostopData = async (line, timeQ, date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`microstop/byLine/${line}/${timeQ}`, { schemaName: schemaName, date: date });
};

const getMicrostopTrendData = async (line, timeQ, date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`microstop/trend/byLine/${line}/${timeQ}`, { schemaName: schemaName, date: date });
};

const getMicrostopActionsData = async (line, timeQ, date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`microstop/actions/byLine/${line}/${timeQ}`, { schemaName: schemaName, date: date });
};

const getMicrostopDataByMachine = async (lineId, timeQ, mId, date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`microstop/byMachine/${lineId}/${timeQ}/${mId}`, { schemaName: schemaName, date: date });
};

const getMicrostopTrendDataByMachine = async (lineId, timeQ, mId, date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`microstop/trend/byMachine/${lineId}/${timeQ}/${mId}`, { schemaName: schemaName, date: date });
}

const getMicrostopActionsByMachine = async (lineId, timeQ, mId, date = "2024-08-15", schemaName = "company5") => {
  return await getWithMainThread(`microstop/actions/byMachine/${lineId}/${timeQ}/${mId}`, { schemaName: schemaName, date: date });
};

const MicrostopService = {
  getMicrostopData,
  getMicrostopTrendData,
  getMicrostopActionsData,
  getMicrostopDataByMachine,
  getMicrostopTrendDataByMachine,
  getMicrostopActionsByMachine
};

export default MicrostopService;
