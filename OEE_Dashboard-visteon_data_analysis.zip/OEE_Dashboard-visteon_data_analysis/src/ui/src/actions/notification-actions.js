export const SET_NOTIFICATIONS = "SET_NOTIFICATIONS";
export const SET_EQUIPMENT_TYPE = "SET_EQUIPMENT_TYPE";
export const SET_EQUIPMENT = "SET_EQUIPMENT";
export const SET_PARAMETER = "SET_PARAMETER";
export const SET_TABLE_HEAD_DATA = "SET_TABLE_HEAD_DATA";
export const SET_TABLE_BODY_DATA = "SET_TABLE_BODY_DATA";
export const SET_FILTERD_TABLE_BODY_DATA = "SET_FILTERD_TABLE_BODY_DATA__";
export const SET_DESCRIPTION_DATA = "SET_DESCRIPTION_DATA";
export const SET_NOTIFICATION_DETAILS = "SET_NOTIFICATION_DETAILS";
export const SET_ERROR = "SET_ERROR";
export const SET_current_status = "SET_current_status";
export const SET_SITUATION_UPDATE = "SET_SITUATION_UPDATE";
export const SET_ETR_VALUE = "SET_PERSISTENCE_VALUE";
export const SET_PERSISTENCE_UNIT = "SET_PERSISTENCE_UNIT";
export const INITIALIZE_USER_DATA = "INITIALIZE_USER_DATA";
export const EQUIPMENT_DATA = "EQUIPMENT_DATA";
export const DEFECT_DATA = "DEFECT_DATA";
export const RESET_STATE = "RESET_STATE";
export const SET_EQUIPMENT_ENABLED = "SET_EQUIPMENT_ENABLED";

export const setNotifications = (notifications) => ({
  type: SET_NOTIFICATIONS,
  payload: notifications,
});

export const setEquipmentType = (equipmentType) => ({
  type: SET_EQUIPMENT_TYPE,
  payload: equipmentType,
});

export const setEquipment = (equipment) => ({
  type: SET_EQUIPMENT,
  payload: equipment,
});

export const setParameter = (parameter) => ({
  type: SET_PARAMETER,
  payload: parameter,
});

export const setTableHeadData = (data) => ({
  type: SET_TABLE_HEAD_DATA,
  payload: data,
});

export const setTableBodyData = (data) => {
  return {
    type: SET_TABLE_BODY_DATA,
    payload: data,
  };
};

export const setFilteredTableBodyData = (data) => ({
  type: SET_FILTERD_TABLE_BODY_DATA,
  payload: data,
});

export const setDescriptionData = (description) => ({
  type: SET_DESCRIPTION_DATA,
  payload: description,
});

export const setNotificationDetails = (notifcationDetails) => ({
  type: SET_NOTIFICATION_DETAILS,
  payload: notifcationDetails,
});

export const setError = (errorMessage) => ({
  type: SET_ERROR,
  payload: errorMessage,
});

export const setLatestStatus = (status) => ({
  type: SET_current_status,
  payload: status,
});

export const setSituationUpdate = (update) => ({
  type: SET_SITUATION_UPDATE,
  payload: update,
});

export const setEtrValue = (value) => ({
  type: SET_ETR_VALUE,
  payload: value,
});

export const setPersistenceUnit = (unit) => ({
  type: SET_PERSISTENCE_UNIT,
  payload: unit,
});

export const initializeUserData = (rowData) => ({
  type: INITIALIZE_USER_DATA,
  payload: rowData,
});

export const setEquipmentData = (data) => ({
  type: EQUIPMENT_DATA,
  payload: data,
});

export const setDefectData = (data) => ({
  type: DEFECT_DATA,
  payload: data,
});

export const resetState = () => ({
  type: RESET_STATE,
});

export const setEquipmentEnabled = (isEnabled) => ({
  type: SET_EQUIPMENT_ENABLED,
  payload: isEnabled,
});
