import { useLayoutEffect, memo } from 'react';
import * as am5 from "@amcharts/amcharts5";
import { PieChart } from '@amcharts/amcharts5/.internal/charts/pie/PieChart';
import { PieSeries } from '@amcharts/amcharts5/.internal/charts/pie/PieSeries';
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import am5themes_Responsive from "@amcharts/amcharts5/themes/Responsive";

const TwoLevelPieChart = memo((props) => {
    useLayoutEffect(() => {
        let root = am5.Root.new(props.id);
        root._logo.dispose();
        let responsive = am5themes_Responsive.newEmpty(root);
        responsive.addRule({
            relevant: am5themes_Responsive.widthM,
            applying: function () {
                chart.set("layout", root.verticalLayout);
            },
            removing: function () {
                chart.set("layout", root.horizontalLayout);
            }
        });
        const myTheme = am5.Theme.new(root);
        // Move minor label a bit down
        myTheme.rule("AxisLabel", ["minor"]).setAll({
            dy: 1
        });

        // Tweak minor grid opacity
        myTheme.rule("Grid", ["minor"]).setAll({
            strokeOpacity: 0.08
        });

        // Set themes
        // https://www.amcharts.com/docs/v5/concepts/themes/
        root.setThemes([
            am5themes_Animated.new(root),
            responsive,
            myTheme
        ]);
        // Create chart
        // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/
        let chart = root.container.children.push(
            PieChart.new(root, {
                endAngle: 270,
                layout: root.verticalLayout,
                innerRadius: am5.percent(60)
            })
        );

        let series = chart.series.push(
            PieSeries.new(root, {
                valueField: props.dataSeriesKeyTitle[0].key,
                categoryField: props.categoryField,
                endAngle: 270
            })
        );

        series.set("colors", am5.ColorSet.new(root, {
            colors: props.colors.map(p => am5.color(p))
        }))

        let gradient = am5.RadialGradient.new(root, {
            stops: [
                { color: am5.color(props.colors[0]) },
                { color: am5.color(props.colors[1]) },
                {}
            ]
        })

        series.slices.template.setAll({
            // fillGradient: gradient,
            strokeWidth: 2,
            stroke: am5.color(0xffffff),
            cornerRadius: 10,
            shadowOpacity: 0.1,
            shadowOffsetX: 2,
            shadowOffsetY: 2,
            shadowColor: am5.color(0x000000),
            // fillPattern: am5.GrainPattern.new(root, {
            //     maxOpacity: 0.2,
            //     density: 0.5,
            //     colors: [am5.color(0x000000)]
            // })
        })

        series.slices.template.states.create("hover", {
            shadowOpacity: 1,
            shadowBlur: 10,
            tooltipText: "{category}: {value} " + props.dataSeriesKeyTitle[0]["title"]
        })

        if (props.handleClick) {
            series.slices.template.events.on("click", ev => {
                let points = [{ "x": ev.target.dataItem.dataContext["key"] }];
                props.handleClick({ "points": points });
            })
        }

        series.ticks.template.setAll({
            strokeOpacity: 0.4,
            strokeDasharray: [2, 2],
        })

        series.states.create("hidden", {
            endAngle: -90
        });

        series.labels.template.setAll({
            paddingTop: 20,
            fontSize: 12,
            maxWidth: 100,
            fontFamily: props.fontFamily,
            oversizedBehavior: 'wrap'
        })

        // Set data
        // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data
        if (props.data !== null)
            series.data.setAll(props.data)

        let legend = chart.children.push(am5.Legend.new(root, {
            centerX: am5.percent(50),
            x: am5.percent(50),
            marginTop: 15,
            marginBottom: 15
        }));
        legend.labels.template.setAll({
            fontFamily: props.fontFamily,
            fontSize: 12,
        })
        legend.valueLabels.template.setAll({
            fontFamily: props.fontFamily,
            fontSize: 12,
            marginRight: 20
        })
        legend.markerRectangles.template.adapters.add("fillGradient", function () {
            return undefined;
        })
        legend.data.setAll(series.dataItems);
        series.appear(1000, 100);
        return () => {
            root.dispose();
        };
    }, [props])
    return (
        <div id={props.id} style={{ width: '100%', height: props.height }}></div>
    );
}, (prevProps, nextProps) => {
    // Only re-render if `data` has changed
    return prevProps.data === nextProps.data && prevProps.dataSeriesKeyTitle === nextProps.dataSeriesKeyTitle;
})
export default TwoLevelPieChart;