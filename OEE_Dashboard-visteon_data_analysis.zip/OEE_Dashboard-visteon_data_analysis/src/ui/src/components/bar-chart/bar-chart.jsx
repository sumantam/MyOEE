import { useLayoutEffect, memo } from 'react';
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import am5themes_Responsive from "@amcharts/amcharts5/themes/Responsive";
import UtilityMethods from '../../utilities';

const BarChart = memo((props) => {
    useLayoutEffect(() => {
        let root = am5.Root.new(props.id);
        root._logo.dispose();
        let responsive = am5themes_Responsive.newEmpty(root);
        responsive.addRule({
            relevant: am5themes_Responsive.widthM,
            applying: function () {
                chart.set("layout", root.verticalLayout);
            },
            removing: function () {
                chart.set("layout", root.horizontalLayout);
            }
        });
        root.setThemes([
            am5themes_Animated.new(root), responsive
        ]);
        let chart = root.container.children.push(am5xy.XYChart.new(root, {
            panX: false,
            panY: false,
            wheelX: "panX",
            wheelY: "zoomX",
            paddingLeft: 0,
            layout: root.verticalLayout
        }));

        // Create axes
        // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/

        let yRenderer = am5xy.AxisRendererY.new(root, {
            inversed: true,
            cellStartLocation: 0.1,
            cellEndLocation: 0.9,
            minorGridEnabled: true
        });

        let yAxis = chart.yAxes.push(am5xy.CategoryAxis.new(root, {
            categoryField: props.categoryField,
            renderer: yRenderer
        }));

        yRenderer.labels.template.setAll({
            fontSize: 12,
            fontFamily: props.fontFamily
        })

        // Add scrollbar
        // https://www.amcharts.com/docs/v5/charts/xy-chart/scrollbars/
        chart.set("scrollbarY", am5.Scrollbar.new(root, {
            orientation: "vertical",
            scale: 0.95
        }));

        if (props.data !== null)
            yAxis.data.setAll(props.data);

        let maxVal = 0;
        if (props.data !== null)
            maxVal = Math.max(...props.data.map(p => p[props.dataSeriesKeyTitle[0]["key"]])) + 100

        let xRenderer = am5xy.AxisRendererX.new(root, {
            strokeOpacity: 0.1,
            minGridDistance: 50
        });

        let xAxis = chart.xAxes.push(am5xy.ValueAxis.new(root, {
            renderer: xRenderer,
            min: 0,
            max: maxVal
        }));

        xRenderer.labels.template.setAll({
            fontSize: 12,
            fontFamily: props.fontFamily
        })

        xAxis.get("renderer").labels.template.setAll({
            oversizedBehavior: "fit",
            maxWidth: 50,
            textAlign: "center"
        });

        // Add series
        // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
        function createSeries(field, name, greenGradientColor, yellowGradientColor, redGradientColor) {
            let series = chart.series.push(am5xy.ColumnSeries.new(root, {
                name: name,
                xAxis: xAxis,
                yAxis: yAxis,
                valueXField: field,
                categoryYField: props.categoryField,
                sequencedInterpolation: true,
                tooltip: am5.Tooltip.new(root, {
                    pointerOrientation: "horizontal",
                    labelText: "[bold]{name}[/]\n{categoryY}: {valueX}"
                })
            }));

            if (greenGradientColor !== null && yellowGradientColor !== null && redGradientColor !== null) {
                series.columns.template.adapters.add("fill", function (fill, target) {
                    let dataContext = target.dataItem.dataContext;
                    let linearGradient = null;
                    let color = null;
                    if (dataContext) {
                        let adjustedAdherence = UtilityMethods.getAdjustedAdherence(dataContext.plan, dataContext.actual);
                        if (adjustedAdherence < props.range[1]) {
                            color = redGradientColor[1]
                            // linearGradient = am5.LinearGradient.new(root, {
                            //     rotation: 0,
                            //     stops: [
                            //         { color: greenGradientColor[0] },
                            //         { color: greenGradientColor[1] }
                            //     ]
                            // });
                        }
                        else if (adjustedAdherence >= props.range[1] && adjustedAdherence < props.range[2]) {
                            color = yellowGradientColor[0]
                            // linearGradient = am5.LinearGradient.new(root, {
                            //     rotation: 0,
                            //     stops: [
                            //         { color: yellowGradientColor[0] },
                            //         { color: yellowGradientColor[1] }
                            //     ]
                            // });
                        }
                        else {
                            color = greenGradientColor[1]
                            // linearGradient = am5.LinearGradient.new(root, {
                            //     rotation: 0,
                            //     stops: [
                            //         { color: redGradientColor[0] },
                            //         { color: redGradientColor[1] }
                            //     ]
                            // });
                        }
                    }
                    return color;
                })
            }
            if (props.data !== null && greenGradientColor !== null && yellowGradientColor !== null && redGradientColor !== null) {
                let adjustedAdherenceForSecondLegend = UtilityMethods.getAdjustedAdherence(props.data[0].plan, props.data[0].actual);
                let secondLegendColor = adjustedAdherenceForSecondLegend < props.range[1] ? redGradientColor[1] :
                    adjustedAdherenceForSecondLegend >= props.range[1] && adjustedAdherenceForSecondLegend < props.range[2] ? yellowGradientColor[0] :
                        greenGradientColor[1];
                series.columns.template.setAll({
                    height: am5.p100,
                    strokeOpacity: 0,
                    fillOpacity: 1,
                    fill: name === props.dataSeriesKeyTitle[0]["title"] ? am5.color(0x006ffd) : secondLegendColor
                });
            }
            series.bullets.push(function () {
                return am5.Bullet.new(root, {
                    locationX: 1,
                    locationY: 0.5,
                    sprite: am5.Label.new(root, {
                        centerY: am5.p50,
                        centerX: am5.p100,
                        text: "{valueX}",
                        fontSize: props.data !== null && props.data.length > 10 ? '1vh' : '1.5vh',
                        fontFamily: props.fontFamily,
                        populateText: true
                    })
                });
            });

            // series.bullets.push(function () {
            //     return am5.Bullet.new(root, {
            //         locationX: 1,
            //         locationY: 0.5,
            //         sprite: am5.Label.new(root, {
            //             centerX: am5.p100,
            //             centerY: am5.p50,
            //             text: "{name}",
            //             fill: am5.color(0xffffff),
            //             populateText: true
            //         })
            //     });
            // });

            if (props.data !== null)
                series.data.setAll(props.data);
            series.appear();

            return series;
        }

        props.dataSeriesKeyTitle.forEach(item => {
            if (item.isColorModificationRequired)
                createSeries(item.key, item.title, props.greenGradientColor, props.yellowGradientColor, props.redGradientColor)
            else
                createSeries(item.key, item.title, null, null, null)
        })

        // Add legend
        // https://www.amcharts.com/docs/v5/charts/xy-chart/legend-xy-series/
        let legend = chart.children.push(am5.Legend.new(root, {
            centerX: am5.p50,
            y: am5.percent(95),
            x: am5.p50
        }));

        legend.data.setAll(chart.series.values);


        // Add cursor
        // https://www.amcharts.com/docs/v5/charts/xy-chart/cursor/
        let cursor = chart.set("cursor", am5xy.XYCursor.new(root, {
            behavior: "zoomY"
        }));
        cursor.lineY.set("forceHidden", true);
        cursor.lineX.set("forceHidden", true);


        // Make stuff animate on load
        // https://www.amcharts.com/docs/v5/concepts/animations/
        chart.appear(1000, 100);
        return () => {
            root.dispose();
        };
    }, [props])

    return (
        <div id={props.id} style={{ width: '100%', height: props.height }}></div>
    );
}, (prevProps, nextProps) => {
    // Only re-render if `data` has changed
    return prevProps.data === nextProps.data;
})
export default BarChart;