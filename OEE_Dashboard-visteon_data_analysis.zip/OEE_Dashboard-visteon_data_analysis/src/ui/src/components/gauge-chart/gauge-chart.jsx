import { useLayoutEffect, memo } from 'react';
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import * as am5radar from "@amcharts/amcharts5/radar";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import am5themes_Responsive from "@amcharts/amcharts5/themes/Responsive";

const GaugeChart = memo((props) => {
    useLayoutEffect(() => {
        let root = am5.Root.new(props.id);
        root._logo.dispose();
        let responsive = am5themes_Responsive.newEmpty(root);
        responsive.addRule({
            relevant: am5themes_Responsive.widthM,
            applying: function () {
                chart.set("layout", root.verticalLayout);
            },
            removing: function () {
                chart.set("layout", root.horizontalLayout);
            }
        });
        root.setThemes([
            am5themes_Animated.new(root), responsive
        ]);

        let chart = root.container.children.push(
            am5radar.RadarChart.new(root, {
                panX: false,
                panY: false,
                startAngle: -180,
                endAngle: 0,
                innerRadius: am5.percent(80)
            })
        );

        var axisRenderer = am5radar.AxisRendererCircular.new(root, {
            strokeOpacity: 0.1,
            minGridDistance: 30
        });

        axisRenderer.ticks.template.setAll({
            visible: true,
            strokeOpacity: 0.5
        });

        axisRenderer.grid.template.setAll({
            visible: false
        });

        var axis = chart.xAxes.push(
            am5xy.ValueAxis.new(root, {
                maxDeviation: 0,
                min: props.range[0],
                max: props.range[3],
                strictMinMax: true,
                renderer: axisRenderer
            })
        );

        function createRange(start, end, color1, color2, label) {

            var rangeDataItem = axis.makeDataItem({
                value: start,
                endValue: end
            });

            var range = axis.createAxisRange(rangeDataItem);

            rangeDataItem.get("axisFill").setAll({
                visible: true,
                // fill: color,
                fillGradient: am5.LinearGradient.new(root, {
                    rotation: 0,
                    stops: [
                        { color: color1 },
                        { color: color2 }
                    ]
                }),
                fillOpacity: 1
            });

            rangeDataItem.get("tick").setAll({
                visible: false
            });

            rangeDataItem.get("label").setAll({
                text: label,
                inside: true,
                radius: 8,
                fontSize: "0.9em",
                fontFamily: props.fontFamily,
                fill: am5.color(0xffffff)
            });

        }

        createRange(props.range[0], props.range[1], props.redGradientColor[0], props.redGradientColor[1]);
        createRange(props.range[1], props.range[2], props.yellowGradientColor[0], props.yellowGradientColor[1]);
        createRange(props.range[2], props.range[3], props.greenGradientColor[0], props.greenGradientColor[1]);

        // Add clock hand
        let handDataItem = axis.makeDataItem({
            value: 0
        });
        let tooltip = am5.Tooltip.new(root, {});
        tooltip.get("background").setAll({
            fill: am5.color(0xb7d0cf)
        });
        let sprite = am5radar.ClockHand.new(root, {
            radius: am5.percent(99),
            pinRadius: am5.percent(10),
            tooltipText: props.value + "%",
            tooltipPosition: "pointer",
        });
        sprite.set("tooltip", tooltip)
        var hand = handDataItem.set("bullet", am5xy.AxisBullet.new(root, {
            sprite: sprite,
        }));

        axis.createAxisRange(handDataItem);

        handDataItem.get("grid").set("visible", false);
        handDataItem.get("tick").set("visible", true);

        if (props.value > 0) {
            setInterval(() => {
                handDataItem.animate({
                    key: "value",
                    to: props.value,
                    duration: 800,
                    easing: am5.ease.out(am5.ease.cubic)
                });
            }, 2000);
        }

        chart.appear(1000, 100);

        return () => {
            root.dispose();
        };
    }, [props]);

    return (
        <>
            <h6 style={{ textAlign: 'center', fontSize: props.fontSize, fontFamily: props.fontFamily }}>{props.id} - {props.value}%</h6>
            <div id={props.id} style={{ width: '100%', height: props.height }}></div>
        </>
    );
}, (prevProps, nextProps) => {
    // Only re-render if `data` has changed
    return prevProps.value === nextProps.value;
})

export default GaugeChart;