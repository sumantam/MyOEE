import { Box, Divider, Grid, Typography } from '@mui/material';
import Plot from 'react-plotly.js';
import './paynter-chart.css';
import { randomId } from '@mui/x-data-grid-generator';

const PaynterChart = ({ data, markerData, colors, firstColumnName, IsMs }) => {

    const config = {
        displaylogo: false,
        responsive: true, // Make the plot responsive
    };

    const chartDataList = [];
    const maxValuePoints = [];
    data.forEach((d, i) => {
        const markerFinder = d["dataPoints"].filter(p => p.value > 0).map(p => p["label"]);
        // const conditionMatcher = firstColumnName === "Issue" && !IsMs ? "Issue Type " : "";
        const conditionMatcher = "";
        // const matchedMarkers = markerData.filter(p => markerFinder.includes(p.xValue) && d["target"] === conditionMatcher + p["target"]);
        const matchedMarkers = markerData.filter(p => markerFinder.includes(p.xValue) && d["target"].includes(conditionMatcher + p["target"]));
        const markerXValues = matchedMarkers.map(p => p.xValue);
        const markercolors = matchedMarkers.map(p => p.colorCode);
        const markerYValues = [...d.dataPoints.filter(p => markerXValues.includes(p.label) && p.value > 0).map(x => x.value)];
        // markerXValues.forEach(yVal => {
        //     let indexOfMarkerDataPoint = d["dataPoints"].findIndex(p => p["label"] === yVal);
        //     if (indexOfMarkerDataPoint > 0) {
        //         if (d["dataPoints"][indexOfMarkerDataPoint]["value"] > d["dataPoints"][indexOfMarkerDataPoint - 1]["value"]) {
        //             let delta = d["dataPoints"][indexOfMarkerDataPoint]["value"] - d["dataPoints"][indexOfMarkerDataPoint - 1]["value"];
        //             if (delta < d["dataPoints"][indexOfMarkerDataPoint]["value"]) {
        //                 let modifiedValue = d["dataPoints"][indexOfMarkerDataPoint]["value"] - delta - 1;
        //                 d["dataPoints"][indexOfMarkerDataPoint]["value"] = modifiedValue > 0 ? modifiedValue : 0;
        //             }

        //         }
        //     }
        // })
        const chartData = {
            target: d.target,
            data: [{
                x: d.dataPoints.map((p) => p.label),
                y: d.dataPoints.map((p) => p.value),
                type: 'bar',
                name: '',
                // width: 0.7,
                marker: { color: colors[i], opacity: 1 }
            }]
        };

        if (markerXValues?.length > 0 && markerYValues.length > 0)
            chartData.data.push({
                x: markerXValues,
                y: markerYValues,
                mode: 'markers',
                name: null,
                marker: {
                    color: colors[5],
                    size: 15,
                    symbol: 'diamond'
                },
                cliponaxis: false,
            });

        maxValuePoints.push(Math.max(...d.dataPoints.map(i => i.value)));
        chartDataList.push(chartData);
    });

    let maxValueRange = Math.max(...maxValuePoints.map(i => i));
    maxValueRange = maxValueRange + (10 - (maxValueRange % 10));

    const layout = {
        xaxis: { showgrid: false, zeroline: false, visible: false, automargin: true, autotickangles: true, autoshift: true },
        yaxis: { showgrid: false, zeroline: false, visible: true, showticklabels: false, range: [0, maxValueRange] },
        //yaxis: { showgrid: false, zeroline: false, visible: true, showticklabels: false },
        margin: { t: 10, b: 10 },
        autosize: true,
        height: 100,
        showlegend: false,
        responsive: true
    };

    return (
        <Box flexGrow={1}>
            {
                chartDataList.map((item) => {
                    return (
                        <Box key={randomId()}>
                            <Grid container spacing={1} justifyContent="center">
                                <Grid item xs={4} sm={4} md={2} lg={2} style={{ margin: 'auto', wordWrap: 'break-word' }}>
                                    <Typography style={{ width: '100%', margin: 'auto', wordWrap: 'break-word', fontWeight: 600 }}>{item.target}</Typography>
                                </Grid>
                                <Grid item xs={8} sm={8} md={10} lg={10} style={{ margin: 'auto' }}>
                                    <Plot data={item.data} layout={layout} style={{ width: '100%', cursor: 'pointer' }} config={config} className='custom-pareto-chart' />
                                </Grid>
                            </Grid >
                            <Divider />
                        </Box>
                    )
                })
            }
            {/* <Plot data={trendData} layout={layout} style={{ width: '100%', height: '100%' }} config={config} className='custom-pareto-chart' /> */}
        </Box >
    );
};

export default PaynterChart;

