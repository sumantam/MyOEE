import React from "react";
import {
    Box,
    Grid,
    Card,
    CardContent
} from "@mui/material";

import "./cycle-time-table.css";

const CycleTimeTable = ({ gridData, handleClick, fontFamily, greenGradientColor, redGradientColor, yellowGradientColor, colors }) => {

    const lineData = [
        {
            "lineId": "Ch001",
            "lineName": "Line-1"
        },
        {
            "lineId": "Ch002",
            "lineName": "Line-2"
        },
        {
            "lineId": "Ch003",
            "lineName": "Line-3"
        },
        {
            "lineId": "Ch004",
            "lineName": "Line-4"
        },
        {
            "lineId": "Ch005",
            "lineName": "Line-5"
        }
    ];

    const cycleTimeData = gridData

    const getColorForCycleTimeBox = (actualCycleTime, stdCycleTime) => {
        if (actualCycleTime <= stdCycleTime) return greenGradientColor[0];
        else {
            let diff = (actualCycleTime - stdCycleTime) / stdCycleTime * 100;
            if (diff > 0 && diff <= 2) return greenGradientColor[0];
            else if (diff > 2 && diff <= 3) return yellowGradientColor[0];
            else return redGradientColor[0];
        }
    }

    const getPerformanceLossOrGain = (actualCycleTime, stdCycleTime) => {
        return ((actualCycleTime - stdCycleTime) / stdCycleTime * 100).toFixed(2);
    }

    return (
        <Box flexGrow={1}>
            <Grid container spacing={1} justifyContent="center" className="custom-grid-row">
                <Grid item xs={2} sm={2} md={2} lg={2} className="custom-grid-border" style={{ fontWeight: 600, fontFamily: fontFamily, paddingTop: '0.8rem' }}>Models</Grid>
                {lineData.map((line, j) => {
                    return (
                        <Grid key={j} item xs={2} sm={2} md={2} lg={2} style={{ textAlign: 'center', fontWeight: 600, fontFamily: fontFamily, paddingTop: '0.8rem' }} className="custom-grid-border">
                            {line.lineName}
                        </Grid>
                    );
                })}

            </Grid>
            {cycleTimeData.map((cyleTime, k) => {
                return (
                    <Grid key={k} container spacing={1} justifyContent="center" className="custom-grid-row">
                        <Grid item xs={2} sm={2} md={2} lg={2} className="custom-grid-border" style={{ fontWeight: 600, fontFamily: fontFamily, paddingTop: '0.8rem' }}>{cyleTime.model}</Grid>
                        {lineData.map((line, i) => {
                            const cycleTimeDataObject = cyleTime.data.find(p => p.lineId === line.lineId);
                            const backColorForCycleTimeBox = getColorForCycleTimeBox(cycleTimeDataObject.actualCycleTime, cycleTimeDataObject.stdCycleTime);
                            const performanceLossOrGain = getPerformanceLossOrGain(cycleTimeDataObject.actualCycleTime, cycleTimeDataObject.stdCycleTime);
                            return (
                                cycleTimeDataObject.actualCycleTime > 0 ?
                                    <Grid key={i} item xs={2} sm={2} md={2} lg={2} className="custom-grid-border" style={{ backgroundColor: backColorForCycleTimeBox, textAlign: 'center', fontFamily: fontFamily, paddingTop: '0.8rem' }}>
                                        <div className="custom-tooltip-on-hover">{cycleTimeDataObject.actualCycleTime}</div>
                                        <div className="custom-tooltip">
                                            <Card style={{ backgroundColor: colors[5] }}>
                                                <CardContent>
                                                    <Grid container spacing={1} justifyContent="center">
                                                        <Grid item xs={6} sm={6} md={6} lg={6} style={{ fontFamily: fontFamily, fontWeight: 600 }}>
                                                            Actual Cycle Time
                                                        </Grid>
                                                        <Grid item xs={6} sm={6} md={6} lg={6} style={{ fontFamily: fontFamily, fontWeight: 600 }}>
                                                            {cycleTimeDataObject.actualCycleTime}
                                                        </Grid>
                                                        <Grid item xs={6} sm={6} md={6} lg={6} style={{ fontFamily: fontFamily, fontWeight: 600 }}>
                                                            Standard Cycle Time
                                                        </Grid>
                                                        <Grid item xs={6} sm={6} md={6} lg={6} style={{ fontFamily: fontFamily, fontWeight: 600 }}>
                                                            {cycleTimeDataObject.stdCycleTime}
                                                        </Grid>
                                                        <Grid item xs={6} sm={6} md={6} lg={6} style={{ fontFamily: fontFamily, fontWeight: 600 }}>
                                                            {performanceLossOrGain > 0 ? "Performance Loss" : "Performance Gain"}
                                                        </Grid>
                                                        <Grid item xs={6} sm={6} md={6} lg={6} style={{ fontFamily: fontFamily, fontWeight: 600 }}>
                                                            {performanceLossOrGain}%
                                                        </Grid>
                                                    </Grid>
                                                </CardContent>
                                            </Card>
                                        </div>
                                    </Grid> :
                                    <Grid key={i} item xs={2} sm={2} md={2} lg={2} className="custom-grid-border" style={{ textAlign: 'center', fontFamily: fontFamily, paddingTop: '0.8rem' }}></Grid>
                            )
                        })}
                    </Grid>
                );
            })}
        </Box>
    );
};

export default CycleTimeTable;
