import { Box } from '@mui/material';
import Plot from 'react-plotly.js';
import './pareto-chart.css';

const ParetoChart = ({ data, colors, handleClick, isLegendToBeAdjusted }) => {

    const layout = {
        xaxis: { automargin: true, autotickangles: true, autoshift: true },
        yaxis: { title: 'Stop Time (mins)' },
        yaxis2: {
            title: 'Percentage',
            overlaying: 'y',
            side: 'right',
            range: [0, 110]
        },
        margin: { t: 10, b: 10 },
        legend: {
            orientation: 'h',
            x: 0.30,
            y: isLegendToBeAdjusted ? -0.55 : -0.2 // Adjust this value to position the legend relative to the chart
        },
        autosize: true
    };

    const sortedData = data.map(p=> p).sort((a,b)=> b.value - a.value);  

    const config = {
        displaylogo: false,
        responsive: true
    };

    const total = sortedData.reduce((accumulator, currentValue) => {
        return accumulator + currentValue.value;
    }, 0);

    sortedData.forEach((d, i) => {
        d.percentage = ((d.value / total) * 100);
    });

    sortedData.forEach((current, i) => {
        if (i === 0) {
            current.cumulitivePercentage = current.percentage;
        }
        else {
            current.cumulitivePercentage = sortedData[i - 1].cumulitivePercentage + current.percentage;
        }
    });

    const chartData = [
        {
            x: sortedData.map((item) => { return item.key === "Performance" ? item.key + " (*Mostly due to Microstops)" : item.key }),
            y: sortedData.map((item) => { return item.value }),
            type: 'bar',
            name: 'Stop Time (mins)',
            width: 0.5,
            marker: { color: colors[0], opacity: 1 }

        }, {
            x: sortedData.map((item) => { return item.key === "Performance" ? item.key + " (*Mostly due to Microstops)" : item.key }),
            y: sortedData.map((item) => { return item.cumulitivePercentage; }),
            name: 'Percentage',
            yaxis: 'y2',
            type: 'scatter',
            marker: { size: 12 },
            line: { color: colors[4], shape: 'spline' }
        }
    ];    

    return (
        <Box style={{ width: '100%', height: '100%' }}>
            <Plot data={chartData} layout={layout} style={{ width: '100%', height: '100%' }} 
            config={config} onClick={handleClick} className='custom-pareto-chart' />
        </Box>
    );
};

export default ParetoChart;

