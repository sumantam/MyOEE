import { useLayoutEffect, memo } from 'react';
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import am5themes_Responsive from "@amcharts/amcharts5/themes/Responsive";

const LineChart = memo((props) => {
    useLayoutEffect(() => {
        let root = am5.Root.new(props.id);
        root._logo.dispose();
        let responsive = am5themes_Responsive.newEmpty(root);
        responsive.addRule({
            relevant: am5themes_Responsive.widthM,
            applying: function () {
                chart.set("layout", root.verticalLayout);
            },
            removing: function () {
                chart.set("layout", root.horizontalLayout);
            }
        });

        const myTheme = am5.Theme.new(root);
        // Move minor label a bit down
        myTheme.rule("AxisLabel", ["minor"]).setAll({
            dy: 1
        });

        // Tweak minor grid opacity
        myTheme.rule("Grid", ["minor"]).setAll({
            strokeOpacity: 0.08
        });

        // Set themes
        // https://www.amcharts.com/docs/v5/concepts/themes/
        root.setThemes([
            am5themes_Animated.new(root),
            responsive,
            myTheme
        ]);


        // Create chart
        // https://www.amcharts.com/docs/v5/charts/xy-chart/
        let chart = root.container.children.push(am5xy.XYChart.new(root, {
            panX: false,
            panY: false,
            wheelX: "panX",
            wheelY: "zoomX",
            paddingLeft: 0
        }));

        chart.get("colors").set("colors",
            props.colors.map(p => am5.color(p))
        );

        // Add cursor
        // https://www.amcharts.com/docs/v5/charts/xy-chart/cursor/
        let cursor = chart.set("cursor", am5xy.XYCursor.new(root, {
            behavior: "zoomX"
        }));
        cursor.lineY.set("visible", false);

        // let date = new Date();
        // date.setHours(0, 0, 0, 0);
        // let value = 100;

        // Create axes
        // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/


        // xAxis.set("minorDateFormats", {
        //     day: "dd",
        //     month: "MM"
        // });

        let maxVal = 100;
        let minVal = 0;
        if (props.data !== null) {
            let allVals = [];
            props.data.forEach(item => item["values"].forEach(val => allVals.push(val[props.valueField])))
            maxVal = Math.max(...allVals) + 5;
            minVal = Math.min(...allVals) - 5 > 0 ? Math.min(...allVals) - 5 : 0
        }

        let yRenderer = am5xy.AxisRendererY.new(root, {});

        let yAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
            renderer: yRenderer,
            max: maxVal,
            min: minVal
        }));

        yRenderer.labels.template.setAll({
            fontSize: 12,
            fontFamily: props.fontFamily
        })

        yAxis.children.unshift(am5.Label.new(root, {
            text: props.yAxisTitle,
            textAlign: 'center',
            y: am5.p50,
            rotation: -90,
            fontWeight: 400,
            fontFamily: props.fontFamily
        }));

        // Add scrollbar
        // https://www.amcharts.com/docs/v5/charts/xy-chart/scrollbars/
        chart.set("scrollbarX", am5.Scrollbar.new(root, {
            orientation: "horizontal"
        }));


        // Add series
        // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
        if (props.data !== null) {
            let xRenderer = am5xy.AxisRendererX.new(root, {
                minGridDistance: 50,
                minorGridEnabled: true
            });
            let xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(root, {
                categoryField: props.categoryField,
                // maxDeviation: 0,
                // baseInterval: {
                //     timeUnit: "day",
                //     count: 1
                // },
                renderer: xRenderer,
                tooltip: am5.Tooltip.new(root, {})
            }));

            if (props.labelRotation["required"]) {
                xRenderer.labels.template.setAll({
                    // rotation: props.labelRotation["angle"],
                    oversizedBehavior: "fit",
                    maxWidth: 70,
                    textAlign: "center",
                    centerY: am5.p50,
                    paddingTop: 15,
                    centerX: am5.p100,
                    height: 100,
                    fontSize: 12,
                    fontFamily: props.fontFamily
                });
            }
            else {
                xRenderer.labels.template.setAll({
                    paddingTop: 20
                });
            }

            props.data.forEach(item => {
                let series = chart.series.push(am5xy.LineSeries.new(root, {
                    name: item.title === "Performance" ? item.title + " (*Mostly due to Microstops)" : item.title,
                    xAxis: xAxis,
                    yAxis: yAxis,
                    valueYField: props.valueField,
                    categoryXField: props.categoryField,
                    legendLabelText: item.title + ": {categoryX}",
                    legendRangeLabelText: "{name}",
                    tooltip: am5.Tooltip.new(root, {
                        labelText: item.title + " - {valueY} " + props.unit
                    })
                }));
                // Actual bullet
                series.bullets.push(function () {
                    let bulletCircle = am5.Circle.new(root, {
                        radius: 5,
                        fill: series.get("fill")
                    });
                    return am5.Bullet.new(root, {
                        sprite: bulletCircle
                    })
                })
                let data = item.values;
                series.data.setAll(data);
                xAxis.data.setAll(data);
                // Make stuff animate on load
                // https://www.amcharts.com/docs/v5/concepts/animations/
                series.appear(1000);
            })
        }
        var legend = chart.children.push(am5.Legend.new(root, {
            centerX: am5.p50,
            y: am5.percent(85),
            x: am5.p50,
            paddingLeft: 25
        }));

        legend.labels.template.setAll({
            fontSize: 12,
            oversizedBehavior: 'wrap-no-break',
            fontFamily: props.fontFamily,
            paddingLeft: 20
        });

        legend.data.setAll(chart.series.values);
        chart.appear(1000, 100);
        return () => {
            root.dispose();
        };
    }, [props])

    return (
        <div id={props.id} style={{ width: '100%', height: props.height }}></div>
    );
}, (prevProps, nextProps) => {
    // Only re-render if `data` has changed
    return prevProps.data === nextProps.data && prevProps.valueField === nextProps.valueField;
})
export default LineChart;