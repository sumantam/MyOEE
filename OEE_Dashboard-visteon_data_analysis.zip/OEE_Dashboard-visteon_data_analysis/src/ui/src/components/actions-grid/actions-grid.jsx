import { Box } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { randomId } from '@mui/x-data-grid-generator';
import './actions-grid.css';

const Actions = ({ data, firstColumnName, fontFamily, redGradientColor, greenGradientColor, yellowGradientColor, isExpanded, IsMs }) => {
    const columns = [
        {
            field: 'parentId',
            headerName: firstColumnName,
            headerClassName: 'custom-action-grid-header',
            minWidth: 120,
            flex: isExpanded ? 1 : 0,
            renderCell: (params) => {
                return firstColumnName === "Issue" && !IsMs ? <div title={params["row"]["auxText"]}>{firstColumnName} Type {params.value}</div> :
                    <div>{params.value}</div>
            }
        },
        // {
        //     field: 'rootCause',
        //     headerName: 'Description',
        //     headerClassName: 'custom-action-grid-header',
        //     flex: 1
        // },
        {
            field: 'rootCause',
            headerName: 'Root Cause',
            headerClassName: 'custom-action-grid-header',
            minWidth: 120,
            flex: isExpanded ? 1 : 0,
            renderCell: (params) => {
                <div style={{ fontFamily: fontFamily }}>{params.value}</div>
            }
        },
        {
            field: 'action',
            headerName: 'Action',
            headerClassName: 'custom-action-grid-header',
            minWidth: 100,
            flex: isExpanded ? 1 : 0,
            renderCell: (params) => {
                <div style={{ fontFamily: fontFamily }}>{params.value}</div>
            }
        },
        {
            field: 'by',
            headerName: 'Responsibility',
            headerClassName: 'custom-action-grid-header',
            minWidth: 120,
            flex: isExpanded ? 1 : 0,
            renderCell: (params) => {
                <div style={{ fontFamily: fontFamily }}>{params.value}</div>
            }
        },
        // {
        //     field: 'time',
        //     headerName: 'Incident Date',
        //     headerClassName: 'custom-action-grid-header',
        //     minWidth: 120,
        //     flex: isExpanded ? 1 : 0,
        //     renderCell: (params) => {
        //         <div style={{ fontFamily: fontFamily }}>{params.value}</div>
        //     }
        // },
        // {
        //     field: 'targetTime',
        //     headerName: 'Target Date',
        //     headerClassName: 'custom-action-grid-header',
        //     minWidth: 120,
        //     flex: isExpanded ? 1 : 0,
        //     renderCell: (params) => {
        //         <div style={{ fontFamily: fontFamily }}>{params.value}</div>
        //     }
        // },
        {
            field: 'actualTime',
            headerName: 'Actual Date',
            headerClassName: 'custom-action-grid-header',
            minWidth: 120,
            flex: isExpanded ? 1 : 0,
            renderCell: (params) => {
                <div style={{ fontFamily: fontFamily }}>{params.value}</div>
            }
        },
        {
            field: 'status',
            headerName: 'Status',
            headerClassName: 'custom-action-grid-header',
            maxWidth: 100,
            flex: isExpanded ? 1 : 0,
            renderCell: (params) => {
                return params.value === "G" ? <div style={{ background: greenGradientColor[0], "textAlign": "center", "display": "list-item" }}></div> :
                    params.value === "R" ? <div style={{ background: redGradientColor[0], "textAlign": "center", "display": "list-item" }}></div> :
                        params.value === "Y" ? <div style={{ background: yellowGradientColor[0], "textAlign": "center", "display": "list-item" }}></div> :
                            <div></div>
            }
        },
        // {
        //     field: 'resp',
        //     headerName: 'Responsibility',
        //     flex: 1
        // },
        // {
        //     field: 'action',
        //     headerName: 'Action',
        //     headerClassName:'custom-action-grid-header',
        //     flex: 1
        // }
    ];
    return (
        <Box flexGrow={1} style={{ width: '100%', height: '80vh', maxHeight: '100%' }}>
            <DataGrid
                getRowId={() => randomId()}
                rows={data}
                columns={columns}
                initialState={{
                    // sorting: {
                    //     sortModel: [{ field: 'parentId', sort: 'asc' }],
                    // },
                    pagination: {
                        paginationModel: {
                            pageSize: 10,
                        },
                    },
                }}
                pageSizeOptions={[5, 10, 20]}
                disableRowSelectionOnClick
            />
        </Box >
    );
};

export default Actions;

