import * as React from 'react';
import Button from '@mui/material/Button';
import { Download } from '@mui/icons-material';

export default function FileDownload(props) {
    return (
        <Button
            variant="contained"
            startIcon={<Download />}
            onClick={() => props.download()}
        >
            Download Sample CSV
        </Button>
    );
}