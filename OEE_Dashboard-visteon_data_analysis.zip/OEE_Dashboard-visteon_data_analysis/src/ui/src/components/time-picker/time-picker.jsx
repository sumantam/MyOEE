import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';

export default function TimePickerValue(props) {
    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <TimePicker
                views={['hours', 'minutes', 'seconds']}
                label={props.label}
                value={props.value}
                onChange={(newValue) => props.setTime(newValue)}
            />
        </LocalizationProvider>

    )
}