import { useLayoutEffect, memo } from 'react';
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import am5themes_Responsive from "@amcharts/amcharts5/themes/Responsive";

const ColumnLineChart = memo((props) => {
    useLayoutEffect(() => {
        let root = am5.Root.new(props.id);
        root._logo.dispose();
        let responsive = am5themes_Responsive.newEmpty(root);
        responsive.addRule({
            relevant: am5themes_Responsive.widthM,
            applying: function () {
                chart.set("layout", root.verticalLayout);
            },
            removing: function () {
                chart.set("layout", root.horizontalLayout);
            }
        });
        root.setThemes([
            am5themes_Animated.new(root), responsive
        ]);
        // Create chart
        // https://www.amcharts.com/docs/v5/charts/xy-chart/
        let chart = root.container.children.push(am5xy.XYChart.new(root, {
            panX: false,
            panY: false,
            wheelX: "panX",
            wheelY: "zoomX",
            paddingLeft: 0,
            paddingRight: 0,
            layout: root.verticalLayout
        }));

        root.numberFormatter.set("numberFormat", "#.##");

        chart.get("colors").set("colors",
            props.colors.map(p => am5.color(p))
        );
        // Create axes
        // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
        let xRenderer = am5xy.AxisRendererX.new(root, {
            minGridDistance: 85,
            minorGridEnabled: true
        })

        let xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(root, {
            categoryField: props.categoryField,
            renderer: xRenderer
        }));

        xRenderer.grid.template.setAll({
            location: 1
        })

        xRenderer.labels.template.setAll({
            paddingTop: 20,
            fontSize: 12,
            oversizedBehavior: 'wrap',
            fontFamily: props.fontFamily,
            maxWidth: 100
        });

        // If rotation required
        // if (props.labelRotationRequired) {
        //     xRenderer.labels.template.setAll({
        //         rotation: -45,
        //         centerY: am5.p50,
        //         centerX: am5.p100,
        //         paddingRight: 15,
        //         fontSize: 12
        //     });
        // }
        // else {
        //     xRenderer.labels.template.setAll({
        //         paddingTop: 20,
        //         fontSize: 12
        //     });
        // }

        if (props.data !== null) {
            xAxis.data.setAll(props.data);
        }

        let yRenderer = am5xy.AxisRendererY.new(root, {
            strokeOpacity: 0.1,
        });

        let yAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
            renderer: yRenderer
        }));

        yRenderer.labels.template.setAll({
            fontSize: 12,
            fontFamily: props.fontFamily
        })

        yAxis.children.unshift(am5.Label.new(root, {
            text: props.dataSeriesKeyTitle[0]["title"],
            textAlign: 'center',
            y: am5.p50,
            rotation: -90,
            fontWeight: 400,
            fontFamily: props.fontFamily
        }));

        let paretoAxisRenderer = am5xy.AxisRendererY.new(root, { opposite: true });
        let paretoAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
            renderer: paretoAxisRenderer,
            min: 0,
            max: 100,
            strictMinMax: true,
        }));

        paretoAxisRenderer.labels.template.setAll({
            fontSize: 12,
            fontFamily: props.fontFamily
        })

        paretoAxis.children.unshift(am5.Label.new(root, {
            text: props.dataSeriesKeyTitle[1]["title"],
            textAlign: 'center',
            x: am5.p100,
            y: am5.p50,
            rotation: -90,
            fontWeight: 400,
            fontFamily: props.fontFamily
        }));

        paretoAxisRenderer.grid.template.set("forceHidden", true);
        paretoAxis.set("numberFormat", "#'%");


        // Add series
        // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
        let series = chart.series.push(am5xy.ColumnSeries.new(root, {
            xAxis: xAxis,
            yAxis: yAxis,
            valueYField: props.dataSeriesKeyTitle[0].key,
            categoryXField: props.categoryField
        }));

        series.columns.template.setAll({
            tooltipText: `{categoryX}\n${props.dataSeriesKeyTitle[0].title}: {valueY}`,
            tooltipY: 0,
            strokeOpacity: 0,
            cornerRadiusTL: 6,
            cornerRadiusTR: 6
        });

        series.columns.template.adapters.add("fill", function (fill, target) {
            return chart.get("colors").getIndex(series.dataItems.indexOf(target.dataItem));
        })


        // pareto series
        let paretoSeries = chart.series.push(am5xy.LineSeries.new(root, {
            xAxis: xAxis,
            yAxis: paretoAxis,
            valueYField: props.dataSeriesKeyTitle[1].key,
            categoryXField: props.categoryField,
            stroke: root.interfaceColors.get("alternativeBackground"),
            maskBullets: false
        }));

        paretoSeries.bullets.push(function () {
            return am5.Bullet.new(root, {
                locationY: 1,
                sprite: am5.Circle.new(root, {
                    radius: 5,
                    fill: series.get("fill"),
                    stroke: root.interfaceColors.get("alternativeBackground"),
                    tooltipText: `{categoryX} - ${props.dataSeriesKeyTitle[1].title}: {valueY}%`,
                })
            })
        })

        if (props.data !== null) {
            series.data.setAll(props.data);
            paretoSeries.data.setAll(props.data);
        }

        // Make stuff animate on load
        // https://www.amcharts.com/docs/v5/concepts/animations/
        series.appear();
        chart.appear(1000, 100);
        return () => {
            root.dispose();
        };
    }, [props])

    return (
        <div id={props.id} style={{ width: '100%', height: props.height, marginTop: '2rem' }}></div>
    )
}, (prevProps, nextProps) => {
    // Only re-render if `data` has changed
    return prevProps.data === nextProps.data && prevProps.dataSeriesKeyTitle === nextProps.dataSeriesKeyTitle;
})
export default ColumnLineChart;