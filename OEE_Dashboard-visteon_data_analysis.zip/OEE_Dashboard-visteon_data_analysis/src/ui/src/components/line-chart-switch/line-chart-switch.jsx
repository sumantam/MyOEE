import * as React from 'react';
import Switch from '@mui/material/Switch';
import { Stack, Typography } from '@mui/material';


export default function LineChartSwitch({ switchValue, handleSwitchClicked, trueValue, falseValue, fontFamily }) {
  return (
    <Stack
      direction="row"
      margin={2}
      spacing={1}
      sx={{ alignItems: "center", justifyContent: "right" }}
    >
      <Typography style={{ fontFamily: fontFamily }}>{falseValue}</Typography>
      <Switch
        checked={switchValue}
        onChange={handleSwitchClicked}
        inputProps={{ "aria-label": "controlled" }}
      />
      <Typography style={{ fontFamily: fontFamily }}>{trueValue}</Typography>
    </Stack>
  );
}
