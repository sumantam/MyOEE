import { useLayoutEffect, memo } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addPath } from "../../reducers/bread-crumb-reducer";

import * as am5 from "@amcharts/amcharts5";
import * as am5map from "@amcharts/amcharts5/map";
import am5geodata_worldLow from "@amcharts/amcharts5-geodata/worldLow";
import am5geodata_data_countries2 from "@amcharts/amcharts5-geodata/data/countries2";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import am5themes_Responsive from "@amcharts/amcharts5/themes/Responsive";
import { setPlantFilter, setPlantNameFilter, geoDataSelector, dateSelector, fetchLines } from '../../reducers/filter-reducer';

const WorldMap = memo((props) => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const geoData = useSelector(geoDataSelector);
    const dateParam = useSelector(dateSelector);

    // const [geoData, setGeoData] = useSelector(geoDataSelector);
    useLayoutEffect(() => {
        let continents = {
            "AF": 0,
            "AN": 1,
            "AS": 2,
            "EU": 3,
            "NA": 4,
            "OC": 5,
            "SA": 6
        }
        let root = am5.Root.new("worldMap");
        let colors = am5.ColorSet.new(root, {});
        root._logo.dispose();
        let responsive = am5themes_Responsive.newEmpty(root);
        // responsive.addRule({
        //     relevant: am5themes_Responsive.widthM,
        //     applying: function () {
        //         chart.set("layout", root.verticalLayout);
        //     },
        //     removing: function () {
        //         chart.set("layout", root.horizontalLayout);
        //     }
        // });
        root.setThemes([
            am5themes_Animated.new(root), responsive
        ]);
        let chart = root.container.children.push(
            am5map.MapChart.new(root, {
                panX: "rotateX",
                projection: am5map.geoNaturalEarth1(),
                centerX: 50
            })
        );


        // Create main polygon series for countries
        // https://www.amcharts.com/docs/v5/charts/map-chart/map-polygon-series/
        let worldSeries = chart.series.push(
            am5map.MapPolygonSeries.new(root, {
                geoJSON: geoData,
                exclude: ["AQ"]
            }),
        );

        worldSeries.mapPolygons.template.setAll({
            // tooltipText: "{name}",
            interactive: true,
            fill: am5.color(0xaaaaaa),
            templateField: "polygonSettings"
        });

        // Set up data for countries
        let data = [];
        for (var id in am5geodata_data_countries2) {
            if (am5geodata_data_countries2.hasOwnProperty(id)) {
                let country = am5geodata_data_countries2[id];
                if (country.maps.length) {
                    data.push({
                        id: id,
                        map: country.maps[0],
                        polygonSettings: {
                            fill: colors.getIndex(continents[country.continent_code]),
                        }
                    });
                }
            }
        }
        worldSeries.data.setAll(data);

        if (props.data !== undefined && props.data !== null && props.data.length > 0) {
            let bubbleSeries = chart.series.push(
                am5map.MapPointSeries.new(root, {
                    calculateAggregates: true,
                    // valueField: "value",
                    // polygonIdField: "id"
                    latitudeField: "lat",
                    longitudeField: "long"
                })
            );
            let index = 0;
            bubbleSeries.bullets.push(function () {
                let markerColor = props.markerBackground[index++];
                let circle = am5.Circle.new(root, {
                    radius: 10,
                    fill: markerColor,
                    tooltipY: am5.p100,
                    tooltipHTML: markerColor !== 'black' ? `<div style=\"background: {tooltipBackground}; border-radius: 0.5rem; padding: 1rem; position: fixed; margin-left: -10rem; cursor: pointer;\">
                                    <center style=\"margin-bottom: 0.5rem;\"><strong style=\"font-family: props.fontFamily; color: black;\">{name}</strong></center>
                                    <table>
                                        <tr>
                                            <th style=\"width: 6rem;\"></th>
                                            <th style=\"width: 6rem; font-family: props.fontFamily; color: black;\">Last Day</th>
                                            <th style=\"width: 6rem; font-family: props.fontFamily; color: black;\">Last Week</th>
                                        </tr>
                                        <tr>
                                            <th align="left" style=\"width: 6rem; font-family: props.fontFamily; color: black;\">Planned</th>
                                            <td align="center" style=\"width: 6rem; font-family: props.fontFamily; color: black;\">{lastDayData.planned}</td>
                                            <td align="center" style=\"width: 6rem; font-family: props.fontFamily; color: black;\">{lastWeekData.planned}</td>
                                        </tr>
                                        <tr>
                                            <th align="left" style=\"width: 6rem; font-family: props.fontFamily; color: black;\">Actual</th>
                                            <td align="center" style=\"width: 6rem; font-family: props.fontFamily; color: black; background: {lastDayData.bgColorForActual}\">{lastDayData.actual}</td>
                                            <td align="center" style=\"width: 6rem; font-family: props.fontFamily; color: black; background: {lastWeekData.bgColorForActual};\">{lastWeekData.actual}</td>
                                        </tr>
                                        <tr>
                                            <th align="left" style=\"width: 6rem; font-family: props.fontFamily; color: black;\">OEE</th>
                                            <td align="center" style=\"width: 6rem; font-family: props.fontFamily; color: black; background: {lastDayData.bgColorForOee};\">{lastDayData.oee}%</td>
                                            <td align="center" style=\"width: 6rem; font-family: props.fontFamily; color: black; background: {lastWeekData.bgColorForOee};\">{lastWeekData.oee}%</td>
                                        </tr>
                                    </table>
                                </div>` :
                        `<div style=\"background: {tooltipBackground}; border-radius: 0.5rem; padding: 1rem; position: fixed; margin-left: -10rem; \">
                                    <center style=\"margin-bottom: 0.5rem;\"><strong style=\"font-family: props.fontFamily; color: black;\">No data available for {name} ${getNoDataIndicationText()}</strong></center>
                                </div>`
                })
                if (markerColor !== 'black') {
                    circle.events.on("click", (ev) => {
                        dispatch(setPlantFilter(ev.target.dataItem.dataContext.id));
                        dispatch(setPlantNameFilter(ev.target.dataItem.dataContext.name));
                        dispatch(fetchLines(ev.target.dataItem.dataContext.name))
                        dispatch(addPath({ path: '/oee/dashboard/smt', name: 'Plant Dashboard', icon: 'home' }))
                        navigate('/oee/dashboard/smt');
                    })
                }

                return am5.Bullet.new(root, {
                    sprite: circle
                });
            });
            bubbleSeries.data.setAll(props.data)
        }

        chart.appear(1000, 100);

        const getNoDataIndicationText = () => {
            let fetchedDate = new Date(dateParam);
            return fetchedDate.getFullYear() !== 1900 ? `at ${fetchedDate.toDateString()}` : "";
        }
        return () => {
            root.dispose();
        };
    }, [props])

    return (
        <div id="worldMap" style={{ width: '100%', height: '85vh' }}></div>
    );
}, (prevProps, nextProps) => {
    // Only re-render if `data` has changed
    return prevProps.data === nextProps.data;
})
export default WorldMap;