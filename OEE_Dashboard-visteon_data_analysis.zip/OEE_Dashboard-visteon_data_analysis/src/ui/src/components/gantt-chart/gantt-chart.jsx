import { useLayoutEffect, memo } from 'react';
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import am5themes_Responsive from "@amcharts/amcharts5/themes/Responsive";

const GanttChart = memo((props) => {
    useLayoutEffect(() => {
        let root = am5.Root.new(props.id);
        root._logo.dispose();
        root.dateFormatter.setAll({
            // dateFormat: "yyyy-MM-dd HH:mm",
            dateFormat: "yyyy-MM-dd HH:mm:ss.SSS",
            dateFields: ["valueX", "openValueX"]
        });
        let responsive = am5themes_Responsive.newEmpty(root);
        responsive.addRule({
            relevant: am5themes_Responsive.widthM,
            applying: function () {
                chart.set("layout", root.verticalLayout);
            },
            removing: function () {
                chart.set("layout", root.horizontalLayout);
            }
        });
        root.setThemes([
            am5themes_Animated.new(root), responsive
        ]);
        let chart = root.container.children.push(am5xy.XYChart.new(root, {
            panX: true,
            panY: false,
            wheelX: "panX",
            wheelY: "zoomX",
            paddingLeft: 0,
            layout: root.verticalLayout
        }));

        let colors = chart.get("colors");

        let data = [
            {
                line: "Line 1",
                fromDate: "2024-07-15 06:00",
                toDate: "2024-07-15 07:00",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 1",
                fromDate: "2024-07-15 07:00",
                toDate: "2024-07-15 07:05",
                columnSettings: {
                    fill: am5.color(0xfd0000)
                },
                state: "Breakdown"
            },
            {
                line: "Line 1",
                fromDate: "2024-07-15 07:05",
                toDate: "2024-07-15 10:00",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 1",
                fromDate: "2024-07-15 10:00",
                toDate: "2024-07-15 10:30",
                columnSettings: {
                    fill: am5.color(0xe4ff00)
                },
                state: "Changeover"
            },
            {
                line: "Line 1",
                fromDate: "2024-07-15 10:30",
                toDate: "2024-07-15 12:00",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 1",
                fromDate: "2024-07-15 12:00",
                toDate: "2024-07-15 12:02",
                columnSettings: {
                    fill: am5.color(0x1a36fc)
                },
                state: "Microstop"
            },
            {
                line: "Line 1",
                fromDate: "2024-07-15 12:02",
                toDate: "2024-07-15 14:00",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 2",
                fromDate: "2024-07-15 06:00",
                toDate: "2024-07-15 14:00",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 3",
                fromDate: "2024-07-15 06:00",
                toDate: "2024-07-15 08:00",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 3",
                fromDate: "2024-07-15 08:00",
                toDate: "2024-07-15 08:10",
                columnSettings: {
                    fill: am5.color(0xfd0000)
                },
                state: "Breakdown"
            },
            {
                line: "Line 3",
                fromDate: "2024-07-15 08:10",
                toDate: "2024-07-15 08:20",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 3",
                fromDate: "2024-07-15 08:20",
                toDate: "2024-07-15 08:40",
                columnSettings: {
                    fill: am5.color(0xfd0000)
                },
                state: "Breakdown"
            },
            {
                line: "Line 3",
                fromDate: "2024-07-15 08:40",
                toDate: "2024-07-15 11:00",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 3",
                fromDate: "2024-07-15 11:00",
                toDate: "2024-07-15 11:30",
                columnSettings: {
                    fill: am5.color(0xe4ff00)
                },
                state: "Changeover"
            },
            {
                line: "Line 3",
                fromDate: "2024-07-15 11:30",
                toDate: "2024-07-15 13:00",
                columnSettings: {
                    fill: am5.color(0x00ff3b)
                },
                state: "Running"
            },
            {
                line: "Line 3",
                fromDate: "2024-07-15 13:00",
                toDate: "2024-07-15 14:00",
                columnSettings: {
                    fill: am5.color(0xfd0000)
                },
                state: "Breakdown"
            }
        ];

        props.data.forEach(p => {
            p["columnSettings"] = {
                fill: am5.color(p["color"])
            }
        })

        // Create axes
        // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
        let yRenderer = am5xy.AxisRendererY.new(root, {
            minorGridEnabled: true
        });
        yRenderer.grid.template.set("location", 1);

        let yAxis = chart.yAxes.push(
            am5xy.CategoryAxis.new(root, {
                // categoryField: "line",
                categoryField: props.categoryField,
                renderer: yRenderer,
                tooltip: am5.Tooltip.new(root, {})
            })
        );

        // yAxis.data.setAll([
        //     { "line": "Line 1" },
        //     { "line": "Line 2" },
        //     { "line": "Line 3" }
        // ]);

        yAxis.data.setAll(props.yaxisKeyVal);

        let xAxis = chart.xAxes.push(
            am5xy.DateAxis.new(root, {
                // baseInterval: { timeUnit: "minute", count: 1 },
                baseInterval: { timeUnit: "millisecond", count: 1 },
                min: new Date(props.fromTime).getTime(),
                max: new Date(props.toTime).getTime(),
                renderer: am5xy.AxisRendererX.new(root, {
                    minorGridEnabled: true,
                    minGridDistance: 90,
                })
            })
        );

        let series = chart.series.push(am5xy.ColumnSeries.new(root, {
            xAxis: xAxis,
            yAxis: yAxis,
            openValueXField: "fromDate",
            valueXField: "toDate",
            // categoryYField: "line",
            categoryYField: props.categoryField,
            sequencedInterpolation: true,
        }));

        series.columns.template.setAll({
            templateField: "columnSettings",
            strokeOpacity: 0,
            // tooltipText: "{state}:\n[bold]{openValueX}[/] - [bold]{valueX}[/]"
            tooltipText: props.isTooltipTextPrefixMachine ? "{pcbId} - {event}:\n[bold]{openValueX}[/] - [bold]{valueX}[/]" :
                "{machine}:\n[bold]{openValueX}[/] - [bold]{valueX}[/]"
        });

        series.columns.template.events.on("click", function (ev) {
            props.clickToPopulatePcbSpecficGantt(ev.target._dataItem.dataContext["pcbId"], props.id)
        });

        series.data.processor = am5.DataProcessor.new(root, {
            dateFields: ["fromDate", "toDate"],
            // dateFormat: "yyyy-MM-dd HH:mm"
            dateFormat: "yyyy-MM-dd HH:mm:ss.SSS"
        });

        // series.data.setAll(data);
        series.data.setAll(props.data);

        // Add scrollbars
        chart.set("scrollbarX", am5.Scrollbar.new(root, { orientation: "horizontal" }));

        // Make stuff animate on load
        // https://www.amcharts.com/docs/v5/concepts/animations/
        series.appear();
        chart.appear(1000, 100);
        return () => {
            root.dispose();
        };
    }, [props])

    return (
        <>
            <h6 style={{ textAlign: 'center' }}>{props.title}</h6>
            <div id={props.id} style={{ width: '100%', height: props.height, margin: 'auto' }}></div>
        </>
    );
}, (prevProps, nextProps) => {
    // Only re-render if `data` has changed
    return prevProps.id === nextProps.id;
})
export default GanttChart;