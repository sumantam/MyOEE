import './range-selector.css';

const RangeSelector = () => {

    return (

        // <Grid container spacing={1} justifyContent="center">
        //     <Grid item xs={6} sm={6} md={6} lg={6} style={{ background: 'red' }}>

        //     </Grid>
        //     <Grid item xs={6} sm={6} md={6} lg={6} style={{ background: 'green' }}>

        //     </Grid>
        //     <Grid item xs={6} sm={6} md={6} lg={6} style={{ background: 'blue' }}>

        //     </Grid>
        //     <Grid item xs={6} sm={6} md={6} lg={6} style={{ background: 'orange' }}>

        //     </Grid>
        // </Grid>
        <div className="custom-range-selector">
            <div className="custom-range-box" style={{ background: '#90f1ef' }} title="Last Shift"></div>
            <div className="custom-range-box" style={{ background: '#ffd6e0' }} title="Last 3 Shifts"></div>
            <div className="custom-range-box" style={{ background: '#ffef9f' }} title="Last week"></div>
            <div className="custom-range-box" style={{ background: '#c1fba4' }} title="Last month"></div>
        </div>
    )

};

export default RangeSelector;