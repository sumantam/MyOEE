import { Box } from '@mui/material';
import Plot from 'react-plotly.js';
import './trend-chart-bar.css';

const TrendBarChart = ({ data, colors }) => {

    const layout = {
        xaxis: { title: '', automargin: true, autotickangles: true, autoshift: true, autorange: true },
        yaxis: { title: 'Stop Time(mins)', automargin: true, showline: true },
        margin: { t: 10, b: 10 },
        legend: {
            traceorder:'normal',
            orientation: 'h',
            fill: 'none',
            x: 0.0,
            y: -0.2 // Adjust this value to position the legend relative to the chart
        },
        autosize: true,
        responsive: true,
        barmode: 'stack'
    };

    var trendData = [];

    data.forEach((item, i) => {
        const obj = {
            x: [], y: [], name: item.target,
            stackgroup: 'one',
            type: 'bar',
            // width: 0.5,
            marker: { color: colors[i], opacity: 1 }
        };
        item.dataPoints.forEach((i) => {
            obj.x.push(i.label);
            obj.y.push(i.value);
        });
        trendData.push(obj);
    });

    const config = {
        displaylogo: false,
        responsive: true, // Make the plot responsive
    };

    return (
        <Box style={{ width: '100%', height: '100%' }}>
            <Plot data={trendData} layout={layout} style={{ width: '100%', height: '100%' }} config={config} className='custom-trend-chart-bar' />
        </Box>
    );
};

export default TrendBarChart;

