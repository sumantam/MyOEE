import { memo } from 'react';
import { Card, CardContent, CardHeader, Grid, IconButton, Typography } from "@mui/material";
import GaugeChart from '../gauge-chart/gauge-chart';
import ParetoChart from "../pareto-chart/pareto-chart";
import RenderType from "../../models/render-type";
import TrendChart from "../trend-chart/trend-chart";
import Actions from "../actions-grid/actions-grid";
import PaynterChart from "../paynter-chart/paynter-chart";
import TrendBarChart from "../trend-chart-bar/trend-chart-bar";
import { CloseFullscreen, OpenInFull } from "@mui/icons-material";
import ChartSwitch from "../chart-switch/chart-switch";
import ChartSwitch2 from "../chart-switch-2/chart-switch-2";
import CustomTable from "../custom-table/custom-table";
import CycleTimeTable from "../cycle-time-table/cycle-time-table";
import LineChart from "../line-chart/line-chart";
import TwoLevelPieChart from "../two-level-pie-chart/two-level-pie-chart";
import LineChartSwitch from "../line-chart-switch/line-chart-switch";
import FunctionsIcon from '@mui/icons-material/Functions';
import { useSelector } from "react-redux";
import { themeSelector } from "../../reducers/filter-reducer";

const CardBox = memo(({
  type,
  data,
  actions,
  markerData,
  handleExpansion,
  isSwitchRequired,
  switchChart,
  id,
  expanded,
  colors,
  handleClick,
  firstColumnName,
  timeRange,
  lineOrMachine,
  trueValue,
  falseValue,
  handleLineSwitchClick,
  switchValue,
  lineChartYLabel,
  fontFamily,
  greenGradientColor,
  redGradientColor,
  yellowGradientColor,
  colorShades,
  closeCard,
  totalTrendGetter,
  isLegendToBeAdjusted = false,
  totalParams,
  IsMs = false,
  IsLossOrGainIndicatorRequired = false,
  isLineClicked = false,
  gaugeRange,
  chartHeight,
  fontSize
}) => {
  const theme = useSelector(themeSelector);

  const renderTitle = () => {
    const timeRangeStr = lineOrMachine !== undefined && timeRange !== undefined ? " - (" + lineOrMachine + ") (" + timeRange["start"].toDateString() + " - " + timeRange["end"].toDateString() + ")"
      : "";
    const lossOrGainString = IsLossOrGainIndicatorRequired ? " => Loss (+) / Gain (-)" : "";
    switch (type) {
      case RenderType.PARETO:
      case RenderType.PARETOPIE:
        return "Pareto" + lossOrGainString + timeRangeStr;
      case RenderType.TREND:
      case RenderType.TRENDBAR:
        return "Trend" + lossOrGainString + timeRangeStr;
      case RenderType.PAYNTER:
        return "Paynter" + timeRangeStr;
      case RenderType.ACTIONS:
        return "Actions" + timeRangeStr;
      case RenderType.CustomTable:
        return "(Please click on any line to view the trend)";
      case RenderType.CycleTimeTable:
        return "Please hover on any cell to view Performance Loss or Gain"
      case RenderType.LineChartTrend:
        return lineOrMachine !== undefined ? "Plan vs Actual (" + lineOrMachine + ")" : "";
      default:
        return "";
    }
  };

  const renderSection = () => {
    switch (type) {
      case RenderType.Gauge:
        return <GaugeChart
          value={data}
          id={id}
          range={gaugeRange}
          redGradientColor={redGradientColor}
          yellowGradientColor={yellowGradientColor}
          greenGradientColor={greenGradientColor}
          fontFamily={fontFamily}
          fontSize={fontSize}
          height={chartHeight} />
      case RenderType.PARETO:
        return (
          <ParetoChart data={data} colors={colors} handleClick={handleClick} isLegendToBeAdjusted={isLegendToBeAdjusted} />
        );
      case RenderType.PARETOPIE:
        return (
          <TwoLevelPieChart
            id={id}
            data={data}
            colors={colors}
            categoryField="key"
            fontFamily={fontFamily}
            handleClick={handleClick}
            height="390px"
            dataSeriesKeyTitle={[
              { key: "value", title: "(mins)" },
              { key: "percentage", title: "Percentage" },
            ]} />
        );
      case RenderType.TREND:
        return <TrendChart data={data} colors={colors} />;
      case RenderType.TRENDBAR:
        return <TrendBarChart data={data} colors={colors} />;
      case RenderType.PAYNTER:
        return (
          <PaynterChart data={data} markerData={markerData} colors={colors} firstColumnName={firstColumnName} IsMs={IsMs} />
        );
      case RenderType.ACTIONS:
        return <Actions data={actions} firstColumnName={firstColumnName} fontFamily={fontFamily} greenGradientColor={greenGradientColor} redGradientColor={redGradientColor} yellowGradientColor={yellowGradientColor} isExpanded={expanded} IsMs={IsMs} />;
      case RenderType.CustomTable:
        return <CustomTable gridData={data} handleClick={handleClick} fontFamily={fontFamily} greenGradientColor={greenGradientColor} redGradientColor={redGradientColor} yellowGradientColor={yellowGradientColor} />;
      case RenderType.CycleTimeTable:
        return <CycleTimeTable gridData={data} handleClick={handleClick} fontFamily={fontFamily} greenGradientColor={greenGradientColor} redGradientColor={redGradientColor} yellowGradientColor={yellowGradientColor} colors={colors} />;
      case RenderType.LineChartTrend:
        return <LineChart
          data={data}
          unit={switchValue ? "min" : ""}
          yAxisTitle={lineChartYLabel}
          labelRotation={{ "required": true, "angle": -45 }}
          categoryField="range"
          valueField="value"
          id="changeOverGridTrend"
          fontFamily={fontFamily}
          colors={colorShades}
          height="400px" />;
      default:
        return <></>;
    }
  };
  const renderAction = () => {
    switch (type) {
      case RenderType.TREND:
        return (
          <>
            <ChartSwitch switchChart={(flag) => switchChart(flag)} />
            <IconButton onClick={() => handleExpansion(!expanded)}>
              {expanded ? <CloseFullscreen /> : <OpenInFull />}
            </IconButton>
          </>
        );
      case RenderType.TRENDBAR:
        return (
          <>
            <ChartSwitch switchChart={(flag) => switchChart(flag)} />
            <IconButton onClick={() => handleExpansion(!expanded)}>
              {expanded ? <CloseFullscreen /> : <OpenInFull />}
            </IconButton>
          </>
        );
      case RenderType.PARETO:
        return (
          <>
            <ChartSwitch2 switchChart={(flag) => switchChart(flag)} />
            <IconButton onClick={() => handleExpansion(!expanded)}>
              {expanded ? <CloseFullscreen /> : <OpenInFull />}
            </IconButton>
          </>
        );
      case RenderType.PARETOPIE:
        return (
          <>
            <ChartSwitch2 switchChart={(flag) => switchChart(flag)} />
            <IconButton onClick={() => handleExpansion(!expanded)}>
              {expanded ? <CloseFullscreen /> : <OpenInFull />}
            </IconButton>
          </>
        );
      case RenderType.LineChartTrend:
        return (<div style={{ display: 'flex' }}>
          <IconButton title="Total Trend" onClick={() => totalTrendGetter()}><FunctionsIcon /></IconButton>
          <LineChartSwitch switchValue={switchValue} handleSwitchClicked={handleLineSwitchClick} trueValue={trueValue} falseValue={falseValue} fontFamily={fontFamily} />
          <IconButton onClick={() => handleExpansion(!expanded)}>
            {expanded ? <CloseFullscreen /> : <OpenInFull />}
          </IconButton>
          {/* <IconButton>
            <Close onClick={closeCard}/>
          </IconButton> */}
        </div>)
      default:
        return (
          <>
            {/* <IconButton onClick={() => handleExpansion(!expanded)}>
              {expanded ? <CloseFullscreen /> : <OpenInFull />}
            </IconButton> */}
          </>
        )
    }
  };
  return (
    <Card sx={{ width: "100%", height: "100%" }}>
      {type !== RenderType.Gauge ?
        <CardHeader
          titleTypographyProps={{ fontSize: 16, fontWeight: 600, fontFamily: fontFamily }}
          title={renderTitle()}
          action={
            renderAction()
          }
        /> : <></>
      }
      <CardContent>
        <Grid container spacing={1} justifyContent="center">
          {type === RenderType.LineChartTrend && lineOrMachine === "Total" ?
            <>
              <Grid item xs={12} sm={12} md={6} lg={6}>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>Total Count Plan - {totalParams?.plan?.count}</Typography>
              </Grid>
              <Grid item xs={12} sm={12} md={6} lg={6} sx={{ textAlign: { xs: 'left', sm: 'left', md: 'right', lg: 'right' } }}>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>Total Count Actual - {totalParams?.actual?.count}</Typography>
              </Grid>
              <Grid item xs={12} sm={12} md={6} lg={6}>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>Total Average Plan - {totalParams?.plan?.stop} min</Typography>
              </Grid>
              <Grid item xs={12} sm={12} md={6} lg={6} sx={{ textAlign: { xs: 'left', sm: 'left', md: 'right', lg: 'right' } }}>
                <Typography style={{ fontSize: "1rem", fontWeight: "bold", fontFamily: theme["fontFamily"] }}>Total Average Actual - {totalParams?.actual?.stop} min</Typography>
              </Grid>
            </> : <></>
          }
          <Grid item xs={12} sm={12} md={12} lg={12}>
            {renderSection()}
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
}, (prevProps, nextProps) => {
  // Only re-render if `data` has changed
  return prevProps.data === nextProps.data &&
    prevProps.type === nextProps.type &&
    prevProps.expanded === nextProps.expanded &&
    prevProps.switchValue === nextProps.switchValue &&
    prevProps.isLineClicked === nextProps.isLineClicked;
})

export default CardBox;
