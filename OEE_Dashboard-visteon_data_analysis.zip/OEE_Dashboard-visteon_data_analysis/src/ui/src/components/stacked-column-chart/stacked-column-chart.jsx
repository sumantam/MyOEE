import { useLayoutEffect, memo } from 'react';
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import am5themes_Responsive from "@amcharts/amcharts5/themes/Responsive";

const StackedColumnChart = memo((props) => {
    useLayoutEffect(() => {
        let root = am5.Root.new(props.id);
        root._logo.dispose();
        let responsive = am5themes_Responsive.newEmpty(root);
        responsive.addRule({
            relevant: am5themes_Responsive.widthM,
            applying: function () {
                chart.set("layout", root.verticalLayout);
            },
            removing: function () {
                chart.set("layout", root.horizontalLayout);
            }
        });
        root.setThemes([
            am5themes_Animated.new(root), responsive
        ]);
        // Create chart
        // https://www.amcharts.com/docs/v5/charts/xy-chart/
        let chart = root.container.children.push(am5xy.XYChart.new(root, {
            panX: false,
            panY: false,
            wheelX: "panX",
            wheelY: "zoomX",
            paddingLeft: 0,
            layout: root.verticalLayout
        }));

        chart.set("scrollbarX", am5.Scrollbar.new(root, {
            orientation: "horizontal"
        }));

        chart.get("colors").set("colors",
            props.colors.map(p => am5.color(p))
        );
        // Create axes
        // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
        let xRenderer = am5xy.AxisRendererX.new(root, {
            minGridDistance: 50,
            minorGridEnabled: true
        });
        let xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(root, {
            categoryField: props.categoryField,
            renderer: xRenderer,
            tooltip: am5.Tooltip.new(root, {})
        }));

        xRenderer.grid.template.setAll({
            location: 1
        })

        xRenderer.labels.template.setAll({
            oversizedBehavior: "fit",
            maxWidth: 70,
            textAlign: "center",
            fontSize: 12,
            fontFamily: props.fontFamily
        });

        // If rotation required
        // if (props.labelRotationRequired) {
        //     xRenderer.labels.template.setAll({
        //         rotation: -45,
        //         centerY: am5.p50,
        //         centerX: am5.p100,
        //         paddingRight: 15,
        //         fontSize: 12
        //     });
        // }
        // else {
        //     xRenderer.labels.template.setAll({
        //         paddingTop: 20,
        //         fontSize: 12
        //     });
        // }

        if (props.data !== null) {
            xAxis.data.setAll(props.data);
        }

        let yRenderer = am5xy.AxisRendererY.new(root, {
            strokeOpacity: 0.1,
        });

        let yAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
            renderer: yRenderer
        }));

        yRenderer.labels.template.setAll({
            fontSize: 12,
            fontFamily: props.fontFamily
        })

        yAxis.children.unshift(am5.Label.new(root, {
            text: props.dataSeriesKeyTitle[0]["title"],
            textAlign: 'center',
            y: am5.p50,
            rotation: -90,
            fontWeight: 400,
            fontFamily: props.fontFamily
        }));

        // Add legend
        // https://www.amcharts.com/docs/v5/charts/xy-chart/legend-xy-series/
        let legend = chart.children.push(am5.Legend.new(root, {
            centerX: am5.p50,
            x: am5.p50,
            paddingLeft: 25
        }));

        // Add series
        // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
        function makeSeries(name, fieldName) {
            let series = chart.series.push(am5xy.ColumnSeries.new(root, {
                name: name,
                stacked: true,
                xAxis: xAxis,
                yAxis: yAxis,
                valueYField: fieldName,
                categoryXField: props.categoryField
            }));

            series.columns.template.setAll({
                tooltipText: "{name}, {categoryX}: {valueY}%",
                tooltipY: am5.percent(10)
            });
            if (props.data !== null) {
                series.data.setAll(props.data);
            }

            // Make stuff animate on load
            // https://www.amcharts.com/docs/v5/concepts/animations/
            series.appear();

            series.bullets.push(function () {
                return am5.Bullet.new(root, {
                    sprite: am5.Label.new(root, {
                        text: "{valueY}%",
                        fill: root.interfaceColors.get("alternativeText"),
                        centerY: am5.p50,
                        centerX: am5.p50,
                        fontSize: 12,
                        fontFamily: props.fontFamily,
                        populateText: true
                    })
                });
            });

            legend.data.push(series);
        }

        if (props.barKeysAndTitles !== null) {
            props.barKeysAndTitles.forEach(item => {
                makeSeries(item["title"], item["key"]);
            })
        }

        // let series = chart.series.push(am5xy.ColumnSeries.new(root, {
        //     stacked: true,
        //     xAxis: xAxis,
        //     yAxis: yAxis,
        //     valueYField: props.dataSeriesKeyTitle[0].key,
        //     categoryXField: props.categoryField
        // }));

        // series.columns.template.setAll({
        //     tooltipText: `{categoryX} - ${props.dataSeriesKeyTitle[0].title}: {valueY}`,
        //     tooltipY: 0,
        //     strokeOpacity: 0,
        //     cornerRadiusTL: 6,
        //     cornerRadiusTR: 6
        // });

        // series.columns.template.adapters.add("fill", function (fill, target) {
        //     return chart.get("colors").getIndex(series.dataItems.indexOf(target.dataItem));
        // })

        // if (props.data !== null) {
        //     series.data.setAll(props.data);
        // }

        // Make stuff animate on load
        // https://www.amcharts.com/docs/v5/concepts/animations/
        // series.appear();
        chart.appear(1000, 100);
        return () => {
            root.dispose();
        };
    }, [props])

    return (
        <div id={props.id} style={{ width: '100%', height: props.height, marginTop: '1rem' }}></div>
    )

}, (prevProps, nextProps) => {
    // Only re-render if `data` has changed
    return prevProps.data === nextProps.data && prevProps.barKeysAndTitles === nextProps.barKeysAndTitles;
})
export default StackedColumnChart;