import React from "react";
import {
  Box,
  Grid,
} from "@mui/material";

import "./custom-table.css";

const CustomTable = ({ gridData, handleClick, fontFamily, greenGradientColor, redGradientColor, yellowGradientColor }) => {

  const totalModels = gridData[0].data.plan.map((i) => i.modelName);

  const getColorForCountBox = (actualCount, plannedCount) => {
    if (actualCount >= plannedCount) return greenGradientColor[0];
    else return redGradientColor[0];
  }

  // const getColorForAverageBox = (actualAverage, plannedAverage) => {
  //   if (actualAverage <= plannedAverage) return greenGradientColor[0];
  //   else {
  //     let diff = (actualAverage - plannedAverage) / plannedAverage * 100;
  //     if (diff > 0 && diff <= 10) return greenGradientColor[0];
  //     else if (diff > 10 && diff <= 20) return yellowGradientColor[0];
  //     else return redGradientColor[0];
  //   }
  // }

  // This method is only for demo purpose. Once done, commented method at the above will be applicable
  const getColorForAverageBox = (actualAverage, plannedAverage) => {
    if (actualAverage <= plannedAverage) return greenGradientColor[0];
    else {
      let diff = (actualAverage - plannedAverage) / plannedAverage * 100;
      if (diff > 0 && diff <= 10) return greenGradientColor[0];
      else if (diff > 10 && diff <= 30) return yellowGradientColor[0];
      else return redGradientColor[0];
    }
  }

  const handleLineClick = (lineNameAndId) => {
    handleClick(lineNameAndId);
  };

  return (
    <Box flexGrow={1}>
      <Grid container spacing={1} justifyContent="center" className="custom-grid-row">
        <Grid item xs={2} sm={2} md={2} lg={2} className="custom-grid-border"></Grid>
        {gridData.map((gd, h) => {
          return (
            <Grid key={h} item xs={2} sm={2} md={2} lg={2} style={{ textAlign: 'center', fontWeight: 600, fontFamily: fontFamily, paddingTop: '0.8rem' }} className="custom-grid-border" onClick={() => handleLineClick({ "lineName": gd.lineName, "lineId": gd.lineId })}>
              {gd.lineName}
            </Grid>
          );
        })}

      </Grid>
      <Grid container spacing={1} justifyContent="center" className="custom-grid-row">
        <Grid item xs={2} sm={2} md={2} lg={2} className="custom-grid-border"></Grid>
        {gridData.map((gd, i) => {
          return (
            <Grid key={i} item xs={2} sm={2} md={2} lg={2}>
              <Grid container spacing={1} justifyContent="center">
                <Grid item xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'center', fontWeight: 600, fontFamily: fontFamily, paddingLeft: 0, paddingTop: '0.8rem' }} className="custom-grid-border custom-grid-row" onClick={() => handleLineClick({ "lineName": gd.lineName, "lineId": gd.lineId })}>
                  Count
                </Grid>
                <Grid item xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'center', fontWeight: 600, fontFamily: fontFamily, paddingLeft: 0, paddingTop: '0.8rem' }} className="custom-grid-border custom-grid-row" onClick={() => handleLineClick({ "lineName": gd.lineName, "lineId": gd.lineId })}>
                  Average
                </Grid>
              </Grid>
            </Grid>
          );
        })}
      </Grid>
      {totalModels.map((m, j) => {
        return (
          <div key={j}>
            <Grid container spacing={1} justifyContent="center" className="custom-grid-row">
              <Grid item xs={2} sm={2} md={2} lg={2} className="custom-grid-border" style={{ fontWeight: 600, fontFamily: fontFamily, paddingTop: '0.8rem' }}>{`${m} Plan`}</Grid>
              {gridData.map((gd, k) => {
                const planData = gd.data.plan.find(i => i.modelName === m);
                const planAvgTime = planData !== undefined ? planData?.count !== 0 && planData.value !== 0 ? ((planData.value / planData.count)).toFixed(2) : 0 : 0;
                return (
                  <Grid key={k} item xs={2} sm={2} md={2} lg={2} style={{ textAlign: 'center', fontFamily: fontFamily }} onClick={() => handleLineClick({ "lineName": gd.linename, "lineId": gd.line })}>
                    <Grid container spacing={1} justifyContent="center">
                      <Grid item xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'center', fontFamily: fontFamily, paddingLeft: 0, paddingTop: '0.8rem' }} className="custom-grid-border custom-grid-row">
                        <div style={{ margin: 'auto', fontFamily: fontFamily }}>{planData !== undefined ? planData.count : 0}</div>
                      </Grid>
                      <Grid item xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'center', fontFamily: fontFamily, paddingLeft: 0, paddingTop: '0.8rem' }} className="custom-grid-border custom-grid-row">
                        <div style={{ margin: 'auto', fontFamily: fontFamily }}>{planAvgTime}</div>
                      </Grid>
                    </Grid>
                  </Grid>
                );
              })}
            </Grid>
            <Grid container spacing={1} justifyContent="center" className="custom-grid-row">
              <Grid item xs={2} sm={2} md={2} lg={2} className="custom-grid-border" style={{ fontWeight: 600, fontFamily: fontFamily, paddingTop: '0.8rem' }}>{`${m} Actual`}</Grid>
              {gridData.map((gd, l) => {
                const actualData = gd.data.actual.find(i => i.modelName === m);
                const actAvgTime = actualData !== undefined ? actualData?.count !== 0 && actualData.value !== 0 ? ((actualData.value / actualData.count)).toFixed(2) : 0 : 0;
                const planData = gd.data.plan.find(i => i.modelName === m);
                const planAvgTime = planData !== undefined ? planData?.count !== 0 && planData?.value !== 0 ? ((planData.value / planData.count)).toFixed(2) : 0 : 0;
                const backColorForAvgBox = getColorForAverageBox(actAvgTime, planAvgTime);
                const backColorForCountBox = getColorForCountBox(actualData !== undefined ? actualData.count : 0, planData !== undefined ? planData.count : 0);
                return (
                  <Grid key={l} item xs={2} sm={2} md={2} lg={2} style={{ textAlign: 'center', fontFamily: fontFamily }} onClick={() => handleLineClick({ "lineName": gd.linename, "lineId": gd.line })}>
                    <Grid container spacing={1} justifyContent="center">
                      <Grid item xs={6} sm={6} md={6} lg={6} style={{ backgroundColor: backColorForCountBox, textAlign: 'center', fontFamily: fontFamily, paddingLeft: 0, paddingTop: '0.8rem' }} className="custom-grid-border custom-grid-row">
                        <div style={{ margin: 'auto', fontFamily: fontFamily }}>{actualData !== undefined ? actualData.count : 0}</div>
                      </Grid>
                      <Grid item xs={6} sm={6} md={6} lg={6} style={{ backgroundColor: backColorForAvgBox, textAlign: 'center', fontFamily: fontFamily, paddingLeft: 0, paddingTop: '0.8rem' }} className="custom-grid-border custom-grid-row">
                        <div style={{ margin: 'auto', fontFamily: fontFamily }}>{actAvgTime}</div>
                      </Grid>
                    </Grid>
                  </Grid>
                );
              })}
            </Grid>
          </div>
        );
      })}
    </Box>
  );
};

export default CustomTable;
