import * as React from "react";
import { styled } from "@mui/material/styles";
import Button from "@mui/material/Button";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";

const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
});

export default function FileUpload({ uploadFile, isUploading }) {
    return (
        <Button
            component="label"
            role={undefined}
            variant="contained"
            tabIndex={-1}
            startIcon={<CloudUploadIcon />}
            disabled={isUploading} // Disable button during upload
        >
            {isUploading ? "Uploading..." : "Upload files"}
            <VisuallyHiddenInput
                type="file"
                accept=".xls, .xlsx, .csv"
                onChange={(event) => {
                    uploadFile(event.target.files[0]);
                    event.target.value = ""; // Reset input
                }}
                multiple
            />
        </Button>
    );
}