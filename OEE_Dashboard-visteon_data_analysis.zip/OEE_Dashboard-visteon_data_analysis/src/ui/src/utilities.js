export default class UtilityMethods {

    /**
     * This method filters Line_Shift_Plans using a given plan id and returns shift id of the first element of the filtered Line_Shift_Plans array
     * @param {string} planId Id of the plan
     * @param {object[]} lineShiftPlans Line_Shift_Plans array
     * @returns Shift Id of the first element of the filtered Line_Shift_Plans array
     */
    static getFilteredShiftId = (planId, lineShiftPlans) => {
      return lineShiftPlans.filter(item => item.Plan_Id === planId)[0].Shift_Id;
    }
  
    /**
     * This method filters Line_Shift_Times using a given shift id and returns line id of the first element of the filtered Line_Shift_Times array
     * @param {string} shiftId Id of the shift
     * @param {object[]} lineShiftTimes Line_Shift_Times array
     * @returns Line Id of the first element of the filtered Line_Shift_Times array
     */
    static getFilteredLineId = (shiftId, lineShiftTimes) => {
      return lineShiftTimes.filter(item => item.id === shiftId)[0].Line;
    }
  
    static getFilteredLineIdShiftIdPairs = (lineIds, lineShiftTimes) => {
      let lineIdShiftIdPairs = []
      let filteredLineShiftTimes = lineShiftTimes.filter(item => lineIds.includes(item["Line"]));
      let setOfLineIds = [...new Set(filteredLineShiftTimes.map(obj => obj["Line"]))]
      setOfLineIds.forEach(item => {
        let shifts = filteredLineShiftTimes.filter(ls => ls["Line"] === item).map(p => p["id"]);
        lineIdShiftIdPairs.push({ "Line": item, "Shifts": shifts })
      });
      return lineIdShiftIdPairs;
    }
  
    /**
     * This method filters Machines_In_Pipeline using a given line id and returns an array of the names of Machine_Types
     * @param {string} shiftId Id of the line
     * @param {object[]} machinesInPipeLine Machines_In_Pipeline array
     * @returns an array of the names of Machine_Types
     */
    static getFilteredMachineNamesInPipeLine = (shiftId, machinesInPipeLine) => {
      return machinesInPipeLine.filter(item => item.Line === shiftId).map(item => item.Machine_Type);
    }
  
    static getFilteredDowntimeInstances = (machineIds, downtimeInstances) => {
      return downtimeInstances.filter(item => machineIds.includes(item["Machines_In_Pipeline_Id"])).map(item => item["Downtime_Reason_Id"]);
    }
  
    static getFilteredDowntimeClassNames = (downtimeReasonIds, downtimeReasons) => {
      return downtimeReasons.filter(item => downtimeReasonIds.includes(item["Reason_Id"])).map(item => item["Class"]);
    }
  
    /**
     * This method filters Machine_Types using an array of names of Machine_Types and returns an array of Machine_Types
     * @param {string[]} machineTypeNames Array of the names of Machine_Types
     * @param {object[]} machineTypes Machine_Types array
     * @returns an array of Machine_Types
     */
    static getFilteredMachineTypes = (machineTypeNames, machineTypes) => {
      return machineTypes.filter(item => machineTypeNames.includes(item.Name));
    }
  
    /**
     * This method returns maximum value of the Manufacturers_Cycle_Time from an given array of Machine_Types
     * @param {object[]} machineTypes Machine_Types array
     * @returns maximum value of the Manufacturers_Cycle_Time
     */
    static getIdealCycleTime = (machineTypes) => {
      return Math.max(...machineTypes.map(x => x.Manufacturers_Cycle_Time));
    }
  
  
    /**
     * This method filters Production_Summary using a line id and returns an array of Production_Summary
     * @param {string[]} shiftId shift ids
     * @param {object[]} productionSummaries Production_Summary array
     * @returns an array of Production_Summary
     */
    static getFilteredProductionSummaries = (shiftIds, productionSummaries) => {
      return productionSummaries.filter(item => shiftIds.includes(item.Shift_Id));
    }
  
    static getSumOfStopTimes = (data, field) => {
      let sum = 0;
      data.forEach(item => sum += item[field]);
      return sum;
    }
  
  
    /**
     * This method returns good count if isGoodCount is true. Otherwise it returns total count
     * @param {object[]} productionSummaries Production_Summary array
     * @param {boolean} isGoodCount Flag to indicate whether to determine total count or good count
     * @returns total count or good count
     */
    static getTotalCountOrGoodCount = (productionSummaries, isGoodCount) => {
      let runStatusArray = [];
      productionSummaries.forEach(ps => {
        let data = ps["Data"];
        if (data !== undefined && data.length > 0) {
          data.forEach(item => {
            let productions = item["Productions"];
            if (productions !== undefined && productions.length > 0) {
              productions.forEach(prod => {
                let runs = prod["Runs"];
                if (runs !== undefined && runs.length > 0) {
                  runs.forEach(x => runStatusArray.push(x["Status"]))
                }
              })
            }
          })
        }
      })
      return isGoodCount ? runStatusArray.filter(item => item === "OK").length : runStatusArray.length;
    }
  
    /**
     * This method filters Line_Shift_Times using a shift id and returns first entry of the filtered Line_Shift_Times
     * @param {}string shiftId Shift Id
     * @param {*} lineShiftTimes Line_Shift_Times array
     * @returns first entry of the filtered Line_Shift_Times
     */
    static getFilteredLineShiftTime = (shiftId, lineShiftTimes) => {
      return lineShiftTimes.filter(item => item["id"] === shiftId)[0];
    }
  
    /**
     * This method returns planned production time
     * @param {object} lineShiftTime Details of a shift
     * @param {number} shutdownDuration Duration of a shutdown 
     * @returns planned production time
     */
    static getPlannedProductionTime = (lineShiftTime, shutdownDuration = 0) => {
      return this.getTimeInSeconds(lineShiftTime["Start"], lineShiftTime["End"]) - shutdownDuration; // 8 hrs
    }
  
    /**
     * This method filters Machines_In_Pipeline using a given line id and returns an array of the ids of Machine_Types
     * @param {string} shiftId Id of the line
     * @param {object[]} machinesInPipeLine Machines_In_Pipeline array
     * @returns an array of the ids of Machine_Types
     */
    static getFilteredMachineIdsInPipeLine = (lineIds, machinesInPipeLine) => {
      return machinesInPipeLine.filter(item => lineIds.includes(item["Line"])).map(item => item.Id);
    }
  
    /**
     * This method returns sum of all changeover instances time
     * @param {object[]} productionSummaries Production_Summary array
     * @returns sum of all changeover instances time
     */
    static getTotalChangeoverTime = (productionSummaries) => {
      let totalChangeoverTime = 0;
      productionSummaries.forEach(ps => {
        if (ps !== undefined) {
          let data = ps["Data"];
          if (data !== undefined && data.length > 0)
            data.forEach(item => {
              if (item["Changeover_Time_Start"] !== undefined && item["Changeover_Time_end  "] !== undefined)
                totalChangeoverTime += this.getTimeInSeconds(item["Changeover_Time_Start"], item["Changeover_Time_end  "])
            });
        }
      })
      return totalChangeoverTime;
    }
  
    static getTotalDowntimeCount = (productionSummaries) => {
      let totalDowntimeCount = 0;
      productionSummaries.forEach(ps => {
        let data = ps["Data"];
        if (data !== undefined && data.length > 0) {
          data.forEach(item => totalDowntimeCount += (item["Changeover_Time_Start"] !== null || item["Changeover_Time_Start"] !== undefined || item["Changeover_Time_Start"] !== "") && (item["Changeover_Time_end "] !== null || item["Changeover_Time_end "] !== undefined || item["Changeover_Time_end "] !== "") ? 1 : 0);
        }
      })
      return totalDowntimeCount;
    }
  
    /**
     * This method returns sum of other downtime instances except changeover for a particular shift
     * @param {string[]} machineIdsInPipeline Array of the ids of Machine_Types
     * @param {*} downtimeInstances Downtime_Instances array
     * @returns sum of other downtime instances except changeover for a particular shift
     */
    static getSumOfOtherDowntimeInstances = (machineIdsInPipeline, downtimeInstances) => {
      let filteredDowntimeInstances = downtimeInstances.filter(item => item.Downtime_Reason_Id !== 'DTR_0001' && machineIdsInPipeline.includes(item.Machines_In_Pipeline_Id));
      let sum = 0;
      filteredDowntimeInstances.forEach(item => sum += this.getTimeInSeconds(item.From_Time, item.To_Time));
      return sum;
    }
  
    /**
     * This method returns sum of all microstop instances time
     * @param {object[]} productionSummaries Production_Summary Array
     * @returns sum of all microstop instances time
     */
    static getTotalMicrostopInstancesTime = (productionSummaries) => {
      var totalMicostopInstancesTime = 0;
      productionSummaries.forEach(ps => {
        let data = ps["Data"];
        if (data !== undefined && data.length > 0) {
          data.forEach(item => {
            let productions = item["Productions"];
            if (productions !== undefined && productions.length > 0) {
              productions.forEach(prod => {
                let runs = prod["Runs"];
                if (runs !== undefined && runs.length > 0) {
                  runs.forEach(run => {
                    let microstopInstances = run["Microstop_Instances"];
                    if (microstopInstances !== undefined && microstopInstances.length > 0) {
                      microstopInstances.forEach(mi => {
                        if (mi["Start"] !== undefined && mi["End"] !== undefined)
                          totalMicostopInstancesTime += this.getTimeInSeconds(mi["Start"], mi["End"]);
                      })
                    }
                  })
                }
              })
            }
          })
        }
      })
  
      return totalMicostopInstancesTime;
    }
  
    /**
     * This method returns difference between two times in seconds
     * @param {string} fromTime From time
     * @param {string} toTime To time
     * @returns difference between two times in seconds
     */
    static getTimeInSeconds = (fromTime, toTime) => {
      return (new Date(this.getTimeStamp(toTime)) - new Date(this.getTimeStamp(fromTime))) / 1000;
    }
  
    static getTimeStamp = (dateString) => {
      if (dateString.indexOf(':') === -1) {
        let firstPart = dateString.substring(0, dateString.indexOf('T') + 1);
        let secondPart = dateString.substring(dateString.indexOf('T') + 1);
        let modifiedSecondPart = secondPart.match(/.{1,2}/g).join(":");
        return firstPart + modifiedSecondPart;
      }
      else
        return dateString;
    }
  
    /**
     * This method returns sum of all non production times
     * @param {number[]} nonProductionTimes Array of non production times
     * @returns sum of all non production times 
     */
    static getTotalNonProductionTime = (nonProductionTimes) => {
      let sum = 0;
      nonProductionTimes.forEach(item => sum += item);
      return sum;
    }
  
    /**
     * This method returns rum time by subtracting non production time from planned production time
     * @param {number} plannedProductionTime Planned production time
     * @param {number} nonProductionTime Non production time
     * @returns Run time
     */
    static getRunTime = (plannedProductionTime, nonProductionTime) => {
      return plannedProductionTime - nonProductionTime;
    }
  
    /**
     * This method returns availability as quotient of run time and planned production time
     * @param {number} runTime Run time
     * @param {number} plannedProductionTime Planned production time
     * @returns Availability
     */
    static getAvailability = (runTime, plannedProductionTime) => {
      return (runTime / plannedProductionTime);
    }
  
    /**
     * This method returns performance dividing the product of ideal cycle time, total count by run time
     * @param {number} idealCycleTime Ideal cycle time
     * @param {number} totalCount Total count
     * @param {number} runTime Run time
     * @returns Performance
     */
    static getPerformance = (idealCycleTime, totalCount, runTime) => {
      return (idealCycleTime * totalCount) / runTime;
    }
  
    /**
     * This method returns quality as quotient of good count and total count
     * @param {number} goodCount Good count
     * @param {number} totalCount Total count
     * @returns Quality
     */
    static getQuality = (goodCount, totalCount) => {
      return goodCount / totalCount;
    }
  
    /**
     * This method returns OEE as a product of availability, performance and quality
     * @param {number} availability Availability
     * @param {number} performance Performance
     * @param {number} quality Quality
     * @returns OEE
     */
    static getOee = (availability, performance, quality) => {
      return availability * performance * quality;
    }
  
    /**
     * This method returns adjusted adherence percentage
     * @param {number} target Target count
     * @param {number} actual Actual count
     * @returns Adjusted Adherence Percentage
     */
    static getAdjustedAdherence = (target, actual) => {
      return target > actual ? actual / target * 100 : (2 - actual / target) * 100;
    }
  
    static getFilteredLineShiftPlan = (planId, lineShiftPlans) => {
      return lineShiftPlans.filter(item => item.Plan_Id === planId)[0];
    }
  
    static getFilteredLineShiftPlans = (shiftIds, lineShiftPlans) => {
      return lineShiftPlans.filter(item => shiftIds.includes(item["Shift_Id"]));
    }
  
    static getActualVsPlanDataByModelForShifts = (lineShiftPlans, productionSummaries) => {
      let retVal = [];
      productionSummaries.forEach(ps => {
        let data = ps["Data"];
        if (data !== undefined && data.length > 0) {
          data.forEach(item => {
            let filteredLineShiftPlan = this.getFilteredLineShiftPlan(item["Line_Shift_Plan_Id"], lineShiftPlans);
            let productions = item["Productions"];
            let actualProduced = 0;
            if (productions !== undefined && productions.length > 0) {
              productions.forEach(prod => {
                let runs = prod["Runs"];
                if (runs !== undefined && runs.length > 0)
                  runs.forEach(run => actualProduced += run["Status"] === "OK" ? 1 : 0)
              })
              retVal.push({ "model": filteredLineShiftPlan["Model_Name"], "plan": filteredLineShiftPlan["To_Produce"], "actual": actualProduced });
            }
          })
        }
      })
      return retVal;
    }
  
    static getActualVsPlanDataByLine = (lineIdShiftIdPair, productionSummaries, lineShiftPlans) => {
      let actualProduced = 0;
      let filteredLineShiftPlans = this.getFilteredLineShiftPlans(lineIdShiftIdPair["Shifts"], lineShiftPlans);
      let plan = 0;
      filteredLineShiftPlans.forEach(item => plan += item[["To_Produce"]]);
  
      productionSummaries.forEach(ps => {
        let data = ps["Data"];
        if (data !== undefined && data.length > 0) {
          data.forEach(item => {
            let productions = item["Productions"];
            if (productions !== undefined && productions.length > 0) {
              productions.forEach(prod => {
                let runs = prod["Runs"];
                if (runs !== undefined && runs.length > 0)
                  runs.forEach(run => actualProduced += run["Status"] === "OK" ? 1 : 0)
              })
                ;
            }
          })
        }
      })
      return { "line": lineIdShiftIdPair["Line"], "plan": plan, "actual": actualProduced };
    }

    static createTimeQuantumRange = (rangeIndicator, year = 2024, date = 17, month = 7) => {
      let dayInMs = 86400000;
      let dayInMsToBeSubtracted = rangeIndicator === "day" ? dayInMs : rangeIndicator === "week" ? 7 * dayInMs : rangeIndicator === "month" ? 28 * dayInMs : 365 * dayInMs;
      let todayStartingFromSixAm = new Date(year, month, date, 11, 30, 0);
      let endDate = new Date(todayStartingFromSixAm.getTime());
      let startDate = new Date(endDate.getTime() - dayInMsToBeSubtracted);
      return { "start": startDate, "end": endDate };
    }

    static createTimeQuantumRangeForTrend = (rangeIndicator, year = 2024, date = 16, month = 7) => {
      let dayInMs = 86400000;
      let dayInMsToBeSubtracted = rangeIndicator === "day" ? 7 * dayInMs : rangeIndicator === "week" ? 56 * dayInMs : rangeIndicator === "month" ? 360 * dayInMs : 1825 * dayInMs;
      let todayStartingFromSixAm = new Date(year, month, date, 11, 30, 0);
      let endDate = new Date(todayStartingFromSixAm.getTime());
      let startDate = new Date(endDate.getTime() - dayInMsToBeSubtracted + dayInMs);
      return { "start": startDate, "end": endDate };
    }
  
  
  }