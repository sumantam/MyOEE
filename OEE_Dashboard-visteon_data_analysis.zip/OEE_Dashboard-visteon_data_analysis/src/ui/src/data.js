import { randomArrayItem, randomCreatedDate, randomId, randomRating, randomStatusOptions, randomTaxCode, randomTraderName } from "@mui/x-data-grid-generator";
import * as am5 from "@amcharts/amcharts5";

export const microstopParetoData = [
    {
        equipment: "Pick & Place 3",
        stopTimes: [
            {
                range: 'CW14',
                time: 20
            },
            {
                range: 'CW15',
                time: 3
            },
            {
                range: 'CW16',
                time: 25
            },
            {
                range: 'CW17',
                time: 30
            },
            {
                range: 'CW18',
                time: 25
            },
            {
                range: 'CW19',
                time: 10
            },
            {
                range: 'CW20',
                time: 5
            },
            {
                range: 'CW21',
                time: 25
            },
            {
                range: 'CW22',
                time: 30
            },
            {
                range: 'CW23',
                time: 35
            },
            {
                range: 'CW24',
                time: 40
            },
            {
                range: 'CW25',
                time: 50
            }
        ]
    },
    {
        equipment: "Pick & Place 1",
        stopTimes: [
            {
                range: 'CW14',
                time: 0
            },
            {
                range: 'CW15',
                time: 0
            },
            {
                range: 'CW16',
                time: 15
            },
            {
                range: 'CW17',
                time: 20
            },
            {
                range: 'CW18',
                time: 5
            },
            {
                range: 'CW19',
                time: 10
            },
            {
                range: 'CW20',
                time: 25
            },
            {
                range: 'CW21',
                time: 30
            },
            {
                range: 'CW22',
                time: 50
            },
            {
                range: 'CW23',
                time: 0
            },
            {
                range: 'CW24',
                time: 40
            },
            {
                range: 'CW25',
                time: 30
            }
        ]
    },
    {
        equipment: "AOI",
        stopTimes: [
            {
                range: 'CW14',
                time: 0
            },
            {
                range: 'CW15',
                time: 0
            },
            {
                range: 'CW16',
                time: 5
            },
            {
                range: 'CW17',
                time: 15
            },
            {
                range: 'CW18',
                time: 20
            },
            {
                range: 'CW19',
                time: 0
            },
            {
                range: 'CW20',
                time: 8
            },
            {
                range: 'CW21',
                time: 7
            },
            {
                range: 'CW22',
                time: 5
            },
            {
                range: 'CW23',
                time: 0
            },
            {
                range: 'CW24',
                time: 3
            },
            {
                range: 'CW25',
                time: 10
            }
        ]
    },
    {
        equipment: "SPI",
        stopTimes: [
            {
                range: 'CW14',
                time: 0
            },
            {
                range: 'CW15',
                time: 0
            },
            {
                range: 'CW16',
                time: 10
            },
            {
                range: 'CW17',
                time: 12
            },
            {
                range: 'CW18',
                time: 10
            },
            {
                range: 'CW19',
                time: 0
            },
            {
                range: 'CW20',
                time: 0
            },
            {
                range: 'CW21',
                time: 2
            },
            {
                range: 'CW22',
                time: 11
            },
            {
                range: 'CW23',
                time: 18
            },
            {
                range: 'CW24',
                time: 10
            },
            {
                range: 'CW25',
                time: 7
            }
        ]
    },
    {
        equipment: "Printer",
        stopTimes: [
            {
                range: 'CW14',
                time: 0
            },
            {
                range: 'CW15',
                time: 0
            },
            {
                range: 'CW16',
                time: 5
            },
            {
                range: 'CW17',
                time: 2
            },
            {
                range: 'CW18',
                time: 4
            },
            {
                range: 'CW19',
                time: 3
            },
            {
                range: 'CW20',
                time: 0
            },
            {
                range: 'CW21',
                time: 10
            },
            {
                range: 'CW22',
                time: 8
            },
            {
                range: 'CW23',
                time: 7
            },
            {
                range: 'CW24',
                time: 0
            },
            {
                range: 'CW25',
                time: 3
            }
        ]
    },
    {
        equipment: "Others",
        stopTimes: [
            {
                range: 'CW14',
                time: 15
            },
            {
                range: 'CW15',
                time: 20
            },
            {
                range: 'CW16',
                time: 13
            },
            {
                range: 'CW17',
                time: 30
            },
            {
                range: 'CW18',
                time: 25
            },
            {
                range: 'CW19',
                time: 0
            },
            {
                range: 'CW20',
                time: 5
            },
            {
                range: 'CW21',
                time: 25
            },
            {
                range: 'CW22',
                time: 135
            },
            {
                range: 'CW23',
                time: 20
            },
            {
                range: 'CW24',
                time: 15
            },
            {
                range: 'CW25',
                time: 30
            }
        ]
    }
];


export const microstopActions = [
    {
        id: randomId(),
        machine: "Pick & Place 3",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'CW16',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Pick & Place 3",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'CW22',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Pick & Place 1",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'CW19',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "AOI",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'CW16',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "AOI",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'CW18',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "SPI",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'CW22',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Printer",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'CW23',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Others",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'CW15',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    }
];

export const breakdownData = [
    {
        equipment: "Pick & Place 4",
        stopTimes: [
            {
                range: 'Jan',
                time: 5
            },
            {
                range: 'Feb',
                time: 2
            },
            {
                range: 'Mar',
                time: 7
            },
            {
                range: 'Apr',
                time: 11
            },
            {
                range: 'May',
                time: 5
            },
            {
                range: 'Jun',
                time: 8
            },
            {
                range: 'Jul',
                time: 3
            },
            {
                range: 'Aug',
                time: 9
            }
        ]
    },
    {
        equipment: "Pick & Place 2",
        stopTimes: [
            {
                range: 'Jan',
                time: 5
            },
            {
                range: 'Feb',
                time: 2
            },
            {
                range: 'Mar',
                time: 7
            },
            {
                range: 'Apr',
                time: 4
            },
            {
                range: 'May',
                time: 2
            },
            {
                range: 'Jun',
                time: 5
            },
            {
                range: 'Jul',
                time: 3
            },
            {
                range: 'Aug',
                time: 2
            }
        ]
    },
    {
        equipment: "Printer",
        stopTimes: [
            {
                range: 'Jan',
                time: 0
            },
            {
                range: 'Feb',
                time: 2
            },
            {
                range: 'Mar',
                time: 7
            },
            {
                range: 'Apr',
                time: 3
            },
            {
                range: 'May',
                time: 2
            },
            {
                range: 'Jun',
                time: 1
            },
            {
                range: 'Jul',
                time: 3
            },
            {
                range: 'Aug',
                time: 2
            }
        ]
    },
    {
        equipment: "Oven",
        stopTimes: [
            {
                range: 'Jan',
                time: 0
            },
            {
                range: 'Feb',
                time: 2
            },
            {
                range: 'Mar',
                time: 0
            },
            {
                range: 'Apr',
                time: 2
            },
            {
                range: 'May',
                time: 1
            },
            {
                range: 'Jun',
                time: 2
            },
            {
                range: 'Jul',
                time: 0
            },
            {
                range: 'Aug',
                time: 3
            }
        ]
    },
    {
        equipment: "SPI",
        stopTimes: [
            {
                range: 'Jan',
                time: 0
            },
            {
                range: 'Feb',
                time: 1
            },
            {
                range: 'Mar',
                time: 0
            },
            {
                range: 'Apr',
                time: 2
            },
            {
                range: 'May',
                time: 1
            },
            {
                range: 'Jun',
                time: 2
            },
            {
                range: 'Jul',
                time: 0
            },
            {
                range: 'Aug',
                time: 1
            }
        ]
    },
    {
        equipment: "Others",
        stopTimes: [
            {
                range: 'Jan',
                time: 3
            },
            {
                range: 'Feb',
                time: 1
            },
            {
                range: 'Mar',
                time: 5
            },
            {
                range: 'Apr',
                time: 6
            },
            {
                range: 'May',
                time: 1
            },
            {
                range: 'Jun',
                time: 2
            },
            {
                range: 'Jul',
                time: 1
            },
            {
                range: 'Aug',
                time: 1
            }
        ]
    },
];

export const breakdownActions = [
    {
        id: randomId(),
        machine: "Pick & Place 4",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'Jan',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Pick & Place 2",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'Mar',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Pick & Place 2",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'May',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Oven",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'Apr',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "SPI",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'Feb',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "SPI",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'Aug',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Others",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'May',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    },
    {
        id: randomId(),
        machine: "Others",
        issue: randomTraderName(),
        rootCause: 23,
        issueDate: 'Jul',
        resp: randomArrayItem(['Executive', 'Supervisor', 'Operator']),
        action: randomTaxCode()
    }
];

export const oeeTrend = [
    {
        "title": "Quality",
        "values": [
            {
                "range": "CW1",
                "value": 97
            },
            {
                "range": "CW2",
                "value": 98
            },
            {
                "range": "CW3",
                "value": 99
            },
            {
                "range": "CW4",
                "value": 98
            },
            {
                "range": "CW5",
                "value": 97
            },
            {
                "range": "CW6",
                "value": 98
            }
        ]
    },
    {
        "title": "Availibility",
        "values": [
            {
                "range": "CW1",
                "value": 96
            },
            {
                "range": "CW2",
                "value": 90
            },
            {
                "range": "CW3",
                "value": 97
            },
            {
                "range": "CW4",
                "value": 93
            },
            {
                "range": "CW5",
                "value": 94
            },
            {
                "range": "CW6",
                "value": 95
            }
        ]
    },
    {
        "title": "Performance",
        "values": [
            {
                "range": "CW1",
                "value": 85
            },
            {
                "range": "CW2",
                "value": 88
            },
            {
                "range": "CW3",
                "value": 83
            },
            {
                "range": "CW4",
                "value": 79
            },
            {
                "range": "CW5",
                "value": 77
            },
            {
                "range": "CW6",
                "value": 80
            }
        ]
    },
    {
        "title": "OEE",
        "values": [
            {
                "range": "CW1",
                "value": 79.15
            },
            {
                "range": "CW2",
                "value": 77.62
            },
            {
                "range": "CW3",
                "value": 79.70
            },
            {
                "range": "CW4",
                "value": 72.00
            },
            {
                "range": "CW5",
                "value": 70.20
            },
            {
                "range": "CW6",
                "value": 74.48
            }
        ]
    }
]

export const productionByLine = [
    {
        "line": "Line1",
        "plan": 300,
        "actual": 290
    },
    {
        "line": "Line2",
        "plan": 250,
        "actual": 245
    },
    {
        "line": "Line3",
        "plan": 180,
        "actual": 170
    },
    {
        "line": "Line4",
        "plan": 150,
        "actual": 140
    },
    {
        "line": "Line5",
        "plan": 140,
        "actual": 130
    },
    {
        "line": "Line6",
        "plan": 300,
        "actual": 290
    },
    {
        "line": "Line7",
        "plan": 250,
        "actual": 130
    },
    {
        "line": "Line8",
        "plan": 180,
        "actual": 170
    },
    {
        "line": "Line9",
        "plan": 150,
        "actual": 140
    },
    {
        "line": "Line10",
        "plan": 140,
        "actual": 130
    },
    {
        "line": "Line11",
        "plan": 300,
        "actual": 290
    },
    {
        "line": "Line12",
        "plan": 250,
        "actual": 130
    },
    {
        "line": "Line13",
        "plan": 180,
        "actual": 170
    },
    {
        "line": "Line14",
        "plan": 150,
        "actual": 140
    },
    {
        "line": "Line15",
        "plan": 140,
        "actual": 130
    }
]

export const productionByModel = [
    {
        "model": "Model1",
        "plan": 300,
        "actual": 290
    },
    {
        "model": "Model2",
        "plan": 250,
        "actual": 130
    },
    {
        "model": "Model3",
        "plan": 180,
        "actual": 170
    },
    {
        "model": "Model4",
        "plan": 150,
        "actual": 140
    },
    {
        "model": "Model5",
        "plan": 140,
        "actual": 130
    }
]

export const downTimeParetoByProductionLine = [
    {
        "line": "Line1",
        "stopTime": 80,
        "percentage": 30
    },
    {
        "line": "Line2",
        "stopTime": 60,
        "percentage": 53
    },
    {
        "line": "Line3",
        "stopTime": 40,
        "percentage": 68
    },
    {
        "line": "Line4",
        "stopTime": 25,
        "percentage": 77
    },
    {
        "line": "Line5",
        "stopTime": 10,
        "percentage": 81
    },
    {
        "line": "Others",
        "stopTime": 50,
        "percentage": 100
    }
]

export const downTimeParetoByCause = [
    {
        "line": "Changeover",
        "stopTime": 200,
        "percentage": 50
    },
    {
        "line": "Microstops",
        "stopTime": 80,
        "percentage": 70
    },
    {
        "line": "Breakdowns",
        "stopTime": 40,
        "percentage": 80
    },
    {
        "line": "Material Shortage",
        "stopTime": 28,
        "percentage": 87
    },
    {
        "line": "Quality Issue",
        "stopTime": 12,
        "percentage": 90
    },
    {
        "line": "Others",
        "stopTime": 40,
        "percentage": 100
    }
]


export const default_QoS = [{
    "available": 0.95,
    "performance": 0.8,
    "quality": 0.98,
    "oee": 0.745,
    "bts": 0.85,
    "ftt": 0.97,
    "scrap": 3
}]

export const colors = ['rgb(6, 55, 115)', 'rgb(46, 129, 229)', 'rgb(92, 196, 229)', 'rgb(164, 131, 221)', 'rgb(177, 89, 89)', 'rgb(237, 129, 78)'];
export const colors2 = ['#2B65BE', '#2b8cbe', '#4eb3d3', '#7bccc4', '#a8ddb5', '#ccebc5', '#E71036', '#14E2A1', '#2C2F30'];
export const redGradientColor = [am5.color(0xfd0000), am5.color(0xff9500)];
export const yellowGradientColor = [am5.color(0xfdcb00), am5.color(0xe4ff00)];
export const greenGradientColor = [am5.color(0xabfd00), am5.color(0x00ff3b)];
